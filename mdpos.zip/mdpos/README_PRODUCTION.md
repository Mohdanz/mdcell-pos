# Panduan Produksi MD POS & Pembukuan (Production-Ready Guide)

Repositori ini telah dikonfigurasi untuk kesiapan lingkungan produksi skala enterprise. Arsitektur ini memisahkan frontend, backend, mengintegrasikan PostgreSQL, mendukung JWT Authentication, Docker Compose, PM2, dan Nginx Reverse Proxy dengan optimalisasi performa tinggi serta keamanan berlapis.

---

## 🏗️ Ringkasan Arsitektur Produksi

```
                             [ Pengguna / Browser ]
                                        │
                                        ▼ (Port 80 / 443 SSL)
                             [ Nginx Reverse Proxy ]
                                        │
                        ┌───────────────┴───────────────┐ (Load Balancing)
                        ▼ (Port 3000)                   ▼ (Port 3000)
              [ PM2 Cluster Node 1 ]          [ PM2 Cluster Node 2 ]
                        │                               │
                        └───────────────┬───────────────┘
                                        ▼ (Port 5432)
                            [ PostgreSQL Database ]
                                        │
                                        ▼ (Backup Bulanan/Harian)
                            [ Otomatis Backup Script ]
```

---

## 📁 Struktur Kode Modular & Produksi

Arsitektur produksi ditata dengan sangat modular agar mudah dipelihara dan dikembangkan oleh tim developer Anda:

```
├── /dist/                  # Build artifact siap saji untuk produksi
├── /src/
│   ├── /components/        # Komponen UI modular (AccountingView, POS, dll)
│   ├── /data/              # Fallback file-based database saat inisiasi
│   ├── /db/                # Drizzle ORM schemas dan konfigurasi koneksi SQL
│   ├── App.tsx             # Pengendali routing UI utama
│   └── main.tsx            # Entrypoint utama Client React SPA
├── /scripts/
│   ├── init.sql            # Skema inisialisasi awal database PostgreSQL
│   └── backup.sh           # Script otomatisasi backup harian & rotasi 7 hari
├── server.ts               # Express backend dengan Vite integration middleware
├── Dockerfile              # Docker multi-stage build berkinerja tinggi
├── docker-compose.yml      # Orchestration lengkap App, DB, dan Nginx Proxy
├── nginx.conf              # Konfigurasi reverse proxy, GZIP, rate limit & SSL
├── ecosystem.config.cjs    # Konfigurasi manajemen proses PM2 (Cluster Mode)
└── .env.example            # Template variabel lingkungan rahasia produksi
```

---

## 🚀 Panduan Instalasi & Deployment Cepat

Ikuti langkah-langkah di bawah ini untuk men-deploy aplikasi secara utuh di server produksi Anda:

### 1. Prasyarat Sistem
Pastikan server Anda sudah terinstal:
- **Docker** (v20+) dan **Docker Compose** (v2.0+)
- **Git** (untuk clone repositori)

### 2. Konfigurasi Variabel Lingkungan (`.env`)
Salin file `.env.example` ke `.env` di server produksi Anda dan lengkapi nilainya:
```bash
cp .env.example .env
```
Isi konfigurasi database produksi, port, kunci rahasia JWT, serta alamat URL domain Anda:
```env
PORT=3000
NODE_ENV=production
DATABASE_URL=postgres://md_user:md_password_secure@db:5432/md_pos_db
JWT_SECRET=gunakan_kunci_sangat_rahasia_dan_panjang_anda_disini
APP_URL=https://pos.perusahaananda.com
```

### 3. Jalankan Menggunakan Docker Compose
Hanya dengan satu perintah, seluruh ekosistem (Aplikasi Express+Vite, PostgreSQL Database, dan Nginx Proxy) akan terunduh, dikompilasi, dikonfigurasi, dan berjalan secara otomatis:
```bash
docker-compose up -d --build
```

Verifikasi status kontainer untuk memastikan semuanya berjalan dengan status sehat:
```bash
docker-compose ps
```

---

## 🔒 Fitur Unggulan Sistem Produksi

### 🛡️ 1. Nginx Reverse Proxy & Keamanan Berlapis
File `nginx.conf` yang disertakan telah dioptimalkan secara mendalam dengan standar keamanan industri:
- **Rate Limiting**: Melindungi API dari serangan Brute-Force dan DDoS (dibatasi 10 request/detik per IP dengan burst maksimal 20).
- **Security Headers**: Dilengkapi dengan `X-Frame-Options: SAMEORIGIN`, `X-Content-Type-Options: nosniff`, `X-XSS-Protection`, dan kebijakan CSP yang ketat.
- **Gzip Compression**: Mempercepat load file JavaScript, CSS, dan JSON hingga 70% sebelum dikirim ke browser pengguna.
- **Asset Caching**: File gambar, stylesheet, dan script diletakkan di cache browser pengguna selama 30 hari untuk mempercepat pemuatan halaman berulang.

### ⚡ 2. PM2 Cluster Mode (Tahan Down-Time)
Aplikasi dijalankan menggunakan **PM2 (Process Manager 2)** dalam mode kluster (`cluster_mode`):
- Memanfaatkan seluruh core CPU server secara seimbang (Load Balancing internal).
- Fitur **Zero-Downtime Reload**: Memperbarui kode tanpa menghentikan layanan karena proses dimatikan dan dihidupkan secara bergantian.
- **Auto-Restart on Memory Leaks**: Menghindari crash akibat kebocoran memori dengan menetapkan ambang batas maksimal restart otomatis pada penggunaan memori sebesar 1GB.

### 💾 3. Backup Otomatis & Rotasi Data (Anti-Hilang)
Script `/scripts/backup.sh` mengotomatiskan pencadangan PostgreSQL secara harian:
- Melakukan ekspor data penuh skema dan baris data database menggunakan utilitas `pg_dump`.
- **Rotasi Otomatis (Retention Policy)**: Menghapus cadangan yang sudah berumur lebih dari 7 hari secara otomatis agar menghemat ruang penyimpanan server.
- Anda dapat menjadwalkannya di server menggunakan utility `crontab` bawaan Linux:
  ```bash
  # Menjadwalkan backup harian setiap jam 2 pagi
  0 2 * * * /bin/sh /app/scripts/backup.sh >> /var/log/md_pos_backup.log 2>&1
  ```

---

## 🔑 Implementasi JWT Authentication (Backend Best Practices)

Untuk memisahkan akses Administrator Pemilik dan Kasir pada level backend, skema JWT Authentication yang aman dapat diimplementasikan pada `server.ts` sebagai berikut:

```typescript
import jwt from 'jsonwebtoken';

// Middleware Autentikasi Token
export function authenticateToken(req: any, res: any, next: any) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Akses ditolak, token diperlukan.' });
  }

  jwt.verify(token, process.env.JWT_SECRET || 'secret', (err: any, user: any) => {
    if (err) return res.status(403).json({ error: 'Token tidak valid atau kedaluwarsa.' });
    req.user = user;
    next();
  });
}

// Middleware Proteksi Khusus Admin
export function requireAdmin(req: any, res: any, next: any) {
  if (req.user && req.user.role === 'admin') {
    next();
  } else {
    res.status(403).json({ error: 'Hak akses ditolak. Khusus Administrator.' });
  }
}
```

Terapkan middleware di atas pada rute akuntansi rahasia di Express:
```typescript
app.get('/api/accounting/journal', authenticateToken, requireAdmin, (req, res) => {
  // Hanya admin yang bisa memproses jurnal akuntansi
});
```

---

## 📈 Pemantauan Log Aplikasi (Logging)

Semua log sistem produksi terekam secara rapi dalam folder `/logs/` dalam format JSON dan log teks terstruktur:
- **PM2 Out Logs (`/logs/pm2-out.log`)**: Mencatat semua proses server, inisialisasi server, dan audit transaksi yang berhasil dilakukan.
- **PM2 Error Logs (`/logs/pm2-err.log`)**: Mencatat setiap kegagalan fungsi, database timeout, atau error unhandled exceptions untuk memudahkan debugging cepat.
- Gunakan perintah berikut di dalam server untuk memantau log secara real-time:
  ```bash
  pm2 logs md-pos-production
  ```
