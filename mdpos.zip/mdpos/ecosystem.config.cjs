module.exports = {
  apps: [
    {
      name: 'md-pos-production',
      script: './dist/server.cjs',
      instances: 'max', // Utilizing all CPU cores
      exec_mode: 'cluster',
      autorestart: true,
      watch: false,
      max_memory_restart: '1G', // Auto reboot if memory exceeds 1GB due to leaks
      env: {
        NODE_ENV: 'development',
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000
      },
      error_file: './logs/pm2-err.log',
      out_file: './logs/pm2-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      kill_timeout: 3000, // Wait 3s for active connections before shutting down
    }
  ]
};
