import { db, testDbConnection } from '../src/db/index.ts';
import * as schema from '../src/db/schema.ts';
import { eq, ne } from 'drizzle-orm';

async function run() {
  console.log('🧹 Running database cleanup script...');
  
  // 1. Connect and initialize
  await testDbConnection();
  
  try {
    console.log('Deleting child tables first...');
    // Delete in correct order to avoid foreign key constraint violations
    await db.delete(schema.voucherSerials);
    await db.delete(schema.eWalletHistories);
    await db.delete(schema.transactions);
    await db.delete(schema.shifts);
    await db.delete(schema.journalLines);
    await db.delete(schema.journalEntries);
    await db.delete(schema.budgets);
    
    console.log('Deleting parent tables...');
    await db.delete(schema.products);
    await db.delete(schema.physicalCategories);
    
    // Clear ewallets except cash, or reset cash
    console.log('Resetting eWallets...');
    await db.delete(schema.eWallets).where(ne(schema.eWallets.id, 'cash'));
    await db.update(schema.eWallets)
      .set({ balance: 0 })
      .where(eq(schema.eWallets.id, 'cash'));
      
    // Clear users except admin
    console.log('Resetting users...');
    await db.delete(schema.users).where(ne(schema.users.role, 'admin'));
    
    console.log('✅ PostgreSQL database cleanup complete!');
  } catch (err) {
    console.error('❌ Error during database cleanup:', err);
  }
  
  console.log('🎉 Data cleanup process finished!');
  process.exit(0);
}

run();
