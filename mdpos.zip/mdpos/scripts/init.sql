-- PostgreSQL Initialization script for MD POS Production
-- This script prepares default schemas, sample roles, and configures tracking tables

CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'kasir',
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS system_logs (
    id SERIAL PRIMARY KEY,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    level VARCHAR(10) NOT NULL,
    message TEXT NOT NULL,
    metadata JSONB
);

-- Insert default admin if not existing (password hash for 'admin123' as demo)
INSERT INTO users (username, password_hash, role, name)
VALUES ('admin', '$2b$10$wVwepWq6yDk7mJ82/6X3OugX7PzWf3yP3BfN/Gq4W9O6UuG21GzSq', 'admin', 'Administrator Pemilik')
ON CONFLICT (username) DO NOTHING;
