import sharp from 'sharp';
import fs from 'fs';
import path from 'path';

const svgPath = path.resolve('public/logo.svg');
const svgBuffer = fs.readFileSync(svgPath);

async function generateAssets() {
  console.log('Generating PNG assets from logo.svg...');
  
  // 512x512 main logo.png
  await sharp(svgBuffer)
    .resize(512, 512)
    .png()
    .toFile(path.resolve('public/logo.png'));
  console.log('Created public/logo.png (512x512)');

  // 192x192 android
  await sharp(svgBuffer)
    .resize(192, 192)
    .png()
    .toFile(path.resolve('public/android-chrome-192x192.png'));
  console.log('Created public/android-chrome-192x192.png');

  // 512x512 android
  await sharp(svgBuffer)
    .resize(512, 512)
    .png()
    .toFile(path.resolve('public/android-chrome-512x512.png'));
  console.log('Created public/android-chrome-512x512.png');

  // 180x180 apple touch
  await sharp(svgBuffer)
    .resize(180, 180)
    .png()
    .toFile(path.resolve('public/apple-touch-icon.png'));
  console.log('Created public/apple-touch-icon.png');

  // 64x64 favicon.ico (or favicon.png)
  await sharp(svgBuffer)
    .resize(64, 64)
    .png()
    .toFile(path.resolve('public/favicon.ico'));
  console.log('Created public/favicon.ico');

  console.log('All branding logo assets successfully generated!');
}

generateAssets().catch(err => {
  console.error('Error generating logo assets:', err);
  process.exit(1);
});
