#!/bin/sh
# Shell Script to automate PostgreSQL backups securely with rotations
# Set directory paths
BACKUP_DIR="/app/backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="${BACKUP_DIR}/md_pos_db_backup_${TIMESTAMP}.sql"

# Ensure backup directory exists
mkdir -p "${BACKUP_DIR}"

echo "Starting PostgreSQL backup process..."

# Perform pg_dump inside the docker container or on local database
# Uses connection variables passed via docker environment or local environment variables
if [ -z "${DATABASE_URL}" ]; then
  # Fallback to defaults
  PGPASSWORD="md_password_secure" pg_dump -h db -U md_user -d md_pos_db -F c -b -v -f "${BACKUP_FILE}"
else
  pg_dump "${DATABASE_URL}" -F c -b -v -f "${BACKUP_FILE}"
fi

if [ $? -eq 0 ]; then
  echo "Backup successfully completed: ${BACKUP_FILE}"
  
  # Retention policy: Rotate backup and keep only the last 7 daily backups
  echo "Applying retention policy: cleaning up backups older than 7 days..."
  find "${BACKUP_DIR}" -name "md_pos_db_backup_*.sql" -mtime +7 -exec rm -f {} \;
  echo "Retention cleanup completed successfully."
else
  echo "Error: Database backup process failed." >&2
  exit 1
fi
