CREATE TABLE "voucher_serials" (
	"id" text PRIMARY KEY NOT NULL,
	"product_id" text NOT NULL,
	"barcode" text NOT NULL,
	"serial_number" text,
	"expired_date" text,
	"supplier" text,
	"purchase_price" double precision DEFAULT 0 NOT NULL,
	"purchase_date" text,
	"sold_transaction_id" text,
	"sold_at" text,
	"returned_at" text,
	"notes" text,
	"status" text DEFAULT 'READY' NOT NULL,
	"created_at" text NOT NULL,
	"updated_at" text NOT NULL
);
--> statement-breakpoint
ALTER TABLE "voucher_serials" ADD CONSTRAINT "voucher_serials_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "barcode_idx" ON "voucher_serials" USING btree ("barcode");
