DROP TABLE "customers" CASCADE;--> statement-breakpoint
DROP TABLE "super_admins" CASCADE;--> statement-breakpoint
DROP TABLE "suppliers" CASCADE;--> statement-breakpoint
DROP TABLE "tenants" CASCADE;