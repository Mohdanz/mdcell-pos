CREATE TABLE "accounts" (
	"code" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"category" text NOT NULL,
	"normal_balance" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "budgets" (
	"id" text PRIMARY KEY NOT NULL,
	"account_code" text NOT NULL,
	"account_name" text NOT NULL,
	"limit" double precision NOT NULL,
	"period" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "customers" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"phone" text NOT NULL,
	"points" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "customers_phone_unique" UNIQUE("phone")
);
--> statement-breakpoint
CREATE TABLE "ewallet_histories" (
	"id" text PRIMARY KEY NOT NULL,
	"ewallet_id" text,
	"ewallet_name" text NOT NULL,
	"amount" double precision NOT NULL,
	"type" text NOT NULL,
	"transaction_id" text,
	"description" text NOT NULL,
	"date" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "ewallets" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"provider" text NOT NULL,
	"balance" double precision DEFAULT 0 NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"logo_url" text,
	"category" text DEFAULT 'ewallet'
);
--> statement-breakpoint
CREATE TABLE "journal_entries" (
	"id" text PRIMARY KEY NOT NULL,
	"date" text NOT NULL,
	"reference" text NOT NULL,
	"description" text NOT NULL,
	"is_manual" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "journal_lines" (
	"id" serial PRIMARY KEY NOT NULL,
	"entry_id" text NOT NULL,
	"account_code" text NOT NULL,
	"account_name" text NOT NULL,
	"type" text NOT NULL,
	"amount" double precision NOT NULL
);
--> statement-breakpoint
CREATE TABLE "physical_categories" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"icon" text,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" text NOT NULL,
	"updated_at" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "products" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"category" text NOT NULL,
	"operator" text NOT NULL,
	"purchase_price" double precision NOT NULL,
	"selling_price" double precision NOT NULL,
	"stock" integer DEFAULT 0 NOT NULL,
	"min_stock_limit" integer DEFAULT 5 NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"image_url" text
);
--> statement-breakpoint
CREATE TABLE "shifts" (
	"id" text PRIMARY KEY NOT NULL,
	"cashier_id" text,
	"cashier_name" text NOT NULL,
	"start_time" text NOT NULL,
	"end_time" text,
	"initial_cash" double precision NOT NULL,
	"total_sales" double precision DEFAULT 0 NOT NULL,
	"total_transfer_sales" double precision DEFAULT 0,
	"total_withdrawals" double precision DEFAULT 0,
	"total_profit" double precision DEFAULT 0 NOT NULL,
	"total_discounts" double precision DEFAULT 0,
	"transaction_count" integer DEFAULT 0 NOT NULL,
	"status" text DEFAULT 'open' NOT NULL,
	"closed_by" text
);
--> statement-breakpoint
CREATE TABLE "suppliers" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"phone" text,
	"address" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "transactions" (
	"id" text PRIMARY KEY NOT NULL,
	"invoice_number" text NOT NULL,
	"date" text NOT NULL,
	"customer_phone" text DEFAULT '' NOT NULL,
	"total_amount" double precision NOT NULL,
	"total_profit" double precision NOT NULL,
	"cashier_id" text,
	"cashier_name" text NOT NULL,
	"ewallet_id" text,
	"ewallet_name" text NOT NULL,
	"status" text DEFAULT 'success' NOT NULL,
	"type" text DEFAULT 'topup',
	"withdrawal_type" text,
	"admin_fee" double precision DEFAULT 0,
	"items" jsonb NOT NULL,
	CONSTRAINT "transactions_invoice_number_unique" UNIQUE("invoice_number")
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" text PRIMARY KEY NOT NULL,
	"username" text NOT NULL,
	"name" text NOT NULL,
	"role" text NOT NULL,
	"email" text NOT NULL,
	"avatar_color" text NOT NULL,
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "users_username_unique" UNIQUE("username")
);
--> statement-breakpoint
ALTER TABLE "budgets" ADD CONSTRAINT "budgets_account_code_accounts_code_fk" FOREIGN KEY ("account_code") REFERENCES "public"."accounts"("code") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ewallet_histories" ADD CONSTRAINT "ewallet_histories_ewallet_id_ewallets_id_fk" FOREIGN KEY ("ewallet_id") REFERENCES "public"."ewallets"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "journal_lines" ADD CONSTRAINT "journal_lines_entry_id_journal_entries_id_fk" FOREIGN KEY ("entry_id") REFERENCES "public"."journal_entries"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "journal_lines" ADD CONSTRAINT "journal_lines_account_code_accounts_code_fk" FOREIGN KEY ("account_code") REFERENCES "public"."accounts"("code") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "shifts" ADD CONSTRAINT "shifts_cashier_id_users_id_fk" FOREIGN KEY ("cashier_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "transactions" ADD CONSTRAINT "transactions_cashier_id_users_id_fk" FOREIGN KEY ("cashier_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "transactions" ADD CONSTRAINT "transactions_ewallet_id_ewallets_id_fk" FOREIGN KEY ("ewallet_id") REFERENCES "public"."ewallets"("id") ON DELETE no action ON UPDATE no action;