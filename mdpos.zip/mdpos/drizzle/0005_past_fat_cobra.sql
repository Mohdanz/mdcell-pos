CREATE TABLE "backups" (
	"id" text PRIMARY KEY NOT NULL,
	"filename" text NOT NULL,
	"size" integer NOT NULL,
	"status" text NOT NULL,
	"type" text NOT NULL,
	"error" text,
	"created_at" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "system_logs" (
	"id" text PRIMARY KEY NOT NULL,
	"timestamp" text NOT NULL,
	"level" text NOT NULL,
	"module" text NOT NULL,
	"message" text NOT NULL,
	"stack_trace" text,
	"user_id" text,
	"username" text
);
--> statement-breakpoint
ALTER TABLE "products" ADD COLUMN "barcode_type" text DEFAULT 'none' NOT NULL;--> statement-breakpoint
ALTER TABLE "products" ADD COLUMN "barcode" text;--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN "password" text DEFAULT '123456' NOT NULL;