import React from 'react';

export type WatermarkType =
  | 'dashboard'
  | 'produk'
  | 'barcode'
  | 'scanner'
  | 'voucher'
  | 'pulsa'
  | 'ewallet'
  | 'pembukuan'
  | 'laporan'
  | 'shift'
  | 'kasir'
  | 'pengaturan'
  | 'transaksi';

interface CardWatermarkProps {
  type: WatermarkType;
  className?: string;
  position?: 'bottom-right' | 'top-right' | 'bottom-left' | 'top-left';
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export const CardWatermark: React.FC<CardWatermarkProps> = ({
  type,
  className = '',
  position = 'bottom-right',
  size = 'md',
}) => {
  const getPositionClasses = () => {
    switch (position) {
      case 'top-right':
        return 'absolute top-0 right-0';
      case 'bottom-left':
        return 'absolute bottom-0 left-0';
      case 'top-left':
        return 'absolute top-0 left-0';
      case 'bottom-right':
      default:
        return 'absolute bottom-0 right-0';
    }
  };

  const getSizeClasses = () => {
    switch (size) {
      case 'sm':
        return 'w-16 h-16';
      case 'lg':
        return 'w-28 h-28 lg:w-36 lg:h-36';
      case 'xl':
        return 'w-36 h-36 lg:w-48 lg:h-48';
      case 'md':
      default:
        return 'w-24 h-24 lg:w-28 lg:h-28';
    }
  };

  const renderSvg = () => {
    switch (type) {
      case 'dashboard':
        return (
          <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            {/* Analytics Dashboard Grid & Charts */}
            <path d="M10 90h80M20 90V60l15-10 20 20 25-35M80 35h10v10M20 90h12V75H20zM40 90h12V55H40zM60 90h12V40H60z" />
            <circle cx="20" cy="60" r="2" fill="currentColor" />
            <circle cx="35" cy="50" r="2" fill="currentColor" />
            <circle cx="55" cy="70" r="2" fill="currentColor" />
            <circle cx="80" cy="35" r="2" fill="currentColor" />
          </svg>
        );
      case 'produk':
        return (
          <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            {/* Box / Package Vector */}
            <path d="M50 15L15 32v36l35 17 35-17V32L50 15z" />
            <path d="M15 32l35 16 35-16M50 48v36" />
            <path d="M32 24l35 16M22 41.5l14 6.5M64 48l14-6.5" />
          </svg>
        );
      case 'barcode':
        return (
          <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round">
            {/* Barcode lines */}
            <path d="M10 25v50M18 25v50M26 25v50M30 25v50M40 25v50M48 25v50M54 25v50M62 25v50M68 25v50M76 25v50M82 25v50M90 25v50" strokeWidth="4" />
            <path d="M26 25v50M48 25v50M68 25v50M82 25v50" strokeWidth="7" />
            <path d="M10 82h80" strokeWidth="2" strokeDasharray="4 4" />
          </svg>
        );
      case 'scanner':
        return (
          <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            {/* QR Scanner Frame & Laser */}
            <path d="M15 30V15h15M70 15h15v15M85 70v15H70M30 85H15V70" />
            <path d="M25 25h15v15H25zM60 25h15v15H60zM25 60h15v15H25z" strokeWidth="2" />
            <path d="M31 31h3M66 31h3M31 66h3" strokeWidth="3" />
            <path d="M10 50h80" stroke="currentColor" strokeWidth="3" strokeDasharray="2 2" className="animate-pulse" />
          </svg>
        );
      case 'voucher':
        return (
          <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            {/* Ticket Vector */}
            <path d="M15 35a8 8 0 000 16v14a10 10 0 0010 10h50a10 10 0 0010-10V51a8 8 0 000-16V21a10 10 0 00-10-10H25a10 10 0 00-10 10v14z" />
            <path d="M35 15v70M65 15v70" strokeDasharray="3 4" />
            <circle cx="50" cy="32" r="3" fill="currentColor" />
            <circle cx="50" cy="50" r="3" fill="currentColor" />
            <circle cx="50" cy="68" r="3" fill="currentColor" />
          </svg>
        );
      case 'pulsa':
        return (
          <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            {/* Smartphone + Signal */}
            <rect x="25" y="10" width="50" height="80" rx="8" />
            <path d="M45 15h10M50 82h1" strokeWidth="4" />
            <path d="M10 55a20 20 0 010-20M17 50a12 12 0 010-10M83 40a12 12 0 010 10M90 35a20 20 0 010 20" />
          </svg>
        );
      case 'ewallet':
        return (
          <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            {/* Digital Wallet */}
            <path d="M15 25h60a5 5 0 015 5v50a5 5 0 01-5 5H15a5 5 0 01-5-5V30a5 5 0 015-5z" />
            <path d="M10 40h70M55 40v30c0 3 2 5 5 5h20V40H55z" />
            <circle cx="68" cy="58" r="4" fill="currentColor" />
            <path d="M25 15h50a5 5 0 015 5v5" strokeDasharray="4 4" />
          </svg>
        );
      case 'pembukuan':
        return (
          <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            {/* Calculator + Ledger */}
            <rect x="15" y="15" width="40" height="70" rx="4" />
            <path d="M22 25h26M22 35h6m10 0h10M22 47h6v6h-6zm14 0h6v6h-6zm-14 14h6v6h-6zm14 0h6v6h-6zm14-14h6v20h-6z" />
            <path d="M65 25h20M65 40h20M65 55h25M65 70h15" strokeWidth="3" />
            <circle cx="90" cy="25" r="2" fill="currentColor" />
            <circle cx="90" cy="40" r="2" fill="currentColor" />
          </svg>
        );
      case 'laporan':
        return (
          <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            {/* Charts Report */}
            <circle cx="50" cy="50" r="35" strokeWidth="5" />
            <path d="M50 15v35h35" strokeWidth="5" strokeLinecap="square" />
            <path d="M15 80c10-15 25-5 40-20s20-25 30-10" strokeWidth="3" strokeDasharray="1 3" />
          </svg>
        );
      case 'shift':
        return (
          <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            {/* Clock */}
            <circle cx="50" cy="50" r="38" />
            <path d="M50 20v30l18 10M50 8v4M50 88v4M8 50h4M88 50h4" strokeWidth="3" />
          </svg>
        );
      case 'kasir':
        return (
          <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            {/* Cash Register */}
            <path d="M20 50h60l8 35H12l8-35z" />
            <path d="M30 20h40v30H30zM40 50V35" />
            <rect x="25" y="60" width="10" height="8" rx="1" />
            <rect x="45" y="60" width="10" height="8" rx="1" />
            <rect x="65" y="60" width="10" height="8" rx="1" />
            <path d="M45 28h10M52 20h1" />
          </svg>
        );
      case 'pengaturan':
        return (
          <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            {/* Gear */}
            <circle cx="50" cy="50" r="16" />
            <path d="M50 10l3 8 7-3 3 7-8 3 3 8 8-3 3 7-8 3v8l8 3-3 7-8-3-3 8 8 3-3 7-8-3v8l-8-3-3 7 8 3-3 8-8-3-3 7 8 3v-8l-8-3-3 7-8-3 3-8-8-3 3-7 8-3v-8l-8-3 3-7 8 3 3-8-8-3 3-7 8 3V10z" />
          </svg>
        );
      case 'transaksi':
        return (
          <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            {/* Receipt */}
            <path d="M25 15h50v65l-5-4-5 4-5-4-5 4-5-4-5 4-5-4-5 4-5-4-5 4V15z" />
            <path d="M35 30h30M35 42h20M35 54h30M35 66h15" strokeWidth="3" />
            <path d="M15 10h70" strokeWidth="1" strokeDasharray="4 4" />
          </svg>
        );
      default:
        return null;
    }
  };

  return (
    <div
      className={`${getPositionClasses()} ${getSizeClasses()} pointer-events-none select-none overflow-hidden text-indigo-500/6 dark:text-indigo-400/5 transition-all duration-300 transform translate-x-2 translate-y-2 z-0 ${className}`}
    >
      {renderSvg()}
    </div>
  );
};
