import React, { useState, useMemo } from 'react';
import * as XLSX from 'xlsx';
import { Transaction, EWallet, ProductCategory, Product, PhysicalCategory, User } from '../types';
import { getJakartaDateString } from '../utils/dateUtils';
import { 
  BarChart3, 
  TrendingUp, 
  DollarSign, 
  ShoppingBag, 
  Search, 
  Calendar, 
  Printer, 
  FileText, 
  Smartphone, 
  Wifi, 
  Zap, 
  Gamepad2, 
  Layers,
  Sparkles,
  CheckCircle2,
  FileSpreadsheet,
  Package,
  Tag
} from 'lucide-react';

// Imports consolidated above
interface ReportsViewProps {
  transactions: Transaction[];
  eWallets: EWallet[];
  products: Product[];
  physicalCategories: PhysicalCategory[];
  currentUser?: User;
}

export default function ReportsView({ transactions, eWallets, products, physicalCategories = [], currentUser }: ReportsViewProps) {
  const [reportPeriod, setReportPeriod] = useState<'daily' | 'monthly' | 'yearly'>('daily');
  const [selectedDate, setSelectedDate] = useState<string>(
    getJakartaDateString() // default to today in WIB
  );
  const [selectedMonth, setSelectedMonth] = useState<string>(
    getJakartaDateString().substring(0, 7) // default to current month in WIB
  );
  const [selectedYear, setSelectedYear] = useState<string>(
    getJakartaDateString().substring(0, 4) // default to current year in WIB
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCashier, setFilterCashier] = useState(() => {
    return currentUser?.role === 'kasir' ? currentUser.id : 'semua';
  });
  const [filterWallet, setFilterWallet] = useState('semua');
  const [filterDiscountOnly, setFilterDiscountOnly] = useState(false);
  const [filterDiscountReason, setFilterDiscountReason] = useState('semua');
  
  // Selected transaction for re-printing invoice receipt
  const [selectedTxForReceipt, setSelectedTxForReceipt] = useState<Transaction | null>(null);

  // States for breakdown customization (E-Wallet apps vs Physical stock items)
  const [breakdownTab, setBreakdownTab] = useState<'ewallet' | 'item_stock'>('ewallet');

  // Helper label to show active period beautifully
  const activePeriodLabel = useMemo(() => {
    if (reportPeriod === 'daily') {
      return new Date(selectedDate).toLocaleDateString('id-ID', { dateStyle: 'medium' });
    } else if (reportPeriod === 'monthly') {
      const [year, month] = selectedMonth.split('-');
      const date = new Date(parseInt(year, 10), parseInt(month, 10) - 1, 1);
      return date.toLocaleDateString('id-ID', { year: 'numeric', month: 'long' });
    } else {
      return `Tahun ${selectedYear}`;
    }
  }, [reportPeriod, selectedDate, selectedMonth, selectedYear]);

  // 1. Filtered transaction list based on selected period & query & filters
  const filteredTransactionsByDateAndQuery = useMemo(() => {
    return transactions.filter((tx) => {
      // Period matching
      let matchDate = false;
      if (reportPeriod === 'daily') {
        const txDateStr = getJakartaDateString(tx.date);
        matchDate = txDateStr === selectedDate;
      } else if (reportPeriod === 'monthly') {
        const txMonthStr = getJakartaDateString(tx.date).substring(0, 7);
        matchDate = txMonthStr === selectedMonth;
      } else if (reportPeriod === 'yearly') {
        const txYearStr = getJakartaDateString(tx.date).substring(0, 4);
        matchDate = txYearStr === selectedYear;
      }

      // Query matching (phone, invoice, product)
      const matchesSearch = 
        tx.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.customerPhone.includes(searchQuery) ||
        tx.items.some(item => item.productName.toLowerCase().includes(searchQuery.toLowerCase()));

      // Role/Cashier match
      const matchCashier = filterCashier === 'semua' || tx.cashierId === filterCashier;

      // Wallet match
      const matchWallet = filterWallet === 'semua' || tx.eWalletId === filterWallet;

      // Discount match
      const hasDiscount = tx.items.some(item => item.discountAmount && item.discountAmount > 0);
      const matchDiscountOnly = !filterDiscountOnly || hasDiscount;

      // Discount reason match
      const matchDiscountReason = filterDiscountReason === 'semua' || tx.items.some(item => item.discountReason === filterDiscountReason);

      return matchDate && matchesSearch && matchCashier && matchWallet && matchDiscountOnly && matchDiscountReason;
    });
  }, [transactions, reportPeriod, selectedDate, selectedMonth, selectedYear, searchQuery, filterCashier, filterWallet, filterDiscountOnly, filterDiscountReason]);

  // 2. Generate list of operators/cashiers who processed sales
  const cashiers = useMemo(() => {
    const list = transactions.map(t => ({ id: t.cashierId, name: t.cashierName }));
    const unique: Record<string, string> = {};
    list.forEach(item => { unique[item.id] = item.name; });
    return Object.entries(unique).map(([id, name]) => ({ id, name }));
  }, [transactions]);

  // 3. Performance Metrics calculation for the selected period
  const selectedDateMetrics = useMemo(() => {
    let revenue = 0;
    let profit = 0;
    let count = 0;

    filteredTransactionsByDateAndQuery.forEach((tx) => {
      if (tx.status === 'success') {
        revenue += tx.totalAmount;
        profit += tx.totalProfit;
        count += 1;
      }
    });

    return { revenue, profit, count };
  }, [filteredTransactionsByDateAndQuery]);

  // 3.5. Calculate total discounts applied for the period
  const totalDiscounts = useMemo(() => {
    let total = 0;
    filteredTransactionsByDateAndQuery.forEach((tx) => {
      if (tx.status === 'success') {
        tx.items.forEach((item) => {
          if (item.discountAmount) {
            total += item.discountAmount;
          }
        });
      }
    });
    return total;
  }, [filteredTransactionsByDateAndQuery]);

  // 4. Overall cumulative stats (Total all-time)
  const allTimeMetrics = useMemo(() => {
    let revenue = 0;
    let profit = 0;
    let count = 0;

    transactions.forEach((tx) => {
      if (tx.status === 'success') {
        revenue += tx.totalAmount;
        profit += tx.totalProfit;
        count += 1;
      }
    });

    return { revenue, profit, count };
  }, [transactions]);

  // 5. Category breakdown stats for chart visualization on SELECTED period
  const categoryBreakdown = useMemo(() => {
    const breakdown: Record<string, { count: number; revenue: number; profit: number }> = {
      pulsa: { count: 0, revenue: 0, profit: 0 },
      paket_data: { count: 0, revenue: 0, profit: 0 },
      token_pln: { count: 0, revenue: 0, profit: 0 },
      topup_game: { count: 0, revenue: 0, profit: 0 },
      withdrawal: { count: 0, revenue: 0, profit: 0 },
      edc_transfer: { count: 0, revenue: 0, profit: 0 }
    };

    // Initialize physical categories dynamically
    physicalCategories.forEach(cat => {
      breakdown[cat.id] = { count: 0, revenue: 0, profit: 0 };
    });

    filteredTransactionsByDateAndQuery.forEach((tx) => {
      if (tx.status !== 'success') return;
      tx.items.forEach((item) => {
        const cat = item.category;
        let targetCat = cat;
        // Map old legacy physical categories if any exist
        if (cat === 'barang_fisik') {
          targetCat = 'cat-aksesoris';
        } else if (cat === 'voucher_fisik') {
          targetCat = 'cat-lainnya';
        }

        if (!breakdown[targetCat]) {
          breakdown[targetCat] = { count: 0, revenue: 0, profit: 0 };
        }
        breakdown[targetCat].count += item.quantity;
        breakdown[targetCat].revenue += item.sellingPrice * item.quantity;
        breakdown[targetCat].profit += item.profit;
      });
    });

    return Object.entries(breakdown).map(([category, value]) => ({
      category: category as ProductCategory,
      ...value
    }));
  }, [filteredTransactionsByDateAndQuery, physicalCategories]);

  // Overall E-Wallet/Aplikasi breakdown for selected period
  const overallEWalletBreakdown = useMemo(() => {
    const breakdown: Record<string, { id: string; name: string; provider: string; count: number; revenue: number; profit: number }> = {};
    
    eWallets.forEach((w) => {
      breakdown[w.id] = {
        id: w.id,
        name: w.name,
        provider: w.provider,
        count: 0,
        revenue: 0,
        profit: 0
      };
    });

    filteredTransactionsByDateAndQuery.forEach((tx) => {
      if (tx.status !== 'success') return;
      if (!breakdown[tx.eWalletId]) {
        breakdown[tx.eWalletId] = {
          id: tx.eWalletId,
          name: tx.eWalletName,
          provider: 'Lainnya',
          count: 0,
          revenue: 0,
          profit: 0
        };
      }
      breakdown[tx.eWalletId].count += 1;
      breakdown[tx.eWalletId].revenue += tx.totalAmount;
      breakdown[tx.eWalletId].profit += tx.totalProfit;
    });

    return Object.values(breakdown).filter(w => w.count > 0 || w.revenue > 0).sort((a, b) => b.revenue - a.revenue);
  }, [filteredTransactionsByDateAndQuery, eWallets]);

  // Physical stock items sale and inventory status
  const physicalItemsBreakdown = useMemo(() => {
    const isDigital = (cat: string) => ['pulsa', 'paket_data', 'token_pln', 'topup_game', 'withdrawal', 'edc_transfer'].includes(cat);

    // 1. Sales during this period for physical products
    const sales: Record<string, { soldCount: number; revenue: number; profit: number }> = {};
    
    filteredTransactionsByDateAndQuery.forEach((tx) => {
      if (tx.status !== 'success') return;
      tx.items.forEach((item) => {
        if (!isDigital(item.category)) {
          if (!sales[item.productId]) {
            sales[item.productId] = {
              soldCount: 0,
              revenue: 0,
              profit: 0
            };
          }
          sales[item.productId].soldCount += item.quantity;
          sales[item.productId].revenue += item.sellingPrice * item.quantity;
          sales[item.productId].profit += item.profit;
        }
      });
    });

    // 2. Combine with actual products stock levels to show current stock
    const physicalProducts = products.filter(p => !isDigital(p.category));
    
    return physicalProducts.map((p) => {
      const saleInfo = sales[p.id] || { soldCount: 0, revenue: 0, profit: 0 };
      return {
        id: p.id,
        name: p.name,
        operator: p.operator || 'Aksesoris',
        stock: p.stock,
        minStockLimit: p.minStockLimit,
        soldCount: saleInfo.soldCount,
        revenue: saleInfo.revenue,
        profit: saleInfo.profit
      };
    }).sort((a, b) => b.soldCount - a.soldCount || a.stock - b.stock);
  }, [filteredTransactionsByDateAndQuery, products]);

  const maxWalletRevenue = useMemo(() => {
    const vals = overallEWalletBreakdown.map(w => w.revenue);
    return Math.max(...vals, 1);
  }, [overallEWalletBreakdown]);

  const maxPhysicalRevenue = useMemo(() => {
    const vals = physicalItemsBreakdown.map(p => p.revenue);
    return Math.max(...vals, 1);
  }, [physicalItemsBreakdown]);

  // Excel integration export function
  const handleExportToExcel = () => {
    const successTx = filteredTransactionsByDateAndQuery.filter(t => t.status === 'success');
    const allTxInPeriod = filteredTransactionsByDateAndQuery;

    // Build Ringkasan Sheet
    const summaryData = [
      { 'LAPORAN REKAPITULASI TRANSAKSI': 'KONTER CELL POS', 'Nilai': '' },
      { 'LAPORAN REKAPITULASI TRANSAKSI': 'Periode Laporan', 'Nilai': reportPeriod === 'daily' ? `Harian (${selectedDate})` : reportPeriod === 'monthly' ? `Bulanan (${selectedMonth})` : `Tahunan (${selectedYear})` },
      { 'LAPORAN REKAPITULASI TRANSAKSI': 'Waktu Cetak', 'Nilai': new Date().toLocaleString('id-ID') },
      { 'LAPORAN REKAPITULASI TRANSAKSI': '', 'Nilai': '' },
      { 'LAPORAN REKAPITULASI TRANSAKSI': 'RINGKASAN UTAMA', 'Nilai': '' },
      { 'LAPORAN REKAPITULASI TRANSAKSI': 'Total Omset Penjualan (Revenue)', 'Nilai': selectedDateMetrics.revenue },
      { 'LAPORAN REKAPITULASI TRANSAKSI': 'Total Keuntungan Bersih (Profit)', 'Nilai': selectedDateMetrics.profit },
      { 'LAPORAN REKAPITULASI TRANSAKSI': 'Total Transaksi Sukses', 'Nilai': selectedDateMetrics.count },
      { 'LAPORAN REKAPITULASI TRANSAKSI': 'Total Transaksi Gagal/Pending', 'Nilai': allTxInPeriod.length - selectedDateMetrics.count },
      { 'LAPORAN REKAPITULASI TRANSAKSI': 'Rasio Keberhasilan', 'Nilai': allTxInPeriod.length ? `${Math.round((selectedDateMetrics.count / allTxInPeriod.length) * 100)}%` : '0%' },
      { 'LAPORAN REKAPITULASI TRANSAKSI': '', 'Nilai': '' },
      { 'LAPORAN REKAPITULASI TRANSAKSI': 'PERFORMA KATEGORI PRODUK', 'Nilai': '' }
    ];

    const categoryHeader = {
      'LAPORAN REKAPITULASI TRANSAKSI': 'Nama Kategori',
      'Nilai': 'Qty Terjual',
      '__EMPTY': 'Total Omset',
      '__EMPTY_1': 'Total Profit'
    };
    summaryData.push(categoryHeader as any);

    categoryBreakdown.forEach(cat => {
      summaryData.push({
        'LAPORAN REKAPITULASI TRANSAKSI': getCategoryName(cat.category),
        'Nilai': cat.count,
        '__EMPTY': cat.revenue,
        '__EMPTY_1': cat.profit
      } as any);
    });

    summaryData.push({ 'LAPORAN REKAPITULASI TRANSAKSI': '', 'Nilai': '' } as any);
    summaryData.push({ 'LAPORAN REKAPITULASI TRANSAKSI': 'DISTRIBUSI SALDO E-WALLET (MODAL AGEN)', 'Nilai': '' } as any);

    const ewalletHeader = {
      'LAPORAN REKAPITULASI TRANSAKSI': 'Nama E-Wallet',
      'Nilai': 'Total Transaksi Sukses',
      '__EMPTY': 'Total Omset Didanai'
    };
    summaryData.push(ewalletHeader as any);

    const walletDistribution: Record<string, { name: string; count: number; revenue: number }> = {};
    eWallets.forEach(w => {
      walletDistribution[w.id] = { name: w.name, count: 0, revenue: 0 };
    });
    
    successTx.forEach(tx => {
      if (walletDistribution[tx.eWalletId]) {
        walletDistribution[tx.eWalletId].count += 1;
        walletDistribution[tx.eWalletId].revenue += tx.totalAmount;
      } else {
        walletDistribution[tx.eWalletId] = { name: tx.eWalletName, count: 1, revenue: tx.totalAmount };
      }
    });

    Object.values(walletDistribution).forEach(w => {
      if (w.count > 0) {
        summaryData.push({
          'LAPORAN REKAPITULASI TRANSAKSI': w.name,
          'Nilai': w.count,
          '__EMPTY': w.revenue
        } as any);
      }
    });

    const wsSummary = XLSX.utils.json_to_sheet(summaryData, { skipHeader: true });

    // Detailed ledger sheet
    const txDetails = allTxInPeriod.map(tx => ({
      'No. Invoice': tx.invoiceNumber,
      'Tanggal': tx.date ? new Date(tx.date).toLocaleDateString('id-ID') : '-',
      'Waktu': tx.date ? new Date(tx.date).toLocaleTimeString('id-ID') : '-',
      'No. HP / ID Pelanggan': tx.customerPhone || '-',
      'Nama Produk': tx.items[0]?.productName || '-',
      'Kategori': tx.items[0] ? getCategoryName(tx.items[0].category) : '-',
      'E-Wallet Sumber': tx.eWalletName,
      'Harga Modal (Rp)': tx.items[0]?.purchasePrice || 0,
      'Harga Jual (Rp)': tx.totalAmount,
      'Keuntungan Bersih (Rp)': tx.totalProfit,
      'Nama Kasir': tx.cashierName,
      'Status': (tx.status || 'SUCCESS').toUpperCase()
    }));

    const wsDetails = XLSX.utils.json_to_sheet(txDetails);

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, wsSummary, 'Ringkasan Laporan');
    XLSX.utils.book_append_sheet(wb, wsDetails, 'Detail Transaksi');

    let periodStr = '';
    if (reportPeriod === 'daily') periodStr = `HARIAN_${selectedDate}`;
    else if (reportPeriod === 'monthly') periodStr = `BULANAN_${selectedMonth}`;
    else periodStr = `TAHUNAN_${selectedYear}`;

    XLSX.writeFile(wb, `REKAP_TRANSAKSI_${periodStr}.xlsx`);
  };

  const maxCategoryRevenue = useMemo(() => {
    const vals = categoryBreakdown.map(c => c.revenue);
    return Math.max(...vals, 1); // avoid division by zero
  }, [categoryBreakdown]);

  const formatRupiah = (num: number | null | undefined) => {
    if (num === undefined || num === null || isNaN(num)) return 'Rp 0';
    return 'Rp ' + num.toLocaleString('id-ID');
  };

  const handlePrintReceipt = () => {
    window.print();
  };

  const getCategoryName = (cat: string) => {
    if (!cat) return 'Lainnya';
    if (cat === 'pulsa') return 'Pulsa';
    if (cat === 'paket_data') return 'Paket Data';
    if (cat === 'token_pln') return 'Token PLN';
    if (cat === 'topup_game') return 'Top Up Game';
    if (cat === 'withdrawal') return 'Tarik Tunai';
    if (cat === 'edc_transfer') return 'Transfer Bank / EDC';
    
    // Check if it's in our dynamic categories
    const found = (physicalCategories || []).find(c => c.id === cat);
    if (found) return found.name;
    
    if (cat === 'barang_fisik') return 'Aksesoris';
    if (cat === 'voucher_fisik') return 'Voucher Fisik';
    return cat;
  };

  const getCategoryIcon = (cat: ProductCategory) => {
    switch (cat) {
      case 'pulsa': return <Smartphone className="w-4 h-4 text-indigo-600" />;
      case 'paket_data': return <Wifi className="w-4 h-4 text-blue-600" />;
      case 'token_pln': return <Zap className="w-4 h-4 text-amber-500" />;
      case 'topup_game': return <Gamepad2 className="w-4 h-4 text-purple-600" />;
      case 'voucher_fisik': return <Layers className="w-4 h-4 text-blue-600" />;
      case 'barang_fisik': return <ShoppingBag className="w-4 h-4 text-emerald-600" />;
      case 'withdrawal': return <Layers className="w-4 h-4 text-rose-500" />;
      default: return <ShoppingBag className="w-4 h-4 text-emerald-600" />;
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 bg-slate-50">
      
      {/* Header */}
      <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">
            {currentUser?.role === 'kasir' ? 'RIWAYAT TRANSAKSI KASIR' : 'LAPORAN PENJUALAN POS'}
          </h1>
          <p className="text-slate-500 text-sm">
            {currentUser?.role === 'kasir'
              ? 'Arsip riwayat transaksi penjualan konter pulsa & e-wallet terintegrasi detail cetak struk'
              : 'Analisis pembukuan harian, bulanan, tahunan, & rekap otomatis terintegrasi Excel'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 self-start xl:self-auto">
          {/* Period Selector Tabs */}
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setReportPeriod('daily')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                reportPeriod === 'daily' 
                  ? 'bg-white text-slate-900 shadow-xs' 
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              Harian
            </button>
            <button
              onClick={() => setReportPeriod('monthly')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                reportPeriod === 'monthly' 
                  ? 'bg-white text-slate-900 shadow-xs' 
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              Bulanan
            </button>
            <button
              onClick={() => setReportPeriod('yearly')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                reportPeriod === 'yearly' 
                  ? 'bg-white text-slate-900 shadow-xs' 
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              Tahunan
            </button>
          </div>

          {/* Date Picker Input */}
          <div className="flex items-center space-x-2 bg-white px-3 py-2 rounded-xl border border-slate-200 shadow-xs">
            <Calendar className="w-4 h-4 text-slate-400" />
            <span className="text-xs font-bold text-slate-500 uppercase">
              {reportPeriod === 'daily' ? 'Hari:' : reportPeriod === 'monthly' ? 'Bulan:' : 'Tahun:'}
            </span>
            {reportPeriod === 'daily' && (
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="border-none bg-transparent text-xs font-bold text-slate-800 focus:outline-none focus:ring-0 p-0"
              />
            )}
            {reportPeriod === 'monthly' && (
              <input
                type="month"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="border-none bg-transparent text-xs font-bold text-slate-800 focus:outline-none focus:ring-0 p-0"
              />
            )}
            {reportPeriod === 'yearly' && (
              <select
                value={selectedYear}
                onChange={(e) => setSelectedYear(e.target.value)}
                className="border-none bg-transparent text-xs font-bold text-slate-800 focus:outline-none focus:ring-0 p-0"
              >
                {[2024, 2025, 2026, 2027, 2028, 2029, 2030].map(y => (
                  <option key={y} value={y.toString()}>{y}</option>
                ))}
              </select>
            )}
          </div>

          {/* Excel Export Button */}
          {currentUser?.role !== 'kasir' && (
            <button
              onClick={handleExportToExcel}
              className="flex items-center space-x-1.5 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all border border-emerald-500 cursor-pointer"
              title="Ekspor rekap lengkap ke file Microsoft Excel (.xlsx)"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Ekspor Rekap Excel</span>
            </button>
          )}
        </div>
      </div>

      {/* 2. Top Banner Statistics for Selected Date */}
      {currentUser?.role !== 'kasir' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          
          {/* Total revenue */}
          <div className="p-5 rounded-[20px] bg-white border border-slate-100 shadow-sm relative overflow-hidden">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                {reportPeriod === 'daily' ? 'Omset Jualan Hari Ini' : reportPeriod === 'monthly' ? 'Omset Jualan Bulan Ini' : 'Omset Jualan Tahun Ini'}
              </span>
              <span className="p-2 bg-blue-50 rounded-xl text-blue-600"><TrendingUp className="w-5 h-5" /></span>
            </div>
            <p className="text-3xl font-black text-slate-900 font-mono tracking-tight leading-none">
              {formatRupiah(selectedDateMetrics.revenue)}
            </p>
            <div className="flex items-center text-xs text-slate-400 font-medium mt-3">
              <span className="font-semibold text-blue-600 mr-1 capitalize">{reportPeriod}</span>
              <span>akumulasi periode {activePeriodLabel}</span>
            </div>
          </div>

          {/* Total profit */}
          <div className="p-5 rounded-[20px] bg-white border border-slate-100 shadow-sm relative overflow-hidden">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Keuntungan Bersih (Profit)</span>
              <span className="p-2 bg-emerald-50 rounded-xl text-emerald-600"><DollarSign className="w-5 h-5" /></span>
            </div>
            <p className="text-3xl font-black text-emerald-600 font-mono tracking-tight leading-none">
              {formatRupiah(selectedDateMetrics.profit)}
            </p>
            <div className="flex items-center text-xs text-slate-400 font-medium mt-3">
              <span className="font-semibold text-emerald-600 mr-1">Laba Bersih</span>
              <span>real-time dari selisih harga jual</span>
            </div>
          </div>

          {/* Total discounts */}
          <div className="p-5 rounded-[20px] bg-white border border-slate-100 shadow-sm relative overflow-hidden">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Diskon yang Diberikan</span>
              <span className="p-2 bg-rose-50 rounded-xl text-rose-600"><Tag className="w-5 h-5" /></span>
            </div>
            <p className="text-3xl font-black text-rose-600 font-mono tracking-tight leading-none">
              {formatRupiah(totalDiscounts)}
            </p>
            <div className="flex items-center text-xs text-slate-400 font-medium mt-3">
              <span className="font-semibold text-rose-600 mr-1">Potongan</span>
              <span>total diskon dipotong dari harga normal</span>
            </div>
          </div>

          {/* Total transaction volume */}
          <div className="p-5 rounded-[20px] bg-white border border-slate-100 shadow-sm relative overflow-hidden">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Volume Transaksi</span>
              <span className="p-2 bg-blue-50 rounded-xl text-blue-600"><ShoppingBag className="w-5 h-5" /></span>
            </div>
            <p className="text-3xl font-black text-slate-900 font-mono tracking-tight leading-none">
              {selectedDateMetrics.count} <span className="text-base font-normal text-slate-400">Trx</span>
            </p>
            <div className="flex items-center text-xs text-slate-400 font-medium mt-3">
              <span className="font-semibold text-blue-600 mr-1">Status</span>
              <span>seluruh transaksi berhasil di periode ini</span>
            </div>
          </div>
        </div>
      )}

      {/* 3. Visual Breakdown SVG / CSS Charts */}
      {currentUser?.role !== 'kasir' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-6">
        
        {/* Left Card: E-Wallet and Item Stok Fisik break down list */}
        <div className="lg:col-span-5 bg-white p-5 rounded-[20px] border border-slate-100 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-100 pb-3 mb-4">
              <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center">
                <BarChart3 className="w-4 h-4 mr-1.5 text-blue-600" />
                Proporsi Penjualan & Stok ({reportPeriod === 'daily' ? 'Hari Ini' : reportPeriod === 'monthly' ? 'Bulan Ini' : 'Tahun Ini'})
              </h2>
            </div>

            {/* Quick Filter Tabs inside Card */}
            <div className="grid grid-cols-2 bg-slate-100 p-1 rounded-xl mb-4 gap-1">
              <button
                onClick={() => setBreakdownTab('ewallet')}
                className={`py-1.5 px-3 rounded-lg text-xs font-bold text-center transition-all cursor-pointer ${
                  breakdownTab === 'ewallet'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                E-Wallet / Aplikasi
              </button>
              <button
                onClick={() => setBreakdownTab('item_stock')}
                className={`py-1.5 px-3 rounded-lg text-xs font-bold text-center transition-all cursor-pointer ${
                  breakdownTab === 'item_stock'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                Item Stok Fisik
              </button>
            </div>

            {/* Rendering Lists */}
            <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
              {breakdownTab === 'ewallet' && (
                overallEWalletBreakdown.length === 0 ? (
                  <p className="text-center text-xs text-slate-400 py-8 italic">Tidak ada transaksi e-wallet di periode ini.</p>
                ) : (
                  overallEWalletBreakdown.map((row) => {
                    const percentage = Math.round((row.revenue / maxWalletRevenue) * 100);
                    return (
                      <div key={row.id} className="space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                        <div className="flex justify-between items-center text-xs">
                          <span className="font-bold text-slate-800 flex items-center space-x-1.5">
                            <span className="w-2 h-2 rounded-full bg-emerald-500" />
                            <span>{row.name}</span>
                          </span>
                          <div className="font-mono text-slate-500 font-semibold text-[11px]">
                            {row.count} trx • <span className="text-slate-900 font-extrabold">{formatRupiah(row.revenue)}</span>
                          </div>
                        </div>
                        <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                          <div 
                            className="bg-emerald-600 h-full rounded-full transition-all duration-500"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                        <div className="text-[10px] text-slate-400 flex justify-between font-medium pt-0.5">
                          <span>Suplier: {row.provider}</span>
                          <span className="text-emerald-600 font-semibold">Laba: {formatRupiah(row.profit)}</span>
                        </div>
                      </div>
                    );
                  })
                )
              )}

              {breakdownTab === 'item_stock' && (
                physicalItemsBreakdown.length === 0 ? (
                  <p className="text-center text-xs text-slate-400 py-8 italic">Tidak ada sediaan item stok fisik.</p>
                ) : (
                  physicalItemsBreakdown.map((row) => {
                    const percentage = Math.round((row.revenue / maxPhysicalRevenue) * 100);
                    const isOutOfStock = row.stock <= 0;
                    const isLowStock = row.stock > 0 && row.stock <= row.minStockLimit;
                    
                    return (
                      <div key={row.id} className="space-y-1.5 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                        <div className="flex justify-between items-start text-xs">
                          <div className="space-y-0.5">
                            <span className="font-bold text-slate-800 flex items-center space-x-1.5">
                              <Package className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                              <span className="line-clamp-1">{row.name}</span>
                            </span>
                            <div className="text-[10px] text-slate-400 font-medium">
                              Sisa Stok: <span className={`font-bold ${isOutOfStock ? 'text-red-500' : isLowStock ? 'text-amber-500' : 'text-slate-600'}`}>{row.stock} pcs</span>
                              {isOutOfStock && <span className="ml-1 px-1 py-0.2 bg-red-50 text-red-600 rounded text-[9px] font-bold">Habis</span>}
                              {isLowStock && <span className="ml-1 px-1 py-0.2 bg-amber-50 text-amber-600 rounded text-[9px] font-bold">Limit</span>}
                            </div>
                          </div>
                          
                          <div className="font-mono text-slate-500 font-semibold text-right text-[11px] shrink-0">
                            Terjual: <span className="text-slate-900 font-bold">{row.soldCount} pcs</span>
                            <div className="text-slate-800 font-bold">{formatRupiah(row.revenue)}</div>
                          </div>
                        </div>

                        {row.soldCount > 0 && (
                          <>
                            <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden mt-1">
                              <div 
                                className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                                style={{ width: `${percentage}%` }}
                              />
                            </div>
                            <div className="text-[10px] text-indigo-600 text-right font-semibold">
                              Laba Jual: {formatRupiah(row.profit)}
                            </div>
                          </>
                        )}
                      </div>
                    );
                  })
                )
              )}
            </div>
          </div>

          <p className="text-[9px] text-slate-400 mt-4 bg-slate-50 p-2.5 rounded-xl border border-slate-100 leading-snug">
            * Analisis proporsi menyajikan kontribusi omset bruto real-time dari masing-masing {breakdownTab === 'ewallet' ? 'e-wallet / aplikasi penyuplai utama' : 'item stok produk fisik beserta sisa persediaan di etalase konter'}.
          </p>
        </div>

        {/* Right Card: Cumulated All-time metrics summary panel (7 Cols) */}
        <div className="lg:col-span-7 bg-white p-5 rounded-[20px] border border-slate-100 shadow-sm flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wider border-b border-slate-100 pb-3 mb-4 flex items-center">
              <Sparkles className="w-4 h-4 mr-1.5 text-amber-500" />
              Performa Kumulatif Pembukuan Konter (All-Time)
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-2">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Omset Penjualan</span>
                <p className="text-xl font-black text-slate-800 font-mono mt-1">{formatRupiah(allTimeMetrics.revenue)}</p>
                <span className="text-[9px] text-slate-400 mt-1 block">Akumulasi seluruh transaksi sukses</span>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Laba Bersih Toko</span>
                <p className="text-xl font-black text-emerald-600 font-mono mt-1">{formatRupiah(allTimeMetrics.profit)}</p>
                <span className="text-[9px] text-slate-400 mt-1 block">Selisih harga jual dan harga modal server</span>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-100 pt-4 mt-4 text-xs text-slate-500 space-y-2 leading-relaxed">
            <div className="flex justify-between items-center">
              <span className="font-semibold text-slate-700">Skema Transaksi Konter Pulsa:</span>
              <span className="text-blue-600 font-bold bg-blue-50 px-2 py-0.5 rounded text-[10px] uppercase">Aman & Terkendali</span>
            </div>
            <p>
              Setiap kali Kasir memproses penjualan pulsa/paket data, sistem POS secara otomatis mendebit saldo modal e-wallet agen Anda. Hal ini mencegah terjadinya selisih pembukuan manual karena kasir tidak perlu mencatat sisa saldo modem/kartu server secara terpisah.
            </p>
          </div>
        </div>
      </div>
      )}

      {/* 4. Complete Transaction Ledger of the Selected Date */}
      <div className="bg-white rounded-[20px] border border-slate-100 shadow-sm p-5">
        
        {/* Table Filter controls */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-slate-100 pb-4 mb-4 gap-4">
          <div>
            <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
              Daftar Transaksi Periode {activePeriodLabel}
            </h2>
            <p className="text-[11px] text-slate-400 mt-0.5">Ditemukan {filteredTransactionsByDateAndQuery.length} transaksi pada periode ini</p>
          </div>

          <div className="flex items-center space-x-2 flex-wrap gap-y-2">
            
            {/* Search Input bar */}
            <div className="relative">
              <Search className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-400 w-4 h-4" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari No. HP atau Transaksi..."
                className="pl-8 pr-2 py-1.5 border border-slate-200 rounded-xl text-xs bg-slate-50 focus:outline-none focus:ring-1 focus:ring-blue-500 w-40"
              />
            </div>

            {/* Cashier Selector */}
            <select
              value={filterCashier}
              onChange={(e) => setFilterCashier(e.target.value)}
              className="p-1.5 border border-slate-200 bg-slate-50 rounded-xl text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="semua">Semua Kasir</option>
              {cashiers.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>

            {/* Wallet Selector */}
            <select
              value={filterWallet}
              onChange={(e) => setFilterWallet(e.target.value)}
              className="p-1.5 border border-slate-200 bg-slate-50 rounded-xl text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="semua">Semua Dompet</option>
              {eWallets.map(w => (
                <option key={w.id} value={w.id}>{w.name}</option>
              ))}
            </select>

            {/* Discount Filter Button */}
            <button
              onClick={() => {
                const next = !filterDiscountOnly;
                setFilterDiscountOnly(next);
                if (!next) setFilterDiscountReason('semua');
              }}
              className={`p-1.5 border rounded-xl text-xs font-bold flex items-center space-x-1 transition-all ${
                filterDiscountOnly 
                  ? 'bg-rose-50 border-rose-200 text-rose-700 shadow-xs' 
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:text-slate-800'
              }`}
              title="Hanya tampilkan transaksi yang menggunakan diskon"
            >
              <Tag className="w-3.5 h-3.5" />
              <span>Hanya Diskon</span>
            </button>

            {/* Discount Reason Filter */}
            {filterDiscountOnly && (
              <select
                value={filterDiscountReason}
                onChange={(e) => setFilterDiscountReason(e.target.value)}
                className="p-1.5 border border-rose-200 bg-rose-50 text-rose-800 rounded-xl text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-rose-500 animate-in fade-in duration-200"
              >
                <option value="semua">Semua Alasan Diskon</option>
                <option value="Pelanggan Setia">Pelanggan Setia</option>
                <option value="Promo">Promo</option>
                <option value="Nego">Nego</option>
                <option value="Barang Rusak/Cacat">Barang Rusak/Cacat</option>
                <option value="Clearance">Clearance</option>
                <option value="Karyawan">Karyawan</option>
                <option value="Lainnya">Lainnya / Manual</option>
              </select>
            )}
          </div>
        </div>

        {/* List of transactions */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/70 border-b border-slate-100 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                <th className="py-2.5 px-4">No. Transaksi</th>
                <th className="py-2.5 px-4">Jam Trx</th>
                <th className="py-2.5 px-4">No. HP / ID Pelanggan</th>
                <th className="py-2.5 px-4">Nama Produk</th>
                <th className="py-2.5 px-4">{currentUser?.role === 'kasir' ? 'E-Wallet / Operator' : 'E-Wallet (Modal)'}</th>
                <th className="py-2.5 px-4 text-right">Harga Jual</th>
                {currentUser?.role !== 'kasir' && <th className="py-2.5 px-4 text-right">Laba Bersih</th>}
                <th className="py-2.5 px-4 text-center">Status</th>
                <th className="py-2.5 px-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
              {filteredTransactionsByDateAndQuery.length === 0 ? (
                <tr>
                  <td colSpan={currentUser?.role === 'kasir' ? 8 : 9} className="py-12 text-center text-slate-400">
                    <FileText className="w-10 h-10 text-slate-200 mx-auto mb-1 animate-pulse" />
                    <p className="font-semibold text-slate-500 text-xs">Belum ada aktivitas transaksi</p>
                    <p className="text-[10px] text-slate-400 mt-1">Saring tanggal atau proses penjualan baru di Kasir POS.</p>
                  </td>
                </tr>
              ) : (
                filteredTransactionsByDateAndQuery.map((tx) => {
                  const isSuccess = tx.status === 'success';
                  const timeStr = tx.date ? new Date(tx.date).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) : '-';

                  return (
                    <tr key={tx.id} className="hover:bg-slate-50/30 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-slate-800">
                        {tx.invoiceNumber}
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-500">
                        {timeStr}
                      </td>
                      <td className="py-3 px-4 font-mono font-semibold text-slate-900">
                        {tx.customerPhone}
                      </td>
                      <td className="py-3 px-4">
                        <div className="space-y-0.5">
                          <p className="font-bold text-slate-800 leading-tight">
                            {tx.items[0]?.productName || 'Tanpa Nama'}
                          </p>
                          <div className="flex flex-wrap gap-1 items-center mt-0.5">
                            <span className="text-[9px] text-slate-400 bg-slate-100 px-1 py-0.2 rounded inline-block uppercase font-bold">
                              {tx.items[0] ? getCategoryName(tx.items[0].category) : ''}
                            </span>
                            {tx.items[0]?.discountAmount && tx.items[0]?.discountAmount > 0 ? (
                              <span className="text-[9px] text-rose-700 bg-rose-50 border border-rose-150 border-rose-100 px-1 rounded inline-block font-extrabold" title={`Alasan: ${tx.items[0].discountReason}`}>
                                🏷️ Diskon {formatRupiah(tx.items[0].discountAmount)} ({tx.items[0].discountReason})
                              </span>
                            ) : null}
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center space-x-2">
                          {(() => {
                            const walletObj = eWallets.find((w) => w.id === tx.eWalletId);
                            return walletObj?.logoUrl ? (
                              <img 
                                src={walletObj.logoUrl} 
                                alt={tx.eWalletName} 
                                className="w-7 h-7 object-cover rounded-lg border border-slate-200 shrink-0" 
                                referrerPolicy="no-referrer"
                              />
                            ) : null;
                          })()}
                          <div className="space-y-0.5">
                            <p className="font-semibold text-slate-800 leading-none">{tx.eWalletName}</p>
                            {currentUser?.role !== 'kasir' ? (
                              <span className="text-[9px] text-slate-400 font-mono">Modal: -{formatRupiah(tx.items[0]?.purchasePrice || 0)}</span>
                            ) : (
                              <span className="text-[9px] text-slate-400 font-mono">Operator: {tx.cashierName}</span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                        {formatRupiah(tx.totalAmount)}
                      </td>
                      {currentUser?.role !== 'kasir' && (
                        <td className="py-3 px-4 text-right font-mono font-bold text-emerald-600">
                          +{formatRupiah(tx.totalProfit)}
                        </td>
                      )}
                      <td className="py-3 px-4 text-center">
                        <span className={`inline-flex items-center px-1.5 py-0.5 rounded-md text-[9px] font-bold ${
                          isSuccess ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700'
                        }`}>
                          {isSuccess ? 'BERHASIL' : 'GAGAL'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => setSelectedTxForReceipt(tx)}
                          className="p-1 hover:bg-slate-100 text-slate-600 rounded"
                          title="Detail Transaksi"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* RE-PRINT RECEIPT POPUP MODAL */}
      {selectedTxForReceipt && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 pb-12 sm:pb-4 z-[200]">
          <div className="bg-white rounded-[20px] shadow-2xl max-w-sm w-full overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-200">
            
            {/* Printable Receipt Container */}
            <div id="print-receipt" className="p-6 bg-white text-slate-800 font-sans text-xs">
              
              {/* Detail Header */}
              <div className="flex flex-col items-center justify-center text-center pb-5 border-b border-slate-100">
                <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mb-2.5">
                  <CheckCircle2 className="w-7 h-7" />
                </div>
                <h3 className="font-extrabold text-base text-slate-900 leading-tight">Detail Transaksi Arsip</h3>
                <p className="text-[10px] text-emerald-600 font-extrabold bg-emerald-50 px-2.5 py-0.5 rounded-full mt-1.5 uppercase tracking-wider">
                  Salinan Resmi
                </p>
              </div>

              {/* Transaction Amount Hero */}
              <div className="py-5 text-center bg-slate-50/50 rounded-[16px] my-4 border border-slate-100">
                <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider mb-0.5">Total Bayar</p>
                <p className="text-2xl font-black text-slate-900 tracking-tight">
                  {formatRupiah(selectedTxForReceipt.totalAmount)}
                </p>
              </div>

              {/* Detail Meta Info Grid */}
              <div className="space-y-3 py-1 border-b border-slate-100 text-[11px] text-slate-600">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-semibold uppercase tracking-wider text-[9px]">No. Transaksi</span>
                  <span className="font-mono font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded-md text-[10px]">
                    {selectedTxForReceipt.invoiceNumber}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-semibold uppercase tracking-wider text-[9px]">Waktu Transaksi</span>
                  <span className="font-bold text-slate-800">
                    {selectedTxForReceipt.date ? new Date(selectedTxForReceipt.date).toLocaleString('id-ID', {
                      dateStyle: 'medium',
                      timeStyle: 'short'
                    }) : '-'}
                  </span>
                </div>
                {selectedTxForReceipt.customerPhone && selectedTxForReceipt.customerPhone !== '-' && (
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400 font-semibold uppercase tracking-wider text-[9px]">No. Pelanggan</span>
                    <span className="font-extrabold text-slate-800">{selectedTxForReceipt.customerPhone}</span>
                  </div>
                )}
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-semibold uppercase tracking-wider text-[9px]">Kasir Operator</span>
                  <span className="font-bold text-slate-800">{selectedTxForReceipt.cashierName}</span>
                </div>
              </div>

              {/* Detail Items / Products */}
              <div className="py-4 border-b border-slate-100 space-y-3">
                <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Detail Produk</p>
                {(selectedTxForReceipt.items || []).map((item, index) => (
                  <div key={index} className="space-y-1.5 text-xs">
                    <div className="flex justify-between items-start">
                      <div className="min-w-0 pr-2">
                        <p className="font-extrabold text-slate-800 truncate leading-snug">{item.productName}</p>
                        <p className="text-[10px] text-slate-400 font-medium">
                          {(getCategoryName(item.category) || 'Lainnya').toUpperCase()} • Qty: {item.quantity || 1}
                        </p>
                        {item.scannedBarcodes && item.scannedBarcodes.length > 0 && (
                          <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-mono font-bold mt-0.5">
                            Barcode: {item.scannedBarcodes.join(', ')}
                          </p>
                        )}
                      </div>
                      <div className="text-right shrink-0">
                        {item.discountAmount && item.discountAmount > 0 ? (
                          <>
                            <p className="font-extrabold text-slate-800">{formatRupiah(item.sellingPrice * item.quantity)}</p>
                            <p className="text-[9px] text-slate-400 line-through">@{formatRupiah(item.originalPrice || item.sellingPrice)}</p>
                          </>
                        ) : (
                          <>
                            <p className="font-extrabold text-slate-800">{formatRupiah(item.sellingPrice * item.quantity)}</p>
                            <p className="text-[9px] text-slate-400">@{formatRupiah(item.sellingPrice)}</p>
                          </>
                        )}
                      </div>
                    </div>
                    {item.discountAmount && item.discountAmount > 0 && (
                      <div className="bg-slate-50 p-2 rounded-xl text-[10px] space-y-1 border border-slate-100">
                        <div className="flex justify-between text-slate-500">
                          <span>Harga Awal ({item.quantity}x):</span>
                          <span className="font-medium font-mono">{formatRupiah((item.originalPrice || item.sellingPrice) * item.quantity)}</span>
                        </div>
                        <div className="flex justify-between text-rose-500 font-bold">
                          <span>Diskon ({item.discountType === 'percent' ? 'Persen' : 'Nominal'}):</span>
                          <span className="font-mono">-{formatRupiah(item.discountAmount)}</span>
                        </div>
                        {item.discountReason && (
                          <div className="flex justify-between text-slate-500 text-[9px] italic">
                            <span>Alasan Diskon:</span>
                            <span className="font-semibold">{item.discountReason}</span>
                          </div>
                        )}
                        <div className="flex justify-between text-slate-800 font-extrabold pt-1 border-t border-slate-200">
                          <span>Harga Akhir:</span>
                          <span className="font-mono">{formatRupiah(item.sellingPrice * item.quantity)}</span>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Detail Payments & Wallets */}
              <div className="py-4 space-y-2.5 text-[11px] text-slate-600">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-semibold uppercase tracking-wider text-[9px]">Sistem Server</span>
                  <span className="font-bold text-slate-800 bg-blue-50 text-blue-700 px-2 py-0.5 rounded-md text-[10px] uppercase">
                    {selectedTxForReceipt.eWalletName || 'Tunai'}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-semibold uppercase tracking-wider text-[9px]">Metode Pembayaran</span>
                  <span className="font-bold text-slate-700">
                    {selectedTxForReceipt.items[0]?.paymentMethod === 'transfer' ? 'Transfer' : selectedTxForReceipt.eWalletId === 'cash' ? 'Tunai' : selectedTxForReceipt.type === 'physical' && selectedTxForReceipt.eWalletId !== 'cash' ? 'Transfer' : 'Tunai'}
                  </span>
                </div>
              </div>

              {/* Detail Footer */}
              <div className="text-center pt-4 border-t border-slate-100 space-y-1.5 flex flex-col items-center">
                <img 
                  src="/logo.png" 
                  alt="MD POS Logo" 
                  onError={(e) => {
                    if (e.currentTarget.src !== window.location.origin + "/logo.png") {
                      e.currentTarget.src = "/logo.png";
                    }
                  }} 
                  className="w-8 h-8 object-contain mb-1 rounded bg-white p-0.5 border border-slate-200" 
                  referrerPolicy="no-referrer"
                />
                <p className="font-extrabold text-slate-800 tracking-wider text-[10px]">MD POS</p>
                <p className="text-[9px] text-indigo-500 font-bold">https://mdcell.my.id</p>
                <p className="text-[8px] text-slate-400">Salinan digital resmi dari rekaman data transaksi penjualan.</p>
              </div>
            </div>

            {/* Modal Controls (Not Printed) */}
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex space-x-2">
              <button
                onClick={handlePrintReceipt}
                className="flex-1 flex items-center justify-center py-2.5 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition-all shadow-sm"
              >
                <Printer className="w-4 h-4 mr-1.5" />
                Cetak Detail Transaksi
              </button>
              <button
                onClick={() => setSelectedTxForReceipt(null)}
                className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold text-center transition-all shadow-sm"
              >
                Tutup Detail
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
