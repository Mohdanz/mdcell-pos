import React, { useState, useMemo, useEffect } from 'react';
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  Layers, 
  Wallet, 
  CreditCard, 
  Calendar, 
  FileText, 
  Plus, 
  ArrowRightLeft, 
  CheckCircle2, 
  RefreshCw, 
  Printer, 
  Download, 
  BookOpen, 
  Search, 
  Sparkles, 
  ChevronDown, 
  ChevronUp, 
  Info,
  Building,
  Coins,
  ArrowDownLeft,
  ArrowUpRight,
  PiggyBank,
  Check,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { 
  Account, 
  JournalEntry, 
  JournalLine, 
  Transaction, 
  EWallet, 
  EWalletHistory, 
  Product, 
  Shift 
} from '../types';

export const CHART_OF_ACCOUNTS: Account[] = [
  { code: '101', name: 'Kas di Drawer (Laci Kasir)', category: 'Asset', normalBalance: 'Debit' },
  { code: '102', name: 'Saldo E-Wallet Agen', category: 'Asset', normalBalance: 'Debit' },
  { code: '103', name: 'Persediaan Barang Dagang', category: 'Asset', normalBalance: 'Debit' },
  { code: '104', name: 'Saldo Rekening Bank', category: 'Asset', normalBalance: 'Debit' },
  { code: '301', name: 'Modal Pemilik', category: 'Equity', normalBalance: 'Credit' },
  { code: '302', name: 'Laba Ditahan', category: 'Equity', normalBalance: 'Credit' },
  { code: '401', name: 'Pendapatan Penjualan', category: 'Revenue', normalBalance: 'Credit' },
  { code: '402', name: 'Pendapatan Jasa & Komisi', category: 'Revenue', normalBalance: 'Credit' },
  { code: '501', name: 'Harga Pokok Penjualan (HPP)', category: 'Expense', normalBalance: 'Debit' },
  { code: '502', name: 'Beban Selisih Kas Shift', category: 'Expense', normalBalance: 'Debit' },
  { code: '503', name: 'Beban Diskon & Promosi', category: 'Expense', normalBalance: 'Debit' },
  { code: '504', name: 'Beban Listrik & Internet', category: 'Expense', normalBalance: 'Debit' },
  { code: '505', name: 'Beban Sewa Konter', category: 'Expense', normalBalance: 'Debit' },
  { code: '506', name: 'Beban Gaji & Operator', category: 'Expense', normalBalance: 'Debit' },
  { code: '507', name: 'Beban Operasional Lain', category: 'Expense', normalBalance: 'Debit' },
];

interface AccountingViewProps {
  transactions: Transaction[];
  eWallets: EWallet[];
  histories: EWalletHistory[];
  products: Product[];
  shifts: Shift[];
}

export default function AccountingView({
  transactions,
  eWallets,
  histories,
  products,
  shifts
}: AccountingViewProps) {
  // Navigation
  const [activeTab, setActiveTab] = useState<'dashboard' | 'entry' | 'ledger'>('dashboard');
  const [reportType, setReportType] = useState<'income' | 'balance' | 'cash_flow'>('income');
  
  // Local Manual Journals (fetched from backend)
  const [manualJournalEntries, setManualJournalEntries] = useState<JournalEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Form State - Pengeluaran (Expense)
  const [expenseAccount, setExpenseAccount] = useState('507');
  const [expenseSource, setExpenseSource] = useState<'101' | '104' | 'ewallet'>('101');
  const [selectedExpenseWalletId, setSelectedExpenseWalletId] = useState('');
  const [expenseAmount, setExpenseAmount] = useState<number>(0);
  const [expenseDate, setExpenseDate] = useState(new Date().toISOString().slice(0, 10));
  const [expenseMemo, setExpenseMemo] = useState('');

  // Form State - Mutasi Drawer ⇆ Bank
  const [transferType, setTransferType] = useState<'drawer_to_bank' | 'bank_to_drawer'>('drawer_to_bank');
  const [transferAmount, setTransferAmount] = useState<number>(0);
  const [transferDate, setTransferDate] = useState(new Date().toISOString().slice(0, 10));
  const [transferMemo, setTransferMemo] = useState('');

  // Form State - Setor Modal
  const [capitalDest, setCapitalDest] = useState<'101' | '104'>('101');
  const [capitalAmount, setCapitalAmount] = useState<number>(0);
  const [capitalDate, setCapitalDate] = useState(new Date().toISOString().slice(0, 10));
  const [capitalMemo, setCapitalMemo] = useState('');

  // Form State - Deposit E-Wallet
  const [depositWalletId, setDepositWalletId] = useState('');
  const [depositSource, setDepositSource] = useState<'101' | '104'>('101');
  const [depositAmount, setDepositAmount] = useState<number>(0);
  const [depositDate, setDepositDate] = useState(new Date().toISOString().slice(0, 10));
  const [depositMemo, setDepositMemo] = useState('');

  // Audit Log State
  const [journalSearch, setJournalSearch] = useState('');
  const [journalFilterType, setJournalFilterType] = useState<'all' | 'manual' | 'auto'>('all');
  const [selectedLedgerAccount, setSelectedLedgerAccount] = useState<string>('101');

  // Load manual journals
  const fetchManualJournals = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/accounting/journal');
      if (res.ok) {
        const data: JournalEntry[] = await res.json();
        // Manual journals are marked with isManual = true
        setManualJournalEntries(data.filter(entry => entry.isManual));
      }
    } catch (err) {
      console.error('Failed to load manual accounting logs:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchManualJournals();
  }, []);

  // AUTOMATIC SYNC IN MEMORY (No button click required, fully real-time)
  const journalEntries = useMemo(() => {
    const generated: JournalEntry[] = [];
    const allEvents: { date: string; type: 'capital' | 'txn' | 'history'; data: any }[] = [];

    // 1. Initial Capital Baseline
    const totalEWalletStarting = eWallets.reduce((acc, w) => acc + w.balance, 0);
    const totalInventoryStarting = products.reduce((acc, p) => acc + (p.stock * p.purchasePrice), 0);
    const totalCashStarting = shifts && shifts.length > 0
      ? shifts.reduce((acc, s) => acc + Number(s.initialCash || 0), 0)
      : 0;

    if (totalEWalletStarting > 0 || totalInventoryStarting > 0 || totalCashStarting > 0) {
      allEvents.push({
        date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
        type: 'capital',
        data: {
          ewallet: totalEWalletStarting,
          inventory: totalInventoryStarting,
          cash: totalCashStarting
        }
      });
    }

    // 2. Automated POS successful transactions
    transactions.forEach(t => {
      if (t.status === 'success') {
        allEvents.push({ date: t.date, type: 'txn', data: t });
      }
    });

    // 3. Digital Wallet manual mutasi logs (skip if has a transactionId, i.e., already POS, OR if it was created as a manual deposit)
    histories.forEach(h => {
      const isManualTopup = h.transactionId?.startsWith('manual-topup') || h.transactionId?.startsWith('je-wal-') || h.transactionId?.startsWith('JE-');
      if (!h.transactionId && !isManualTopup) {
        allEvents.push({ date: h.date, type: 'history', data: h });
      }
    });

    // Sort chronologically
    allEvents.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    // Generate accounting double-entries
    allEvents.forEach((event, index) => {
      const entryId = `AUTO-JE-${String(index + 1).padStart(5, '0')}`;

      if (event.type === 'capital') {
        const { cash, ewallet, inventory } = event.data;
        const lines: { accountCode: string; type: 'debit' | 'credit'; amount: number }[] = [];

        if (cash > 0) lines.push({ accountCode: '101', type: 'debit', amount: cash });
        if (ewallet > 0) lines.push({ accountCode: '102', type: 'debit', amount: ewallet });
        if (inventory > 0) lines.push({ accountCode: '103', type: 'debit', amount: inventory });

        const totalCapital = cash + ewallet + inventory;

        if (totalCapital > 0 && lines.length > 0) {
          lines.push({ accountCode: '301', type: 'credit', amount: totalCapital });

          generated.push({
            id: entryId,
            date: event.date,
            reference: 'MODAL-AWAL',
            description: 'Pencatatan Modal Awal Usaha (Sistem Otomatis)',
            isManual: false,
            lines: lines.map(line => ({
              accountCode: line.accountCode,
              accountName: CHART_OF_ACCOUNTS.find(a => a.code === line.accountCode)!.name,
              type: line.type,
              amount: line.amount
            }))
          });
        }
      }
      else if (event.type === 'txn') {
        const t: Transaction = event.data;
        const purchasePrice = t.items.reduce((acc, item) => acc + (item.purchasePrice * item.quantity), 0);
        const sellingPrice = t.totalAmount;
        const adminFee = t.adminFee || 0;

        const paymentMethod = t.items[0]?.paymentMethod || 'cash';
        const debitAccountCode = paymentMethod === 'transfer' ? '104' : '101';

        if (t.type === 'withdrawal') {
          // Tarik Tunai
          generated.push({
            id: entryId,
            date: t.date,
            reference: t.invoiceNumber,
            description: `Tarik Tunai via ${t.eWalletName} (Fee: Rp ${adminFee.toLocaleString('id-ID')})`,
            isManual: false,
            lines: [
              { accountCode: '102', type: 'debit' as const, amount: sellingPrice },
              { accountCode: '101', type: 'credit' as const, amount: sellingPrice - adminFee },
              { accountCode: '402', type: 'credit' as const, amount: adminFee }
            ].map(line => ({
              accountCode: line.accountCode,
              accountName: CHART_OF_ACCOUNTS.find(a => a.code === line.accountCode)!.name,
              type: line.type,
              amount: line.amount
            }))
          });
        }
        else {
          const isPhysical = t.type === 'physical';
          const creditSourceCode = isPhysical ? '103' : '102'; // Physical stock vs E-Wallet Balance

          const lines = [
            { accountCode: debitAccountCode, type: 'debit' as const, amount: sellingPrice + adminFee },
            { accountCode: '401', type: 'credit' as const, amount: sellingPrice }
          ];

          if (adminFee > 0) {
            lines.push({ accountCode: '402', type: 'credit' as const, amount: adminFee });
          }

          if (purchasePrice > 0) {
            lines.push({ accountCode: '501', type: 'debit' as const, amount: purchasePrice });
            lines.push({ accountCode: creditSourceCode, type: 'credit' as const, amount: purchasePrice });
          }

          generated.push({
            id: entryId,
            date: t.date,
            reference: t.invoiceNumber,
            description: `Penjualan ${isPhysical ? 'Fisik' : 'Digital'} (${t.invoiceNumber})`,
            isManual: false,
            lines: lines.map(line => ({
              accountCode: line.accountCode,
              accountName: CHART_OF_ACCOUNTS.find(a => a.code === line.accountCode)!.name,
              type: line.type,
              amount: line.amount
            }))
          });
        }
      }
      else if (event.type === 'history') {
        const h: EWalletHistory = event.data;
        const isDebit = h.type === 'debit';
        const isInitialDeposit = (h.description || '').toLowerCase().includes('deposit awal') ||
                                 (h.description || '').toLowerCase().includes('modal awal') ||
                                 (h.description || '').toLowerCase().includes('initial');

        const debitAccountCode = isDebit ? '102' : '101';
        const creditAccountCode = isDebit ? (isInitialDeposit ? '301' : '101') : '102';

        generated.push({
          id: entryId,
          date: h.date,
          reference: `MUT-${h.id.slice(0, 6).toUpperCase()}`,
          description: `Mutasi Saldo E-Wallet: ${h.description}`,
          isManual: false,
          lines: [
            { accountCode: debitAccountCode, type: 'debit' as const, amount: h.amount },
            { accountCode: creditAccountCode, type: 'credit' as const, amount: h.amount }
          ].map(line => ({
            accountCode: line.accountCode,
            accountName: CHART_OF_ACCOUNTS.find(a => a.code === line.accountCode)!.name,
            type: line.type,
            amount: line.amount
          }))
        });
      }
    });

    // Merge manual and auto-generated, sorted newest first
    return [...manualJournalEntries, ...generated].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [manualJournalEntries, transactions, eWallets, histories, products]);

  // Real-time dynamic double-entry ledger calculations
  const accountBalances = useMemo(() => {
    const balances: Record<string, number> = {};
    CHART_OF_ACCOUNTS.forEach(a => { balances[a.code] = 0; });

    journalEntries.forEach(entry => {
      entry.lines.forEach(line => {
        const coa = CHART_OF_ACCOUNTS.find(a => a.code === line.accountCode);
        if (!coa) return;

        const isDebit = line.type === 'debit';
        const isNormalDebit = coa.normalBalance === 'Debit';

        if (isNormalDebit) {
          balances[coa.code] += isDebit ? line.amount : -line.amount;
        } else {
          balances[coa.code] += isDebit ? -line.amount : line.amount;
        }
      });
    });

    return balances;
  }, [journalEntries]);

  // Helper values for simple dashboard
  const kasTunai = accountBalances['101'] || 0;
  const saldoEWallet = accountBalances['102'] || 0;
  const nilaiStok = accountBalances['103'] || 0;
  const saldoBank = accountBalances['104'] || 0;
  const totalModal = (accountBalances['301'] || 0) + (accountBalances['302'] || 0);
  const totalAset = kasTunai + saldoEWallet + nilaiStok + saldoBank;

  const currentMonth = new Date().toISOString().slice(0, 7);
  const monthlyExpenses = useMemo(() => {
    return journalEntries.reduce((acc, entry) => {
      if (entry.date.slice(0, 7) !== currentMonth) return acc;
      const expenseLineTotal = entry.lines.reduce((lAcc, line) => {
        if (line.accountCode.startsWith('5') && line.type === 'debit') {
          return lAcc + line.amount;
        }
        return lAcc;
      }, 0);
      return acc + expenseLineTotal;
    }, 0);
  }, [journalEntries]);

  const labaBersih = useMemo(() => {
    let revenue = 0;
    let expense = 0;
    journalEntries.forEach(entry => {
      entry.lines.forEach(line => {
        if (line.accountCode.startsWith('4')) {
          revenue += line.type === 'credit' ? line.amount : -line.amount;
        } else if (line.accountCode.startsWith('5')) {
          expense += line.type === 'debit' ? line.amount : -line.amount;
        }
      });
    });
    return revenue - expense;
  }, [journalEntries]);

  // Show status updates
  const triggerSuccess = (msg: string) => {
    setSuccessMessage(msg);
    setTimeout(() => setSuccessMessage(null), 4000);
  };

  // 1. Submit Manual Expense (Catat Biaya)
  const handleSaveExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (expenseAmount <= 0) return;

    const expenseName = CHART_OF_ACCOUNTS.find(a => a.code === expenseAccount)!.name;
    let creditCode = '101'; // Default Kas laci
    let creditName = 'Kas di Drawer (Laci Kasir)';

    if (expenseSource === '104') {
      creditCode = '104';
      creditName = 'Saldo Rekening Bank';
    } else if (expenseSource === 'ewallet') {
      creditCode = '102';
      const w = eWallets.find(wallet => wallet.id === selectedExpenseWalletId);
      creditName = w ? `Saldo E-Wallet (${w.name})` : 'Saldo E-Wallet Agen';
    }

    const newEntryId = `JE-EXP-${Date.now().toString().slice(-5)}`;

    const newEntry: JournalEntry = {
      id: newEntryId,
      date: expenseDate,
      reference: 'PENGELUARAN',
      description: expenseMemo || `Pembayaran beban: ${expenseName}`,
      isManual: true,
      lines: [
        { accountCode: expenseAccount, accountName: expenseName, type: 'debit', amount: expenseAmount },
        { accountCode: creditCode, accountName: creditName, type: 'credit', amount: expenseAmount }
      ]
    };

    try {
      // 1. Save journal entry to backend
      const res = await fetch('/api/accounting/journal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newEntry)
      });

      if (res.ok) {
        // 2. If E-Wallet payment source, update e-wallet balance and history in the DB
        if (expenseSource === 'ewallet' && selectedExpenseWalletId) {
          const targetWallet = eWallets.find(w => w.id === selectedExpenseWalletId);
          if (targetWallet) {
            const newHist = {
              id: `ewh-exp-${Date.now()}`,
              eWalletId: selectedExpenseWalletId,
              eWalletName: targetWallet.name,
              amount: expenseAmount,
              type: 'credit',
              transactionId: newEntryId, // Link to prevent auto-sync double counting
              description: expenseMemo || `Pembayaran beban ${expenseName}`
            };

            await fetch('/api/ewallet-histories', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(newHist)
            });

            const newBalance = Number(targetWallet.balance) - expenseAmount;
            await fetch(`/api/ewallets/${selectedExpenseWalletId}`, {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ ...targetWallet, balance: newBalance })
            });
          }
        }

        setManualJournalEntries(prev => [newEntry, ...prev]);
        setExpenseAmount(0);
        setExpenseMemo('');
        triggerSuccess(`✓ Beban ${expenseName} sebesar Rp ${expenseAmount.toLocaleString('id-ID')} berhasil dicatat!`);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // 2. Submit Mutasi Kas / Internal Bank Transfer
  const handleSaveTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (transferAmount <= 0) return;

    const source = transferType === 'drawer_to_bank' ? '101' : '104';
    const dest = transferType === 'drawer_to_bank' ? '104' : '101';

    const sourceName = CHART_OF_ACCOUNTS.find(a => a.code === source)!.name;
    const destName = CHART_OF_ACCOUNTS.find(a => a.code === dest)!.name;

    const newEntry: JournalEntry = {
      id: `JE-TX-${Date.now().toString().slice(-5)}`,
      date: transferDate,
      reference: 'MUTASI-KAS-BANK',
      description: transferMemo || `Mutasi dana internal dari ${sourceName} ke ${destName}`,
      isManual: true,
      lines: [
        { accountCode: dest, accountName: destName, type: 'debit', amount: transferAmount },
        { accountCode: source, accountName: sourceName, type: 'credit', amount: transferAmount }
      ]
    };

    try {
      const res = await fetch('/api/accounting/journal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newEntry)
      });
      if (res.ok) {
        setManualJournalEntries(prev => [newEntry, ...prev]);
        setTransferAmount(0);
        setTransferMemo('');
        triggerSuccess('✓ Mutasi internal kas dan rekening bank berhasil disimpan!');
      }
    } catch (err) {
      console.error(err);
    }
  };

  // 3. Submit Setor Modal Pemilik
  const handleSaveCapital = async (e: React.FormEvent) => {
    e.preventDefault();
    if (capitalAmount <= 0) return;

    const destName = CHART_OF_ACCOUNTS.find(a => a.code === capitalDest)!.name;

    const newEntry: JournalEntry = {
      id: `JE-CAP-${Date.now().toString().slice(-5)}`,
      date: capitalDate,
      reference: 'SETOR-MODAL',
      description: capitalMemo || `Penyetoran Modal Pemilik ke ${destName}`,
      isManual: true,
      lines: [
        { accountCode: capitalDest, accountName: destName, type: 'debit', amount: capitalAmount },
        { accountCode: '301', accountName: 'Modal Pemilik', type: 'credit', amount: capitalAmount }
      ]
    };

    try {
      const res = await fetch('/api/accounting/journal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newEntry)
      });
      if (res.ok) {
        setManualJournalEntries(prev => [newEntry, ...prev]);
        setCapitalAmount(0);
        setCapitalMemo('');
        triggerSuccess(`✓ Penyetoran modal usaha sebesar Rp ${capitalAmount.toLocaleString('id-ID')} dicatat!`);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // 4. Submit Deposit E-Wallet (Isi Saldo Agen)
  const handleSaveDepositEWallet = async (e: React.FormEvent) => {
    e.preventDefault();
    if (depositAmount <= 0 || !depositWalletId) return;

    const targetWallet = eWallets.find(w => w.id === depositWalletId);
    if (!targetWallet) return;

    const sourceName = CHART_OF_ACCOUNTS.find(a => a.code === depositSource)!.name;
    const entryId = `JE-WAL-${Date.now().toString().slice(-5)}`;

    try {
      // 1. Record E-Wallet history log
      const newHistoryLog = {
        id: `ewh-acc-${Date.now()}`,
        eWalletId: depositWalletId,
        eWalletName: targetWallet.name,
        amount: depositAmount,
        type: 'debit',
        transactionId: entryId, // Marked with entryId so auto-sync ignores it!
        description: depositMemo || `Top Up saldo ${targetWallet.name} didanai oleh ${sourceName}`
      };

      await fetch('/api/ewallet-histories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newHistoryLog)
      });

      // 2. Put updated wallet balance
      const newBalance = Number(targetWallet.balance) + depositAmount;
      await fetch(`/api/ewallets/${depositWalletId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...targetWallet, balance: newBalance })
      });

      // 3. Post double-entry manual journal entries
      const newEntry: JournalEntry = {
        id: entryId,
        date: depositDate,
        reference: 'DEPOSIT-EWALLET',
        description: depositMemo || `Pengisian saldo ${targetWallet.name} didanai oleh ${sourceName}`,
        isManual: true,
        lines: [
          { accountCode: '102', accountName: 'Saldo E-Wallet Agen', type: 'debit', amount: depositAmount },
          { accountCode: depositSource, accountName: sourceName, type: 'credit', amount: depositAmount }
        ]
      };

      await fetch('/api/accounting/journal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newEntry)
      });

      setManualJournalEntries(prev => [newEntry, ...prev]);
      setDepositAmount(0);
      setDepositMemo('');
      triggerSuccess(`✓ Berhasil mengisi saldo ${targetWallet.name} sebesar Rp ${depositAmount.toLocaleString('id-ID')}!`);
    } catch (err) {
      console.error('Failed to process wallet top-up:', err);
    }
  };

  // Clear Accounting Data - Developer Safety Override
  const handleClearAllJournals = async () => {
    if (!window.confirm('PERINGATAN KRITIS: Apakah Anda yakin ingin menghapus seluruh pembukuan manual (Beban, Setoran, Transfer)? Tindakan ini tidak dapat dibatalkan.')) return;

    try {
      const res = await fetch('/api/accounting/journal', { method: 'DELETE' });
      if (res.ok) {
        setManualJournalEntries([]);
        triggerSuccess('✓ Seluruh data pembukuan manual berhasil dikosongkan!');
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Print PDF
  const handleExportPDF = (type: 'income' | 'balance' | 'cash_flow') => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Pop-up terblokir! Izinkan pop-up untuk mencetak laporan.');
      return;
    }

    const title = type === 'income' ? 'Laporan Laba Rugi' : type === 'balance' ? 'Laporan Neraca' : 'Laporan Arus Kas';
    let contentHtml = '';

    if (type === 'income') {
      const expTotal = CHART_OF_ACCOUNTS.filter(a => a.code.startsWith('5')).reduce((sum, current) => sum + (accountBalances[current.code] || 0), 0);
      contentHtml = `
        <table class="report-table">
          <thead>
            <tr>
              <th>URAIAN REKENING</th>
              <th class="text-right">JUMLAH (RP)</th>
            </tr>
          </thead>
          <tbody>
            <tr class="section-title"><td colspan="2">I. PENDAPATAN OPERASIONAL</td></tr>
            <tr><td>Pendapatan Penjualan</td><td class="text-right">${(accountBalances['401'] || 0).toLocaleString('id-ID')}</td></tr>
            <tr><td>Pendapatan Jasa & Komisi Agen</td><td class="text-right">${(accountBalances['402'] || 0).toLocaleString('id-ID')}</td></tr>
            <tr class="total-row"><td>TOTAL PENDAPATAN</td><td class="text-right">${((accountBalances['401'] || 0) + (accountBalances['402'] || 0)).toLocaleString('id-ID')}</td></tr>
            
            <tr class="section-title"><td colspan="2">II. HARGA POKOK & BEBAN OPERASIONAL</td></tr>
            <tr><td>Harga Pokok Penjualan (HPP)</td><td class="text-right">(${(accountBalances['501'] || 0).toLocaleString('id-ID')})</td></tr>
            <tr><td>Beban Selisih Kas Shift (Laci Kasir)</td><td class="text-right">${(accountBalances['502'] || 0).toLocaleString('id-ID')}</td></tr>
            <tr><td>Beban Diskon & Promosi</td><td class="text-right">${(accountBalances['503'] || 0).toLocaleString('id-ID')}</td></tr>
            <tr><td>Beban Listrik & Internet Konter</td><td class="text-right">${(accountBalances['504'] || 0).toLocaleString('id-ID')}</td></tr>
            <tr><td>Beban Sewa Konter Fisik</td><td class="text-right">${(accountBalances['505'] || 0).toLocaleString('id-ID')}</td></tr>
            <tr><td>Beban Gaji & Operator Kasir</td><td class="text-right">${(accountBalances['506'] || 0).toLocaleString('id-ID')}</td></tr>
            <tr><td>Beban Operasional Lainnya</td><td class="text-right">${(accountBalances['507'] || 0).toLocaleString('id-ID')}</td></tr>
            <tr class="total-row"><td>TOTAL BEBAN PENGELUARAN</td><td class="text-right">(${expTotal.toLocaleString('id-ID')})</td></tr>
            
            <tr class="net-profit-row"><td>LABA BERSIH OPERASIONAL (NET PROFIT)</td><td class="text-right">Rp ${labaBersih.toLocaleString('id-ID')}</td></tr>
          </tbody>
        </table>
      `;
    } 
    else if (type === 'balance') {
      contentHtml = `
        <table class="report-table">
          <thead>
            <tr>
              <th>AKTIVA (ASET / HARTA)</th>
              <th class="text-right">NOMINAL (RP)</th>
              <th>PASIVA (UTANG & MODAL)</th>
              <th class="text-right">NOMINAL (RP)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Kas di Drawer (Laci Kasir)</td>
              <td class="text-right">${kasTunai.toLocaleString('id-ID')}</td>
              <td>Kewajiban / Utang Usaha</td>
              <td class="text-right">0</td>
            </tr>
            <tr>
              <td>Saldo E-Wallet Agen</td>
              <td class="text-right">${saldoEWallet.toLocaleString('id-ID')}</td>
              <td>Modal Pemilik</td>
              <td class="text-right">${(accountBalances['301'] || 0).toLocaleString('id-ID')}</td>
            </tr>
            <tr>
              <td>Saldo Rekening Bank</td>
              <td class="text-right">${saldoBank.toLocaleString('id-ID')}</td>
              <td>Laba Ditahan</td>
              <td class="text-right">${(accountBalances['302'] || 0).toLocaleString('id-ID')}</td>
            </tr>
            <tr>
              <td>Persediaan Barang Dagang</td>
              <td class="text-right">${nilaiStok.toLocaleString('id-ID')}</td>
              <td>Laba Tahun Berjalan</td>
              <td class="text-right">${labaBersih.toLocaleString('id-ID')}</td>
            </tr>
            <tr class="total-row">
              <td>TOTAL AKTIVA (ASET)</td>
              <td class="text-right">Rp ${totalAset.toLocaleString('id-ID')}</td>
              <td>TOTAL PASIVA & MODAL</td>
              <td class="text-right">Rp ${totalAset.toLocaleString('id-ID')}</td>
            </tr>
          </tbody>
        </table>
      `;
    } 
    else if (type === 'cash_flow') {
      const opInflows = journalEntries.filter(e => e.reference !== 'SETOR-MODAL' && e.reference !== 'MODAL-AWAL').reduce((sum, entry) => {
        return sum + entry.lines.reduce((lSum, l) => (l.type === 'debit' && (l.accountCode === '101' || l.accountCode === '104')) ? lSum + l.amount : lSum, 0);
      }, 0);

      const opOutflows = journalEntries.reduce((sum, entry) => {
        return sum + entry.lines.reduce((lSum, l) => (l.type === 'credit' && (l.accountCode === '101' || l.accountCode === '104') && !entry.lines.some(cl => cl.accountCode === '102' || cl.accountCode === '301')) ? lSum + l.amount : lSum, 0);
      }, 0);

      const finInflows = journalEntries.filter(e => e.reference === 'SETOR-MODAL' || e.reference === 'MODAL-AWAL').reduce((sum, entry) => {
        return sum + entry.lines.reduce((lSum, l) => (l.type === 'debit' && (l.accountCode === '101' || l.accountCode === '104')) ? lSum + l.amount : lSum, 0);
      }, 0);

      const netFlow = (opInflows - opOutflows) + finInflows;

      contentHtml = `
        <table class="report-table">
          <thead>
            <tr>
              <th>URAIAN ARUS KAS</th>
              <th class="text-right">JUMLAH NOMINAL (RP)</th>
            </tr>
          </thead>
          <tbody>
            <tr class="section-title"><td colspan="2">I. ARUS KAS DARI AKTIVITAS OPERASIONAL</td></tr>
            <tr><td>Penerimaan Kas dari Pelanggan / Sales</td><td class="text-right">${opInflows.toLocaleString('id-ID')}</td></tr>
            <tr><td>Pengeluaran Kas untuk Pembelian & Operasional</td><td class="text-right">(${(opOutflows).toLocaleString('id-ID')})</td></tr>
            <tr class="total-row"><td>Kas Bersih dari Aktivitas Operasional</td><td class="text-right">${(opInflows - opOutflows).toLocaleString('id-ID')}</td></tr>
            
            <tr class="section-title"><td colspan="2">II. ARUS KAS DARI AKTIVITAS FINANSIAL / PENDANAAN</td></tr>
            <tr><td>Setoran Modal Pemilik Baru</td><td class="text-right">${finInflows.toLocaleString('id-ID')}</td></tr>
            <tr class="total-row"><td>Kas Bersih dari Aktivitas Pendanaan</td><td class="text-right">${finInflows.toLocaleString('id-ID')}</td></tr>
            
            <tr class="net-profit-row"><td>KENAIKAN KAS BERSIH (NET CHANGE)</td><td class="text-right">Rp ${netFlow.toLocaleString('id-ID')}</td></tr>
            <tr><td style="font-weight: bold; padding-top: 15px;">Kas Pada Akhir Periode</td><td class="text-right" style="font-weight: bold; padding-top: 15px;">Rp ${(kasTunai + saldoBank).toLocaleString('id-ID')}</td></tr>
          </tbody>
        </table>
      `;
    }

    printWindow.document.write(`
      <html>
        <head>
          <title>${title}</title>
          <style>
            body {
              font-family: 'Courier New', Courier, monospace;
              padding: 40px;
              color: #1a1a1a;
              line-height: 1.4;
            }
            .header {
              text-align: center;
              border-bottom: 2px double #333;
              padding-bottom: 15px;
              margin-bottom: 30px;
            }
            .header h1 {
              font-size: 24px;
              margin: 0;
              font-weight: 900;
              letter-spacing: 1px;
            }
            .header h2 {
              font-size: 14px;
              margin: 5px 0 0 0;
              color: #555;
            }
            .header p {
              font-size: 11px;
              margin: 3px 0 0 0;
              color: #888;
            }
            .report-table {
              width: 100%;
              border-collapse: collapse;
              font-size: 12px;
            }
            .report-table th {
              border-bottom: 2px solid #333;
              padding: 8px;
              text-align: left;
              font-weight: bold;
            }
            .report-table td {
              padding: 6px 8px;
            }
            .section-title td {
              font-weight: bold;
              padding-top: 15px;
              border-bottom: 1px solid #ddd;
              text-transform: uppercase;
            }
            .total-row td {
              border-top: 1px dashed #333;
              border-bottom: 1px solid #333;
              font-weight: bold;
            }
            .net-profit-row td {
              border-top: 2px solid #333;
              border-bottom: 2px solid #333;
              font-weight: 900;
              font-size: 13px;
              background-color: #f5f5f5;
              padding: 10px 8px;
            }
            .text-right {
              text-align: right;
            }
            .footer-sig {
              margin-top: 60px;
              display: flex;
              justify-content: space-between;
              font-size: 11px;
            }
            .footer-sig .sig-box {
              text-align: center;
              width: 150px;
            }
            .footer-sig .sig-line {
              margin-top: 60px;
              border-top: 1px solid #333;
              font-weight: bold;
              padding-top: 5px;
            }
            @media print {
              body { margin: 20px; }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>MD CELLULAR</h1>
            <h2>${title.toUpperCase()}</h2>
            <p>Periode s/d ${new Date().toLocaleDateString('id-ID')}</p>
          </div>
          ${contentHtml}
          <div class="footer-sig">
            <div class="sig-box">
              <p>Dibuat Oleh,</p>
              <div class="sig-line">Operator Kasir</div>
            </div>
            <div class="sig-box">
              <p>Mengetahui,</p>
              <div class="sig-line">Pemilik (Admin)</div>
            </div>
          </div>
          <script>
            window.onload = function() {
              window.print();
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  // Export Financial Statements to Excel
  const handleExportExcel = () => {
    const wb = XLSX.utils.book_new();

    // 1. Income Statement Sheet
    const incomeRows = [
      ['LAPORAN LABA RUGI KONTER MD CELL'],
      [`Periode s/d ${new Date().toLocaleDateString('id-ID')}`],
      [],
      ['PENDAPATAN'],
      ['Pendapatan Penjualan', accountBalances['401'] || 0],
      ['Pendapatan Jasa & Komisi', accountBalances['402'] || 0],
      ['TOTAL PENDAPATAN', (accountBalances['401'] || 0) + (accountBalances['402'] || 0)],
      [],
      ['HARGA POKOK & BEBAN PENGELUARAN'],
      ['Harga Pokok Penjualan (HPP)', accountBalances['501'] || 0],
      ['Beban Selisih Kas Shift', accountBalances['502'] || 0],
      ['Beban Diskon & Promosi', accountBalances['503'] || 0],
      ['Beban Listrik & Internet', accountBalances['504'] || 0],
      ['Beban Sewa Konter', accountBalances['505'] || 0],
      ['Beban Gaji & Operator', accountBalances['506'] || 0],
      ['Beban Operasional Lain', accountBalances['507'] || 0],
      ['TOTAL BEBAN PENGELUARAN', CHART_OF_ACCOUNTS.filter(a => a.code.startsWith('5')).reduce((sum, current) => sum + (accountBalances[current.code] || 0), 0)],
      [],
      ['LABA BERSIH USAHA', labaBersih]
    ];
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(incomeRows), 'Laba Rugi');

    // 2. Balance Sheet Sheet
    const balanceRows = [
      ['LAPORAN NERACA KEUANGAN MD CELL'],
      [`Per Tanggal ${new Date().toLocaleDateString('id-ID')}`],
      [],
      ['AKTIVA (ASET)', '', 'PASIVA (UTANG & MODAL)'],
      ['Kas Tunai Drawer', kasTunai, 'Kewajiban / Utang Usaha', 0],
      ['Saldo E-Wallet Agen', saldoEWallet, 'Modal Pemilik', accountBalances['301'] || 0],
      ['Saldo Rekening Bank', saldoBank, 'Laba Ditahan', accountBalances['302'] || 0],
      ['Persediaan Barang Dagang', nilaiStok, 'Laba Tahun Berjalan', labaBersih],
      ['TOTAL AKTIVA (ASET)', totalAset, 'TOTAL PASIVA & MODAL', totalAset]
    ];
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(balanceRows), 'Neraca');

    XLSX.writeFile(wb, `Laporan-Keuangan-MDCELL-${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  // Filter journal logs for audit trail
  const filteredJournals = useMemo(() => {
    return journalEntries.filter(entry => {
      if (journalFilterType === 'manual' && !entry.isManual) return false;
      if (journalFilterType === 'auto' && entry.isManual) return false;

      if (!journalSearch) return true;
      const query = journalSearch.toLowerCase();
      return (
        entry.id.toLowerCase().includes(query) ||
        entry.reference.toLowerCase().includes(query) ||
        entry.description.toLowerCase().includes(query) ||
        entry.lines.some(l => l.accountName.toLowerCase().includes(query) || l.accountCode.includes(query))
      );
    });
  }, [journalEntries, journalSearch, journalFilterType]);

  // Calculate Ledger Ledger details
  const ledgerLinesForSelectedAccount = useMemo(() => {
    let balanceAccumulator = 0;
    const coa = CHART_OF_ACCOUNTS.find(a => a.code === selectedLedgerAccount);
    if (!coa) return [];

    const isNormalDebit = coa.normalBalance === 'Debit';

    const list = [...journalEntries]
      .reverse() // Sort chronologically to accumulate balance forward
      .flatMap(entry => {
        return entry.lines
          .filter(line => line.accountCode === selectedLedgerAccount)
          .map(line => {
            const isDebit = line.type === 'debit';
            let change = line.amount;
            if (isNormalDebit) {
              balanceAccumulator += isDebit ? change : -change;
            } else {
              balanceAccumulator += isDebit ? -change : change;
            }

            return {
              entryId: entry.id,
              date: entry.date,
              reference: entry.reference,
              description: entry.description,
              type: line.type,
              amount: line.amount,
              runningBalance: balanceAccumulator
            };
          });
      });

    return list.reverse(); // Newest first for rendering
  }, [journalEntries, selectedLedgerAccount]);

  return (
    <div id="pembukuan-dashboard-container" className="p-4 lg:p-6 max-w-7xl mx-auto space-y-6 w-full">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white dark:bg-slate-900 p-6 rounded-[20px] border border-slate-150 dark:border-slate-800 shadow-sm transition-colors duration-200">
        <div>
          <div className="flex items-center space-x-2 text-indigo-600 dark:text-indigo-400 font-extrabold text-xs uppercase tracking-wider mb-1">
            <ShieldCheck className="w-4 h-4" />
            <span>Sistem Pembukuan Otomatis (Double-Entry Ledger)</span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight">PEMBUKUAN KEUANGAN</h1>
          <p className="text-slate-500 dark:text-slate-400 text-xs font-medium mt-1">
            Laporan Keuangan, Rugi Laba, Neraca, Mutasi Kas, dan Jurnal Audit terintegrasi POS otomatis.
          </p>
        </div>

        <div className="flex items-center space-x-2 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-400 px-4 py-2.5 rounded-[16px] border border-emerald-100 dark:border-emerald-900/40 text-xs font-bold animate-fadeIn">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse inline-block mr-1.5" />
          <span>Real-Time POS Sync Aktif</span>
        </div>
      </div>

      {/* Success Notification */}
      {successMessage && (
        <div className="bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40 text-emerald-800 dark:text-emerald-400 p-4 rounded-[16px] flex items-center space-x-3 text-xs font-extrabold animate-bounce shadow-sm">
          <Check className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Primary Tab Navigation */}
      <div className="flex space-x-1.5 bg-slate-100 dark:bg-slate-800/40 p-1 rounded-[16px] w-full sm:w-max">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex items-center space-x-2 px-5 py-3 text-xs font-extrabold rounded-xl transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'dashboard'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
              : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/60'
          }`}
        >
          <Layers className="w-4 h-4 text-indigo-500" />
          <span>Ringkasan & Laporan Keuangan</span>
        </button>

        <button
          onClick={() => setActiveTab('entry')}
          className={`flex items-center space-x-2 px-5 py-3 text-xs font-extrabold rounded-xl transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'entry'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
              : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/60'
          }`}
        >
          <Plus className="w-4 h-4 text-emerald-500" />
          <span>Catat Mutasi & Biaya Manual</span>
        </button>

        <button
          onClick={() => setActiveTab('ledger')}
          className={`flex items-center space-x-2 px-5 py-3 text-xs font-extrabold rounded-xl transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'ledger'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
              : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/60'
          }`}
        >
          <BookOpen className="w-4 h-4 text-sky-500" />
          <span>Jurnal Umum & Buku Besar</span>
        </button>
      </div>

      {/* TAB 1: DASHBOARD & FINANCIAL STATEMENTS */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          {/* Quick Stats Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-[20px] border border-slate-150 dark:border-slate-800 shadow-xs flex items-center space-x-4 transition-colors">
              <div className="p-3 bg-indigo-50 dark:bg-indigo-950/30 text-indigo-600 dark:text-indigo-400 rounded-[16px]">
                <Coins className="w-6 h-6" />
              </div>
              <div>
                <p className="text-slate-400 dark:text-slate-500 text-[10px] font-bold uppercase tracking-wider">Kas di Laci</p>
                <h3 className="text-base sm:text-lg font-black text-slate-800 dark:text-slate-200 mt-0.5">
                  Rp {kasTunai.toLocaleString('id-ID')}
                </h3>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-5 rounded-[20px] border border-slate-150 dark:border-slate-800 shadow-xs flex items-center space-x-4 transition-colors">
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 rounded-[16px]">
                <CreditCard className="w-6 h-6" />
              </div>
              <div>
                <p className="text-slate-400 dark:text-slate-500 text-[10px] font-bold uppercase tracking-wider">Saldo Rek Bank</p>
                <h3 className="text-base sm:text-lg font-black text-slate-800 dark:text-slate-200 mt-0.5">
                  Rp {saldoBank.toLocaleString('id-ID')}
                </h3>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-5 rounded-[20px] border border-slate-150 dark:border-slate-800 shadow-xs flex items-center space-x-4 transition-colors">
              <div className="p-3 bg-amber-50 dark:bg-amber-950/30 text-amber-600 dark:text-amber-400 rounded-[16px]">
                <Wallet className="w-6 h-6" />
              </div>
              <div>
                <p className="text-slate-400 dark:text-slate-500 text-[10px] font-bold uppercase tracking-wider">Saldo E-Wallet Agen</p>
                <h3 className="text-base sm:text-lg font-black text-slate-800 dark:text-slate-200 mt-0.5">
                  Rp {saldoEWallet.toLocaleString('id-ID')}
                </h3>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-5 rounded-[20px] border border-slate-150 dark:border-slate-800 shadow-xs flex items-center space-x-4 transition-colors">
              <div className="p-3 bg-pink-50 dark:bg-pink-950/30 text-pink-600 dark:text-pink-400 rounded-[16px]">
                <Layers className="w-6 h-6" />
              </div>
              <div>
                <p className="text-slate-400 dark:text-slate-500 text-[10px] font-bold uppercase tracking-wider">Nilai Stok Barang</p>
                <h3 className="text-base sm:text-lg font-black text-slate-800 dark:text-slate-200 mt-0.5">
                  Rp {nilaiStok.toLocaleString('id-ID')}
                </h3>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-[20px] border border-slate-150 dark:border-slate-800 shadow-xs flex items-center space-x-4 transition-colors">
              <div className="p-3 bg-teal-50 dark:bg-teal-950/30 text-teal-600 dark:text-teal-400 rounded-[16px]">
                <Building className="w-6 h-6" />
              </div>
              <div>
                <p className="text-slate-400 dark:text-slate-500 text-[10px] font-bold uppercase tracking-wider">Total Aset Bersih</p>
                <h3 className="text-base sm:text-lg font-black text-slate-800 dark:text-slate-200 mt-0.5">
                  Rp {totalAset.toLocaleString('id-ID')}
                </h3>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-5 rounded-[20px] border border-slate-150 dark:border-slate-800 shadow-xs flex items-center space-x-4 transition-colors">
              <div className="p-3 bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-400 rounded-[16px]">
                <TrendingDown className="w-6 h-6" />
              </div>
              <div>
                <p className="text-slate-400 dark:text-slate-500 text-[10px] font-bold uppercase tracking-wider">Biaya Bulan Ini</p>
                <h3 className="text-base sm:text-lg font-black text-slate-800 dark:text-slate-200 mt-0.5">
                  Rp {monthlyExpenses.toLocaleString('id-ID')}
                </h3>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-5 rounded-[20px] border border-slate-150 dark:border-slate-800 shadow-xs flex items-center space-x-4 transition-colors col-span-2">
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 rounded-[16px]">
                <TrendingUp className="w-6 h-6" />
              </div>
              <div className="flex-1 flex justify-between items-center">
                <div>
                  <p className="text-slate-400 dark:text-slate-500 text-[10px] font-bold uppercase tracking-wider">Akumulasi Laba Bersih</p>
                  <h3 className="text-base sm:text-lg font-black text-emerald-600 dark:text-emerald-400 mt-0.5">
                    Rp {labaBersih.toLocaleString('id-ID')}
                  </h3>
                </div>
                <span className="text-[10px] px-2.5 py-1 bg-emerald-100 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-400 rounded-full font-extrabold uppercase">
                  Tertahan
                </span>
              </div>
            </div>
          </div>

          {/* Detailed Financial Statements Panel */}
          <div className="bg-white dark:bg-slate-900 rounded-[20px] border border-slate-150 dark:border-slate-800 p-6 shadow-sm space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 dark:border-slate-800 pb-5">
              <div>
                <h2 className="text-lg font-extrabold text-slate-900 dark:text-slate-100">Laporan Keuangan Standar Akuntansi</h2>
                <p className="text-slate-400 text-xs mt-0.5 font-medium">Lihat, cetak, atau ekspor laporan keuangan konter Anda kapan saja secara real-time.</p>
              </div>

              <div className="flex flex-wrap gap-2 w-full md:w-auto">
                <button
                  onClick={() => handleExportPDF(reportType)}
                  className="flex items-center space-x-1.5 px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold cursor-pointer transition-all"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Cetak PDF</span>
                </button>

                <button
                  onClick={handleExportExcel}
                  className="flex items-center space-x-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold cursor-pointer transition-all"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Ekspor Excel</span>
                </button>
              </div>
            </div>

            {/* Financial Statement Tabs */}
            <div className="flex space-x-2 bg-slate-50 dark:bg-slate-800/20 p-1 rounded-xl w-full sm:w-max">
              {[
                { id: 'income', name: 'Laba Rugi (Income Statement)' },
                { id: 'balance', name: 'Neraca Keuangan (Balance Sheet)' },
                { id: 'cash_flow', name: 'Arus Kas (Cash Flow)' }
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => setReportType(item.id as any)}
                  className={`px-3 py-2 text-xs font-extrabold rounded-lg cursor-pointer whitespace-nowrap transition-all ${
                    reportType === item.id
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-500 hover:text-slate-700 dark:text-slate-400'
                  }`}
                >
                  {item.name}
                </button>
              ))}
            </div>

            {/* Income Statement View */}
            {reportType === 'income' && (
              <div className="border border-slate-100 dark:border-slate-800 rounded-[16px] p-6 bg-slate-50/50 dark:bg-slate-900/40 space-y-4">
                <div className="text-center pb-4 border-b border-slate-200 dark:border-slate-800">
                  <h3 className="font-extrabold text-slate-800 dark:text-slate-200 text-sm">LAPORAN LABA RUGI</h3>
                  <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-wider font-semibold">Periode Keuangan s/d {new Date().toLocaleDateString('id-ID')}</p>
                </div>

                <div className="space-y-4 text-xs">
                  {/* Revenue Section */}
                  <div>
                    <h4 className="font-black text-slate-400 uppercase text-[10px] tracking-wider mb-2">1. Pendapatan Operasional</h4>
                    <div className="space-y-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                      <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                        <span>Pendapatan Penjualan Barang & Jasa (401)</span>
                        <span>Rp {(accountBalances['401'] || 0).toLocaleString('id-ID')}</span>
                      </div>
                      <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                        <span>Pendapatan Jasa & Komisi Agen E-Wallet (402)</span>
                        <span>Rp {(accountBalances['402'] || 0).toLocaleString('id-ID')}</span>
                      </div>
                      <div className="flex justify-between font-extrabold text-slate-900 dark:text-slate-100 pt-1">
                        <span>TOTAL PENDAPATAN OPERASIONAL</span>
                        <span>Rp {((accountBalances['401'] || 0) + (accountBalances['402'] || 0)).toLocaleString('id-ID')}</span>
                      </div>
                    </div>
                  </div>

                  {/* Expenses Section */}
                  <div>
                    <h4 className="font-black text-slate-400 uppercase text-[10px] tracking-wider mb-2">2. Harga Pokok & Beban Operasional</h4>
                    <div className="space-y-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                      <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                        <span>Harga Pokok Penjualan - HPP (501)</span>
                        <span className="text-rose-500">Rp {(accountBalances['501'] || 0).toLocaleString('id-ID')}</span>
                      </div>
                      <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                        <span>Beban Selisih Kas Hasil Shift (502)</span>
                        <span>Rp {(accountBalances['502'] || 0).toLocaleString('id-ID')}</span>
                      </div>
                      <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                        <span>Beban Diskon & Promosi (503)</span>
                        <span>Rp {(accountBalances['503'] || 0).toLocaleString('id-ID')}</span>
                      </div>
                      <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                        <span>Beban Listrik & Internet Konter (504)</span>
                        <span>Rp {(accountBalances['504'] || 0).toLocaleString('id-ID')}</span>
                      </div>
                      <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                        <span>Beban Sewa Konter (505)</span>
                        <span>Rp {(accountBalances['505'] || 0).toLocaleString('id-ID')}</span>
                      </div>
                      <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                        <span>Beban Gaji Operator & Karyawan (506)</span>
                        <span>Rp {(accountBalances['506'] || 0).toLocaleString('id-ID')}</span>
                      </div>
                      <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                        <span>Beban Operasional Lainnya (507)</span>
                        <span>Rp {(accountBalances['507'] || 0).toLocaleString('id-ID')}</span>
                      </div>
                      <div className="flex justify-between font-extrabold text-slate-900 dark:text-slate-100 pt-1">
                        <span>TOTAL BEBAN OPERASIONAL</span>
                        <span className="text-rose-500">
                          Rp {CHART_OF_ACCOUNTS.filter(a => a.code.startsWith('5')).reduce((sum, current) => sum + (accountBalances[current.code] || 0), 0).toLocaleString('id-ID')}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Net Profit Summary */}
                  <div className="flex justify-between p-4 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/40 rounded-[16px] text-emerald-800 dark:text-emerald-400 font-black text-sm">
                    <span>LABA BERSIH OPERASIONAL (NET PROFIT)</span>
                    <span>Rp {labaBersih.toLocaleString('id-ID')}</span>
                  </div>
                </div>
              </div>
            )}

            {/* Balance Sheet View */}
            {reportType === 'balance' && (
              <div className="border border-slate-100 dark:border-slate-800 rounded-[16px] p-6 bg-slate-50/50 dark:bg-slate-900/40 space-y-4">
                <div className="text-center pb-4 border-b border-slate-200 dark:border-slate-800">
                  <h3 className="font-extrabold text-slate-800 dark:text-slate-200 text-sm">LAPORAN NERACA USAHA (BALANCE SHEET)</h3>
                  <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-wider font-semibold">Per Tanggal Keuangan {new Date().toLocaleDateString('id-ID')}</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-xs">
                  {/* Assets */}
                  <div className="space-y-4">
                    <h4 className="font-black text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800 pb-2">AKTIVA (ASET / HARTA)</h4>
                    <div className="space-y-2.5">
                      <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                        <span>Kas di Drawer (Laci Kasir)</span>
                        <span>Rp {kasTunai.toLocaleString('id-ID')}</span>
                      </div>
                      <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                        <span>Saldo E-Wallet Agen</span>
                        <span>Rp {saldoEWallet.toLocaleString('id-ID')}</span>
                      </div>
                      <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                        <span>Saldo Rekening Bank</span>
                        <span>Rp {saldoBank.toLocaleString('id-ID')}</span>
                      </div>
                      <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                        <span>Persediaan Barang Dagang (Fisik)</span>
                        <span>Rp {nilaiStok.toLocaleString('id-ID')}</span>
                      </div>
                      <div className="flex justify-between font-extrabold text-indigo-600 dark:text-indigo-400 border-t border-slate-200 dark:border-slate-800 pt-3 text-sm">
                        <span>TOTAL AKTIVA (ASET)</span>
                        <span>Rp {totalAset.toLocaleString('id-ID')}</span>
                      </div>
                    </div>
                  </div>

                  {/* Liabilities & Equity */}
                  <div className="space-y-4">
                    <h4 className="font-black text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800 pb-2">PASIVA (UTANG & MODAL)</h4>
                    <div className="space-y-2.5">
                      <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                        <span>Utang Usaha / Jangka Pendek</span>
                        <span>Rp 0</span>
                      </div>
                      <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                        <span>Modal Awal & Tambahan Pemilik</span>
                        <span>Rp {(accountBalances['301'] || 0).toLocaleString('id-ID')}</span>
                      </div>
                      <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                        <span>Laba Ditahan</span>
                        <span>Rp {(accountBalances['302'] || 0).toLocaleString('id-ID')}</span>
                      </div>
                      <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                        <span>Laba Tahun Berjalan (Laba Rugi)</span>
                        <span>Rp {labaBersih.toLocaleString('id-ID')}</span>
                      </div>
                      <div className="flex justify-between font-extrabold text-indigo-600 dark:text-indigo-400 border-t border-slate-200 dark:border-slate-800 pt-3 text-sm">
                        <span>TOTAL PASIVA & MODAL</span>
                        <span>Rp {totalAset.toLocaleString('id-ID')}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-[16px] flex items-center justify-between text-[11px] font-extrabold text-slate-500">
                  <span className="flex items-center space-x-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 mr-1" />
                    <span>Status Balance Neraca:</span>
                    <span className="text-emerald-600 dark:text-emerald-400">SEIMBANG (BALANCED)</span>
                  </span>
                  <span>Selisih: Rp 0</span>
                </div>
              </div>
            )}

            {/* Cash Flow View */}
            {reportType === 'cash_flow' && (
              <div className="border border-slate-100 dark:border-slate-800 rounded-[16px] p-6 bg-slate-50/50 dark:bg-slate-900/40 space-y-4">
                <div className="text-center pb-4 border-b border-slate-200 dark:border-slate-800">
                  <h3 className="font-extrabold text-slate-800 dark:text-slate-200 text-sm">LAPORAN ARUS KAS (CASH FLOW - METODE LANGSUNG)</h3>
                  <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-wider font-semibold">Periode s/d {new Date().toLocaleDateString('id-ID')}</p>
                </div>

                {(() => {
                  const opInflows = journalEntries.filter(e => e.reference !== 'SETOR-MODAL' && e.reference !== 'MODAL-AWAL').reduce((sum, entry) => {
                    return sum + entry.lines.reduce((lSum, l) => (l.type === 'debit' && (l.accountCode === '101' || l.accountCode === '104')) ? lSum + l.amount : lSum, 0);
                  }, 0);

                  const opOutflows = journalEntries.reduce((sum, entry) => {
                    return sum + entry.lines.reduce((lSum, l) => (l.type === 'credit' && (l.accountCode === '101' || l.accountCode === '104') && !entry.lines.some(cl => cl.accountCode === '102' || cl.accountCode === '301')) ? lSum + l.amount : lSum, 0);
                  }, 0);

                  const finInflows = journalEntries.filter(e => e.reference === 'SETOR-MODAL' || e.reference === 'MODAL-AWAL').reduce((sum, entry) => {
                    return sum + entry.lines.reduce((lSum, l) => (l.type === 'debit' && (l.accountCode === '101' || l.accountCode === '104')) ? lSum + l.amount : lSum, 0);
                  }, 0);

                  const netFlow = (opInflows - opOutflows) + finInflows;

                  return (
                    <div className="space-y-6 text-xs">
                      <div>
                        <h4 className="font-black text-slate-400 uppercase text-[10px] tracking-wider mb-2">I. Arus Kas dari Aktivitas Operasional</h4>
                        <div className="space-y-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                          <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                            <span>Penerimaan Kas Tunai & Bank dari Pelanggan</span>
                            <span>Rp {opInflows.toLocaleString('id-ID')}</span>
                          </div>
                          <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                            <span>Pengeluaran Kas/Bank untuk Pembelian Persediaan & Biaya</span>
                            <span className="text-rose-500">(Rp {opOutflows.toLocaleString('id-ID')})</span>
                          </div>
                          <div className="flex justify-between font-extrabold text-slate-900 dark:text-slate-100 pt-1">
                            <span>Kas Bersih dari Aktivitas Operasional</span>
                            <span>Rp {(opInflows - opOutflows).toLocaleString('id-ID')}</span>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-black text-slate-400 uppercase text-[10px] tracking-wider mb-2">II. Arus Kas dari Aktivitas Finansial / Pendanaan</h4>
                        <div className="space-y-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                          <div className="flex justify-between text-slate-600 dark:text-slate-300 font-medium">
                            <span>Setoran Modal Usaha Pemilik (Mulai Baru & Tambahan)</span>
                            <span>Rp {finInflows.toLocaleString('id-ID')}</span>
                          </div>
                          <div className="flex justify-between font-extrabold text-slate-900 dark:text-slate-100 pt-1">
                            <span>Kas Bersih dari Aktivitas Finansial</span>
                            <span>Rp {finInflows.toLocaleString('id-ID')}</span>
                          </div>
                        </div>
                      </div>

                      <div className="p-4 bg-indigo-50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 rounded-[16px] space-y-2.5">
                        <div className="flex justify-between font-black text-indigo-900 dark:text-indigo-300">
                          <span>KENAIKAN / PERUBAHAN BERSIH KAS (NET CHANGE)</span>
                          <span>Rp {netFlow.toLocaleString('id-ID')}</span>
                        </div>
                        <div className="flex justify-between font-extrabold text-slate-600 dark:text-slate-400 border-t border-indigo-100 dark:border-indigo-900/30 pt-2">
                          <span>Saldo Akhir Kas & Bank Riil</span>
                          <span>Rp {(kasTunai + saldoBank).toLocaleString('id-ID')}</span>
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: MANUAL TRANSACTION ENTRY FORMS */}
      {activeTab === 'entry' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Section 1: Catat Pengeluaran / Beban */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-[20px] border border-slate-150 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center space-x-2 text-rose-500 font-extrabold text-xs uppercase tracking-wider">
              <TrendingDown className="w-4 h-4" />
              <span>Pencatatan Beban / Pengeluaran Konter</span>
            </div>
            <div>
              <h2 className="text-base font-black text-slate-800 dark:text-slate-100">Catat Pengeluaran (Beban Operasional)</h2>
              <p className="text-slate-400 text-xs mt-0.5">Catat seluruh pengeluaran bulanan seperti Listrik, Gaji, Sewa, atau internet.</p>
            </div>

            <form onSubmit={handleSaveExpense} className="space-y-4 text-xs">
              <div className="space-y-1.5">
                <label className="font-extrabold text-slate-500">Jenis Beban / Rekening Pengeluaran</label>
                <select
                  value={expenseAccount}
                  onChange={(e) => setExpenseAccount(e.target.value)}
                  className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                >
                  <option value="504">Beban Listrik & Internet Konter (504)</option>
                  <option value="505">Beban Sewa Konter Fisik (505)</option>
                  <option value="506">Beban Gaji Operator / Kasir (506)</option>
                  <option value="507">Beban Operasional Lainnya (507)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="font-extrabold text-slate-500">Sumber Dana Pembayaran</label>
                  <select
                    value={expenseSource}
                    onChange={(e) => setExpenseSource(e.target.value as any)}
                    className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                  >
                    <option value="101">Kas di Drawer Laci (101)</option>
                    <option value="104">Saldo Rekening Bank (104)</option>
                    <option value="ewallet">Saldo Dompet E-Wallet (102)</option>
                  </select>
                </div>

                {expenseSource === 'ewallet' && (
                  <div className="space-y-1.5">
                    <label className="font-extrabold text-slate-500">Pilih Dompet Digital</label>
                    <select
                      value={selectedExpenseWalletId}
                      onChange={(e) => setSelectedExpenseWalletId(e.target.value)}
                      required
                      className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                    >
                      <option value="">-- Pilih E-Wallet --</option>
                      {eWallets.map(w => (
                        <option key={w.id} value={w.id}>{w.name} (Sisa: Rp {w.balance.toLocaleString('id-ID')})</option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="space-y-1.5 col-span-2 sm:col-span-1">
                  <label className="font-extrabold text-slate-500">Nominal Pengeluaran (Rp)</label>
                  <input
                    type="number"
                    value={expenseAmount || ''}
                    onChange={(e) => setExpenseAmount(Number(e.target.value))}
                    required
                    min="1"
                    placeholder="Contoh: 150000"
                    className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                  />
                </div>

                <div className="space-y-1.5 col-span-2 sm:col-span-1">
                  <label className="font-extrabold text-slate-500">Tanggal Pengeluaran</label>
                  <input
                    type="date"
                    value={expenseDate}
                    onChange={(e) => setExpenseDate(e.target.value)}
                    required
                    className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="font-extrabold text-slate-500">Memo / Keterangan Tambahan</label>
                <input
                  type="text"
                  value={expenseMemo}
                  onChange={(e) => setExpenseMemo(e.target.value)}
                  placeholder="Contoh: Bayar Token Listrik Konter Mei"
                  className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                />
              </div>

              <button
                type="submit"
                className="w-full p-3 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-extrabold transition-all cursor-pointer text-center"
              >
                Simpan Pengeluaran
              </button>
            </form>
          </div>

          {/* Section 2: Mutasi Kas ⇆ Rekening Bank */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-[20px] border border-slate-150 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center space-x-2 text-indigo-500 font-extrabold text-xs uppercase tracking-wider">
              <ArrowRightLeft className="w-4 h-4" />
              <span>Mutasi Kas & Rekening Bank</span>
            </div>
            <div>
              <h2 className="text-base font-black text-slate-800 dark:text-slate-100">Mutasi Dana Internal (Kas ⇆ Bank)</h2>
              <p className="text-slate-400 text-xs mt-0.5">Catat transfer uang internal antara laci kasir dan rekening bank Anda.</p>
            </div>

            <form onSubmit={handleSaveTransfer} className="space-y-4 text-xs">
              <div className="space-y-1.5">
                <label className="font-extrabold text-slate-500">Arah Perpindahan Dana</label>
                <select
                  value={transferType}
                  onChange={(e) => setTransferType(e.target.value as any)}
                  className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                >
                  <option value="drawer_to_bank">Ambil Kas Laci → Setor ke Bank (Drawer ke Bank)</option>
                  <option value="bank_to_drawer">Tarik Tunai Bank → Taruh di Laci Kasir (Bank ke Drawer)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="font-extrabold text-slate-500">Jumlah Transfer (Rp)</label>
                  <input
                    type="number"
                    value={transferAmount || ''}
                    onChange={(e) => setTransferAmount(Number(e.target.value))}
                    required
                    min="1"
                    placeholder="Contoh: 1000000"
                    className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="font-extrabold text-slate-500">Tanggal Mutasi</label>
                  <input
                    type="date"
                    value={transferDate}
                    onChange={(e) => setTransferDate(e.target.value)}
                    required
                    className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="font-extrabold text-slate-500">Memo / Keterangan Tambahan</label>
                <input
                  type="text"
                  value={transferMemo}
                  onChange={(e) => setTransferMemo(e.target.value)}
                  placeholder="Contoh: Setor uang kas berlebih ke rekening BCA"
                  className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                />
              </div>

              <button
                type="submit"
                className="w-full p-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-extrabold transition-all cursor-pointer text-center"
              >
                Simpan Mutasi Dana
              </button>
            </form>
          </div>

          {/* Section 3: Setor Modal Pemilik */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-[20px] border border-slate-150 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center space-x-2 text-emerald-500 font-extrabold text-xs uppercase tracking-wider">
              <PiggyBank className="w-4 h-4" />
              <span>Tambahan Modal Pemilik</span>
            </div>
            <div>
              <h2 className="text-base font-black text-slate-800 dark:text-slate-100">Setor Modal Tambahan (Equity)</h2>
              <p className="text-slate-400 text-xs mt-0.5">Catat ketika Anda sebagai pemilik menyuntikkan dana pribadi baru ke konter.</p>
            </div>

            <form onSubmit={handleSaveCapital} className="space-y-4 text-xs">
              <div className="space-y-1.5">
                <label className="font-extrabold text-slate-500">Tujuan Penyimpanan Setoran</label>
                <select
                  value={capitalDest}
                  onChange={(e) => setCapitalDest(e.target.value as any)}
                  className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                >
                  <option value="101">Kas Laci / Cash Drawer (101)</option>
                  <option value="104">Saldo Rekening Bank (104)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="font-extrabold text-slate-500">Nominal Setor Modal (Rp)</label>
                  <input
                    type="number"
                    value={capitalAmount || ''}
                    onChange={(e) => setCapitalAmount(Number(e.target.value))}
                    required
                    min="1"
                    placeholder="Contoh: 5000000"
                    className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="font-extrabold text-slate-500">Tanggal Penyetoran</label>
                  <input
                    type="date"
                    value={capitalDate}
                    onChange={(e) => setCapitalDate(e.target.value)}
                    required
                    className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="font-extrabold text-slate-500">Memo / Keterangan Tambahan</label>
                <input
                  type="text"
                  value={capitalMemo}
                  onChange={(e) => setCapitalMemo(e.target.value)}
                  placeholder="Contoh: Suntikan dana pribadi pemilik untuk stok kuota"
                  className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                />
              </div>

              <button
                type="submit"
                className="w-full p-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-extrabold transition-all cursor-pointer text-center"
              >
                Simpan Setoran Modal
              </button>
            </form>
          </div>

          {/* Section 4: Isi Saldo E-Wallet (Topup Dompet Digital Konter) */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-[20px] border border-slate-150 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center space-x-2 text-amber-500 font-extrabold text-xs uppercase tracking-wider">
              <Wallet className="w-4 h-4" />
              <span>Pengisian Saldo E-Wallet Konter</span>
            </div>
            <div>
              <h2 className="text-base font-black text-slate-800 dark:text-slate-100">Top Up Saldo E-Wallet (Deposit)</h2>
              <p className="text-slate-400 text-xs mt-0.5">Catat pengisian saldo dompet digital server/agen Anda yang didanai Kas/Bank.</p>
            </div>

            <form onSubmit={handleSaveDepositEWallet} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="font-extrabold text-slate-500">Pilih Dompet Agen</label>
                  <select
                    value={depositWalletId}
                    onChange={(e) => setDepositWalletId(e.target.value)}
                    required
                    className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                  >
                    <option value="">-- Pilih E-Wallet --</option>
                    {eWallets.map(w => (
                      <option key={w.id} value={w.id}>{w.name} (Saldo: Rp {w.balance.toLocaleString('id-ID')})</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="font-extrabold text-slate-500">Sumber Pendanaan</label>
                  <select
                    value={depositSource}
                    onChange={(e) => setDepositSource(e.target.value as any)}
                    className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                  >
                    <option value="101">Kas di Drawer Laci (101)</option>
                    <option value="104">Saldo Rekening Bank (104)</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="font-extrabold text-slate-500">Nominal Pengisian (Rp)</label>
                  <input
                    type="number"
                    value={depositAmount || ''}
                    onChange={(e) => setDepositAmount(Number(e.target.value))}
                    required
                    min="1"
                    placeholder="Contoh: 1000000"
                    className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="font-extrabold text-slate-500">Tanggal Deposit</label>
                  <input
                    type="date"
                    value={depositDate}
                    onChange={(e) => setDepositDate(e.target.value)}
                    required
                    className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="font-extrabold text-slate-500">Memo / Keterangan Tambahan</label>
                <input
                  type="text"
                  value={depositMemo}
                  onChange={(e) => setDepositMemo(e.target.value)}
                  placeholder="Contoh: Pengisian saldo DANA Server BCA Transfer"
                  className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                />
              </div>

              <button
                type="submit"
                className="w-full p-3 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-extrabold transition-all cursor-pointer text-center"
              >
                Simpan Deposit E-Wallet
              </button>
            </form>
          </div>

          {/* Critical Maintenance / Developer Actions Card */}
          <div className="bg-slate-50 dark:bg-slate-900/60 p-6 rounded-[20px] border border-dashed border-slate-250 dark:border-slate-800 col-span-1 md:col-span-2 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-start space-x-3 text-xs">
              <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-extrabold text-slate-800 dark:text-slate-200">Mode Perawatan Pembukuan</h4>
                <p className="text-slate-500 dark:text-slate-400 mt-0.5">
                  Gunakan ini jika ingin mengosongkan seluruh pembukuan manual (Setoran modal, Beban dll). Data penjualan di kasir (POS) tidak akan terhapus.
                </p>
              </div>
            </div>

            <button
              onClick={handleClearAllJournals}
              className="px-4 py-2.5 bg-rose-50 dark:bg-rose-950/20 text-rose-700 hover:bg-rose-100 text-xs font-black rounded-xl cursor-pointer transition-all border border-rose-100 dark:border-rose-900/30 whitespace-nowrap"
            >
              Kosongkan Jurnal Manual
            </button>
          </div>
        </div>
      )}

      {/* TAB 3: AUDIT LOG (GENERAL JOURNAL & LEDGER) */}
      {activeTab === 'ledger' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* General Journal List (Left 2 Columns) */}
            <div className="lg:col-span-2 bg-white dark:bg-slate-900 p-6 rounded-[20px] border border-slate-150 dark:border-slate-800 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
                <div>
                  <h3 className="text-base font-black text-slate-800 dark:text-slate-100">Buku Jurnal Umum (General Journal)</h3>
                  <p className="text-slate-400 text-xs mt-0.5">Daftar transaksi akuntansi double-entry kronologis otomatis & manual.</p>
                </div>

                <div className="flex space-x-2 bg-slate-50 dark:bg-slate-800 p-1 rounded-xl text-xs font-bold w-max">
                  <button
                    onClick={() => setJournalFilterType('all')}
                    className={`px-2.5 py-1.5 rounded-lg cursor-pointer ${journalFilterType === 'all' ? 'bg-white dark:bg-slate-700 shadow-xs text-slate-800 dark:text-white' : 'text-slate-400'}`}
                  >
                    Semua
                  </button>
                  <button
                    onClick={() => setJournalFilterType('auto')}
                    className={`px-2.5 py-1.5 rounded-lg cursor-pointer ${journalFilterType === 'auto' ? 'bg-white dark:bg-slate-700 shadow-xs text-slate-800 dark:text-white' : 'text-slate-400'}`}
                  >
                    Otomatis POS
                  </button>
                  <button
                    onClick={() => setJournalFilterType('manual')}
                    className={`px-2.5 py-1.5 rounded-lg cursor-pointer ${journalFilterType === 'manual' ? 'bg-white dark:bg-slate-700 shadow-xs text-slate-800 dark:text-white' : 'text-slate-400'}`}
                  >
                    Manual
                  </button>
                </div>
              </div>

              {/* Search filter */}
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  placeholder="Cari referensi, nomor invoice, akun, atau memo jurnal..."
                  value={journalSearch}
                  onChange={(e) => setJournalSearch(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none text-slate-800 dark:text-slate-100"
                />
              </div>

              {/* List of Journals */}
              <div className="space-y-4 max-h-[600px] overflow-y-auto pr-1">
                {filteredJournals.length === 0 ? (
                  <div className="text-center py-12 text-slate-400 font-medium text-xs">
                    Tidak ditemukan data jurnal yang cocok.
                  </div>
                ) : (
                  filteredJournals.map(entry => (
                    <div key={entry.id} className="border border-slate-100 dark:border-slate-800 rounded-[16px] p-4 bg-slate-50/40 dark:bg-slate-900/40 space-y-3">
                      <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-2 text-[11px]">
                        <div className="flex items-center space-x-2">
                          <span className="font-extrabold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 px-2 py-0.5 rounded-md">{entry.id}</span>
                          <span className="text-slate-400">{new Date(entry.date).toLocaleString('id-ID')}</span>
                        </div>
                        <div className="flex items-center space-x-1.5">
                          <span className="text-slate-400">Ref:</span>
                          <span className="font-extrabold text-slate-700 dark:text-slate-300 bg-slate-200/50 dark:bg-slate-800 px-2 py-0.5 rounded-md">{entry.reference}</span>
                          <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold uppercase ${entry.isManual ? 'bg-amber-100 dark:bg-amber-950/40 text-amber-800 dark:text-amber-400' : 'bg-sky-100 dark:bg-sky-950/40 text-sky-800 dark:text-sky-400'}`}>
                            {entry.isManual ? 'MANUAL' : 'AUTO POS'}
                          </span>
                        </div>
                      </div>

                      <div className="text-xs font-extrabold text-slate-800 dark:text-slate-200">{entry.description}</div>

                      <div className="space-y-1.5 text-[11px]">
                        <div className="grid grid-cols-12 gap-1.5 font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 dark:border-slate-800 pb-1">
                          <div className="col-span-6">Nama Akun / Rekening</div>
                          <div className="col-span-2">Kode</div>
                          <div className="col-span-2 text-right">Debit</div>
                          <div className="col-span-2 text-right">Kredit</div>
                        </div>

                        {entry.lines.map((line, lIdx) => (
                          <div key={lIdx} className="grid grid-cols-12 gap-1.5 font-medium py-1 text-slate-600 dark:text-slate-300">
                            <div className={`col-span-6 flex items-center ${line.type === 'credit' ? 'pl-6 text-slate-500' : 'font-semibold text-slate-800 dark:text-slate-200'}`}>
                              {line.type === 'credit' && <span className="text-slate-400 mr-1.5">└</span>}
                              {line.accountName}
                            </div>
                            <div className="col-span-2 font-mono text-slate-400">{line.accountCode}</div>
                            <div className="col-span-2 text-right font-semibold text-slate-800 dark:text-slate-200">
                              {line.type === 'debit' ? `Rp ${line.amount.toLocaleString('id-ID')}` : '-'}
                            </div>
                            <div className="col-span-2 text-right font-semibold text-slate-800 dark:text-slate-200">
                              {line.type === 'credit' ? `Rp ${line.amount.toLocaleString('id-ID')}` : '-'}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Buku Besar (Right Column) */}
            <div className="bg-white dark:bg-slate-900 p-6 rounded-[20px] border border-slate-150 dark:border-slate-800 shadow-sm space-y-4">
              <div>
                <h3 className="text-base font-black text-slate-800 dark:text-slate-100">Buku Besar Akun (Ledger)</h3>
                <p className="text-slate-400 text-xs mt-0.5">Filter riwayat perputaran mutasi per rekening akun keuangan.</p>
              </div>

              <div className="space-y-1.5 text-xs">
                <label className="font-extrabold text-slate-500">Pilih Rekening Akun Buku Besar</label>
                <select
                  value={selectedLedgerAccount}
                  onChange={(e) => setSelectedLedgerAccount(e.target.value)}
                  className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 font-extrabold outline-none text-slate-800 dark:text-slate-100"
                >
                  {CHART_OF_ACCOUNTS.map(acc => (
                    <option key={acc.code} value={acc.code}>({acc.code}) - {acc.name}</option>
                  ))}
                </select>
              </div>

              {/* Ledger Summary Card */}
              {(() => {
                const coa = CHART_OF_ACCOUNTS.find(a => a.code === selectedLedgerAccount);
                const bal = accountBalances[selectedLedgerAccount] || 0;
                return (
                  <div className="p-4 bg-indigo-50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 rounded-[16px] flex items-center justify-between text-xs font-black">
                    <span className="text-indigo-800 dark:text-indigo-300">Saldo Akhir Akun:</span>
                    <span className="text-indigo-900 dark:text-indigo-200 font-black text-sm">
                      Rp {bal.toLocaleString('id-ID')}
                      <span className="text-[10px] text-slate-400 font-normal ml-1">({coa?.normalBalance})</span>
                    </span>
                  </div>
                );
              })()}

              {/* Ledger Entries List */}
              <div className="space-y-3 max-h-[400px] overflow-y-auto pr-1">
                {ledgerLinesForSelectedAccount.length === 0 ? (
                  <div className="text-center py-12 text-slate-400 font-medium text-xs">
                    Tidak ada transaksi pada akun ini.
                  </div>
                ) : (
                  ledgerLinesForSelectedAccount.map((line, idx) => (
                    <div key={idx} className="p-3 border border-slate-100 dark:border-slate-800 rounded-xl bg-slate-50/50 dark:bg-slate-900/40 text-[11px] space-y-1.5">
                      <div className="flex justify-between text-slate-400 font-bold">
                        <span>{new Date(line.date).toLocaleDateString('id-ID')}</span>
                        <span className="text-indigo-600 dark:text-indigo-400">{line.entryId}</span>
                      </div>
                      <div className="font-extrabold text-slate-700 dark:text-slate-300">{line.description}</div>
                      <div className="flex justify-between items-center text-xs border-t border-dashed border-slate-150 dark:border-slate-800 pt-1.5 font-bold">
                        <span className={line.type === 'debit' ? 'text-emerald-600' : 'text-rose-500'}>
                          {line.type === 'debit' ? `D: +Rp ${line.amount.toLocaleString('id-ID')}` : `K: -Rp ${line.amount.toLocaleString('id-ID')}`}
                        </span>
                        <span className="text-slate-500">
                          Bal: Rp {line.runningBalance.toLocaleString('id-ID')}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
