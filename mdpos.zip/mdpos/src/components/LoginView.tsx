import React, { useState } from 'react';
import { User } from '../types';
import { Smartphone, Shield, User as UserIcon, Lock, CheckCircle2, Sun, Moon } from 'lucide-react';
import { AppConfig } from './SettingsView';

interface LoginViewProps {
  users: User[];
  onLogin: (user: User) => void;
  theme?: 'light' | 'dark';
  toggleTheme?: () => void;
  appConfig?: AppConfig;
}

export default function LoginView({ users, onLogin, theme = 'light', toggleTheme, appConfig }: LoginViewProps) {
  const [username, setUsername] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [logoError, setLogoError] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (username.trim() === '') {
      setError('Username tidak boleh kosong.');
      return;
    }

    if (password.trim() === '') {
      setError('Password tidak boleh kosong.');
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: username.trim(),
          password: password,
        }),
      });

      if (!response.ok) {
        const errData = await response.json();
        setError(errData.error || 'Username atau Password salah.');
        setIsLoading(false);
        return;
      }

      const loggedInUser: User = await response.json();
      setIsLoading(false);
      onLogin(loggedInUser);
    } catch (err: any) {
      console.error('Login error on client:', err);
      setError('Gagal menghubungkan ke server.');
      setIsLoading(false);
    }
  };

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center px-4 py-12 sm:px-6 lg:px-8 relative ${theme === 'dark' ? 'bg-slate-900' : 'bg-[#F8FAFC]'}`}>
      {/* Floating Theme Toggle */}
      {toggleTheme && (
        <button
          type="button"
          onClick={toggleTheme}
          className={`absolute top-6 right-6 p-3 rounded-[16px] border hover:scale-105 active:scale-95 transition-all duration-200 focus:outline-none cursor-pointer ${
            theme === 'dark' 
              ? 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white' 
              : 'bg-white border-slate-200/80 text-slate-500 hover:text-slate-800 shadow-xs hover:bg-slate-50'
          }`}
          title={theme === 'dark' ? "Mode Terang" : "Mode Gelap"}
        >
          {theme === 'dark' ? <Sun className="w-5 h-5 text-amber-500" /> : <Moon className="w-5 h-5" />}
        </button>
      )}

      <div className={`max-w-md w-full space-y-8 p-8 rounded-[20px] shadow-sm border transition-all duration-250 ${
        theme === 'dark' 
          ? 'bg-slate-800 border-slate-700 text-white' 
          : 'bg-white border-slate-200/80 text-slate-900'
      }`}>
        <div className="text-center flex flex-col items-center">
          {!logoError ? (
            <img 
              src={appConfig?.logoUrl || "/logo.png"} 
              alt="MD POS Logo" 
              onError={(e) => {
                if (e.currentTarget.src !== window.location.origin + "/logo.png") {
                  e.currentTarget.src = "/logo.png";
                } else {
                  setLogoError(true);
                }
              }} 
              className="w-16 h-16 object-contain shrink-0 mb-4 rounded-[16px] shadow-xs bg-slate-900/5 dark:bg-slate-800 p-1 border border-slate-200/60 dark:border-slate-700" 
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="inline-flex items-center justify-center p-3 bg-indigo-50 dark:bg-indigo-950/40 rounded-[16px] text-indigo-600 dark:text-indigo-400 mb-4 ring-8 ring-indigo-50/30 dark:ring-indigo-950/15">
              <Smartphone className="w-9 h-9 text-indigo-500" />
            </div>
          )}
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            {appConfig?.name || "MD POS"}
          </h2>
          <p className="mt-1.5 text-xs font-semibold text-slate-500 dark:text-slate-450 uppercase tracking-wide">
            {appConfig?.slogan || "Sistem Kasir Konter Pulsa, Kuota & E-Wallet"}
          </p>
        </div>

        <form className="mt-6 space-y-5" onSubmit={handleLogin}>
          {error && (
            <div className="p-3 bg-red-50 dark:bg-red-950/20 border border-red-200/60 dark:border-red-900/40 text-red-600 dark:text-red-400 rounded-[12px] text-xs text-center font-bold">
              {error}
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label htmlFor="username" className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                Username Operator
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <UserIcon className="w-4.5 h-4.5" />
                </div>
                <input
                  id="username"
                  name="username"
                  type="text"
                  required
                  value={username}
                  onChange={(e) => {
                    setUsername(e.target.value);
                    setError('');
                  }}
                  className={`block w-full pl-10 pr-3.5 py-2.5 border rounded-[12px] leading-5 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-xs font-semibold transition-all duration-150 ${
                    theme === 'dark'
                      ? 'bg-slate-900 border-slate-700 placeholder-slate-500 text-white'
                      : 'bg-white border-slate-200/80 placeholder-slate-400 text-slate-800'
                  }`}
                  placeholder="Masukkan username"
                  autoComplete="username"
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="block text-xs font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                PIN / Password Akses
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4.5 h-4.5" />
                </div>
                <input
                  id="password"
                  name="password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError('');
                  }}
                  className={`block w-full pl-10 pr-3.5 py-2.5 border rounded-[12px] leading-5 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-xs font-mono tracking-widest transition-all duration-150 ${
                    theme === 'dark'
                      ? 'bg-slate-900 border-slate-700 placeholder-slate-500 text-white'
                      : 'bg-white border-slate-200/80 placeholder-slate-400 text-slate-800'
                  }`}
                  placeholder="••••••"
                  autoComplete="current-password"
                />
              </div>
            </div>
          </div>

          <div>
            <button
              type="submit"
              disabled={isLoading}
              className={`group relative w-full flex justify-center py-3 px-4 border border-transparent text-xs font-bold rounded-[12px] text-white transition-all shadow-md ${
                isLoading 
                  ? 'bg-indigo-400 cursor-not-allowed shadow-none' 
                  : 'bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 shadow-indigo-500/10 hover:scale-[1.01] active:scale-[0.99] cursor-pointer'
              }`}
            >
              {isLoading ? 'Sedang Masuk...' : 'MASUK KE POS'}
            </button>
          </div>
        </form>
      </div>

      {/* Official Website Footer */}
      <div className="mt-8 text-center text-xs text-slate-400 dark:text-slate-500 font-bold space-y-1">
        <div>&copy; {new Date().getFullYear()} MD POS • Hak Cipta Dilindungi</div>
        <div>
          Website Resmi:{' '}
          <a 
            href="https://mdcell.my.id" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="text-indigo-500 dark:text-indigo-400 hover:underline hover:text-indigo-600"
          >
            https://mdcell.my.id
          </a>
        </div>
      </div>
    </div>
  );
}
