import React, { useState, useEffect, FormEvent } from 'react';
import { Settings, Save, RotateCcw, Check, Database, Download, RefreshCw, AlertTriangle, ShieldAlert } from 'lucide-react';
import { Transaction, EWallet, EWalletHistory, Product, Shift } from '../types';

export interface AppConfig {
  name: string;
  slogan: string;
  lowStockLimit: number;
  currency: string;
  receiptFooter: string;
  allowLossTransaction?: boolean;
  logoUrl?: string;
}

interface BackupFile {
  filename: string;
  size: number;
  createdAt: string;
}

interface SettingsViewProps {
  appConfig: AppConfig;
  currentUser?: { id: string; name: string; role: string } | null;
  onSaveSettings: (config: AppConfig) => void;
  transactions: Transaction[];
  eWallets: EWallet[];
  histories: EWalletHistory[];
  products: Product[];
  shifts: Shift[];
}

export default function SettingsView({ 
  appConfig, 
  currentUser, 
  onSaveSettings,
  transactions,
  eWallets,
  histories,
  products,
  shifts
}: SettingsViewProps) {
  const [activeTab, setActiveTab] = useState<'general' | 'accounting'>('general');
  const [name, setName] = useState(appConfig.name);
  const [slogan, setSlogan] = useState(appConfig.slogan);
  const [lowStockLimit, setLowStockLimit] = useState(appConfig.lowStockLimit);
  const [currency, setCurrency] = useState(appConfig.currency);
  const [receiptFooter, setReceiptFooter] = useState(appConfig.receiptFooter);
  const [allowLossTransaction, setAllowLossTransaction] = useState(!!appConfig.allowLossTransaction);
  const [logoUrl, setLogoUrl] = useState(appConfig.logoUrl || '');
  const [successMsg, setSuccessMsg] = useState('');
  const [isDragging, setIsDragging] = useState(false);

  // Backup system states
  const [backups, setBackups] = useState<BackupFile[]>([]);
  const [backupsLoading, setBackupsLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [backupMsg, setBackupMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const isAdmin = currentUser?.role === 'admin';

  const fetchBackups = async () => {
    if (!isAdmin) return;
    setBackupsLoading(true);
    try {
      const res = await fetch('/api/system/backups');
      if (res.ok) {
        const data = await res.json();
        setBackups(data);
      }
    } catch (err) {
      console.error('Failed to fetch backups:', err);
    } finally {
      setBackupsLoading(false);
    }
  };

  useEffect(() => {
    fetchBackups();
  }, []);

  const handleCreateBackup = async () => {
    setActionLoading(true);
    setBackupMsg(null);
    try {
      const res = await fetch('/api/system/backups', { method: 'POST' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Gagal memproses backup manual.');
      
      setBackupMsg({ type: 'success', text: `Backup database berhasil dibuat: ${data.filename}` });
      fetchBackups();
    } catch (err: any) {
      setBackupMsg({ type: 'error', text: err.message || 'Gagal membuat backup.' });
    } finally {
      setActionLoading(false);
    }
  };

  const handleRestoreBackup = async (filename: string) => {
    const isConfirmed = window.confirm(
      `PERINGATAN KRITIKAL:\n\nApakah Anda yakin ingin memulihkan (RESTORE) database menggunakan file:\n"${filename}"?\n\nSemua data transaksi, e-wallet, dan produk saat ini akan DIHAPUS dan DIGANTIKAN sepenuhnya dengan data dari file backup tersebut. Tindakan ini tidak dapat dibatalkan.`
    );
    if (!isConfirmed) return;

    setActionLoading(true);
    setBackupMsg(null);
    try {
      const res = await fetch('/api/system/backups/restore', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Gagal memulihkan database dari backup.');

      setBackupMsg({ type: 'success', text: 'Database berhasil dipulihkan secara penuh! Silakan muat ulang halaman ini untuk memperbarui data aplikasi.' });
      
      // Delay to allow user to read the message, then reload the page
      setTimeout(() => {
        window.location.reload();
      }, 3000);
    } catch (err: any) {
      setBackupMsg({ type: 'error', text: err.message || 'Gagal memulihkan data.' });
    } finally {
      setActionLoading(false);
    }
  };

  const handleDownloadBackup = (filename: string) => {
    // Directly trigger browser download of file
    window.location.href = `/api/system/backups/download/${filename}`;
  };

  const processImageFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Berkas harus berupa gambar (PNG, JPG, WEBP, atau SVG).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_SIZE = 256;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_SIZE) {
            height = Math.round((height * MAX_SIZE) / width);
            width = MAX_SIZE;
          }
        } else {
          if (height > MAX_SIZE) {
            width = Math.round((width * MAX_SIZE) / height);
            height = MAX_SIZE;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedBase64 = canvas.toDataURL('image/png');
          setLogoUrl(compressedBase64);
        } else {
          setLogoUrl(event.target?.result as string);
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processImageFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processImageFile(e.target.files[0]);
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    onSaveSettings({
      name: name.trim() || 'MD POS',
      slogan: slogan.trim() || 'KONTER POS MODERN',
      lowStockLimit: Number(lowStockLimit) || 5,
      currency: currency.trim() || 'Rp',
      receiptFooter: receiptFooter.trim() || 'Terima kasih telah berbelanja!',
      allowLossTransaction,
      logoUrl: logoUrl.trim() || undefined,
    });
    setSuccessMsg('Pengaturan berhasil disimpan!');
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  const handleReset = () => {
    setName('MD POS');
    setSlogan('KONTER POS MODERN');
    setLowStockLimit(5);
    setCurrency('Rp');
    setReceiptFooter('Terima kasih telah berbelanja!');
    setAllowLossTransaction(false);
    setLogoUrl('');
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = 2;
    const sizes = ['Bytes', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  };

  return (
    <div id="settings-view-container" className="p-4 lg:p-6 max-w-4xl mx-auto space-y-6 w-full">
      {/* Header */}
      <div className="flex items-center space-x-3">
        <div className="p-2.5 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 rounded-[16px] border border-indigo-100 dark:border-indigo-900/40">
          <Settings className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight">PENGATURAN SISTEM</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider">Konfigurasi Identitas Toko & POS</p>
        </div>
      </div>

      {/* Content wrapper */}
      {activeTab === 'general' && (
        <>
          {successMsg && (
            <div className="bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40 text-emerald-800 dark:text-emerald-400 p-4 rounded-[16px] flex items-center space-x-3 text-xs font-semibold animate-pulse">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Form Card */}
      <form onSubmit={handleSubmit} className="bg-white dark:bg-slate-900 rounded-[20px] border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="p-6 space-y-6">
          {/* Identity Section */}
          <div>
            <h2 className="text-sm font-bold text-slate-800 dark:text-slate-200 mb-4 border-b border-slate-100 dark:border-slate-800 pb-2">Identitas Konter / Toko</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Nama Konter / POS</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[16px] text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all font-semibold text-slate-800 dark:text-slate-100"
                  placeholder="Contoh: MD POS"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Slogan Toko</label>
                <input
                  type="text"
                  required
                  value={slogan}
                  onChange={(e) => setSlogan(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[16px] text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all font-semibold text-slate-800 dark:text-slate-100"
                  placeholder="Contoh: KONTER POS MODERN"
                />
              </div>
            </div>
          </div>

          {/* Logo Section */}
          <div className="border-t border-slate-100 dark:border-slate-800 pt-6">
            <h2 className="text-sm font-bold text-slate-800 dark:text-slate-200 mb-4 pb-2 border-b border-slate-100 dark:border-slate-800">Logo Aplikasi (Konter / Toko)</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
              {/* Preview & Drag area */}
              <div className="md:col-span-2 space-y-4">
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider">Unggah Logo Kustom</label>
                
                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  className={`border-2 border-dashed rounded-[20px] p-6 text-center transition-all flex flex-col items-center justify-center cursor-pointer min-h-[160px] ${
                    isDragging
                      ? 'border-indigo-500 bg-indigo-50/50 dark:bg-indigo-950/20'
                      : 'border-slate-200 dark:border-slate-700 hover:border-indigo-400 dark:hover:border-indigo-500 bg-slate-50/50 dark:bg-slate-850/50'
                  }`}
                  onClick={() => document.getElementById('logo-upload-input')?.click()}
                >
                  <input
                    id="logo-upload-input"
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  
                  <div className="p-3 bg-white dark:bg-slate-800 rounded-[16px] shadow-xs border border-slate-150 dark:border-slate-700 mb-3">
                    {logoUrl ? (
                      <img
                        src={logoUrl}
                        alt="Logo Preview"
                        className="w-16 h-16 object-contain rounded-xl"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <img
                        src="/logo.png"
                        alt="Default Logo"
                        className="w-16 h-16 object-contain rounded-xl opacity-60"
                        referrerPolicy="no-referrer"
                      />
                    )}
                  </div>
                  
                  <p className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    {logoUrl ? 'Klik atau seret untuk mengganti gambar' : 'Seret & Letakkan gambar di sini, atau klik untuk memilih'}
                  </p>
                  <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 font-semibold">
                    Format: PNG, JPG, WEBP, SVG (Maks. 2MB). Rekomendasi rasio 1:1.
                  </p>
                </div>

                {logoUrl && (
                  <button
                    type="button"
                    onClick={() => setLogoUrl('')}
                    className="text-xs font-black text-rose-500 hover:text-rose-600 hover:underline flex items-center space-x-1.5 focus:outline-none cursor-pointer"
                  >
                    <span>&times; Hapus Logo Kustom (Gunakan Logo Default)</span>
                  </button>
                )}
              </div>

              {/* URL fallback / direct input */}
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Atau Masukkan URL Logo</label>
                  <input
                    type="url"
                    value={logoUrl.startsWith('data:') ? '' : logoUrl}
                    onChange={(e) => setLogoUrl(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-[16px] text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all font-semibold text-slate-800 dark:text-slate-100"
                    placeholder="https://example.com/logo.png"
                    disabled={logoUrl.startsWith('data:')}
                  />
                  {logoUrl.startsWith('data:') ? (
                    <p className="text-[10px] text-indigo-500 font-bold mt-1.5">
                      ✓ Menggunakan logo kustom yang diunggah (Base64). Hapus terlebih dahulu jika ingin menggunakan URL eksternal.
                    </p>
                  ) : (
                    <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1.5 leading-relaxed">
                      Tempel tautan alamat gambar kustom yang dihosting di internet.
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* POS Rules */}
          <div>
            <h2 className="text-sm font-bold text-slate-800 dark:text-slate-200 mb-4 border-b border-slate-100 dark:border-slate-800 pb-2">Aturan & Operasional POS</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Batas Minimal Stok Menipis (Warning)</label>
                <input
                  type="number"
                  required
                  min={1}
                  value={lowStockLimit}
                  onChange={(e) => setLowStockLimit(Number(e.target.value))}
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[16px] text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all font-semibold text-slate-800 dark:text-slate-100"
                />
                <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1">Stok produk jualan di bawah angka ini akan memicu badge notifikasi merah.</p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Mata Uang / Simbol</label>
                <input
                  type="text"
                  required
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[16px] text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all font-semibold text-slate-800 dark:text-slate-100"
                />
              </div>
            </div>

            {/* Loss Transaction Permission Toggle */}
            <div className="mt-4 p-4 bg-slate-50 dark:bg-slate-850 border border-slate-200/60 dark:border-slate-800 rounded-[16px]">
              <div className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  id="allowLossTransaction"
                  checked={allowLossTransaction}
                  disabled={currentUser?.role !== 'admin'}
                  onChange={(e) => setAllowLossTransaction(e.target.checked)}
                  className="mt-1 h-4 w-4 text-indigo-600 border-slate-300 rounded focus:ring-indigo-500 disabled:opacity-50"
                />
                <div className="flex flex-col">
                  <label htmlFor="allowLossTransaction" className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider cursor-pointer">
                    Izinkan Transaksi Rugi
                  </label>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 font-medium leading-relaxed">
                    Mengaktifkan opsi ini memungkinkan kasir untuk memproses transaksi dengan harga jual yang lebih rendah dari nominal modal transaksi.
                  </p>
                  {currentUser?.role !== 'admin' && (
                    <span className="text-[10px] text-rose-500 font-black mt-1 uppercase tracking-wide">
                      * Hanya Admin yang dapat mengubah izin transaksi rugi melalui Pengaturan.
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Receipt Settings */}
          <div>
            <h2 className="text-sm font-bold text-slate-800 dark:text-slate-200 mb-4 border-b border-slate-100 dark:border-slate-800 pb-2">Desain Struk Penjualan</h2>
            <div>
              <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5">Catatan Kaki Struk (Receipt Footer)</label>
              <textarea
                rows={3}
                required
                value={receiptFooter}
                onChange={(e) => setReceiptFooter(e.target.value)}
                className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[16px] text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all font-semibold text-slate-800 dark:text-slate-100"
                placeholder="Contoh: Terima kasih telah berbelanja di konter kami!"
              />
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="p-4 bg-slate-50 dark:bg-slate-850/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <button
            type="button"
            onClick={handleReset}
            className="flex items-center space-x-2 px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-250 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-[16px] text-xs font-bold transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Kembali ke Default</span>
          </button>

          <button
            type="submit"
            className="flex items-center space-x-2 px-5 py-2.5 bg-indigo-600 text-white hover:bg-indigo-700 active:scale-95 rounded-[16px] text-xs font-bold shadow-md shadow-indigo-600/20 transition-all"
          >
            <Save className="w-4 h-4" />
            <span>Simpan Perubahan</span>
          </button>
        </div>
      </form>

      {/* PostgreSQL Backup & Restore Section (Admin Only) */}
      {isAdmin && (
        <div className="bg-white dark:bg-slate-900 rounded-[20px] border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden">
          <div className="p-6 space-y-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
              <div className="flex items-center space-x-2.5">
                <div className="p-1.5 bg-emerald-500/10 rounded-xl text-emerald-500">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-sm font-extrabold text-slate-800 dark:text-slate-200 uppercase tracking-wide">
                    Sistem Backup Database (PostgreSQL)
                  </h2>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-0.5">
                    Operasional backup manual, restore, dan riwayat arsip
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={handleCreateBackup}
                disabled={actionLoading}
                className="flex items-center justify-center space-x-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-55 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-sm shadow-emerald-600/10"
              >
                <RefreshCw className={`w-4 h-4 ${actionLoading ? 'animate-spin' : ''}`} />
                <span>Mulai Backup Baru</span>
              </button>
            </div>

            {/* Messages */}
            {backupMsg && (
              <div className={`p-4 rounded-xl border text-xs font-bold flex items-start space-x-2.5 ${
                backupMsg.type === 'success' 
                  ? 'bg-emerald-50 dark:bg-emerald-950/20 border-emerald-100 dark:border-emerald-900/40 text-emerald-700 dark:text-emerald-400' 
                  : 'bg-red-50 dark:bg-red-950/20 border-red-100 dark:border-red-900/40 text-red-700 dark:text-red-400'
              }`}>
                {backupMsg.type === 'success' ? (
                  <Check className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                ) : (
                  <ShieldAlert className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                )}
                <span>{backupMsg.text}</span>
              </div>
            )}

            <div className="p-4 bg-slate-50 dark:bg-slate-850 border border-slate-200/60 dark:border-slate-800/80 rounded-[16px] flex items-start space-x-3 text-xs">
              <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5 animate-bounce" />
              <div className="space-y-1">
                <span className="font-extrabold text-slate-700 dark:text-slate-300">Catatan Keamanan & Pemulihan:</span>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-relaxed font-medium">
                  • Backup otomatis berjalan secara terjadwal setiap 24 jam sekali di latar belakang server.<br />
                  • File backup disimpan secara aman di direktori server dalam format JSON terstruktur.<br />
                  • Proses **Restore** akan menghapus database operasional saat ini (Cascaded Clean) dan mengisinya dengan isi file backup. Gunakan dengan sangat hati-hati!
                </p>
              </div>
            </div>

            {/* Backup History */}
            <div>
              <div className="flex items-center justify-between mb-3 text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wide">
                <span>Riwayat Backup Tersedia ({backups.length})</span>
                <button
                  onClick={fetchBackups}
                  disabled={backupsLoading}
                  className="text-xs text-indigo-500 hover:text-indigo-600 flex items-center space-x-1 focus:outline-none cursor-pointer"
                >
                  <RefreshCw className={`w-3 h-3 ${backupsLoading ? 'animate-spin' : ''}`} />
                  <span>Segarkan List</span>
                </button>
              </div>

              {backupsLoading && backups.length === 0 ? (
                <div className="py-8 text-center text-slate-400 text-xs font-semibold">
                  Memuat berkas backup database...
                </div>
              ) : backups.length === 0 ? (
                <div className="py-10 text-center border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-[16px] text-slate-400 text-xs font-bold">
                  Belum ada riwayat berkas backup yang tersimpan di sistem.
                </div>
              ) : (
                <div className="border border-slate-150 dark:border-slate-800 rounded-[16px] overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="bg-slate-50 dark:bg-slate-800/50 text-[10px] text-slate-400 font-black border-b border-slate-200 dark:border-slate-800 uppercase tracking-wider">
                          <th className="p-3">Nama Berkas Backup</th>
                          <th className="p-3 w-32">Ukuran Berkas</th>
                          <th className="p-3 w-48">Waktu Pembuatan</th>
                          <th className="p-3 w-48 text-center">Tindakan</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                        {backups.map((b) => {
                          const dateObj = new Date(b.createdAt);
                          const dateFormatted = isNaN(dateObj.getTime()) ? b.createdAt : dateObj.toLocaleString('id-ID', {
                            year: 'numeric', month: 'short', day: 'numeric',
                            hour: '2-digit', minute: '2-digit'
                          }) + ' WIB';

                          return (
                            <tr key={b.filename} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/10 transition-all font-semibold">
                              <td className="p-3 font-mono text-slate-700 dark:text-slate-300 truncate max-w-xs" title={b.filename}>
                                {b.filename}
                              </td>
                              <td className="p-3 text-slate-500">
                                {formatBytes(b.size)}
                              </td>
                              <td className="p-3 text-slate-500 font-medium">
                                {dateFormatted}
                              </td>
                              <td className="p-3">
                                <div className="flex items-center justify-center space-x-2">
                                  <button
                                    onClick={() => handleDownloadBackup(b.filename)}
                                    className="p-1 px-2.5 text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 rounded-lg border border-indigo-100 dark:border-indigo-900/30 text-[10px] font-black uppercase transition-all cursor-pointer"
                                    title="Unduh File Backup ke Komputer"
                                  >
                                    Unduh
                                  </button>
                                  <button
                                    onClick={() => handleRestoreBackup(b.filename)}
                                    disabled={actionLoading}
                                    className="p-1 px-2.5 text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950/30 rounded-lg border border-amber-100 dark:border-amber-900/30 text-[10px] font-black uppercase transition-all cursor-pointer disabled:opacity-50"
                                    title="Pulihkan Database Sekarang"
                                  >
                                    Restore
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
        </>
      )}
    </div>
  );
}
