import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  Search, 
  Trash2, 
  Download, 
  RefreshCw, 
  AlertCircle, 
  Info, 
  ChevronDown, 
  ChevronUp,
  FileText
} from 'lucide-react';

interface SystemLog {
  id: string;
  timestamp: string;
  level: 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL';
  module: 'Backend' | 'Database' | 'API' | 'Auth' | 'CRUD';
  message: string;
  stackTrace: string | null;
  userId: string | null;
  username: string | null;
}

export default function LogViewer() {
  const [logs, setLogs] = useState<SystemLog[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [levelFilter, setLevelFilter] = useState<string>('ALL');
  const [moduleFilter, setModuleFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [limit, setLimit] = useState<string>('200');
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const fetchLogs = async () => {
    setIsLoading(true);
    setMessage(null);
    try {
      const queryParams = new URLSearchParams({
        level: levelFilter,
        module: moduleFilter,
        search: searchQuery,
        limit,
      });
      const res = await fetch(`/api/system/logs?${queryParams.toString()}`);
      if (!res.ok) throw new Error('Gagal memuat log sistem dari server');
      const data = await res.json();
      setLogs(data);
    } catch (err: any) {
      console.error(err);
      setMessage({ type: 'error', text: err.message || 'Terjadi kesalahan saat memuat log.' });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, [levelFilter, moduleFilter, limit]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchLogs();
  };

  const handleClearLogs = async () => {
    if (!window.confirm('Apakah Anda yakin ingin menghapus seluruh riwayat log sistem? Tindakan ini tidak dapat dibatalkan.')) {
      return;
    }
    
    setIsLoading(true);
    try {
      const res = await fetch('/api/system/logs', { method: 'DELETE' });
      if (!res.ok) throw new Error('Gagal membersihkan log');
      setLogs([]);
      setMessage({ type: 'success', text: 'Semua log sistem berhasil dibersihkan.' });
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'Gagal membersihkan log.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownloadLogs = () => {
    try {
      const dataStr = JSON.stringify(logs, null, 2);
      const blob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `log_sistem_md_pos_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Download error:', err);
      alert('Gagal mengekspor log.');
    }
  };

  const getLevelBadgeColor = (level: string) => {
    switch (level) {
      case 'CRITICAL':
        return 'bg-red-500/10 text-red-600 border border-red-500/20 dark:bg-red-500/20 dark:text-red-400';
      case 'ERROR':
        return 'bg-rose-500/10 text-rose-600 border border-rose-500/20 dark:bg-rose-500/20 dark:text-rose-400';
      case 'WARNING':
        return 'bg-amber-500/10 text-amber-600 border border-amber-500/20 dark:bg-amber-500/20 dark:text-amber-400';
      case 'INFO':
      default:
        return 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20 dark:bg-emerald-500/20 dark:text-emerald-400';
    }
  };

  const getModuleIcon = (module: string) => {
    switch (module) {
      case 'Auth':
        return <AlertCircle className="w-4 h-4 text-indigo-500" />;
      case 'Database':
        return <FileText className="w-4 h-4 text-blue-500" />;
      case 'API':
        return <RefreshCw className="w-4 h-4 text-purple-500" />;
      case 'CRUD':
        return <Info className="w-4 h-4 text-emerald-500" />;
      default:
        return <Info className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-7xl mx-auto w-full">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <div className="p-2 bg-rose-500/10 rounded-xl text-rose-500">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100">
                Log Sistem & Error
              </h1>
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                Pemantauan kesalahan sistem, log database, aktivitas keamanan, dan login operator.
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={fetchLogs}
            disabled={isLoading}
            className="flex items-center justify-center space-x-2 p-2.5 px-4 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-750 transition-all cursor-pointer disabled:opacity-55"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Segarkan</span>
          </button>

          <button
            onClick={handleDownloadLogs}
            disabled={logs.length === 0 || isLoading}
            className="flex items-center justify-center space-x-2 p-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all cursor-pointer disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>Ekspor JSON</span>
          </button>

          <button
            onClick={handleClearLogs}
            disabled={logs.length === 0 || isLoading}
            className="flex items-center justify-center space-x-2 p-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition-all cursor-pointer disabled:opacity-50"
          >
            <Trash2 className="w-4 h-4" />
            <span>Hapus Semua</span>
          </button>
        </div>
      </div>

      {/* Messages */}
      {message && (
        <div className={`p-4 rounded-xl border text-xs font-bold ${
          message.type === 'success' 
            ? 'bg-emerald-50 dark:bg-emerald-950/20 border-emerald-100 dark:border-emerald-900/40 text-emerald-700 dark:text-emerald-400' 
            : 'bg-red-50 dark:bg-red-950/20 border-red-100 dark:border-red-900/40 text-red-700 dark:text-red-400'
        }`}>
          {message.text}
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-[16px] border border-slate-200/60 dark:border-slate-800 p-4 shadow-xs">
        <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {/* Level Filter */}
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-wider mb-1.5">
              Tingkat (Severity Level)
            </label>
            <select
              value={levelFilter}
              onChange={(e) => setLevelFilter(e.target.value)}
              className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold"
            >
              <option value="ALL">Semua Tingkat</option>
              <option value="INFO">INFO</option>
              <option value="WARNING">WARNING</option>
              <option value="ERROR">ERROR</option>
              <option value="CRITICAL">CRITICAL</option>
            </select>
          </div>

          {/* Module Filter */}
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-wider mb-1.5">
              Modul
            </label>
            <select
              value={moduleFilter}
              onChange={(e) => setModuleFilter(e.target.value)}
              className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold"
            >
              <option value="ALL">Semua Modul</option>
              <option value="Backend">Backend Server</option>
              <option value="Database">Database PostgreSQL</option>
              <option value="API">API Gateway</option>
              <option value="Auth">Login & Auth</option>
              <option value="CRUD">CRUD Operasional</option>
            </select>
          </div>

          {/* Search Message */}
          <div className="md:col-span-2">
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-wider mb-1.5">
              Cari Berdasarkan Pesan
            </label>
            <div className="flex space-x-2">
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Cari pesan error..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 font-sans"
                />
              </div>
              <button
                type="submit"
                className="p-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition-all cursor-pointer"
              >
                Cari
              </button>
            </div>
          </div>
        </form>

        <div className="flex items-center justify-between border-t border-slate-150 dark:border-slate-800 mt-4 pt-3 text-[10px] text-slate-400 font-bold">
          <div>Menampilkan riwayat hingga {logs.length} log terakhir.</div>
          <div className="flex items-center space-x-1">
            <span>Batas Tampilan:</span>
            <select
              value={limit}
              onChange={(e) => setLimit(e.target.value)}
              className="bg-transparent border-none focus:outline-none text-indigo-500 font-extrabold"
            >
              <option value="50">50 Baris</option>
              <option value="100">100 Baris</option>
              <option value="200">200 Baris</option>
              <option value="500">500 Baris</option>
            </select>
          </div>
        </div>
      </div>

      {/* Logs Table / List */}
      <div className="bg-white dark:bg-slate-900 rounded-[16px] border border-slate-200/60 dark:border-slate-800 shadow-xs overflow-hidden">
        {isLoading && logs.length === 0 ? (
          <div className="py-20 text-center text-slate-400 flex flex-col items-center justify-center">
            <RefreshCw className="w-8 h-8 animate-spin text-indigo-500 mb-2" />
            <span className="text-xs font-bold">Memuat log sistem dari database...</span>
          </div>
        ) : logs.length === 0 ? (
          <div className="py-20 text-center text-slate-400 flex flex-col items-center justify-center">
            <AlertCircle className="w-10 h-10 text-slate-300 dark:text-slate-700 mb-2" />
            <h3 className="font-extrabold text-sm text-slate-700 dark:text-slate-300">Tidak Ada Log Ditemukan</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-sm">
              Tidak ada aktivitas sistem atau kesalahan yang tercatat berdasarkan filter pencarian saat ini.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200/80 dark:border-slate-800 text-[10px] font-black text-slate-400 uppercase tracking-wider">
                  <th className="p-4 w-12 text-center">Status</th>
                  <th className="p-4 w-24">Tingkat</th>
                  <th className="p-4 w-32">Modul / Cap</th>
                  <th className="p-4 w-44">Waktu (WIB)</th>
                  <th className="p-4">Pesan Log</th>
                  <th className="p-4 w-32">Operator</th>
                  <th className="p-4 w-20 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                {logs.map((log) => {
                  const isExpanded = expandedLogId === log.id;
                  const dateStr = new Date(log.timestamp).toLocaleString('id-ID', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                  }) + ' WIB';

                  return (
                    <React.Fragment key={log.id}>
                      <tr className={`hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors ${
                        log.level === 'CRITICAL' || log.level === 'ERROR' ? 'bg-rose-50/5 dark:bg-rose-950/2' : ''
                      }`}>
                        <td className="p-4 text-center">
                          <div className="inline-flex justify-center">
                            {getModuleIcon(log.module)}
                          </div>
                        </td>
                        <td className="p-4 font-extrabold">
                          <span className={`px-2 py-0.5 rounded-full text-[9px] font-black tracking-wide ${getLevelBadgeColor(log.level)}`}>
                            {log.level}
                          </span>
                        </td>
                        <td className="p-4 font-bold text-slate-700 dark:text-slate-300">
                          {log.module}
                        </td>
                        <td className="p-4 text-slate-500 font-medium">
                          {dateStr}
                        </td>
                        <td className="p-4 text-slate-800 dark:text-slate-200 font-medium break-all max-w-md">
                          {log.message}
                        </td>
                        <td className="p-4">
                          {log.username ? (
                            <span className="font-bold text-indigo-600 dark:text-indigo-400">
                              @{log.username}
                            </span>
                          ) : (
                            <span className="text-slate-400 font-semibold italic">System</span>
                          )}
                        </td>
                        <td className="p-4 text-center">
                          {log.stackTrace ? (
                            <button
                              onClick={() => setExpandedLogId(isExpanded ? null : log.id)}
                              className="p-1 text-indigo-500 hover:bg-indigo-50 dark:hover:bg-slate-800 rounded-lg transition-all inline-flex items-center space-x-1 font-bold text-[10px] cursor-pointer"
                              title="Tampilkan Detail Stack Trace"
                            >
                              <span>Stack</span>
                              {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                            </button>
                          ) : (
                            <span className="text-slate-300 dark:text-slate-700">-</span>
                          )}
                        </td>
                      </tr>
                      {isExpanded && log.stackTrace && (
                        <tr className="bg-slate-50 dark:bg-slate-950/40">
                          <td colSpan={7} className="p-4">
                            <div className="bg-slate-950 p-4 rounded-xl text-left border border-slate-850 overflow-x-auto">
                              <div className="text-[10px] text-slate-400 font-bold uppercase mb-2 tracking-wider">
                                Detail Stack Trace Kesalahan:
                              </div>
                              <pre className="font-mono text-[11px] text-red-400 whitespace-pre leading-relaxed">
                                {log.stackTrace}
                              </pre>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
