import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Product, ProductCategory, Role, PhysicalCategory } from '../types';
import ProductDetailModal from './ProductDetailModal';
import BarcodeCameraScanner from './BarcodeCameraScanner';
import { 
  Plus, 
  Search, 
  Edit3, 
  Trash2, 
  PackageCheck, 
  AlertTriangle, 
  RefreshCcw, 
  Smartphone, 
  Wifi, 
  Zap, 
  Gamepad2, 
  Layers,
  Sparkles,
  X,
  ShoppingBag,
  Package,
  ArrowUp,
  ArrowDown,
  Check,
  FolderKanban,
  Eye,
  EyeOff,
  Camera,
  FileSpreadsheet,
  Download,
  Upload,
  Lock
} from 'lucide-react';

interface ProductManagementProps {
  products: Product[];
  currentUserRole: Role;
  onAddProduct: (product: Omit<Product, 'id'>) => void;
  onEditProduct: (id: string, updatedProduct: Partial<Product>) => void;
  onDeleteProduct: (id: string) => void;
  physicalCategories?: PhysicalCategory[];
  onSavePhysicalCategories?: (categories: PhysicalCategory[]) => void;
  onRefreshProducts?: () => void;
  onViewVouchers?: (productId: string) => void;
}

export default function ProductManagement({ 
  products, 
  currentUserRole, 
  onAddProduct, 
  onEditProduct, 
  onDeleteProduct,
  physicalCategories = [],
  onSavePhysicalCategories,
  onRefreshProducts,
  onViewVouchers
}: ProductManagementProps) {
  const isAdmin = currentUserRole === 'admin';

  const [vouchersList, setVouchersList] = useState<any[]>([]);

  const loadVouchersList = async () => {
    try {
      const res = await fetch('/api/vouchers');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          setVouchersList(data);
        }
      }
    } catch (err) {
      console.warn('Gagal memuat list voucher:', err);
    }
  };

  useEffect(() => {
    loadVouchersList();
  }, [products]);

  // Filters & Search states
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('semua');
  const [operatorFilter, setOperatorFilter] = useState('semua');
  const [stockStatusFilter, setStockStatusFilter] = useState<'semua' | 'aman' | 'low' | 'empty'>('semua');
  const [barcodeTypeFilter, setBarcodeTypeFilter] = useState<'semua' | 'none' | 'single' | 'massal'>('semua');
  const [selectedVoucherProduct, setSelectedVoucherProduct] = useState<Product | null>(null);
  const [selectedDetailProduct, setSelectedDetailProduct] = useState<Product | null>(null);
  const [selectedBarcodeProduct, setSelectedBarcodeProduct] = useState<Product | null>(null);
  
  // Barcode Scanning and Utilities
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [scanningProduct, setScanningProduct] = useState<Product | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Trigger loading effect when filters change to show the beautiful skeleton loading
  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 450);
    return () => clearTimeout(timer);
  }, [searchQuery, categoryFilter, operatorFilter, stockStatusFilter, barcodeTypeFilter]);

  const activeDetailProduct = useMemo(() => {
    if (!selectedDetailProduct) return null;
    return products.find(p => p.id === selectedDetailProduct.id) || selectedDetailProduct;
  }, [products, selectedDetailProduct]);

  // Form states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  
  const [name, setName] = useState('');
  const [category, setCategory] = useState<string>('');
  const [operator, setOperator] = useState('');
  const [purchasePrice, setPurchasePrice] = useState(0);
  const [sellingPrice, setSellingPrice] = useState(0);
  const [stock, setStock] = useState(0);
  const [minStockLimit, setMinStockLimit] = useState(5);
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const imageFileInputRef = useRef<HTMLInputElement>(null);
  const [barcodeType, setBarcodeType] = useState<'none' | 'single' | 'massal'>('none');
  const [barcode, setBarcode] = useState('');

  // Restock Quick states
  const [isRestockOpen, setIsRestockOpen] = useState(false);
  const [restockProduct, setRestockProduct] = useState<Product | null>(null);
  const [restockAmount, setRestockAmount] = useState(10);

  // Custom visual confirm & error states
  const [formError, setFormError] = useState('');
  const [isPriceWarningAccepted, setIsPriceWarningAccepted] = useState(false);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);

  // Category Manager States
  const [isCategoryManagerOpen, setIsCategoryManagerOpen] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [newCatSortOrder, setNewCatSortOrder] = useState<number>(0);
  const [editingCatId, setEditingCatId] = useState<string | null>(null);
  const [editingCatName, setEditingCatName] = useState('');
  const [editingCatSortOrder, setEditingCatSortOrder] = useState<number>(0);

  // Category Manager Handlers
  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;

    // Default sort order to max order + 1
    const nextSortOrder = newCatSortOrder || (physicalCategories.length > 0 
      ? Math.max(...physicalCategories.map(c => c.sort_order || 0)) + 1 
      : 1);

    const newCat: PhysicalCategory = {
      id: `cat-${Date.now()}`,
      name: newCatName.trim(),
      sort_order: nextSortOrder,
      is_active: true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    const updated = [...physicalCategories, newCat];
    if (onSavePhysicalCategories) {
      onSavePhysicalCategories(updated);
    }
    setNewCatName('');
    setNewCatSortOrder(0);
  };

  const handleStartEditCategory = (cat: PhysicalCategory) => {
    setEditingCatId(cat.id);
    setEditingCatName(cat.name);
    setEditingCatSortOrder(cat.sort_order);
  };

  const handleSaveEditCategory = (id: string) => {
    if (!editingCatName.trim()) return;
    const updated = physicalCategories.map(c => {
      if (c.id === id) {
        return {
          ...c,
          name: editingCatName.trim(),
          sort_order: Number(editingCatSortOrder),
          updated_at: new Date().toISOString()
        };
      }
      return c;
    });
    if (onSavePhysicalCategories) {
      onSavePhysicalCategories(updated);
    }
    setEditingCatId(null);
    setEditingCatName('');
  };

  const handleDeleteCategory = (id: string) => {
    const updated = physicalCategories.filter(c => c.id !== id);
    if (onSavePhysicalCategories) {
      onSavePhysicalCategories(updated);
    }
  };

  const handleToggleCategoryActive = (id: string, currentStatus: boolean) => {
    const updated = physicalCategories.map(c => {
      if (c.id === id) {
        return {
          ...c,
          is_active: !currentStatus,
          updated_at: new Date().toISOString()
        };
      }
      return c;
    });
    if (onSavePhysicalCategories) {
      onSavePhysicalCategories(updated);
    }
  };

  const handleMoveCategory = (index: number, direction: 'up' | 'down') => {
    const sorted = [...physicalCategories].sort((a, b) => a.sort_order - b.sort_order);
    if (direction === 'up' && index > 0) {
      const current = sorted[index];
      const prev = sorted[index - 1];
      
      const temp = current.sort_order;
      current.sort_order = prev.sort_order;
      prev.sort_order = temp;
      
      if (current.sort_order === prev.sort_order) {
        current.sort_order = index;
        prev.sort_order = index - 1;
      }
    } else if (direction === 'down' && index < sorted.length - 1) {
      const current = sorted[index];
      const next = sorted[index + 1];
      
      const temp = current.sort_order;
      current.sort_order = next.sort_order;
      next.sort_order = temp;
      
      if (current.sort_order === next.sort_order) {
        current.sort_order = index;
        next.sort_order = index + 1;
      }
    }
    
    const updated = physicalCategories.map(c => {
      const found = sorted.find(s => s.id === c.id);
      return found ? { ...c, sort_order: found.sort_order } : c;
    });
    
    if (onSavePhysicalCategories) {
      onSavePhysicalCategories(updated);
    }
  };

  // 1. Operators list for filter dropdown
  const operators = useMemo(() => {
    const list = products.map(p => p.operator);
    return ['semua', ...Array.from(new Set(list))];
  }, [products]);

  // 2. Metrics calculated from current products
  const metrics = useMemo(() => {
    const total = products.length;
    const lowStock = products.filter(p => p.stock > 0 && p.stock <= p.minStockLimit).length;
    const outOfStock = products.filter(p => p.stock <= 0).length;
    const totalValue = products.reduce((acc, p) => acc + (p.purchasePrice * p.stock), 0);

    return { total, lowStock, outOfStock, totalValue };
  }, [products]);

  // 3. Filter products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // Find category name if it's a dynamic category
      const foundCat = physicalCategories.find(c => c.id === p.category);
      const catName = foundCat ? foundCat.name : p.category;

      const matchSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.operator.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (p.barcode || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
                          catName.toLowerCase().includes(searchQuery.toLowerCase());

      const matchCategory = categoryFilter === 'semua' || p.category === categoryFilter;
      const matchOperator = operatorFilter === 'semua' || p.operator === operatorFilter;
      const matchBarcodeType = barcodeTypeFilter === 'semua' || (p.barcodeType || 'none') === barcodeTypeFilter;
      
      let matchStock = true;
      if (stockStatusFilter === 'aman') {
        matchStock = p.stock > p.minStockLimit;
      } else if (stockStatusFilter === 'low') {
        matchStock = p.stock > 0 && p.stock <= p.minStockLimit;
      } else if (stockStatusFilter === 'empty') {
        matchStock = p.stock <= 0;
      }

      return matchSearch && matchCategory && matchOperator && matchBarcodeType && matchStock;
    });
  }, [products, searchQuery, categoryFilter, operatorFilter, stockStatusFilter, barcodeTypeFilter, physicalCategories]);

  const handleOpenAddModal = () => {
    setEditingProduct(null);
    setName('');
    setCategory('');
    setOperator('');
    setPurchasePrice(0);
    setSellingPrice(0);
    setStock(10);
    setMinStockLimit(5);
    setDescription('');
    setImageUrl('');
    setBarcodeType('none');
    setBarcode('');
    setFormError('');
    setIsPriceWarningAccepted(false);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (product: Product) => {
    setEditingProduct(product);
    setName(product.name);
    setCategory(product.category);
    setOperator(product.operator);
    setPurchasePrice(product.purchasePrice);
    setSellingPrice(product.sellingPrice);
    setStock(product.stock);
    setMinStockLimit(product.minStockLimit);
    setDescription(product.description);
    setImageUrl(product.imageUrl || '');
    setBarcodeType(product.barcodeType || 'none');
    setBarcode(product.barcode || '');
    setFormError('');
    setIsPriceWarningAccepted(product.sellingPrice < product.purchasePrice);
    setIsModalOpen(true);
  };

  const handleOpenRestock = (product: Product) => {
    setRestockProduct(product);
    setRestockAmount(10);
    setIsRestockOpen(true);
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setFormError('File harus berupa gambar (PNG, JPG, JPEG, WEBP, dll).');
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setFormError('Ukuran gambar maksimal adalah 2MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setImageUrl(event.target.result as string);
        setFormError('');
      }
    };
    reader.onerror = () => {
      setFormError('Gagal membaca file gambar.');
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();

    if (!category) {
      setFormError('Kategori produk wajib dipilih.');
      return;
    }

    if (!name.trim() || !operator.trim()) {
      setFormError('Nama dan Operator wajib diisi.');
      return;
    }

    if (purchasePrice <= 0 || sellingPrice <= 0) {
      setFormError('Harga modal dan harga jual harus lebih besar dari 0.');
      return;
    }

    if (sellingPrice < purchasePrice && !isPriceWarningAccepted) {
      setFormError('Peringatan: Harga jual lebih rendah dari harga modal. Harap centang persetujuan di bawah.');
      return;
    }

    const productPayload = {
      name,
      category,
      operator: operator.trim(),
      purchasePrice: Number(purchasePrice),
      sellingPrice: Number(sellingPrice),
      stock: Number(stock),
      minStockLimit: Number(minStockLimit),
      description,
      imageUrl: imageUrl.trim() || undefined,
      barcodeType,
      barcode: barcodeType === 'single' ? extractBarcodeFromUrl(barcode) : ''
    };

    if (editingProduct) {
      onEditProduct(editingProduct.id, productPayload);
    } else {
      onAddProduct(productPayload);
    }

    setIsModalOpen(false);
  };

  const handleSaveRestock = (e: React.FormEvent) => {
    e.preventDefault();
    if (!restockProduct) return;
    
    const newStock = restockProduct.stock + Number(restockAmount);
    onEditProduct(restockProduct.id, { stock: newStock });
    setIsRestockOpen(false);
    setRestockProduct(null);
  };

  const handleDelete = (product: Product) => {
    setProductToDelete(product);
  };

  const getCategoryBadge = (cat: ProductCategory) => {
    const classes = "text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full inline-flex items-center space-x-1 ";
    
    // Check if it matches a dynamic physical category
    const foundCat = physicalCategories.find(c => c.id === cat);
    if (foundCat) {
      return (
        <span className={classes + "bg-emerald-50 text-emerald-700"}>
          <ShoppingBag className="w-3 h-3 mr-1" /> {foundCat.name}
        </span>
      );
    }

    switch (cat) {
      case 'pulsa': 
        return <span className={classes + "bg-indigo-50 text-indigo-700"}><Smartphone className="w-3 h-3 mr-1" /> Pulsa</span>;
      case 'paket_data': 
        return <span className={classes + "bg-blue-50 text-blue-700"}><Wifi className="w-3 h-3 mr-1" /> Data</span>;
      case 'token_pln': 
        return <span className={classes + "bg-amber-50 text-amber-700"}><Zap className="w-3 h-3 mr-1" /> Token</span>;
      case 'topup_game': 
        return <span className={classes + "bg-purple-50 text-purple-700"}><Gamepad2 className="w-3 h-3 mr-1" /> Game</span>;
      case 'voucher_fisik': 
        return <span className={classes + "bg-teal-50 text-teal-700"}><Layers className="w-3 h-3 mr-1" /> Voucher</span>;
      case 'barang_fisik': 
        return <span className={classes + "bg-emerald-50 text-emerald-700"}><ShoppingBag className="w-3 h-3 mr-1" /> Barang Fisik</span>;
      default:
        return null;
    }
  };

  const formatRupiah = (num: number) => {
    return 'Rp ' + num.toLocaleString('id-ID');
  };

  // Modern Export CSV (Compatible with Excel)
  const handleExportCSV = () => {
    const headers = ['Nama Produk', 'Deskripsi', 'Kategori', 'Operator', 'Harga Modal', 'Harga Jual', 'Stok', 'Min Stock Limit', 'Tipe Barcode', 'Barcode'];
    const rows = products.map(p => [
      p.name,
      p.description || '',
      p.category,
      p.operator,
      p.purchasePrice,
      p.sellingPrice,
      p.stock,
      p.minStockLimit,
      p.barcodeType || 'none',
      p.barcode || ''
    ]);
    
    const csvContent = "\uFEFF" + [headers.join(','), ...rows.map(r => r.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `daftar_produk_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Modern CSV/Excel Import Handler
  const handleImportCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        const lines = text.split('\n');
        if (lines.length <= 1) return;
        
        const parsedProducts: Partial<Product>[] = [];
        const headers = lines[0].split(',').map(h => h.replace(/["\r]/g, '').trim().toLowerCase());
        
        for (let i = 1; i < lines.length; i++) {
          const line = lines[i].trim();
          if (!line) continue;
          
          const values: string[] = [];
          let current = '';
          let inQuotes = false;
          for (let j = 0; j < line.length; j++) {
            const char = line[j];
            if (char === '"') {
              inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
              values.push(current.trim());
              current = '';
            } else {
              current += char;
            }
          }
          values.push(current.trim());
          
          if (values.length < 5) continue;
          
          const nameIdx = headers.indexOf('nama produk');
          const descIdx = headers.indexOf('deskripsi');
          const catIdx = headers.indexOf('kategori');
          const opIdx = headers.indexOf('operator');
          const modalIdx = headers.indexOf('harga modal');
          const jualIdx = headers.indexOf('harga jual');
          const stokIdx = headers.indexOf('stok');
          const limitIdx = headers.indexOf('min stock limit');
          const bcTypeIdx = headers.indexOf('tipe barcode');
          const bcIdx = headers.indexOf('barcode');
          
          const nameVal = nameIdx !== -1 ? values[nameIdx] : values[0];
          const descVal = descIdx !== -1 ? values[descIdx] : '';
          const catVal = catIdx !== -1 ? values[catIdx] : 'barang_fisik';
          const opVal = opIdx !== -1 ? values[opIdx] : 'Umum';
          const modalVal = Number(modalIdx !== -1 ? values[modalIdx] : (values[4] || 0));
          const jualVal = Number(jualIdx !== -1 ? values[jualIdx] : (values[5] || 0));
          const stokVal = Number(stokIdx !== -1 ? values[stokIdx] : (values[6] || 0));
          const limitVal = Number(limitIdx !== -1 ? values[limitIdx] : (values[7] || 5));
          const bcTypeVal = (bcTypeIdx !== -1 ? values[bcTypeIdx] : 'none') as 'none' | 'single' | 'massal';
          const bcVal = bcIdx !== -1 ? values[bcIdx] : '';
          
          if (!nameVal) continue;
          
          parsedProducts.push({
            name: nameVal.replace(/^"|"$/g, ''),
            description: descVal.replace(/^"|"$/g, ''),
            category: catVal,
            operator: opVal.replace(/^"|"$/g, ''),
            purchasePrice: isNaN(modalVal) ? 0 : modalVal,
            sellingPrice: isNaN(jualVal) ? 0 : jualVal,
            stock: isNaN(stokVal) ? 0 : stokVal,
            minStockLimit: isNaN(limitVal) ? 5 : limitVal,
            barcodeType: ['none', 'single', 'massal'].includes(bcTypeVal) ? bcTypeVal : 'none',
            barcode: bcVal.replace(/^"|"$/g, '')
          });
        }
        
        if (parsedProducts.length > 0) {
          for (const newP of parsedProducts) {
            await onAddProduct(newP as Omit<Product, 'id' | 'created_at' | 'updated_at'>);
          }
          alert(`Berhasil mengimpor ${parsedProducts.length} produk!`);
          if (onRefreshProducts) onRefreshProducts();
        }
      } catch (err) {
        console.error(err);
        alert('Gagal mengimpor file CSV. Pastikan format file benar.');
      }
      e.target.value = '';
    };
    reader.readAsText(file);
  };

  const extractBarcodeFromUrl = (input: string): string => {
    // Strip non-printable ASCII control characters (e.g. STX, ETX, Carriage Return, Line Feed, backspace, etc.)
    const cleanedInput = input.replace(/[^\x20-\x7E]/g, '');
    const trimmed = cleanedInput.trim();
    if (!trimmed) return '';
    
    // Check if it's a URL
    if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
      try {
        const url = new URL(trimmed);
        const codeParams = ['code', 'id', 'sn', 'barcode', 'serial', 'v', 'k', 'sn_voucher'];
        for (const param of codeParams) {
          const val = url.searchParams.get(param);
          if (val) return val.trim();
        }
        
        const segments = url.pathname.split('/').filter(Boolean);
        if (segments.length > 0) {
          return segments[segments.length - 1].trim();
        }
      } catch (e) {
        // Ignored
      }
    }
    
    // Strip common wrapper formatting
    return trimmed.replace(/^["'\[\(]+|["'\]\)]+$/g, '');
  };

  const handleOpenScanner = (product: Product) => {
    setScanningProduct(product);
    setIsScannerOpen(true);
  };

  const handleBarcodeScanned = (scannedCode: string) => {
    if (!scanningProduct) return;
    
    const cleanCode = extractBarcodeFromUrl(scannedCode);
    if (!cleanCode) return;

    if (!scanningProduct.barcode) {
      // Pendaftaran barcode baru hanya untuk admin
      if (!isAdmin) {
        alert("Pendaftaran atau tambah barcode baru hanya dapat dilakukan oleh Admin!");
        setIsScannerOpen(false);
        setScanningProduct(null);
        return;
      }
      // Bind barcode and mark as single barcode type
      onEditProduct(scanningProduct.id, { barcode: cleanCode, barcodeType: 'single' });
      alert(`Berhasil mendaftarkan barcode "${cleanCode}" untuk produk "${scanningProduct.name}"!`);
      if (onRefreshProducts) onRefreshProducts();
    } else if (scanningProduct.barcode === cleanCode) {
      // Match! Add 1 stock
      const confirmAdd = window.confirm(
        `Barcode terverifikasi!\nProduk: ${scanningProduct.name}\nStok Saat Ini: ${scanningProduct.stock}\n\nApakah Anda ingin menambah +1 stok untuk produk ini?`
      );
      if (confirmAdd) {
        onEditProduct(scanningProduct.id, { stock: scanningProduct.stock + 1 });
        if (onRefreshProducts) onRefreshProducts();
      }
    } else {
      alert(`Barcode tidak cocok!\nScanned: ${cleanCode}\nProduk: ${scanningProduct.name}\nBarcode Produk: ${scanningProduct.barcode}`);
    }
    
    setIsScannerOpen(false);
    setScanningProduct(null);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 bg-slate-50">
      
      {/* 1. Header with Actions */}
      <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">STOK & PRODUK JUALAN</h1>
          <p className="text-slate-500 text-sm">Kelola produk pulsa, paket data, voucher, dan barang fisik di konter</p>
        </div>
        
        <div className="flex flex-wrap gap-2.5 self-start xl:self-auto font-sans">
          {isAdmin && (
            <button
              id="manage-categories-btn"
              onClick={() => setIsCategoryManagerOpen(true)}
              className="inline-flex items-center justify-center px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all space-x-1.5 cursor-pointer"
            >
              <FolderKanban className="w-4 h-4 text-slate-500" />
              <span>Kelola Kategori</span>
            </button>
          )}

          {isAdmin && (
            <button
              id="add-product-btn"
              onClick={handleOpenAddModal}
              className="inline-flex items-center justify-center px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-lg shadow-blue-500/10 hover:shadow-blue-500/20 hover:-translate-y-0.5 transition-all space-x-1.5 cursor-pointer font-sans"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Produk</span>
            </button>
          )}
        </div>
      </div>

      {/* 2. Metrics Summary */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="p-4 rounded-[20px] bg-white border border-slate-100 shadow-xs flex items-center space-x-4">
          <div className="p-3 bg-blue-50 rounded-xl text-blue-600">
            <PackageCheck className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total Produk</span>
            <p className="text-2xl font-extrabold text-slate-900 font-mono leading-none mt-1">{metrics.total}</p>
          </div>
        </div>

        <div className="p-4 rounded-[20px] bg-white border border-slate-100 shadow-xs flex items-center space-x-4">
          <div className="p-3 bg-amber-50 rounded-xl text-amber-500">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Stok Menipis</span>
            <p className="text-2xl font-extrabold text-amber-600 font-mono leading-none mt-1">{metrics.lowStock}</p>
          </div>
        </div>

        <div className="p-4 rounded-[20px] bg-white border border-slate-100 shadow-xs flex items-center space-x-4">
          <div className="p-3 bg-red-50 rounded-xl text-red-600">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Stok Habis</span>
            <p className="text-2xl font-extrabold text-red-600 font-mono leading-none mt-1">{metrics.outOfStock}</p>
          </div>
        </div>

        {isAdmin ? (
          <div className="p-4 rounded-[20px] bg-white border border-slate-100 shadow-xs flex items-center space-x-4">
            <div className="p-3 bg-emerald-50 rounded-xl text-emerald-600">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Estimasi Aset Stok</span>
              <p className="text-base font-extrabold text-emerald-700 font-mono leading-none mt-1.5">{formatRupiah(metrics.totalValue)}</p>
            </div>
          </div>
        ) : (
          <div className="p-4 rounded-[20px] bg-slate-50 border border-slate-100 flex items-center space-x-3 text-slate-400">
            <div className="p-2.5 bg-slate-100 rounded-xl">
              <Lock className="w-4 h-4 text-slate-400" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block font-sans">Estimasi Aset Stok</span>
              <span className="text-[10px] font-medium block leading-tight mt-0.5 text-slate-500 font-sans">Akses Terbatas Admin</span>
            </div>
          </div>
        )}
      </div>

      {/* 3. Filters & Search Box (Pencarian Produk) */}
      <div className="bg-white p-3 sm:p-5 rounded-[20px] border border-slate-100 shadow-xs mb-6">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2.5">Pencarian & Penyaringan Produk</h3>
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-5 gap-2 sm:gap-3.5">
          {/* Search */}
          <div className="relative col-span-2 lg:col-span-1">
            <label htmlFor="search-query-input" className="sr-only">Cari Produk</label>
            <Search className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 w-4 h-4 my-auto" />
            <input
              id="search-query-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari nama, barcode, operator..."
              className="w-full pl-9 pr-3.5 py-2.5 border border-slate-200 rounded-[16px] text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 focus:bg-white transition-colors"
            />
          </div>

          {/* Category Filter */}
          <div>
            <label htmlFor="category-filter" className="sr-only">Filter Kategori</label>
            <select
              id="category-filter"
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full px-3.5 py-2.5 border border-slate-200 rounded-[16px] text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 text-slate-700"
            >
              <option value="semua">Semua Kategori</option>
              {physicalCategories.map(cat => (
                <option key={cat.id} value={cat.id}>{cat.name}</option>
              ))}
            </select>
          </div>

          {/* Operator Filter */}
          <div>
            <label htmlFor="operator-filter" className="sr-only">Filter Operator</label>
            <select
              id="operator-filter"
              value={operatorFilter}
              onChange={(e) => setOperatorFilter(e.target.value)}
              className="w-full px-3.5 py-2.5 border border-slate-200 rounded-[16px] text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 text-slate-700 capitalize"
            >
              <option value="semua">Semua Operator</option>
              {operators.filter(o => o !== 'semua').map((op) => (
                <option key={op} value={op}>{op}</option>
              ))}
            </select>
          </div>

          {/* Jenis Produk (Barcode Type) Filter */}
          <div>
            <label htmlFor="barcode-type-filter" className="sr-only">Filter Jenis Produk</label>
            <select
              id="barcode-type-filter"
              value={barcodeTypeFilter}
              onChange={(e) => setBarcodeTypeFilter(e.target.value as any)}
              className="w-full px-3.5 py-2.5 border border-slate-200 rounded-[16px] text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 text-slate-700"
            >
              <option value="semua">Semua Jenis Produk</option>
              <option value="none">Tanpa Barcode / Manual</option>
              <option value="single">Barcode Tunggal</option>
              <option value="massal">Barcode Serial / Massal</option>
            </select>
          </div>

          {/* Status Stok Filter */}
          <div>
            <label htmlFor="stock-status-filter" className="sr-only">Filter Status Stok</label>
            <select
              id="stock-status-filter"
              value={stockStatusFilter}
              onChange={(e) => setStockStatusFilter(e.target.value as any)}
              className="w-full px-3.5 py-2.5 border border-slate-200 rounded-[16px] text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 text-slate-700"
            >
              <option value="semua">Semua Kondisi Stok</option>
              <option value="aman">🟢 Aman</option>
              <option value="low">🟡 Menipis</option>
              <option value="empty">🔴 Habis</option>
            </select>
          </div>
        </div>
      </div>

      {/* 4. Products Container (Modern Cards List or Skeleton Loading) */}
      {isLoading ? (
        // Beautiful Pulse Card Skeletons
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-1.5 sm:gap-3 lg:gap-4 animate-in fade-in duration-300">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => (
            <div key={n} className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl shadow-2xs p-2 sm:p-3 animate-pulse flex flex-col justify-between h-[180px]">
              <div className="flex items-start gap-2">
                <div className="w-10 h-10 bg-slate-100 dark:bg-slate-800 rounded-lg shrink-0"></div>
                <div className="flex-1 space-y-1.5 min-w-0">
                  <div className="h-3 bg-slate-100 dark:bg-slate-800 rounded-sm w-3/4"></div>
                  <div className="flex gap-1">
                    <div className="h-2.5 bg-slate-100 dark:bg-slate-800 rounded-sm w-1/3"></div>
                    <div className="h-2.5 bg-slate-100 dark:bg-slate-800 rounded-sm w-1/4"></div>
                  </div>
                </div>
              </div>
              <div className="h-4 bg-slate-100 dark:bg-slate-800 rounded-md mt-2"></div>
              <div className="h-6 bg-slate-100 dark:bg-slate-800 rounded-md mt-2"></div>
              <div className="h-6 bg-slate-100 dark:bg-slate-800 rounded-md mt-2"></div>
            </div>
          ))}
        </div>
      ) : filteredProducts.length === 0 ? (
        <div className="bg-white rounded-[20px] border border-slate-100 shadow-xs p-12 text-center text-slate-400">
          <PackageCheck className="w-16 h-16 text-slate-200 mx-auto mb-3 animate-pulse" />
          <p className="font-extrabold text-slate-600 text-base">Tidak ada stok produk jualan</p>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">Daftar produk kosong atau tidak sesuai kriteria penyaringan yang Anda pilih.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-7 gap-2 sm:gap-2.5 lg:gap-3 animate-in fade-in duration-300">
          {filteredProducts.map((p) => {
            const isOutOfStock = p.stock <= 0;
            const isLowStock = p.stock > 0 && p.stock <= p.minStockLimit;
            const profit = p.sellingPrice - p.purchasePrice;

            // Custom placeholder category visualizer
            const getPlaceholderDetails = (cat: ProductCategory) => {
              switch (cat) {
                case 'pulsa': 
                  return { gradient: 'from-indigo-500/10 to-indigo-600/5', icon: <Smartphone className="w-8 h-8 text-indigo-500" /> };
                case 'paket_data': 
                  return { gradient: 'from-blue-500/10 to-blue-600/5', icon: <Wifi className="w-8 h-8 text-blue-500" /> };
                case 'token_pln': 
                  return { gradient: 'from-amber-500/10 to-amber-600/5', icon: <Zap className="w-8 h-8 text-amber-500" /> };
                case 'topup_game': 
                  return { gradient: 'from-purple-500/10 to-purple-600/5', icon: <Gamepad2 className="w-8 h-8 text-purple-500" /> };
                case 'voucher_fisik': 
                  return { gradient: 'from-teal-500/10 to-teal-600/5', icon: <Layers className="w-8 h-8 text-teal-500" /> };
                case 'barang_fisik': 
                  return { gradient: 'from-emerald-500/10 to-emerald-600/5', icon: <ShoppingBag className="w-8 h-8 text-emerald-500" /> };
                default: 
                  return { gradient: 'from-slate-500/10 to-slate-600/5', icon: <Package className="w-8 h-8 text-slate-400" /> };
              }
            };

            const placeholder = getPlaceholderDetails(p.category);

            // Tipe B: Produk Multi Barcode (barcodeType === 'massal')
            if (p.barcodeType === 'massal') {
              const productVouchers = vouchersList.filter(v => v.productId === p.id);
              const readyCount = productVouchers.filter(v => v.status === 'READY').length;
              const soldCount = productVouchers.filter(v => v.status === 'SOLD').length;
              const returnCount = productVouchers.filter(v => v.status === 'RETURNED').length;
              const damagedCount = productVouchers.filter(v => v.status === 'DAMAGED').length;
              const expiredCount = productVouchers.filter(v => v.status === 'EXPIRED').length;

              return (
                <div 
                  key={p.id} 
                  id={`product-card-${p.id}`}
                  className="group relative bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl hover:border-indigo-400 dark:hover:border-indigo-500/50 hover:shadow-md transition-all duration-200 flex flex-col justify-between overflow-hidden"
                >
                  <div className="p-2 sm:p-2.5 flex flex-col flex-1 min-w-0">
                    {/* Photo + Meta Flex Row */}
                    <div className="flex items-start gap-1.5">
                      <div className="w-8 h-8 sm:w-9 sm:h-9 shrink-0 rounded-lg overflow-hidden border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 relative flex items-center justify-center">
                        {p.imageUrl ? (
                          <img
                            src={p.imageUrl}
                            alt={p.name}
                            loading="lazy"
                            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className={`w-full h-full bg-gradient-to-br ${placeholder.gradient} flex items-center justify-center transition-all duration-300`}>
                            {React.cloneElement(placeholder.icon, { className: "w-4 h-4 text-current shrink-0" })}
                          </div>
                        )}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="cursor-pointer" onClick={() => setSelectedDetailProduct(p)}>
                          <h4 className="font-extrabold text-slate-800 dark:text-slate-100 text-[10.5px] sm:text-[11px] leading-tight line-clamp-2 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors" title={p.name}>
                            {p.name}
                          </h4>
                        </div>

                        <div className="flex flex-wrap items-center gap-0.5 mt-0.5">
                          <span className="text-[7px] font-black tracking-wider text-slate-500 bg-slate-100 dark:bg-slate-800 px-1 py-0.2 rounded uppercase">
                            {p.operator}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Simple Statistics Grid */}
                    <div className="grid grid-cols-5 gap-0.5 border-t border-slate-100 dark:border-slate-800 pt-1 mt-1.5 bg-slate-50/60 dark:bg-slate-950/30 p-1 rounded-md text-center">
                      <div>
                        <span className="text-[6.5px] text-slate-400 font-bold uppercase tracking-wider block">Ready</span>
                        <span className="text-[8.5px] font-mono font-black text-emerald-600 leading-none">{readyCount}</span>
                      </div>
                      <div>
                        <span className="text-[6.5px] text-slate-400 font-bold uppercase tracking-wider block">Sold</span>
                        <span className="text-[8.5px] font-mono font-black text-blue-600 leading-none">{soldCount}</span>
                      </div>
                      <div>
                        <span className="text-[6.5px] text-slate-400 font-bold uppercase tracking-wider block">Retur</span>
                        <span className="text-[8.5px] font-mono font-black text-amber-600 leading-none">{returnCount}</span>
                      </div>
                      <div>
                        <span className="text-[6.5px] text-slate-400 font-bold uppercase tracking-wider block">Rusak</span>
                        <span className="text-[8.5px] font-mono font-black text-rose-600 leading-none">{damagedCount}</span>
                      </div>
                      <div>
                        <span className="text-[6.5px] text-slate-400 font-bold uppercase tracking-wider block">Exp</span>
                        <span className="text-[8.5px] font-mono font-black text-slate-500 leading-none">{expiredCount}</span>
                      </div>
                    </div>

                    {/* Unified Pricing Grid Panel for Tipe B */}
                    {isAdmin ? (
                      <div className="grid grid-cols-3 gap-0.5 border-t border-slate-100 dark:border-slate-800 pt-1 mt-1 text-center bg-slate-50/60 dark:bg-slate-950/30 p-1 rounded-md">
                        <div>
                          <p className="text-[6.5px] text-slate-400 font-bold uppercase tracking-wider">Modal</p>
                          <p className="text-[8px] font-mono font-bold text-slate-600 dark:text-slate-400 truncate">{formatRupiah(p.purchasePrice)}</p>
                        </div>
                        <div>
                          <p className="text-[6.5px] text-slate-400 font-bold uppercase tracking-wider">Jual</p>
                          <p className="text-[8px] font-mono font-black text-slate-900 dark:text-white truncate">{formatRupiah(p.sellingPrice)}</p>
                        </div>
                        <div>
                          <p className="text-[6.5px] text-slate-400 font-bold uppercase tracking-wider">Margin</p>
                          <p className="text-[8px] font-mono font-bold text-emerald-600 dark:text-emerald-400 truncate">+{formatRupiah(profit)}</p>
                        </div>
                      </div>
                    ) : (
                      <div className="border-t border-slate-100 dark:border-slate-800 pt-1 mt-1 text-center bg-slate-50/60 dark:bg-slate-950/30 p-1 rounded-md flex justify-between items-center px-1">
                        <p className="text-[6.5px] text-slate-500 font-bold uppercase tracking-wider">Harga Jual</p>
                        <p className="text-[9px] font-mono font-black text-slate-900 dark:text-white">{formatRupiah(p.sellingPrice)}</p>
                      </div>
                    )}
                  </div>

                  {/* Multi Barcode Action Bar */}
                  <div className="p-1 bg-slate-50/80 dark:bg-slate-900/80 border-t border-slate-100 dark:border-slate-800/80 grid grid-cols-3 gap-0.5 shrink-0">
                    {isAdmin ? (
                      <button
                        id={`btn-manage-barcodes-${p.id}`}
                        onClick={() => onViewVouchers && onViewVouchers(p.id)}
                        className="py-1 text-[8px] font-black text-blue-700 dark:text-blue-400 bg-blue-50/60 dark:bg-blue-950/30 hover:bg-blue-100 dark:hover:bg-blue-900/40 rounded-md transition-all inline-flex items-center justify-center space-x-0.5 cursor-pointer"
                        title="Kelola Barcode di Barcode Center"
                      >
                        <Layers className="w-2.5 h-2.5 text-blue-600 shrink-0" />
                        <span>Barcode</span>
                      </button>
                    ) : (
                      <div className="hidden"></div>
                    )}

                    {isAdmin ? (
                      <button
                        id={`btn-edit-${p.id}`}
                        onClick={() => handleOpenEditModal(p)}
                        className="py-1 text-[8px] font-bold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200/80 dark:border-slate-700 rounded-md transition-all inline-flex items-center justify-center space-x-0.5 cursor-pointer"
                      >
                        <Edit3 className="w-2.5 h-2.5 text-slate-500 shrink-0" />
                        <span>Edit</span>
                      </button>
                    ) : (
                      <div className="hidden"></div>
                    )}

                    {isAdmin ? (
                      <button
                        id={`btn-delete-${p.id}`}
                        onClick={() => handleDelete(p)}
                        className="py-1 text-[8px] font-bold text-red-600 dark:text-red-400 bg-red-50/60 dark:bg-red-950/30 hover:bg-red-100 dark:hover:bg-red-900/40 rounded-md transition-all inline-flex items-center justify-center space-x-0.5 cursor-pointer"
                      >
                        <Trash2 className="w-2.5 h-2.5 text-red-500 shrink-0" />
                        <span>Hapus</span>
                      </button>
                    ) : (
                      <div className="hidden"></div>
                    )}
                  </div>
                </div>
              );
            }

            // Tipe A: Produk Single Barcode (atau Kelola Manual / Tanpa Barcode)
            return (
              <div 
                key={p.id} 
                id={`product-card-${p.id}`}
                className="group relative bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl hover:border-indigo-400 dark:hover:border-indigo-500/50 hover:shadow-md transition-all duration-200 flex flex-col justify-between overflow-hidden"
              >
                <div className="p-2 sm:p-2.5 flex flex-col flex-1 min-w-0">
                  {/* Photo + Meta Flex Row */}
                  <div className="flex items-start gap-1.5">
                    <div className="w-8 h-8 sm:w-9 sm:h-9 shrink-0 rounded-lg overflow-hidden border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 relative flex items-center justify-center">
                      {p.imageUrl ? (
                        <img
                          src={p.imageUrl}
                          alt={p.name}
                          loading="lazy"
                          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className={`w-full h-full bg-gradient-to-br ${placeholder.gradient} flex items-center justify-center transition-all duration-300`}>
                          {React.cloneElement(placeholder.icon, { className: "w-4 h-4 text-current shrink-0" })}
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="cursor-pointer" onClick={() => setSelectedDetailProduct(p)}>
                        <h4 className="font-extrabold text-slate-800 dark:text-slate-100 text-[10.5px] sm:text-[11px] leading-tight line-clamp-2 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors" title={p.name}>
                          {p.name}
                        </h4>
                      </div>

                      <div className="flex flex-wrap items-center gap-0.5 mt-0.5">
                        <span className="text-[7px] font-black tracking-wider text-slate-500 bg-slate-100 dark:bg-slate-800 px-1 py-0.2 rounded uppercase">
                          {p.operator}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Stock, Barcode, Serial Indicators Block */}
                  <div className="mt-1.5 pt-1 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[8px] gap-1">
                    {/* Stock status badge */}
                    <div className="flex items-center gap-1">
                      <span className="text-[7px] font-bold text-slate-400 uppercase tracking-wider">Stok:</span>
                      {isOutOfStock ? (
                        <span className="inline-flex items-center px-1 py-0.2 rounded text-[7.5px] font-black bg-red-50 dark:bg-red-950/20 text-red-700 dark:text-red-400 animate-pulse">
                          Habis
                        </span>
                      ) : isLowStock ? (
                        <span className="inline-flex items-center px-1 py-0.2 rounded text-[7.5px] font-black bg-amber-50 dark:bg-amber-950/20 text-amber-700 dark:text-amber-400">
                          {p.stock}
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-1 py-0.2 rounded text-[7.5px] font-black bg-emerald-50 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-400">
                          {p.stock}
                        </span>
                      )}
                    </div>

                    {/* Barcode details */}
                    <div className="flex items-center gap-0.5 font-semibold">
                      <span className="text-[7px] font-bold text-slate-400 uppercase tracking-wider">BC:</span>
                      <span className="text-[7.5px] font-mono font-bold text-slate-600 dark:text-slate-400 truncate max-w-[50px] sm:max-w-[65px]" title={p.barcode}>
                        {p.barcode || 'Manual'}
                      </span>
                    </div>
                  </div>

                  {/* Pricing Grid Panel or Single Price for Cashier */}
                  {isAdmin ? (
                    <div className="grid grid-cols-3 gap-0.5 border-t border-slate-100 dark:border-slate-800 pt-1 mt-1 text-center bg-slate-50/60 dark:bg-slate-950/30 p-1 rounded-md">
                      <div>
                        <p className="text-[6.5px] text-slate-400 font-bold uppercase tracking-wider">Modal</p>
                        <p className="text-[8px] font-mono font-bold text-slate-600 dark:text-slate-400 truncate">{formatRupiah(p.purchasePrice)}</p>
                      </div>
                      <div>
                        <p className="text-[6.5px] text-slate-400 font-bold uppercase tracking-wider">Jual</p>
                        <p className="text-[8px] font-mono font-black text-slate-900 dark:text-white truncate">{formatRupiah(p.sellingPrice)}</p>
                      </div>
                      <div>
                        <p className="text-[6.5px] text-slate-400 font-bold uppercase tracking-wider">Margin</p>
                        <p className="text-[8px] font-mono font-bold text-emerald-600 dark:text-emerald-400 truncate">+{formatRupiah(profit)}</p>
                      </div>
                    </div>
                  ) : (
                    <div className="border-t border-slate-100 dark:border-slate-800 pt-1 mt-1 text-center bg-slate-50/60 dark:bg-slate-950/30 p-1 rounded-md flex justify-between items-center px-1">
                      <p className="text-[6.5px] text-slate-500 font-bold uppercase tracking-wider">Harga Jual</p>
                      <p className="text-[9px] font-mono font-black text-slate-900 dark:text-white">{formatRupiah(p.sellingPrice)}</p>
                    </div>
                  )}
                </div>

                {/* Footer/Action Buttons - Compact Single Row for Tipe A */}
                <div className="p-1 bg-slate-50/80 dark:bg-slate-900/80 border-t border-slate-100 dark:border-slate-800/80 grid grid-cols-3 gap-0.5 shrink-0">
                  {isAdmin ? (
                    <button
                      id={`btn-edit-${p.id}`}
                      onClick={() => handleOpenEditModal(p)}
                      className="py-1 text-[8px] font-bold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200/80 dark:border-slate-700 rounded-md transition-all inline-flex items-center justify-center space-x-0.5 cursor-pointer"
                      title="Edit detail produk"
                    >
                      <Edit3 className="w-2.5 h-2.5 text-slate-500 shrink-0" />
                      <span>Edit</span>
                    </button>
                  ) : (
                    <div className="hidden"></div>
                  )}

                  {isAdmin ? (
                    <button
                      id={`btn-scan-barcode-${p.id}`}
                      onClick={() => handleOpenScanner(p)}
                      className="py-1 text-[8px] font-black text-emerald-700 dark:text-emerald-400 bg-emerald-50/60 dark:bg-emerald-950/30 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 rounded-md transition-all inline-flex items-center justify-center space-x-0.5 cursor-pointer"
                      title={!p.barcode ? "Scan untuk mendaftarkan barcode baru" : "Scan Barcode Tunggal untuk konfirmasi / input cepat"}
                    >
                      <Camera className="w-2.5 h-2.5 text-emerald-600 shrink-0" />
                      <span>Scan</span>
                    </button>
                  ) : (
                    <div className="hidden"></div>
                  )}

                  {isAdmin ? (
                    <button
                      id={`btn-delete-${p.id}`}
                      onClick={() => handleDelete(p)}
                      className="py-1 text-[8px] font-bold text-red-600 dark:text-red-400 bg-red-50/60 dark:bg-red-950/30 hover:bg-red-100 dark:hover:bg-red-900/40 rounded-md transition-all inline-flex items-center justify-center space-x-0.5 cursor-pointer"
                      title="Hapus Produk dari POS"
                    >
                      <Trash2 className="w-2.5 h-2.5 text-red-500 shrink-0" />
                      <span>Hapus</span>
                    </button>
                  ) : (
                    <div className="hidden"></div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 5. ADD/EDIT PRODUCT MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 pb-12 sm:pb-4 z-[200]">
          <div className="bg-white rounded-[20px] shadow-2xl max-w-lg w-full max-h-[90vh] flex flex-col overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-200">
            <div className="p-5 bg-slate-950 text-white flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-extrabold text-base tracking-wide uppercase">
                  {editingProduct ? 'EDIT DATA PRODUK' : 'TAMBAH PRODUK BARU'}
                </h3>
                <p className="text-[10px] text-blue-400 font-semibold mt-0.5 uppercase">Spesifikasi Data POS</p>
              </div>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="flex-1 flex flex-col min-h-0 overflow-hidden">
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {formError && (
                <div className="p-3 bg-red-50 border border-red-100 text-red-700 rounded-xl text-xs font-bold flex items-center space-x-2 animate-in fade-in duration-200">
                  <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Product Name */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Nama Produk
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Contoh: Pulsa Telkomsel 25.000"
                    className="w-full px-3.5 py-2 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {/* Category */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Kategori Jualan
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3.5 py-2 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                  >
                    <option value="" disabled>-- Pilih Kategori --</option>
                    {/* Dynamic Physical Categories */}
                    {physicalCategories
                      .filter(cat => cat.is_active !== false || cat.id === category)
                      .map(cat => (
                        <option key={cat.id} value={cat.id}>{cat.name}</option>
                      ))}
                  </select>
                </div>

                {/* Operator */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Operator / Brand
                  </label>
                  <input
                    type="text"
                    required
                    value={operator}
                    onChange={(e) => setOperator(e.target.value)}
                    placeholder="Contoh: Telkomsel, XL, PLN"
                    className="w-full px-3.5 py-2 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {/* Harga Modal */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Harga Modal (Rp)
                  </label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={purchasePrice || ''}
                    onChange={(e) => setPurchasePrice(Number(e.target.value))}
                    className="w-full px-3.5 py-2 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono font-bold"
                  />
                </div>

                {/* Harga Jual */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Harga Jual (Rp)
                  </label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={sellingPrice || ''}
                    onChange={(e) => setSellingPrice(Number(e.target.value))}
                    className="w-full px-3.5 py-2 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono font-bold"
                  />
                </div>

                {/* Stock */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Jumlah Stok
                  </label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={stock}
                    onChange={(e) => setStock(Number(e.target.value))}
                    className="w-full px-3.5 py-2 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                  />
                </div>

                {/* Limit min */}
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Limit Minim Stok
                  </label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={minStockLimit}
                    onChange={(e) => setMinStockLimit(Number(e.target.value))}
                    className="w-full px-3.5 py-2 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                  />
                </div>

                {/* Description */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Deskripsi Produk (Keterangan)
                  </label>
                  <textarea
                    rows={2}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Contoh: Paket internet kuota utama tanpa dibagi-bagi."
                    className="w-full px-3.5 py-2 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {/* Tipe Barcode / Produk */}
                <div className="sm:col-span-2 bg-slate-50 p-3 rounded-[16px] border border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-extrabold text-slate-700 uppercase tracking-wider mb-1">
                      Tipe Barcode / Produk
                    </label>
                    <select
                      value={barcodeType === 'none' ? 'single' : barcodeType}
                      onChange={(e) => setBarcodeType(e.target.value as 'single' | 'massal')}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-slate-800"
                    >
                      <option value="single">Single Barcode (1 Barcode untuk seluruh stok)</option>
                      <option value="massal">Multi Barcode (Banyak Barcode serial unik / Voucher)</option>
                    </select>
                  </div>

                  {barcodeType !== 'massal' && (
                    <div className="animate-in slide-in-from-left duration-200">
                      <label className="block text-xs font-extrabold text-slate-700 uppercase tracking-wider mb-1">
                        Kode Barcode (Single)
                      </label>
                      <input
                        type="text"
                        value={barcode}
                        onChange={(e) => setBarcode(e.target.value)}
                        placeholder="Scan atau ketik kode barcode..."
                        className="w-full px-3 py-1.5 border border-slate-300 rounded-xl text-xs font-mono font-bold focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                      />
                    </div>
                  )}
                </div>

                {/* Image URL */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
                    Gambar Produk (Mendukung Upload File & Drag-and-Drop)
                  </label>
                  
                  {/* File Upload / Drag & Drop Container */}
                  <div
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={handleDrop}
                    onClick={() => imageFileInputRef.current?.click()}
                    className={`border-2 border-dashed rounded-2xl p-5 text-center cursor-pointer transition-all flex flex-col items-center justify-center min-h-[140px] relative overflow-hidden ${
                      isDragging
                        ? 'border-blue-500 bg-blue-50/40'
                        : imageUrl
                        ? 'border-slate-300 bg-slate-50/30'
                        : 'border-slate-300 hover:border-blue-400 bg-white hover:bg-slate-50/20'
                    }`}
                  >
                    <input
                      ref={imageFileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="hidden"
                    />

                    {imageUrl ? (
                      <div className="w-full flex flex-col sm:flex-row items-center justify-center gap-4 relative z-10 p-1">
                        <div className="relative w-24 h-24 rounded-xl border border-slate-200 overflow-hidden bg-slate-100 shadow-sm shrink-0 flex items-center justify-center">
                          <img
                            src={imageUrl}
                            alt="Preview Produk"
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div className="text-left flex-1 min-w-0">
                          <p className="text-xs font-bold text-slate-700 truncate max-w-[200px]">
                            {imageUrl.startsWith('data:') ? 'Gambar Berhasil Diupload' : 'Gambar dari URL'}
                          </p>
                          <p className="text-[10px] text-slate-450 mt-1">
                            Format gambar yang didukung: PNG, JPG, JPEG, WEBP.
                          </p>
                          <div className="flex items-center space-x-2 mt-3">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                imageFileInputRef.current?.click();
                              }}
                              className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded-lg text-[10px] font-bold transition-colors border border-blue-100"
                            >
                              Ganti Gambar
                            </button>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setImageUrl('');
                                if (imageFileInputRef.current) imageFileInputRef.current.value = '';
                              }}
                              className="px-2.5 py-1.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg text-[10px] font-bold transition-colors border border-red-100"
                            >
                              Hapus Gambar
                            </button>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center space-y-2 py-2">
                        <div className="p-3 bg-blue-50 text-blue-500 rounded-2xl border border-blue-100/50">
                          <Upload className="w-6 h-6" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-700">
                            Seret & Taruh gambar di sini, atau <span className="text-blue-600 hover:underline">Pilih File</span>
                          </p>
                          <p className="text-[10px] text-slate-400 mt-1 font-medium">
                            Maksimal ukuran file: 2MB (Format: PNG, JPG, JPEG, WEBP)
                          </p>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Fallback URL input with nice inline option */}
                  <div className="mt-3 bg-slate-50/50 p-3 rounded-[16px] border border-slate-200/50">
                    <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-1">
                      Atau Masukkan URL Gambar (Opsional)
                    </label>
                    <input
                      type="url"
                      value={imageUrl.startsWith('data:') ? '' : imageUrl}
                      onChange={(e) => setImageUrl(e.target.value)}
                      placeholder="Contoh: https://images.unsplash.com/photo-xxx"
                      className="w-full px-3.5 py-2 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>



              </div>

              {sellingPrice > 0 && purchasePrice > 0 && sellingPrice < purchasePrice && (
                <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-xs space-y-2 animate-in fade-in duration-200">
                  <div className="font-bold flex items-center space-x-1.5 text-amber-850">
                    <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
                    <span>Peringatan: Harga Jual di Bawah Harga Modal</span>
                  </div>
                  <p className="text-slate-600 leading-relaxed">
                    Anda menetapkan harga jual ({formatRupiah(sellingPrice)}) lebih rendah dari harga modal ({formatRupiah(purchasePrice)}). Ini akan mengakibatkan kerugian sebesar {formatRupiah(purchasePrice - sellingPrice)} per transaksi.
                  </p>
                  <label className="flex items-center space-x-2 font-bold text-amber-900 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={isPriceWarningAccepted}
                      onChange={(e) => {
                        setIsPriceWarningAccepted(e.target.checked);
                        if (e.target.checked && formError.includes('Peringatan: Harga jual')) {
                          setFormError('');
                        }
                      }}
                      className="rounded text-amber-600 focus:ring-amber-500 border-amber-300 w-4 h-4"
                    />
                    <span>Ya, Saya menyetujui harga jual rugi ini</span>
                  </label>
                </div>
              )}

              </div>

              <div className="flex justify-end space-x-2 border-t border-slate-100 p-4 bg-slate-50 shrink-0">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs transition-colors"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs transition-colors shadow-lg shadow-blue-500/20"
                >
                  {editingProduct ? 'Simpan Perubahan' : 'Tambah Produk'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 6. RESTOCK QUICK MODAL */}
      {isRestockOpen && restockProduct && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 pb-12 sm:pb-4 z-[200]">
          <div className="bg-white rounded-[20px] shadow-2xl max-w-sm w-full overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 bg-slate-950 text-white flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-sm tracking-wide">RESTOCK PRODUK</h3>
                <p className="text-[10px] text-blue-400 font-semibold mt-0.5 animate-pulse">Tambah Stok Jualan</p>
              </div>
              <button 
                onClick={() => {
                  setIsRestockOpen(false);
                  setRestockProduct(null);
                }}
                className="p-1 bg-slate-900 hover:bg-slate-800 text-slate-400 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveRestock} className="p-5 space-y-4">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <p className="text-xs font-bold text-slate-800 leading-tight">{restockProduct.name}</p>
                <div className="flex justify-between items-center text-[10px] text-slate-500 mt-2 font-mono">
                  <span>Stok saat ini: <strong className="text-slate-700">{restockProduct.stock} pcs</strong></span>
                  <span>Harga modal: <strong className="text-slate-700">{formatRupiah(restockProduct.purchasePrice)}</strong></span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
                  Jumlah Tambahan Stok
                </label>
                <input
                  type="number"
                  required
                  min={1}
                  value={restockAmount}
                  onChange={(e) => setRestockAmount(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-sm font-mono font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="border-t border-slate-100 pt-3 mt-1 flex justify-between items-center text-xs">
                <span className="text-slate-500 font-semibold">Total stok setelah restock:</span>
                <span className="font-bold text-slate-900 font-mono text-sm">{restockProduct.stock + Number(restockAmount)} pcs</span>
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsRestockOpen(false);
                    setRestockProduct(null);
                  }}
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs shadow-lg shadow-blue-500/20"
                >
                  Simpan Stok
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 7. CUSTOM DELETE CONFIRMATION MODAL */}
      {productToDelete && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 pb-12 sm:pb-4 z-[200]">
          <div className="bg-white rounded-[16px] shadow-2xl max-w-sm w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200 p-6">
            <div className="flex items-center space-x-3 text-red-600 mb-4">
              <div className="p-2 bg-red-50 rounded-lg">
                <AlertTriangle className="w-6 h-6 animate-bounce" />
              </div>
              <h3 className="font-bold text-lg text-slate-900">Hapus Produk?</h3>
            </div>
            <p className="text-sm text-slate-600 mb-6 leading-relaxed">
              Apakah Anda yakin ingin menghapus produk <strong className="text-slate-900 font-bold">"{productToDelete.name}"</strong>? Tindakan ini tidak dapat dibatalkan.
            </p>
            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => setProductToDelete(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteProduct(productToDelete.id);
                  setProductToDelete(null);
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold text-xs transition-colors shadow-lg shadow-red-500/20"
              >
                Ya, Hapus
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 8. CATEGORY MANAGER MODAL */}
      {isCategoryManagerOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 pb-12 sm:pb-4 z-[200]">
          <div className="bg-white rounded-[20px] shadow-2xl max-w-lg w-full overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
            {/* Header */}
            <div className="p-4 bg-slate-950 text-white flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-extrabold text-sm tracking-wide">KELOLA KATEGORI PRODUK FISIK</h3>
                <p className="text-[10px] text-blue-400 font-semibold mt-0.5">Kelola kategori dinamis jualan fisik</p>
              </div>
              <button 
                onClick={() => {
                  setIsCategoryManagerOpen(false);
                  setEditingCatId(null);
                }}
                className="p-1 bg-slate-900 hover:bg-slate-800 text-slate-400 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content Area */}
            <div className="p-5 overflow-y-auto space-y-4 flex-1">
              {/* Add New Category Form */}
              <form onSubmit={handleAddCategory} className="bg-slate-50 p-4 rounded-[16px] border border-slate-200 space-y-3 shrink-0">
                <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider">Tambah Kategori Baru</h4>
                <div className="grid grid-cols-3 gap-2">
                  <div className="col-span-2">
                    <label className="block text-[9px] font-bold text-slate-500 uppercase mb-1">Nama Kategori</label>
                    <input
                      type="text"
                      required
                      placeholder="Contoh: Aksesoris, Voucher XL"
                      value={newCatName}
                      onChange={(e) => setNewCatName(e.target.value)}
                      className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] font-bold text-slate-500 uppercase mb-1">Urutan</label>
                    <input
                      type="number"
                      min={0}
                      placeholder="Auto"
                      value={newCatSortOrder || ''}
                      onChange={(e) => setNewCatSortOrder(Number(e.target.value))}
                      className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-800 font-mono"
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  className="w-full inline-flex items-center justify-center py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md shadow-indigo-500/10 transition-colors space-x-1 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Tambah Kategori</span>
                </button>
              </form>

              {/* List of Categories */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-bold text-slate-500 uppercase tracking-wider px-1 mb-1">
                  <span>Daftar Kategori ({physicalCategories.length})</span>
                  <span>Urutan</span>
                </div>

                {physicalCategories.length === 0 ? (
                  <div className="text-center py-8 bg-slate-50 rounded-[16px] border border-dashed border-slate-200">
                    <ShoppingBag className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <p className="text-xs text-slate-500 font-semibold">Belum ada kategori dinamis</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">Kategori yang Anda tambah akan muncul di sini.</p>
                  </div>
                ) : (
                  <div className="space-y-1.5 max-h-[350px] overflow-y-auto pr-1">
                    {physicalCategories
                      .slice()
                      .sort((a, b) => a.sort_order - b.sort_order)
                      .map((cat, idx, arr) => {
                        const isEditing = editingCatId === cat.id;
                        return (
                          <div 
                            key={cat.id} 
                            className={`flex items-center justify-between p-3 rounded-xl border transition-all ${
                              !cat.is_active 
                                ? 'bg-slate-50/50 border-slate-100 opacity-60' 
                                : 'bg-white border-slate-100 hover:border-slate-200'
                            }`}
                          >
                            {isEditing ? (
                              <div className="flex items-center space-x-2 flex-1 mr-2">
                                <input
                                  type="text"
                                  value={editingCatName}
                                  onChange={(e) => setEditingCatName(e.target.value)}
                                  className="flex-1 px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold focus:outline-none text-slate-800"
                                />
                                <input
                                  type="number"
                                  value={editingCatSortOrder}
                                  onChange={(e) => setEditingCatSortOrder(Number(e.target.value))}
                                  className="w-14 px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-mono text-center focus:outline-none text-slate-800"
                                />
                                <button
                                  type="button"
                                  onClick={() => handleSaveEditCategory(cat.id)}
                                  className="p-1.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg transition-colors cursor-pointer"
                                  title="Simpan"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setEditingCatId(null)}
                                  className="p-1.5 bg-slate-200 hover:bg-slate-300 text-slate-600 rounded-lg transition-colors cursor-pointer"
                                  title="Batal"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ) : (
                              <>
                                <div className="flex items-center space-x-2.5">
                                  <span className={`text-xs font-extrabold ${cat.is_active ? 'text-slate-800' : 'text-slate-400 line-through'}`}>
                                    {cat.name}
                                  </span>
                                  {!cat.is_active && (
                                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-400">
                                      Nonaktif
                                    </span>
                                  )}
                                </div>

                                <div className="flex items-center space-x-2">
                                  {/* Sort Order Display */}
                                  <span className="text-[11px] font-extrabold font-mono text-slate-500 bg-slate-50 border border-slate-200 px-2 py-0.5 rounded-lg">
                                    {cat.sort_order}
                                  </span>

                                  {/* Up Arrow */}
                                  <button
                                    type="button"
                                    disabled={idx === 0}
                                    onClick={() => handleMoveCategory(idx, 'up')}
                                    className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-50 disabled:opacity-30 disabled:hover:bg-transparent rounded cursor-pointer"
                                    title="Naikkan Urutan"
                                  >
                                    <ArrowUp className="w-3.5 h-3.5" />
                                  </button>

                                  {/* Down Arrow */}
                                  <button
                                    type="button"
                                    disabled={idx === arr.length - 1}
                                    onClick={() => handleMoveCategory(idx, 'down')}
                                    className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-50 disabled:opacity-30 disabled:hover:bg-transparent rounded cursor-pointer"
                                    title="Turunkan Urutan"
                                  >
                                    <ArrowDown className="w-3.5 h-3.5" />
                                  </button>

                                  {/* Toggle Active/Inactive */}
                                  <button
                                    type="button"
                                    onClick={() => handleToggleCategoryActive(cat.id, cat.is_active)}
                                    className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                                      cat.is_active 
                                        ? 'text-emerald-600 hover:bg-emerald-50' 
                                        : 'text-slate-400 hover:bg-slate-100'
                                    }`}
                                    title={cat.is_active ? "Nonaktifkan Kategori" : "Aktifkan Kategori"}
                                  >
                                    {cat.is_active ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                                  </button>

                                  {/* Rename/Edit Button */}
                                  <button
                                    type="button"
                                    onClick={() => handleStartEditCategory(cat)}
                                    className="p-1.5 text-slate-500 hover:bg-slate-50 rounded-lg cursor-pointer"
                                    title="Ubah Nama/Urutan"
                                  >
                                    <Edit3 className="w-3.5 h-3.5" />
                                  </button>

                                  {/* Delete Button */}
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteCategory(cat.id)}
                                    className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg cursor-pointer"
                                    title="Hapus Kategori"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </>
                            )}
                          </div>
                        );
                      })}
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="bg-slate-50 p-4 border-t border-slate-100 flex justify-end shrink-0">
              <button
                type="button"
                onClick={() => {
                  setIsCategoryManagerOpen(false);
                  setEditingCatId(null);
                }}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl font-bold text-xs transition-colors cursor-pointer"
              >
                Selesai
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. DETAILED PRODUCT MANAGEMENT DIALOG */}
      {activeDetailProduct && (
        <ProductDetailModal
          product={activeDetailProduct}
          currentUserRole={currentUserRole}
          physicalCategories={physicalCategories}
          onClose={() => setSelectedDetailProduct(null)}
          onEditProduct={onEditProduct}
        />
      )}

      {/* 8. SINGLE BARCODE CAMERA SCANNER DIALOG */}
      {isScannerOpen && scanningProduct && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 pb-12 sm:pb-4 z-[200]">
          <div className="bg-white rounded-[20px] shadow-2xl max-w-md w-full overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 bg-slate-950 text-white flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-sm tracking-wide">SCAN BARCODE PRODUK</h3>
                <p className="text-[10px] text-emerald-400 font-semibold mt-0.5 uppercase">Arahkan ke Kamera</p>
              </div>
              <button 
                onClick={() => {
                  setIsScannerOpen(false);
                  setScanningProduct(null);
                }}
                className="p-1 bg-slate-900 hover:bg-slate-800 text-slate-400 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <div className="p-5 flex flex-col items-center">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-[16px] w-full mb-4 text-center">
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Sedang Memproses</span>
                <span className="text-sm font-extrabold text-slate-900 mt-1 block">{scanningProduct.name}</span>
                {scanningProduct.barcode ? (
                  <span className="text-[10px] font-mono text-slate-500 bg-slate-200/60 px-2 py-0.5 rounded-full mt-1.5 inline-block">
                    Target Code: {scanningProduct.barcode}
                  </span>
                ) : (
                  <span className="text-[10px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full mt-1.5 inline-block border border-amber-100">
                    Belum ada barcode. Scan untuk mendaftarkan!
                  </span>
                )}
              </div>

              {/* Live camera stream using our BarcodeCameraScanner */}
              <div className="w-full aspect-square max-w-[280px] bg-slate-950 rounded-[16px] overflow-hidden border border-slate-200 relative">
                <BarcodeCameraScanner 
                  isOpen={isScannerOpen}
                  onScan={handleBarcodeScanned}
                  onClose={() => {
                    setIsScannerOpen(false);
                    setScanningProduct(null);
                  }}
                />
              </div>

              <div className="mt-4 text-center text-xs text-slate-400 max-w-xs leading-relaxed">
                <p>Kamera akan otomatis membaca kode barcode atau QR code. Pastikan pencahayaan cukup dan barcode diposisikan di tengah layar.</p>
              </div>

              <button
                type="button"
                onClick={() => {
                  setIsScannerOpen(false);
                  setScanningProduct(null);
                }}
                className="mt-4 w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
              >
                Tutup Scanner
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
