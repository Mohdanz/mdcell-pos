import React, { useState, useMemo } from 'react';
import { EWallet, Transaction, TransactionItem, ProductCategory, Shift, Product, PhysicalCategory } from '../types';
import { AppConfig } from './SettingsView';
import { 
  Search, 
  Smartphone, 
  Wifi, 
  Layers, 
  Phone, 
  Wallet, 
  CheckCircle2, 
  AlertCircle, 
  Clock,
  ExternalLink,
  Lock,
  Receipt,
  X,
  ShoppingBag,
  HelpCircle,
  Package,
  Check,
  Trash2,
  Play,
  Plus,
  Tag,
  Camera,
  QrCode
} from 'lucide-react';
import BarcodeCameraScanner from './BarcodeCameraScanner';
import { CardWatermark } from './CardWatermark';

interface POSViewProps {
  products: Product[];
  eWallets: EWallet[];
  currentUser: { id: string; name: string; role: string };
  appConfig?: AppConfig;
  transactions: Transaction[];
  onProcessTransaction: (
    customerPhone: string,
    item: any,
    eWalletId: string
  ) => Promise<{ success: boolean; message: string; transaction?: Transaction }>;
  onProcessBatchTransactions?: (
    txs: Array<{ customerPhone: string; item: any; eWalletId: string }>
  ) => Promise<{ success: boolean; message: string; transactions?: Transaction[] }>;
  currentShift: Shift | null;
  shifts: Shift[];
  onStartShift: (initialCash: number, cashierId: string, cashierName: string) => Promise<Shift>;
  onCloseShift: (closedBy: string) => Promise<Shift | null>;
  initialMode?: 'topup' | 'withdrawal' | 'physical' | 'edc_transfer';
  physicalCategories?: PhysicalCategory[];
  posScannerTrigger?: number;
  physicalScannerTrigger?: number;
}

// Quick transaction service presets
const SERVICE_PRESETS = [
  { label: 'DANA', provider: 'DANA', defaultWalletKeyword: 'dana' },
  { label: 'OVO', provider: 'OVO', defaultWalletKeyword: 'ovo' },
  { label: 'GoPay', provider: 'GoPay', defaultWalletKeyword: 'goplay' },
  { label: 'ShopeePay', provider: 'ShopeePay', defaultWalletKeyword: 'shopee' },
  { label: 'PLN Token', provider: 'PLN', defaultWalletKeyword: 'ovo' }, // PLN token often matches OVO or other
  { label: 'Telkomsel', provider: 'Telkomsel', defaultWalletKeyword: 'dana' },
  { label: 'Indosat', provider: 'Indosat', defaultWalletKeyword: 'dana' },
  { label: 'XL Axiata', provider: 'XL', defaultWalletKeyword: 'dana' }
];

// Quick nominal presets
const NOMINAL_PRESETS = [5000, 10000, 20000, 50000, 100000, 200000];

export default function POSView({ 
  products,
  eWallets, 
  currentUser, 
  appConfig,
  transactions, 
  onProcessTransaction,
  onProcessBatchTransactions,
  currentShift,
  shifts,
  onStartShift,
  onCloseShift,
  initialMode,
  physicalCategories = [],
  posScannerTrigger = 0,
  physicalScannerTrigger = 0
}: POSViewProps) {
  // Manual Input States
  const [serviceName, setServiceName] = useState('');
  const [nominalStr, setNominalStr] = useState('');
  const [sellingPriceStr, setSellingPriceStr] = useState('');
  const customerPhone = '-';
  const [selectedEWallet, setSelectedEWallet] = useState<string>('');
  const [historySearchQuery, setHistorySearchQuery] = useState('');

  // POS Mode (Topup vs Withdrawal vs Physical vs EdcTransfer)
  const [posMode, setPosMode] = useState<'topup' | 'withdrawal' | 'physical' | 'edc_transfer'>('topup');

  // Withdrawal Input States
  const [wdAmountStr, setWdAmountStr] = useState('');
  const [wdFeeType, setWdFeeType] = useState<'admin_luar' | 'admin_potong'>('admin_luar');
  const [wdAdminFeeStr, setWdAdminFeeStr] = useState('5000');
  const [wdCustomerPhone, setWdCustomerPhone] = useState('');

  // EDC Transfer States
  const [edcBank, setEdcBank] = useState('');
  const [edcAccountNum, setEdcAccountNum] = useState('');
  const [edcAccountName, setEdcAccountName] = useState('');
  const [edcAmountStr, setEdcAmountStr] = useState('');
  const [edcAdminFeeStr, setEdcAdminFeeStr] = useState('5000');
  const [edcCustomerPhone, setEdcCustomerPhone] = useState('');

  // Physical POS States
  const [selectedProductId, setSelectedProductId] = useState('');
  const [scannedBarcodes, setScannedBarcodes] = useState<string[]>([]);
  const [physicalQuantity, setPhysicalQuantity] = useState(1);
  const [physicalCart, setPhysicalCart] = useState<{
    productId: string;
    productName: string;
    category: string;
    sellingPrice: number;
    purchasePrice: number;
    quantity: number;
    scannedBarcodes: string[];
    discountType: 'none' | 'percent' | 'nominal';
    discountValue: number;
    discountReason?: string;
    discountCustomReason?: string;
  }[]>([]);
  const [discountingCartItemId, setDiscountingCartItemId] = useState<string | null>(null);

  const addProductToPhysicalCart = (product: Product, barcode?: string) => {
    setPhysicalCart(prev => {
      const existingIndex = prev.findIndex(item => item.productId === product.id);
      if (existingIndex > -1) {
        return prev.map((item, idx) => {
          if (idx === existingIndex) {
            const updatedBarcodes = barcode && !item.scannedBarcodes.includes(barcode)
              ? [...item.scannedBarcodes, barcode]
              : item.scannedBarcodes;
            return {
              ...item,
              quantity: item.quantity + 1,
              scannedBarcodes: updatedBarcodes
            };
          }
          return item;
        });
      } else {
        return [
          ...prev,
          {
            productId: product.id,
            productName: product.name,
            category: product.category,
            sellingPrice: product.sellingPrice,
            purchasePrice: product.purchasePrice,
            quantity: 1,
            scannedBarcodes: barcode ? [barcode] : (product.barcode ? [product.barcode] : []),
            discountType: 'none',
            discountValue: 0
          }
        ];
      }
    });
  };

  const [physicalCustomerPhone, setPhysicalCustomerPhone] = useState('');
  const [physicalSearchQuery, setPhysicalSearchQuery] = useState('');
  const [activePhysicalCategoryId, setActivePhysicalCategoryId] = useState<string>('semua');
  const [physicalPaymentMethod, setPhysicalPaymentMethod] = useState<'cash' | 'transfer'>('cash');
  const [physicalSelectedEWallet, setPhysicalSelectedEWallet] = useState<string>('');
  const [topupPaymentMethod, setTopupPaymentMethod] = useState<'cash' | 'transfer'>('cash');
  const [topupSelectedEWallet, setTopupSelectedEWallet] = useState<string>('');
  
  // Physical Item Discount States
  const [physicalDiscountType, setPhysicalDiscountType] = useState<'none' | 'nominal' | 'percent'>('none');
  const [physicalDiscountValue, setPhysicalDiscountValue] = useState<number>(0);
  const [physicalDiscountReason, setPhysicalDiscountReason] = useState<string>('');
  const [physicalDiscountCustomReason, setPhysicalDiscountCustomReason] = useState<string>('');
  const [showDiscountModal, setShowDiscountModal] = useState<boolean>(false);

  // Voucher scanning POS states
  const [voucherBarcodeScan, setVoucherBarcodeScan] = useState('');
  const [scanError, setScanError] = useState('');
  const [scanSuccess, setScanSuccess] = useState('');
  const [isCameraScannerOpen, setIsCameraScannerOpen] = useState(false);

  // Physical Barcode POS scanner states
  const [isPhysicalCameraScannerOpen, setIsPhysicalCameraScannerOpen] = useState(false);
  const [physicalScanError, setPhysicalScanError] = useState('');
  const [physicalScanSuccess, setPhysicalScanSuccess] = useState('');

  // Unified Continuous POS Barcode Scanner states (Android & Tablet)
  const [isAndroidOrTablet, setIsAndroidOrTablet] = useState(false);
  const [isUnifiedScannerOpen, setIsUnifiedScannerOpen] = useState(false);
  const [unifiedScannedCount, setUnifiedScannedCount] = useState(0);
  const [unifiedScanSuccess, setUnifiedScanSuccess] = useState('');
  const [unifiedScanError, setUnifiedScanError] = useState('');

  React.useEffect(() => {
    if (isUnifiedScannerOpen || isCameraScannerOpen || isPhysicalCameraScannerOpen) {
      setUnifiedScannedCount(0);
    }
  }, [isUnifiedScannerOpen, isCameraScannerOpen, isPhysicalCameraScannerOpen]);
  const [showScanNotFoundDialog, setShowScanNotFoundDialog] = useState(false);
  const [lastScannedNotFoundBarcode, setLastScannedNotFoundBarcode] = useState('');
  const [availableVouchersSample, setAvailableVouchersSample] = useState<{barcode: string, status: string, name?: string}[]>([]);

  React.useEffect(() => {
    const checkDevice = () => {
      const ua = navigator.userAgent.toLowerCase();
      const isAndroid = /android/i.test(ua);
      const isTablet = /tablet|ipad/i.test(ua) || (navigator.maxTouchPoints > 1 && /macintosh/i.test(ua));
      const isMobileUA = /mobi|android|touch|mini/i.test(ua);
      const isSmallScreen = window.innerWidth < 1024;
      
      setIsAndroidOrTablet(isAndroid || isTablet || isMobileUA || isSmallScreen);
    };

    checkDevice();
    window.addEventListener('resize', checkDevice);
    return () => window.removeEventListener('resize', checkDevice);
  }, []);

  React.useEffect(() => {
    if (physicalScannerTrigger && physicalScannerTrigger > 0) {
      if (!currentShift) {
        setPhysicalScanError('Scanner tidak dapat dibuka karena sif kasir belum dibuka/dimulai.');
        return;
      }
      setIsPhysicalCameraScannerOpen(true);
    }
  }, [physicalScannerTrigger, currentShift]);

  React.useEffect(() => {
    if (posScannerTrigger && posScannerTrigger > 0) {
      if (!currentShift) {
        setUnifiedScanError('Scanner tidak dapat dibuka karena sif kasir belum dibuka/dimulai.');
        return;
      }
      setIsUnifiedScannerOpen(true);
    }
  }, [posScannerTrigger, currentShift]);

  React.useEffect(() => {
    if (unifiedScanSuccess) {
      const timer = setTimeout(() => {
        setUnifiedScanSuccess('');
      }, 2500);
      return () => clearTimeout(timer);
    }
  }, [unifiedScanSuccess]);

  React.useEffect(() => {
    if (unifiedScanError) {
      const timer = setTimeout(() => {
        setUnifiedScanError('');
      }, 2500);
      return () => clearTimeout(timer);
    }
  }, [unifiedScanError]);

  // Temporary States for Discount Modal
  const [tempDiscountType, setTempDiscountType] = useState<'none' | 'nominal' | 'percent'>('none');
  const [tempDiscountValue, setTempDiscountValue] = useState<number>(0);
  const [tempDiscountReason, setTempDiscountReason] = useState<string>('');
  const [tempDiscountCustomReason, setTempDiscountCustomReason] = useState<string>('');

  React.useEffect(() => {
    if (showDiscountModal) {
      if (discountingCartItemId) {
        const item = physicalCart.find(i => i.productId === discountingCartItemId);
        if (item) {
          setTempDiscountType(item.discountType);
          setTempDiscountValue(item.discountValue);
          setTempDiscountReason(item.discountReason || 'Pelanggan Setia');
          setTempDiscountCustomReason(item.discountCustomReason || '');
        }
      } else {
        setTempDiscountType(physicalDiscountType);
        setTempDiscountValue(physicalDiscountValue);
        setTempDiscountReason(physicalDiscountReason || 'Pelanggan Setia');
        setTempDiscountCustomReason(physicalDiscountCustomReason);
      }
    }
  }, [showDiscountModal, discountingCartItemId, physicalCart, physicalDiscountType, physicalDiscountValue, physicalDiscountReason, physicalDiscountCustomReason]);

  // Shift States
  const [showShiftRecap, setShowShiftRecap] = useState(false);

  // UI States
  const [recentTransaction, setRecentTransaction] = useState<Transaction | null>(null);
  const [recentBatchTransactions, setRecentBatchTransactions] = useState<Transaction[]>([]);
  const [showReceipt, setShowReceipt] = useState(false);
  const [showBatchReceipt, setShowBatchReceipt] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Transaction Queue / Antrean Transaksi
  const [transactionQueue, setTransactionQueue] = useState<{
    id: string;
    type: 'topup' | 'withdrawal' | 'physical';
    phone: string;
    item: any;
    walletId: string;
    walletName: string;
    displayName: string;
    amount: number;
    sellingPrice?: number;
    adminFee?: number;
    withdrawalType?: 'admin_luar' | 'admin_potong';
  }[]>([]);

  // Automatically select/adjust the selected e-wallet based on mode restrictions
  React.useEffect(() => {
    const activeWallets = eWallets.filter(w => w.isActive);
    const allowedWallets = posMode === 'withdrawal'
      ? activeWallets.filter(w => w.category !== 'aplikasi')
      : activeWallets;

    if (allowedWallets.length > 0) {
      const currentSelectedIsValid = selectedEWallet && allowedWallets.some(w => w.id === selectedEWallet);
      if (!currentSelectedIsValid) {
        setSelectedEWallet(allowedWallets[0].id);
      }
    } else {
      if (selectedEWallet) {
        setSelectedEWallet('');
      }
    }
  }, [eWallets, posMode, selectedEWallet]);

  // Automatically scroll the active physical category tab into view
  React.useEffect(() => {
    if (activePhysicalCategoryId) {
      const activeEl = document.getElementById(`pos-cat-tab-${activePhysicalCategoryId}`);
      if (activeEl) {
        activeEl.scrollIntoView({
          behavior: 'smooth',
          block: 'nearest',
          inline: 'center'
        });
      }
    }
  }, [activePhysicalCategoryId]);

  // Automatically select first active e-wallet for physical transfer sales
  React.useEffect(() => {
    const activeWallets = eWallets.filter(w => w.isActive);
    if (activeWallets.length > 0) {
      const isValid = physicalSelectedEWallet && activeWallets.some(w => w.id === physicalSelectedEWallet);
      if (!isValid) {
        setPhysicalSelectedEWallet(activeWallets[0].id);
      }
    } else {
      if (physicalSelectedEWallet) {
        setPhysicalSelectedEWallet('');
      }
    }
  }, [eWallets, physicalSelectedEWallet]);

  // Automatically select first active e-wallet for topup transfer sales
  React.useEffect(() => {
    const activeWallets = eWallets.filter(w => w.isActive && w.id !== 'cash');
    if (activeWallets.length > 0) {
      const isValid = topupSelectedEWallet && activeWallets.some(w => w.id === topupSelectedEWallet);
      if (!isValid) {
        setTopupSelectedEWallet(activeWallets[0].id);
      }
    } else {
      if (topupSelectedEWallet) {
        setTopupSelectedEWallet('');
      }
    }
  }, [eWallets, topupSelectedEWallet]);

  const queueSummary = React.useMemo(() => {
    let totalItems = transactionQueue.length;
    let totalSellingPrice = 0;
    let totalProfit = 0;
    let totalCashMovement = 0; // estimated net cash movement in drawer

    transactionQueue.forEach(qTx => {
      const isWd = qTx.type === 'withdrawal';
      const isTopup = qTx.type === 'topup';
      const isPhysical = qTx.type === 'physical';

      const selling = qTx.sellingPrice || qTx.amount || 0;
      totalSellingPrice += selling;

      if (isWd) {
        totalProfit += qTx.adminFee || 0;
        const cashNeeded = qTx.withdrawalType === 'admin_potong' 
          ? (selling - (qTx.adminFee || 0)) 
          : selling;
        totalCashMovement -= cashNeeded;
      } else if (isTopup) {
        totalProfit += qTx.item?.profit || 0;
        totalCashMovement += selling;
      } else if (isPhysical) {
        totalProfit += qTx.item?.profit || 0;
        if (qTx.walletId === 'cash') {
          totalCashMovement += selling;
        }
      }
    });

    return { totalItems, totalSellingPrice, totalProfit, totalCashMovement };
  }, [transactionQueue]);

  // Sync initialMode prop to posMode state
  React.useEffect(() => {
    if (initialMode) {
      setPosMode(initialMode);
      setErrorMsg('');
      setSuccessMsg('');
    }
  }, [initialMode]);

  // Handle service preset tap
  const handlePresetTap = (preset: typeof SERVICE_PRESETS[0]) => {
    setServiceName(preset.label);
    
    // Auto focus e-wallet based on keyword
    const matchedWallet = eWallets.find(
      w => w.isActive && w.name.toLowerCase().includes(preset.defaultWalletKeyword)
    );
    if (matchedWallet) {
      setSelectedEWallet(matchedWallet.id);
    }
  };

  // Handle nominal preset tap
  const handleNominalPresetTap = (amount: number) => {
    setNominalStr(amount.toString());
    // Kolom Harga Jual diisi sepenuhnya secara manual oleh kasir, tanpa nilai otomatis.
  };

  // Handle adding Top Up to transaction queue
  const handleAddTopUpToQueue = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const nom = parseInt(nominalStr.replace(/\D/g, ''), 10);
    const sell = parseInt(sellingPriceStr.replace(/\D/g, ''), 10);
    const phone = customerPhone.trim() || '-';

    if (!serviceName.trim()) {
      setErrorMsg('Masukkan Nama Transaksi / Layanan.');
      return;
    }

    if (isNaN(nom) || nom <= 0) {
      setErrorMsg('Masukkan Nominal Modal yang valid.');
      return;
    }

    if (isNaN(sell) || sell <= 0) {
      setErrorMsg('Masukkan Harga Jual yang valid.');
      return;
    }

    if (sell < nom && !appConfig?.allowLossTransaction) {
      setErrorMsg('Harga jual tidak boleh lebih rendah dari nominal transaksi.');
      return;
    }

    if (!selectedEWallet) {
      setErrorMsg('Pilih E-Wallet Sumber Saldo.');
      return;
    }

    if (topupPaymentMethod === 'transfer' && !topupSelectedEWallet) {
      setErrorMsg('Pilih E-Wallet penerima transfer terlebih dahulu.');
      return;
    }

    const wallet = eWallets.find(w => w.id === selectedEWallet);
    if (!wallet) {
      setErrorMsg('E-Wallet tidak valid.');
      return;
    }

    // Check balance including existing queued transactions for this wallet
    const alreadyQueuedForThisWallet = transactionQueue
      .filter(q => q.walletId === selectedEWallet && q.type === 'topup')
      .reduce((sum, q) => sum + (q.item.purchasePrice || 0), 0);

    if (wallet.balance < (alreadyQueuedForThisWallet + nom)) {
      setErrorMsg(`Saldo ${wallet.name} tidak cukup untuk menambah transaksi ini ke antrean. Saldo: ${formatRupiah(wallet.balance)}, total di antrean: ${formatRupiah(alreadyQueuedForThisWallet)}.`);
      return;
    }

    const item: TransactionItem = {
      productId: 'manual',
      productName: `${serviceName.trim()} ${nom.toLocaleString('id-ID')}`,
      category: 'pulsa',
      sellingPrice: sell,
      purchasePrice: nom,
      quantity: 1,
      profit: sell - nom,
      paymentMethod: topupPaymentMethod === 'transfer' ? 'transfer' : undefined,
      targetEWalletId: topupPaymentMethod === 'transfer' ? topupSelectedEWallet : undefined
    };

    setTransactionQueue(prev => [
      ...prev,
      {
        id: Math.random().toString(36).substring(2, 9),
        type: 'topup',
        phone,
        item,
        walletId: selectedEWallet,
        walletName: wallet.name,
        displayName: `${serviceName.trim()} ${nom.toLocaleString('id-ID')}`,
        amount: nom,
        sellingPrice: sell
      }
    ]);

    setSuccessMsg(`Transaksi ${serviceName.trim()} ${nom.toLocaleString('id-ID')} berhasil ditambahkan ke antrean.`);
    // Reset manual input fields except customer phone
    setServiceName(selectedWalletObj?.provider || '');
    setNominalStr('');
    setSellingPriceStr('');
  };

  // Handle adding Withdrawal to transaction queue
  const handleAddWithdrawalToQueue = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!selectedEWallet) {
      setErrorMsg('Pilih E-Wallet tujuan transfer konsumen terlebih dahulu.');
      return;
    }

    const amount = parseInt(wdAmountStr.replace(/\D/g, ''), 10) || 0;
    const adminFee = parseInt(wdAdminFeeStr.replace(/\D/g, ''), 10) || 0;
    const phone = wdCustomerPhone.trim() || '-';

    if (amount <= 0) {
      setErrorMsg('Masukkan nominal penarikan yang valid.');
      return;
    }
    if (adminFee < 0) {
      setErrorMsg('Masukkan biaya admin yang valid.');
      return;
    }

    const targetWallet = eWallets.find(w => w.id === selectedEWallet);
    if (!targetWallet) {
      setErrorMsg('E-Wallet tidak valid.');
      return;
    }

    // Enforce cash drawer check (jangan melakukan tarik tunai jika uang laci tidak cukup)
    const currentWithdrawals = currentShift?.totalWithdrawals || 0;
    const currentCashInDrawer = (currentShift?.initialCash || 0) + (currentShift?.totalSales || 0) - (currentShift?.totalTransferSales || 0) - currentWithdrawals;
    
    const alreadyQueuedWdCash = transactionQueue
      .filter(q => q.type === 'withdrawal')
      .reduce((sum, q) => {
        const needed = q.item?.withdrawalType === 'admin_potong' ? (Number(q.amount || 0) - Number(q.adminFee || 0)) : Number(q.amount || 0);
        return sum + needed;
      }, 0);

    const availableCashInDrawer = currentCashInDrawer - alreadyQueuedWdCash;
    const cashNeeded = wdFeeType === 'admin_potong' ? (amount - adminFee) : amount;

    if (availableCashInDrawer < cashNeeded) {
      setErrorMsg(`Transaksi ditolak. Uang laci laci tidak cukup untuk melakukan tarik tunai ini. Sisa uang laci setelah antrean: ${formatRupiah(availableCashInDrawer)}, Dibutuhkan: ${formatRupiah(cashNeeded)}.`);
      return;
    }

    const withdrawalItem = {
      productId: 'withdrawal',
      productName: `Tarik Tunai via ${targetWallet.name}`,
      category: 'withdrawal',
      purchasePrice: 0,
      sellingPrice: 0,
      quantity: 1,
      profit: adminFee,
      type: 'withdrawal',
      withdrawalType: wdFeeType,
      amount: amount,
      adminFee: adminFee
    };

    setTransactionQueue(prev => [
      ...prev,
      {
        id: Math.random().toString(36).substring(2, 9),
        type: 'withdrawal',
        phone,
        item: withdrawalItem,
        walletId: selectedEWallet,
        walletName: targetWallet.name,
        displayName: `Tarik Tunai via ${targetWallet.name} ${amount.toLocaleString('id-ID')}`,
        amount: amount,
        adminFee: adminFee,
        withdrawalType: wdFeeType
      }
    ]);

    setSuccessMsg(`Tarik Tunai sebesar ${formatRupiah(amount)} berhasil ditambahkan ke antrean.`);
    setWdAmountStr('');
    setWdCustomerPhone('');
  };

  // Process all transactions in the queue
  const handleProcessAllQueue = async () => {
    if (transactionQueue.length === 0) return;
    setErrorMsg('');
    setSuccessMsg('');

    if (onProcessBatchTransactions) {
      try {
        const batchPayload = transactionQueue.map(qTx => ({
          customerPhone: qTx.phone,
          item: qTx.item,
          eWalletId: qTx.walletId
        }));

        const result = await onProcessBatchTransactions(batchPayload);
        if (result.success && result.transactions && result.transactions.length > 0) {
          setRecentBatchTransactions(result.transactions);
          setShowBatchReceipt(true);
          setTransactionQueue([]);
          setSuccessMsg(`Seluruh antrean (${result.transactions.length} transaksi) berhasil dihitung dan diproses secara massal!`);
        } else {
          setErrorMsg(result.message || 'Gagal memproses antrean transaksi massal.');
        }
      } catch (err: any) {
        console.error('Error in batch UI handler:', err);
        setErrorMsg(err.message || 'Gagal memproses antrean transaksi massal.');
      }
      return;
    }

    let processedCount = 0;
    let failedCount = 0;
    let lastProcessedTx: Transaction | null = null;
    const remainingQueue: typeof transactionQueue = [];

    // Track dynamic local balances during sequential loop execution to prevent duplicate/overdraft attempts
    const localWalletBalances = new Map<string, number>();
    eWallets.forEach(w => {
      localWalletBalances.set(w.id, Number(w.balance || 0));
    });

    // Calculate initial local drawer cash
    const currentWithdrawals = currentShift?.totalWithdrawals || 0;
    let localDrawerCash = (currentShift?.initialCash || 0) + (currentShift?.totalSales || 0) - (currentShift?.totalTransferSales || 0) - currentWithdrawals;

    // Process each one
    for (const qTx of transactionQueue) {
      const currentWalletObj = eWallets.find(w => w.id === qTx.walletId);
      
      // Topup specific check
      if (qTx.type === 'topup') {
        const currentBalance = localWalletBalances.get(qTx.walletId) || 0;
        const purchaseCost = Number(qTx.item?.purchasePrice || 0) * Number(qTx.item?.quantity || 1);
        if (!currentWalletObj || currentBalance < purchaseCost) {
          failedCount++;
          remainingQueue.push(qTx);
          continue;
        }
      }

      // Withdrawal specific check (Enforce cash drawer validation)
      if (qTx.type === 'withdrawal') {
        const cashNeeded = qTx.item?.withdrawalType === 'admin_potong' 
          ? (Number(qTx.amount || 0) - Number(qTx.adminFee || 0)) 
          : Number(qTx.amount || 0);

        if (localDrawerCash < cashNeeded) {
          failedCount++;
          remainingQueue.push({
            ...qTx,
            error: 'Uang laci tidak mencukupi'
          });
          continue;
        }
      }

      const result = await onProcessTransaction(qTx.phone, qTx.item, qTx.walletId);
      if (result.success && result.transaction) {
        processedCount++;
        lastProcessedTx = result.transaction;

        // On successful transaction, update local tracking variables
        if (qTx.type === 'topup') {
          const purchaseCost = Number(qTx.item?.purchasePrice || 0) * Number(qTx.item?.quantity || 1);
          const currentBalance = localWalletBalances.get(qTx.walletId) || 0;
          localWalletBalances.set(qTx.walletId, currentBalance - purchaseCost);
          // Cash drawer increases because customer paid cash for top-up
          localDrawerCash += Number(qTx.item?.sellingPrice || 0) * Number(qTx.item?.quantity || 1);
        } else if (qTx.type === 'withdrawal') {
          const cashNeeded = qTx.item?.withdrawalType === 'admin_potong' 
            ? (Number(qTx.amount || 0) - Number(qTx.adminFee || 0)) 
            : Number(qTx.amount || 0);
          localDrawerCash -= cashNeeded;
          // E-wallet balance increases because consumer transferred money to e-wallet
          const currentBalance = localWalletBalances.get(qTx.walletId) || 0;
          localWalletBalances.set(qTx.walletId, currentBalance + Number(qTx.amount || 0));
        }
      } else {
        failedCount++;
        remainingQueue.push(qTx);
      }
    }

    setTransactionQueue(remainingQueue);

    if (processedCount > 0) {
      if (lastProcessedTx) {
        setRecentTransaction(lastProcessedTx);
        setShowReceipt(true);
      }
      
      if (failedCount > 0) {
        setSuccessMsg(`Berhasil memproses ${processedCount} transaksi.`);
        setErrorMsg(`Gagal memproses ${failedCount} transaksi karena saldo/kas laci tidak cukup.`);
      } else {
        setSuccessMsg(`Seluruh antrean (${processedCount} transaksi) berhasil diproses!`);
      }
    } else if (failedCount > 0) {
      setErrorMsg(`Gagal memproses ${failedCount} transaksi. Harap periksa saldo server E-Wallet atau uang laci kasir.`);
    }
  };

  // Convert numbers to Rupiah format
  const formatRupiah = (num: number | null | undefined) => {
    if (num === undefined || num === null || isNaN(num)) return 'Rp 0';
    return 'Rp ' + num.toLocaleString('id-ID');
  };

  // Helper to format string input nicely in rupiah
  const getRupiahPreview = (strVal: string) => {
    const num = parseInt(strVal.replace(/\D/g, ''), 10);
    if (isNaN(num)) return 'Rp 0';
    return formatRupiah(num);
  };

  // Calculate profit live
  const calculatedProfit = useMemo(() => {
    const nom = parseInt(nominalStr.replace(/\D/g, ''), 10) || 0;
    const sell = parseInt(sellingPriceStr.replace(/\D/g, ''), 10) || 0;
    return sell - nom;
  }, [nominalStr, sellingPriceStr]);

  const isLossBlocked = useMemo(() => {
    const nom = parseInt(nominalStr.replace(/\D/g, ''), 10) || 0;
    const sell = parseInt(sellingPriceStr.replace(/\D/g, ''), 10) || 0;
    return !!(nominalStr && sellingPriceStr && sell < nom && !appConfig?.allowLossTransaction);
  }, [nominalStr, sellingPriceStr, appConfig?.allowLossTransaction]);

  const selectedWalletObj = useMemo(() => {
    return eWallets.find(w => w.id === selectedEWallet);
  }, [eWallets, selectedEWallet]);

  // Auto-sync serviceName to the selected wallet provider
  React.useEffect(() => {
    if (selectedWalletObj) {
      setServiceName(selectedWalletObj.provider);
    }
  }, [selectedWalletObj]);



  const handleWithdrawalSubmit = async (e?: React.FormEvent | React.MouseEvent) => {
    if (e) e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!selectedEWallet) {
      setErrorMsg('Pilih E-Wallet tujuan transfer konsumen terlebih dahulu.');
      return;
    }

    const amount = parseInt(wdAmountStr.replace(/\D/g, ''), 10) || 0;
    const adminFee = parseInt(wdAdminFeeStr.replace(/\D/g, ''), 10) || 0;
    const phone = wdCustomerPhone.trim() || '-';

    if (amount <= 0) {
      setErrorMsg('Masukkan nominal penarikan yang valid.');
      return;
    }
    if (adminFee < 0) {
      setErrorMsg('Masukkan biaya admin yang valid.');
      return;
    }

    const targetWallet = eWallets.find(w => w.id === selectedEWallet);
    if (!targetWallet) {
      setErrorMsg('E-Wallet tidak valid.');
      return;
    }

    // Enforce cash drawer check (jangan melakukan tarik tunai jika uang laci tidak cukup)
    const currentWithdrawals = currentShift?.totalWithdrawals || 0;
    const currentCashInDrawer = (currentShift?.initialCash || 0) + (currentShift?.totalSales || 0) - (currentShift?.totalTransferSales || 0) - currentWithdrawals;
    const cashNeeded = wdFeeType === 'admin_potong' ? (amount - adminFee) : amount;

    if (currentCashInDrawer < cashNeeded) {
      setErrorMsg(`Transaksi ditolak. Uang laci laci tidak cukup untuk melakukan tarik tunai ini. Sisa uang laci: ${formatRupiah(currentCashInDrawer)}, Dibutuhkan: ${formatRupiah(cashNeeded)}.`);
      return;
    }

    const withdrawalItem = {
      productId: 'withdrawal',
      productName: `Tarik Tunai via ${targetWallet?.name || 'E-Wallet'}`,
      category: 'withdrawal',
      purchasePrice: 0,
      sellingPrice: 0,
      quantity: 1,
      profit: adminFee,
      type: 'withdrawal',
      withdrawalType: wdFeeType,
      amount: amount,
      adminFee: adminFee
    };

    const result = await onProcessTransaction(phone, withdrawalItem, selectedEWallet);

    if (result.success && result.transaction) {
      setRecentTransaction(result.transaction);
      setShowReceipt(true);
      setWdAmountStr('');
      setWdCustomerPhone('');
      setSuccessMsg(`Tarik Tunai sebesar ${formatRupiah(amount)} berhasil diproses!`);
    } else {
      setErrorMsg(result.message);
    }
  };

  const handleCheckout = async (e?: React.FormEvent | React.MouseEvent) => {
    if (e) e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const nom = parseInt(nominalStr.replace(/\D/g, ''), 10);
    const sell = parseInt(sellingPriceStr.replace(/\D/g, ''), 10);

    if (!serviceName.trim()) {
      setErrorMsg('Masukkan Nama Transaksi / Layanan.');
      return;
    }

    if (isNaN(nom) || nom <= 0) {
      setErrorMsg('Masukkan Nominal Modal yang valid.');
      return;
    }

    if (isNaN(sell) || sell <= 0) {
      setErrorMsg('Masukkan Harga Jual yang valid.');
      return;
    }

    if (sell < nom && !appConfig?.allowLossTransaction) {
      setErrorMsg('Harga jual tidak boleh lebih rendah dari nominal transaksi.');
      return;
    }

    if (!selectedEWallet) {
      setErrorMsg('Pilih E-Wallet Sumber Saldo.');
      return;
    }

    if (topupPaymentMethod === 'transfer' && !topupSelectedEWallet) {
      setErrorMsg('Pilih E-Wallet penerima transfer terlebih dahulu.');
      return;
    }

    const wallet = eWallets.find(w => w.id === selectedEWallet);
    if (!wallet) {
      setErrorMsg('E-Wallet tidak valid.');
      return;
    }

    if (wallet.balance < nom) {
      setErrorMsg(`Saldo ${wallet.name} tidak cukup. Saldo saat ini: ${formatRupiah(wallet.balance)}.`);
      return;
    }

    // Construct transaction item conforming to TransactionItem type
    const item: TransactionItem = {
      productId: 'manual',
      productName: `${serviceName.trim()} ${nom.toLocaleString('id-ID')}`,
      category: 'pulsa', // mapped to default
      sellingPrice: sell,
      purchasePrice: nom,
      quantity: 1,
      profit: sell - nom,
      paymentMethod: topupPaymentMethod === 'transfer' ? 'transfer' : undefined,
      targetEWalletId: topupPaymentMethod === 'transfer' ? topupSelectedEWallet : undefined
    };

    const result = await onProcessTransaction(customerPhone, item, selectedEWallet);

    if (result.success && result.transaction) {
      setSuccessMsg('Transaksi berhasil diproses!');
      setRecentTransaction(result.transaction);
      setShowReceipt(true);
      
      // Reset inputs
      setServiceName(selectedWalletObj?.provider || '');
      setNominalStr('');
      setSellingPriceStr('');
    } else {
      setErrorMsg(result.message);
    }
  };

  const handlePhysicalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (physicalCart.length === 0) {
      setErrorMsg('Keranjang masih kosong. Pilih produk terlebih dahulu.');
      return;
    }

    const phone = physicalCustomerPhone.trim() || '-';
    const transactionItems: any[] = [];

    for (const item of physicalCart) {
      const product = products.find(p => p.id === item.productId);
      if (!product) {
        setErrorMsg(`Produk ${item.productName} tidak ditemukan.`);
        return;
      }

      if (product.stock < item.quantity) {
        setErrorMsg(`Stok ${product.name} tidak mencukupi. Sisa stok: ${product.stock} pcs`);
        return;
      }

      const originalSubtotal = product.sellingPrice * item.quantity;
      const hppSubtotal = product.purchasePrice * item.quantity;
      let itemDiscountAmount = 0;

      if (item.discountType === 'nominal') {
        itemDiscountAmount = item.discountValue;
      } else if (item.discountType === 'percent') {
        itemDiscountAmount = Math.round((item.discountValue / 100) * originalSubtotal);
      }

      const finalSubtotal = originalSubtotal - itemDiscountAmount;

      if (itemDiscountAmount > originalSubtotal) {
        setErrorMsg(`Diskon untuk ${product.name} tidak boleh melebihi harganya.`);
        return;
      }

      if (finalSubtotal < hppSubtotal && !appConfig?.allowLossTransaction) {
        setErrorMsg(`Transaksi ditolak. Harga jual setelah diskon untuk ${product.name} berada di bawah batas minimum yang diizinkan.`);
        return;
      }

      const unitSellingPrice = finalSubtotal / item.quantity;

      transactionItems.push({
        productId: product.id,
        productName: product.name,
        category: product.category,
        sellingPrice: unitSellingPrice,
        purchasePrice: product.purchasePrice,
        quantity: item.quantity,
        profit: unitSellingPrice - product.purchasePrice,
        discountAmount: itemDiscountAmount > 0 ? itemDiscountAmount : undefined,
        discountType: item.discountType !== 'none' ? item.discountType : undefined,
        discountReason: itemDiscountAmount > 0 ? (item.discountReason === 'Lainnya' ? item.discountCustomReason : item.discountReason) : undefined,
        originalPrice: product.sellingPrice,
        scannedBarcodes: item.scannedBarcodes.length > 0 ? item.scannedBarcodes : (product.barcode ? [product.barcode] : undefined)
      });
    }

    if (physicalPaymentMethod === 'transfer' && !physicalSelectedEWallet) {
      setErrorMsg('Pilih E-Wallet penerima transfer terlebih dahulu.');
      return;
    }

    const walletId = physicalPaymentMethod === 'cash' ? 'cash' : physicalSelectedEWallet;
    const result = await onProcessTransaction(phone, transactionItems, walletId);

    if (result.success && result.transaction) {
      setSuccessMsg(`Berhasil memproses penjualan ${physicalCart.length} jenis produk!`);
      setRecentTransaction(result.transaction);
      setShowReceipt(true);
      
      // Reset inputs
      setPhysicalCart([]);
      setSelectedProductId('');
      setPhysicalQuantity(1);
      setPhysicalCustomerPhone('');
      setPhysicalPaymentMethod('cash');
      setPhysicalDiscountType('none');
      setPhysicalDiscountValue(0);
      setPhysicalDiscountReason('');
      setPhysicalDiscountCustomReason('');
      setScannedBarcodes([]);
    } else {
      setErrorMsg(result.message);
    }
  };

  const playSuccessfulScanFeedback = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(1400, audioCtx.currentTime);
      gainNode.gain.setValueAtTime(0.08, audioCtx.currentTime);
      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.1);
    } catch (e) {
      console.warn('AudioContext backup beep ignored:', e);
    }
    if (navigator.vibrate) {
      try {
        navigator.vibrate(100);
      } catch (e) {}
    }
  };

  const extractBarcodeFromUrl = (input: string): string => {
    // Strip non-printable ASCII control characters (e.g. STX, ETX, Carriage Return, Line Feed, backspace, etc.)
    const cleanedInput = input.replace(/[^\x20-\x7E]/g, '');
    const trimmed = cleanedInput.trim();
    if (!trimmed) return '';
    
    // Check if it's a URL
    if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
      try {
        const url = new URL(trimmed);
        const codeParams = ['code', 'id', 'sn', 'barcode', 'serial', 'v', 'k', 'sn_voucher'];
        for (const param of codeParams) {
          const val = url.searchParams.get(param);
          if (val) return val.trim();
        }
        
        const segments = url.pathname.split('/').filter(Boolean);
        if (segments.length > 0) {
          return segments[segments.length - 1].trim();
        }
      } catch (e) {
        // Ignored
      }
    }
    
    // Strip common wrapper formatting
    return trimmed.replace(/^["'\[\(]+|["'\]\)]+$/g, '');
  };

  const findProductByBarcode = (scannedCode: string) => {
    const cleaned = extractBarcodeFromUrl(scannedCode).trim().toLowerCase();
    const strippedCleaned = cleaned.replace(/^0+/, '');

    return products.find(p => {
      if (!p.barcode) return false;
      const productBarcode = p.barcode.trim().toLowerCase();
      const strippedProductBarcode = productBarcode.replace(/^0+/, '');

      return (
        productBarcode === cleaned ||
        (strippedProductBarcode && strippedProductBarcode === strippedCleaned)
      );
    });
  };

  const openCameraScanner = () => {
    if (!currentShift) {
      setPhysicalScanError('Scanner tidak dapat dibuka karena sif kasir belum dibuka/dimulai.');
      return;
    }
    setIsPhysicalCameraScannerOpen(true);
  };

  const handleScanPhysicalBarcode = async (rawBarcode: string) => {
    setPhysicalScanError('');
    setPhysicalScanSuccess('');
    
    if (!currentShift) {
      setPhysicalScanError('Scan ditolak. Sif kasir belum dibuka/dimulai.');
      return;
    }
    
    if (!rawBarcode) {
      setPhysicalScanError('Barcode kosong.');
      return;
    }

    const barcode = extractBarcodeFromUrl(rawBarcode).trim();
    const foundProduct = findProductByBarcode(barcode);

    if (foundProduct) {
      playSuccessfulScanFeedback();

      // Check stock
      const existingInCart = physicalCart.find(item => item.productId === foundProduct.id);
      const currentQty = existingInCart ? existingInCart.quantity : 0;
      
      if (foundProduct.stock <= currentQty) {
        setPhysicalScanError(`Stok ${foundProduct.name} tidak mencukupi (Sisa stok: ${foundProduct.stock} pcs).`);
        return;
      }

      // Ensure POS mode is physical, category is all, and search query is empty so product is immediately selected & visible
      setPosMode('physical');
      setActivePhysicalCategoryId('semua');
      setPhysicalSearchQuery('');

      setSelectedProductId(foundProduct.id);
      addProductToPhysicalCart(foundProduct, barcode);
      setPhysicalScanSuccess(`Produk ${foundProduct.name} berhasil ditambahkan ke keranjang.`);
      setVoucherBarcodeScan('');
      setUnifiedScannedCount(prev => prev + 1);
    } else {
      // Barcode not found in physical products langsung, try querying Barcode Center
      try {
        const res = await fetch(`/api/vouchers/barcode/${encodeURIComponent(barcode)}`);
        if (res.ok) {
          const responseData = await res.json();
          setAvailableVouchersSample([]);

          // If backend returned a fallback physical product
          if (responseData.isPhysicalProduct && responseData.product) {
            const p = responseData.product;
            playSuccessfulScanFeedback();

            // Check stock
            const existingInCart = physicalCart.find(item => item.productId === p.id);
            const currentQty = existingInCart ? existingInCart.quantity : 0;
            if (p.stock <= currentQty) {
              setPhysicalScanError(`Stok ${p.name} tidak mencukupi (Sisa stok: ${p.stock} pcs).`);
              return;
            }

            setPosMode('physical');
            setActivePhysicalCategoryId('semua');
            setPhysicalSearchQuery('');

            setSelectedProductId(p.id);
            addProductToPhysicalCart(p, barcode);
            setPhysicalScanSuccess(`Produk ${p.name} berhasil ditambahkan ke keranjang.`);
            setVoucherBarcodeScan('');
            setUnifiedScannedCount(prev => prev + 1);
            return;
          }

          const voucher = responseData;
          if (voucher) {
            if (voucher.status === 'READY') {
              const relatedProduct = products.find(p => p.id === voucher.productId);
              if (relatedProduct) {
                playSuccessfulScanFeedback();

                // Check stock
                const existingInCart = physicalCart.find(item => item.productId === relatedProduct.id);
                const currentQty = existingInCart ? existingInCart.quantity : 0;
                if (relatedProduct.stock <= currentQty) {
                  setPhysicalScanError(`Stok ${relatedProduct.name} tidak mencukupi (Sisa stok: ${relatedProduct.stock} pcs).`);
                  return;
                }

                setPosMode('physical');
                setActivePhysicalCategoryId('semua');
                setPhysicalSearchQuery('');

                setSelectedProductId(relatedProduct.id);
                addProductToPhysicalCart(relatedProduct, barcode);
                setPhysicalScanSuccess(`Produk ${relatedProduct.name} (S/N: ${voucher.serialNumber || '-'}) berhasil ditambahkan ke keranjang.`);
                setVoucherBarcodeScan('');
                setUnifiedScannedCount(prev => prev + 1);
                return;
              } else {
                setPhysicalScanError('Produk terkait barcode ini tidak ditemukan.');
                return;
              }
            } else {
              let msg = "Barcode tidak tersedia";
              if (voucher.status === 'SOLD') {
                msg = "Barcode sudah terjual";
              } else if (voucher.status === 'RETURNED') {
                msg = "Barcode sedang retur";
              } else if (voucher.status === 'DAMAGED') {
                msg = "Barcode rusak";
              } else if (voucher.status === 'EXPIRED') {
                msg = "Barcode sudah kadaluarsa";
              }
              setPhysicalScanError(msg);
              return;
            }
          }
        } else {
          const errData = await res.json().catch(() => ({}));
          if (errData.availableVouchersSample) {
            setAvailableVouchersSample(errData.availableVouchersSample);
          } else {
            setAvailableVouchersSample([]);
          }
          setPhysicalScanError('Produk tidak ditemukan.');
          setLastScannedNotFoundBarcode(barcode);
          setShowScanNotFoundDialog(true);
        }
      } catch (err) {
        console.error(err);
        setPhysicalScanError('Terjadi kesalahan koneksi.');
      }
    }
  };

  const handleScanVoucherBarcode = async (barcodeOverride?: string) => {
    setScanError('');
    setScanSuccess('');
    
    if (!currentShift) {
      setScanError('Scan ditolak. Sif kasir belum dibuka/dimulai.');
      return;
    }
    
    const rawBarcode = (barcodeOverride || voucherBarcodeScan).trim();
    if (barcodeOverride) {
      setVoucherBarcodeScan(barcodeOverride);
    }
    if (!rawBarcode) {
      setScanError('Barcode kosong.');
      return;
    }

    const barcode = extractBarcodeFromUrl(rawBarcode);

    try {
      // 1. Check if it's a "Barcode Tunggal" (physical/standard product barcode) first
      const foundProduct = findProductByBarcode(barcode);
      if (foundProduct) {
        playSuccessfulScanFeedback();

        // Ensure POS mode is physical, category is all, and search query is empty so product is immediately selected & visible
        setPosMode('physical');
        setActivePhysicalCategoryId('semua');
        setPhysicalSearchQuery('');

        setSelectedProductId(foundProduct.id);
        addProductToPhysicalCart(foundProduct, barcode);
        setScanSuccess(`Produk ${foundProduct.name} berhasil ditambahkan ke Item Terpilih.`);
        setUnifiedScannedCount(prev => prev + 1);
        setVoucherBarcodeScan('');
        return;
      }

      // 2. Otherwise query Barcode Center database
      const res = await fetch(`/api/vouchers/barcode/${encodeURIComponent(barcode)}`);
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        if (errData.availableVouchersSample) {
          setAvailableVouchersSample(errData.availableVouchersSample);
        }
        setScanError("Barcode tidak ditemukan.");
        setLastScannedNotFoundBarcode(barcode);
        setShowScanNotFoundDialog(true);
        return;
      }

      const responseData = await res.json();
      setAvailableVouchersSample([]);

      // If backend returned a fallback physical product
      if (responseData.isPhysicalProduct && responseData.product) {
        const p = responseData.product;
        playSuccessfulScanFeedback();

        // Ensure POS mode is physical, category is all, and search query is empty so product is immediately selected & visible
        setPosMode('physical');
        setActivePhysicalCategoryId('semua');
        setPhysicalSearchQuery('');

        setSelectedProductId(p.id);
        addProductToPhysicalCart(p, barcode);
        setScanSuccess(`Produk ${p.name} berhasil ditambahkan ke Item Terpilih.`);
        setUnifiedScannedCount(prev => prev + 1);
        setVoucherBarcodeScan('');
        return;
      }

      const voucher = responseData;
      if (voucher.status !== 'READY') {
        if (voucher.status === 'SOLD') {
          setScanError("Voucher sudah terjual");
        } else if (voucher.status === 'RETURNED') {
          setScanError("Voucher sedang retur");
        } else if (voucher.status === 'DAMAGED') {
          setScanError("Voucher rusak");
        } else if (voucher.status === 'EXPIRED') {
          setScanError("Voucher sudah kadaluarsa");
        } else {
          setScanError(`Voucher tidak tersedia (Status: ${voucher.status}).`);
        }
        return;
      }

      // Find product related to this voucher
      const product = products.find(p => p.id === voucher.productId);
      if (!product) {
        setScanError('Produk terkait voucher ini tidak ditemukan.');
        return;
      }

      // Select the product and track the scanned barcode
      playSuccessfulScanFeedback();

      // Ensure POS mode is physical, category is all, and search query is empty so product is immediately selected & visible
      setPosMode('physical');
      setActivePhysicalCategoryId('semua');
      setPhysicalSearchQuery('');

      setSelectedProductId(product.id);
      addProductToPhysicalCart(product, barcode);
      setScanSuccess(`Produk ${product.name} (S/N: ${voucher.serialNumber || '-'}) berhasil ditambahkan ke Item Terpilih.`);

      setUnifiedScannedCount(prev => prev + 1);
      setVoucherBarcodeScan('');
    } catch (err) {
      console.error(err);
      setScanError('Terjadi kesalahan koneksi.');
    }
  };

  const handleUnifiedBarcodeScan = async (barcode: string) => {
    const rawBarcode = barcode.trim();
    if (!rawBarcode) return;
    if (showScanNotFoundDialog) return; // Ignore if dialog is open

    if (!currentShift) {
      setUnifiedScanError('Scan ditolak. Sif kasir belum dibuka/dimulai.');
      return;
    }

    const cleanBarcode = extractBarcodeFromUrl(rawBarcode);

    // 1. Check physical products first
    const foundProduct = findProductByBarcode(cleanBarcode);
    if (foundProduct) {
      playSuccessfulScanFeedback();

      // Ensure POS mode is physical, category is all, and search query is empty so product is immediately selected & visible
      setPosMode('physical');
      setActivePhysicalCategoryId('semua');
      setPhysicalSearchQuery('');

      setSelectedProductId(foundProduct.id);
      addProductToPhysicalCart(foundProduct, cleanBarcode);
      setUnifiedScanSuccess(`Produk ${foundProduct.name} berhasil ditambahkan ke Item Terpilih.`);
      setUnifiedScannedCount(prev => prev + 1);
      setUnifiedScanError('');
      return;
    }

    // 2. Check Barcode Center database
    try {
      const res = await fetch(`/api/vouchers/barcode/${encodeURIComponent(cleanBarcode)}`);
      if (res.ok) {
        const responseData = await res.json();
        setAvailableVouchersSample([]);

        // If backend returned a fallback physical product
        if (responseData.isPhysicalProduct && responseData.product) {
          const p = responseData.product;
          playSuccessfulScanFeedback();

          // Ensure POS mode is physical, category is all, and search query is empty so product is immediately selected & visible
          setPosMode('physical');
          setActivePhysicalCategoryId('semua');
          setPhysicalSearchQuery('');

          setSelectedProductId(p.id);
          addProductToPhysicalCart(p, cleanBarcode);
          setUnifiedScanSuccess(`Produk ${p.name} berhasil ditambahkan ke Item Terpilih.`);
          setUnifiedScannedCount(prev => prev + 1);
          setUnifiedScanError('');
          setScanError('');
          return;
        }

        const voucher = responseData;
        if (voucher) {
          if (voucher.status === 'READY') {
            const relatedProduct = products.find(p => p.id === voucher.productId);
            if (relatedProduct) {
              playSuccessfulScanFeedback();

              // Ensure POS mode is physical, category is all, and search query is empty so product is immediately selected & visible
              setPosMode('physical');
              setActivePhysicalCategoryId('semua');
              setPhysicalSearchQuery('');

              setSelectedProductId(relatedProduct.id);
              addProductToPhysicalCart(relatedProduct, cleanBarcode);
              setUnifiedScanSuccess(`Produk ${relatedProduct.name} (S/N: ${voucher.serialNumber || '-'}) berhasil ditambahkan ke Item Terpilih.`);
              setUnifiedScannedCount(prev => prev + 1);
              setUnifiedScanError('');
              setScanError('');
              return;
            }
          } else {
            let msg = "Voucher tidak tersedia";
            if (voucher.status === 'SOLD') {
              msg = "Voucher sudah terjual";
            } else if (voucher.status === 'RETURNED') {
              msg = "Voucher sedang retur";
            } else if (voucher.status === 'DAMAGED') {
              msg = "Voucher rusak";
            } else if (voucher.status === 'EXPIRED') {
              msg = "Voucher sudah kadaluarsa";
            }
            setUnifiedScanError(msg);
            setScanError(msg);
            return;
          }
        }
      } else {
        const errData = await res.json().catch(() => ({}));
        if (errData.availableVouchersSample) {
          setAvailableVouchersSample(errData.availableVouchersSample);
        } else {
          setAvailableVouchersSample([]);
        }
        setUnifiedScanError("Barcode tidak ditemukan.");
        setScanError("Barcode tidak ditemukan.");
        setLastScannedNotFoundBarcode(cleanBarcode);
        setShowScanNotFoundDialog(true);
        return;
      }
    } catch (err) {
      console.error('Error fetching voucher by barcode:', err);
      setAvailableVouchersSample([]);
      setUnifiedScanError("Barcode tidak ditemukan.");
      setScanError("Barcode tidak ditemukan.");
      setLastScannedNotFoundBarcode(cleanBarcode);
      setShowScanNotFoundDialog(true);
      return;
    }

    // 3. Not found anywhere
    setUnifiedScanError("Barcode tidak ditemukan.");
    setScanError("Barcode tidak ditemukan.");
    setLastScannedNotFoundBarcode(cleanBarcode);
    setShowScanNotFoundDialog(true);
  };

  const handleAddPhysicalToQueue = () => {
    setErrorMsg('');
    setSuccessMsg('');

    if (!selectedProductId) {
      setErrorMsg('Pilih produk fisik terlebih dahulu.');
      return;
    }

    const product = products.find(p => p.id === selectedProductId);
    if (!product) {
      setErrorMsg('Produk tidak ditemukan.');
      return;
    }

    if (physicalQuantity <= 0) {
      setErrorMsg('Jumlah pembelian minimal 1.');
      return;
    }

    if (product.stock < physicalQuantity) {
      setErrorMsg(`Stok tidak mencukupi. Sisa stok: ${product.stock} pcs`);
      return;
    }

    const phone = physicalCustomerPhone.trim() || '-';

    let discountAmount = 0;
    const originalSubtotal = product.sellingPrice * physicalQuantity;
    const hppSubtotal = product.purchasePrice * physicalQuantity;

    if (physicalDiscountType === 'nominal') {
      discountAmount = physicalDiscountValue;
    } else if (physicalDiscountType === 'percent') {
      discountAmount = Math.round((physicalDiscountValue / 100) * originalSubtotal);
    }

    const finalSubtotal = originalSubtotal - discountAmount;

    if (discountAmount > originalSubtotal) {
      setErrorMsg('Diskon tidak boleh melebihi harga produk.');
      return;
    }

    if (finalSubtotal < hppSubtotal && !appConfig?.allowLossTransaction) {
      setErrorMsg('Transaksi ditolak. Harga jual setelah diskon berada di bawah batas minimum yang diizinkan.');
      return;
    }

    if (physicalPaymentMethod === 'transfer' && !physicalSelectedEWallet) {
      setErrorMsg('Pilih E-Wallet penerima transfer terlebih dahulu.');
      return;
    }

    const walletId = physicalPaymentMethod === 'cash' ? 'cash' : physicalSelectedEWallet;
    const walletName = physicalPaymentMethod === 'cash' ? 'Uang Tunai Laci' : (eWallets.find(w => w.id === physicalSelectedEWallet)?.name || '');

    // single-item sellingPrice should represent the average discounted unit price
    const unitSellingPrice = finalSubtotal / physicalQuantity;

    const item: TransactionItem = {
      productId: product.id,
      productName: product.name,
      category: product.category,
      sellingPrice: unitSellingPrice,
      purchasePrice: product.purchasePrice,
      quantity: physicalQuantity,
      profit: unitSellingPrice - product.purchasePrice,
      discountAmount: discountAmount > 0 ? discountAmount : undefined,
      discountType: physicalDiscountType !== 'none' ? physicalDiscountType : undefined,
      discountReason: discountAmount > 0 ? (physicalDiscountReason === 'Lainnya' ? physicalDiscountCustomReason : physicalDiscountReason) : undefined,
      originalPrice: product.sellingPrice,
      scannedBarcodes: product.barcode ? [product.barcode] : undefined
    };

    setTransactionQueue(prev => [
      ...prev,
      {
        id: `q-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        type: 'physical',
        walletId,
        walletName,
        displayName: `${physicalQuantity}x ${product.name}`,
        phone,
        sellingPrice: finalSubtotal,
        adminFee: 0,
        amount: finalSubtotal,
        item
      }
    ]);

    setSuccessMsg(`Jual ${physicalQuantity}x ${product.name} berhasil ditambahkan ke antrean.`);
    
    // Reset inputs
    setSelectedProductId('');
    setPhysicalQuantity(1);
    setPhysicalCustomerPhone('');
    setPhysicalPaymentMethod('cash');
    setPhysicalDiscountType('none');
    setPhysicalDiscountValue(0);
    setPhysicalDiscountReason('');
    setPhysicalDiscountCustomReason('');
  };

  const handleEdcTransferSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const bank = edcBank.trim();
    const accountNum = edcAccountNum.trim();
    const accountName = edcAccountName.trim();
    const amount = parseInt(edcAmountStr.replace(/\D/g, ''), 10) || 0;
    const adminFee = parseInt(edcAdminFeeStr.replace(/\D/g, ''), 10) || 0;
    const phone = edcCustomerPhone.trim() || '-';

    if (!bank) {
      setErrorMsg('Harap masukkan bank tujuan.');
      return;
    }
    if (!accountNum) {
      setErrorMsg('Harap masukkan nomor rekening tujuan.');
      return;
    }
    if (!accountName) {
      setErrorMsg('Harap masukkan nama pemilik rekening.');
      return;
    }
    if (amount <= 0) {
      setErrorMsg('Harap masukkan nominal transfer yang valid.');
      return;
    }
    if (adminFee < 0) {
      setErrorMsg('Harap masukkan biaya admin yang valid.');
      return;
    }

    const item: any = {
      productId: 'edc_transfer',
      productName: `Transfer EDC ke ${bank} ${accountNum} (a.n. ${accountName})`,
      category: 'edc_transfer',
      sellingPrice: adminFee, // Admin fee paid separately
      purchasePrice: 0, // No cost to us
      quantity: 1,
      profit: adminFee, // Profit is the admin fee
      type: 'edc_transfer',
      transferAmount: amount,
      targetBank: bank,
      targetAccount: accountNum,
      targetAccountName: accountName,
      adminFee: adminFee
    };

    const result = await onProcessTransaction(phone, item, 'cash');

    if (result.success && result.transaction) {
      setSuccessMsg(`Transfer via EDC sebesar Rp ${amount.toLocaleString('id-ID')} berhasil diproses!`);
      setRecentTransaction(result.transaction);
      setShowReceipt(true);

      // Reset states
      setEdcBank('');
      setEdcAccountNum('');
      setEdcAccountName('');
      setEdcAmountStr('');
      setEdcAdminFeeStr('5000');
      setEdcCustomerPhone('');
    } else {
      setErrorMsg(result.message);
    }
  };

  // Get active wallets
  const activeWallets = useMemo(() => {
    return eWallets.filter(w => w.isActive);
  }, [eWallets]);

  // Filter last transactions for quick history panel (showing up to 10 latest)
  const filteredRecentTransactions = useMemo(() => {
    return transactions
      .filter((tx) => {
        if (!tx) return false;
        const phone = tx.customerPhone || '';
        const invoice = tx.invoiceNumber || '';
        const items = tx.items || [];
        
        if (!historySearchQuery) return true;
        const query = historySearchQuery.toLowerCase();
        
        return (
          phone.includes(historySearchQuery) ||
          invoice.toLowerCase().includes(query) ||
          items.some(it => it && it.productName && it.productName.toLowerCase().includes(query))
        );
      })
      .slice(0, 15);
  }, [transactions, historySearchQuery]);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 pb-32 lg:p-6 bg-slate-50 dark:bg-slate-950">


      
      {/* 1. Android Slider E-Wallet Header */}
      {posMode !== 'physical' && posMode !== 'edc_transfer' && (
        <div className="mb-4">
          <div className="flex flex-col xs:flex-row xs:items-center justify-between gap-1.5 mb-2">
            <h2 className="text-xs font-bold text-slate-600 dark:text-slate-400 tracking-tight flex items-center min-w-0">
              <Wallet className="w-3.5 h-3.5 mr-1.5 text-slate-500 dark:text-slate-400 shrink-0" />
              <span className="truncate">Sisa Saldo Server Admin</span>
            </h2>
            <span className="text-[8px] bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 font-bold px-2 py-0.5 rounded-full uppercase tracking-wider self-start xs:self-auto shrink-0">
              Sistem Utama
            </span>
          </div>
          {/* Grid on mobile, horizontal scroll/flex row on desktop */}
          <div className="grid grid-cols-2 min-[400px]:grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:flex lg:flex-row lg:overflow-x-auto gap-2 pt-1.5 pb-4 px-1 -mx-1 snap-x scrollbar-none scroll-smooth">
            {eWallets
              .filter(wallet => wallet.id !== 'cash' && (posMode !== 'withdrawal' || wallet.category !== 'aplikasi'))
              .map(wallet => {
                const isSelected = selectedEWallet === wallet.id;
                return (
                  <button 
                    key={wallet.id}
                    onClick={() => wallet.isActive && setSelectedEWallet(wallet.id)}
                    className={`snap-start shrink-0 lg:w-36 w-full p-2 rounded-xl border text-left transition-all ${
                      !wallet.isActive 
                        ? 'opacity-40 bg-slate-100 dark:bg-slate-800 cursor-not-allowed' 
                        : isSelected 
                        ? 'bg-indigo-50/50 dark:bg-indigo-950/30 text-indigo-950 dark:text-indigo-200 border-indigo-500 shadow-sm ring-1 ring-indigo-500/20' 
                        : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-100 dark:border-slate-850 hover:border-slate-200 dark:hover:border-slate-700 hover:shadow-xs'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className={`text-[8px] font-black uppercase tracking-wider ${isSelected ? 'text-indigo-600' : 'text-slate-400'}`}>
                        {wallet.provider} {wallet.category === 'aplikasi' && '• APP'}
                      </span>
                      <span className={`w-1 h-1 rounded-full ${wallet.isActive ? 'bg-emerald-400' : 'bg-slate-300'}`}></span>
                    </div>
                  
                    <div className="flex items-center space-x-1.5 mt-1">
                      {wallet.logoUrl && (
                        <img 
                          src={wallet.logoUrl} 
                          alt={wallet.name} 
                          className="w-6 h-6 object-cover rounded-md shrink-0" 
                          referrerPolicy="no-referrer"
                        />
                      )}
                      <div className="min-w-0 flex-1">
                        <p className="text-[9px] font-bold truncate leading-none text-slate-605 text-slate-600 dark:text-slate-400">{wallet.name}</p>
                        <p className={`text-[11px] font-black font-mono mt-0.5 ${isSelected ? 'text-indigo-950 dark:text-indigo-200' : 'text-slate-800 dark:text-slate-200'}`}>
                          {formatRupiah(wallet.balance)}
                        </p>
                      </div>
                    </div>
                  </button>
                );
              })}
          </div>
        </div>
      )}

      {/* 2. Unified Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* MAIN TRANSACTION ENTRY FORM (Android Style) */}
        <div className={posMode === 'physical' ? "lg:col-span-12" : "lg:col-span-7"}>
          {!currentShift ? (
            <div className="glass-card rounded-[24px] overflow-hidden">
              <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
                <div>
                  <h2 className="font-extrabold text-sm tracking-wide">SIF KASIR BELUM DIMULAI</h2>
                  <p className="text-[10px] text-red-400 font-bold uppercase mt-0.5">Sistem Laci Terkunci</p>
                </div>
                <span className="text-[10px] bg-red-950 text-red-300 px-2.5 py-1 rounded-full font-bold font-mono">
                  TERKUNCI
                </span>
              </div>
              
              <div className="p-8 text-center space-y-5">
                <div className="w-16 h-16 bg-rose-50 dark:bg-rose-950/20 text-rose-500 rounded-full flex items-center justify-center mx-auto">
                  <Lock className="w-8 h-8" />
                </div>
                
                <div className="max-w-md mx-auto space-y-3">
                  <h3 className="font-extrabold text-slate-800 dark:text-slate-100 text-base">Sif Kasir Belum Dibuka</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    Sistem transaksi laci kasir terkunci karena sif operasional belum dimulai. Harap buka sif baru di menu <strong className="text-slate-700 dark:text-slate-300">Dashboard</strong> terlebih dahulu dengan memasukkan modal uang laci sebelum Anda dapat memproses transaksi apa pun.
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="glass-card rounded-[24px] overflow-hidden relative">
              <CardWatermark
                type={
                  posMode === 'topup'
                    ? 'pulsa'
                    : posMode === 'physical'
                    ? 'produk'
                    : posMode === 'edc_transfer'
                    ? 'ewallet'
                    : 'kasir'
                }
                position="bottom-right"
                size="lg"
                className="opacity-[0.03] dark:opacity-[0.04]"
              />
              
              {/* Form Top Bar */}
              <div className="p-4 bg-white dark:bg-slate-900 border-b border-slate-100/80 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <h2 className="font-extrabold text-xs tracking-wider uppercase text-slate-700 dark:text-slate-200">
                    {posMode === 'topup' ? 'Input Penjualan / Top Up' : posMode === 'physical' ? 'POS Jual Barang Fisik / Aksesoris' : posMode === 'edc_transfer' ? 'Transfer via EDC' : 'Input Tarik Tunai'}
                  </h2>
                  <p className="text-[10px] text-slate-400 dark:text-slate-500 font-medium mt-0.5">
                    {posMode === 'topup' ? 'Proses penjualan pulsa, kuota, atau top up saldo' : posMode === 'physical' ? 'Penjualan aksesoris, charger, kabel, tempered glass, dll.' : posMode === 'edc_transfer' ? 'Transfer uang dari kartu konsumen via EDC' : 'Tarik tunai saldo merchant/e-wallet'}
                  </p>
                </div>
              </div>

              {posMode === 'topup' ? (
                <form onSubmit={handleAddTopUpToQueue}>
                  {/* Form Fields for Top-Up */}
                  <div className="p-5 space-y-4">
                    
                    {/* Notifications */}
                    {errorMsg && (
                      <div className="p-3 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900/40 text-red-600 dark:text-red-400 rounded-xl text-xs flex items-start space-x-1.5">
                        <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>{errorMsg}</span>
                      </div>
                    )}
                    {successMsg && (
                      <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40 text-emerald-700 dark:text-emerald-400 rounded-xl text-xs flex items-start space-x-1.5">
                        <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>{successMsg}</span>
                      </div>
                    )}

                    {/* NOMINAL / MODAL INPUT WITH PRESETS */}
                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-1.5">
                        Nominal Transaksi (Potong Saldo E-Wallet)
                      </label>

                      {/* Quick amount presets (5K, 10K, 20K, 50K, 100K, 200K) */}
                      <div className="flex flex-wrap gap-1 mb-2">
                        {NOMINAL_PRESETS.map((amount) => (
                          <button
                            key={amount}
                            type="button"
                            onClick={() => handleNominalPresetTap(amount)}
                            className="px-2.5 py-1 text-[10px] font-mono font-black rounded-lg bg-indigo-50/60 dark:bg-indigo-950/40 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300 border border-indigo-100/50 dark:border-indigo-900/50 hover:border-indigo-200 dark:hover:border-indigo-800 transition-all active:scale-95"
                          >
                            {amount >= 1000 ? (amount / 1000) + 'K' : amount}
                          </button>
                        ))}
                      </div>

                      <div className="relative">
                        <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-xs font-bold text-slate-400">
                          Rp
                        </span>
                        <input
                          type="number"
                          required
                          min="100"
                          placeholder="Contoh: 100000"
                          value={nominalStr}
                          onChange={(e) => {
                            const val = e.target.value.replace(/\D/g, '');
                            setNominalStr(val);
                          }}
                          className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-mono font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-900 text-slate-800 dark:text-slate-100 transition-all"
                        />
                      </div>
                      {nominalStr && (
                        <p className="text-[10px] text-slate-400 mt-1 font-mono">
                          Format: {getRupiahPreview(nominalStr)}
                        </p>
                      )}
                    </div>

                    {/* SELLING PRICE INPUT */}
                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-1.5">
                        Harga Jual Ke Pelanggan (Penerimaan Kas)
                      </label>
                      <div className="relative">
                        <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-xs font-bold text-slate-400">
                          Rp
                        </span>
                        <input
                          type="number"
                          required
                          min="100"
                          placeholder="Contoh: 103000"
                          value={sellingPriceStr}
                          onChange={(e) => setSellingPriceStr(e.target.value.replace(/\D/g, ''))}
                          className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-mono font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-900 text-slate-800 dark:text-slate-100 transition-all"
                        />
                      </div>
                      <div className="flex items-center justify-between mt-1 text-[10px]">
                        {sellingPriceStr ? (
                          <span className="text-slate-400 font-mono">Format: {getRupiahPreview(sellingPriceStr)}</span>
                        ) : (
                          <span></span>
                        )}
                        {nominalStr && sellingPriceStr && calculatedProfit < 0 && (
                          <span className="text-red-500 font-bold bg-red-50 dark:bg-red-950/40 px-2 py-0.5 rounded animate-pulse border border-red-200/50 dark:border-red-900/30">
                            Harga jual tidak boleh lebih rendah dari nominal transaksi.
                          </span>
                        )}
                      </div>
                    </div>

                    {/* METODE PEMBAYARAN TOPUP */}
                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-1.5">
                        Metode Pembayaran
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setTopupPaymentMethod('cash')}
                          className={`py-2 px-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
                            topupPaymentMethod === 'cash'
                              ? 'bg-emerald-50 dark:bg-emerald-950/20 border-emerald-500 text-emerald-700 dark:text-emerald-300 shadow-sm'
                              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
                          }`}
                        >
                          <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                          Tunai (Laci)
                        </button>
                        <button
                          type="button"
                          onClick={() => setTopupPaymentMethod('transfer')}
                          className={`py-2 px-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
                            topupPaymentMethod === 'transfer'
                              ? 'bg-indigo-50 dark:bg-indigo-950/20 border-indigo-500 text-indigo-700 dark:text-indigo-300 shadow-sm'
                              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
                          }`}
                        >
                          <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
                          Transfer
                        </button>
                      </div>
                    </div>

                    {/* SELECT TARGET WALLET FOR TOPUP (ONLY IF TRANSFER CHOSEN) */}
                    {topupPaymentMethod === 'transfer' && (
                      <div className="space-y-1">
                        <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-1">
                          E-Wallet Penerima Transfer
                        </label>
                        <select
                          value={topupSelectedEWallet}
                          onChange={(e) => setTopupSelectedEWallet(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-900 text-slate-800 dark:text-slate-100 transition-all"
                        >
                          {eWallets
                            .filter((w) => w.isActive && w.id !== 'cash')
                            .map((wallet) => (
                              <option key={wallet.id} value={wallet.id}>
                                {wallet.name} ({formatRupiah(wallet.balance)})
                              </option>
                            ))}
                        </select>
                      </div>
                    )}

                    {/* SELECTED WALLET INFORMATION */}
                    {selectedWalletObj ? (
                      <div>
                        <div className="p-3 bg-slate-50/80 dark:bg-slate-800/80 rounded-xl border border-slate-100 dark:border-slate-800 flex flex-col xs:flex-row justify-between xs:items-center gap-2">
                          <div className="flex items-center space-x-2.5 min-w-0">
                            {selectedWalletObj.logoUrl ? (
                              <img 
                                src={selectedWalletObj.logoUrl} 
                                alt={selectedWalletObj.name} 
                                className="w-7 h-7 object-cover rounded-lg border border-slate-100 dark:border-slate-800 shrink-0"
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <span className="w-7 h-7 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 font-extrabold text-[10px] flex items-center justify-center shrink-0">
                                {selectedWalletObj.provider.substring(0, 3)}
                              </span>
                            )}
                            <div className="min-w-0">
                              <p className="text-[8px] text-slate-400 font-bold uppercase tracking-wider">Sumber Saldo</p>
                              <p className="font-extrabold text-slate-700 dark:text-slate-200 text-xs truncate">{selectedWalletObj.name}</p>
                            </div>
                          </div>
                          <div className="text-left xs:text-right shrink-0">
                            <p className="text-[8px] text-slate-400 font-bold uppercase tracking-wider">Sisa Saldo</p>
                            <p className="font-mono font-black text-indigo-600 dark:text-indigo-400 text-xs">{formatRupiah(selectedWalletObj.balance)}</p>
                          </div>
                        </div>

                        {/* Insufficient balance warning */}
                        {(() => {
                          const reqNominal = parseInt(nominalStr.replace(/\D/g, ''), 10) || 0;
                          if (reqNominal > selectedWalletObj.balance) {
                            return (
                              <div className="mt-2 p-2 bg-rose-50 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-900/40 text-rose-600 dark:text-rose-400 rounded-lg text-[9px] font-bold flex items-center space-x-1.5">
                                <span className="w-1 h-1 rounded-full bg-rose-500 shrink-0 animate-pulse"></span>
                                <span>Peringatan: Saldo server tidak cukup ({formatRupiah(reqNominal)})</span>
                              </div>
                            );
                          }
                          return null;
                        })()}
                      </div>
                    ) : (
                      <div className="p-3.5 bg-amber-50/50 dark:bg-amber-950/20 border border-amber-100/50 dark:border-amber-900/30 text-amber-700 dark:text-amber-400 rounded-xl text-xs font-medium">
                        Silakan pilih E-wallet di bagian atas halaman POS.
                      </div>
                    )}

                  </div>

                  {/* Form Checkout Trigger */}
                  <div className="p-4 bg-slate-50/50 border-t border-slate-100 flex flex-row gap-2.5">
                    <button
                      type="submit"
                      disabled={isLossBlocked || !serviceName || !nominalStr || !sellingPriceStr || !selectedEWallet}
                      className={`flex-1 flex items-center justify-center py-3 px-2 rounded-xl font-bold text-[10px] tracking-wider uppercase transition-all border ${
                        !isLossBlocked && serviceName && nominalStr && sellingPriceStr && selectedEWallet
                          ? 'border-indigo-200 bg-indigo-50 text-indigo-700 hover:bg-indigo-100/50 active:scale-98'
                          : 'border-slate-100 bg-slate-50 text-slate-400 cursor-not-allowed shadow-none'
                      }`}
                    >
                      <Plus className="w-3.5 h-3.5 mr-1" />
                      + Antrean
                    </button>

                    <button
                      type="button"
                      onClick={handleCheckout}
                      disabled={isLossBlocked || !serviceName || !nominalStr || !sellingPriceStr || !selectedEWallet}
                      className={`flex-1 flex items-center justify-center py-3 px-2 rounded-xl font-bold text-[10px] tracking-wider uppercase transition-all ${
                        !isLossBlocked && serviceName && nominalStr && sellingPriceStr && selectedEWallet
                          ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-600/10 active:scale-98'
                          : 'bg-slate-100 text-slate-400 cursor-not-allowed shadow-none'
                      }`}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                      Proses Sekarang
                    </button>
                  </div>
                </form>
              ) : posMode === 'physical' ? (
                <form onSubmit={handlePhysicalSubmit}>
                  {/* Form Fields for Physical Sale */}
                  <div className="p-4 lg:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                    
                    {/* LEFT COLUMN: PRODUCTS & BARCODE SCANNER */}
                    <div className="lg:col-span-7 space-y-5">
                    
                    {/* Notifications */}
                    {errorMsg && (
                      <div className="p-3 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900/40 text-red-600 dark:text-red-400 rounded-xl text-xs flex items-start space-x-1.5">
                        <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>{errorMsg}</span>
                      </div>
                    )}
                    {successMsg && (
                      <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40 text-emerald-700 dark:text-emerald-400 rounded-xl text-xs flex items-start space-x-1.5">
                        <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>{successMsg}</span>
                      </div>
                    )}

                     {/* BARCODE POS ITEM FISIK SCANNER */}
                    <div className="bg-indigo-50/50 dark:bg-indigo-950/10 border border-indigo-100 dark:border-indigo-900/30 p-4 rounded-[16px] mb-2">
                      <label className="block text-[10px] font-black text-indigo-800 dark:text-indigo-400 uppercase tracking-wider mb-1.5 flex items-center space-x-1">
                        <Camera className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                        <span>Scanner Barcode POS Item Fisik</span>
                      </label>
                      <div className="flex space-x-1.5 sm:space-x-2">
                        <input
                          type="text"
                          placeholder="Ketik barcode produk fisik..."
                          value={voucherBarcodeScan}
                          onChange={(e) => {
                            setVoucherBarcodeScan(e.target.value);
                            setPhysicalScanError('');
                            setPhysicalScanSuccess('');
                          }}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleScanPhysicalBarcode(voucherBarcodeScan);
                            }
                          }}
                          className="flex-1 min-w-0 px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-800 dark:text-slate-100 font-mono font-bold"
                        />
                        <button
                          type="button"
                          onClick={() => handleScanPhysicalBarcode(voucherBarcodeScan)}
                          className="px-3 sm:px-4 py-2 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white font-extrabold text-xs rounded-xl transition-all shadow-md shadow-indigo-500/10 shrink-0 cursor-pointer"
                        >
                          Cari / Tambah
                        </button>
                        <button
                          type="button"
                          id="btn-open-camera-scanner"
                          onClick={(e) => {
                            e.preventDefault();
                            openCameraScanner();
                          }}
                          title="Scan Barcode Kamera"
                          className="p-2 sm:px-3 bg-indigo-50 hover:bg-indigo-100 active:scale-95 text-indigo-700 dark:bg-indigo-950/30 dark:hover:bg-indigo-900/40 dark:text-indigo-300 font-extrabold text-xs rounded-xl border border-indigo-200 dark:border-indigo-800/60 transition-all flex items-center justify-center shrink-0 cursor-pointer"
                        >
                          <Camera className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                        </button>
                      </div>
                      {physicalScanError && <p className="text-[10px] text-red-600 font-bold mt-1.5 flex items-center"><AlertCircle className="w-3.5 h-3.5 mr-1" /> {physicalScanError}</p>}
                      {physicalScanSuccess && <p className="text-[10px] text-emerald-700 font-bold mt-1.5 flex items-center"><CheckCircle2 className="w-3.5 h-3.5 mr-1" /> {physicalScanSuccess}</p>}
                    </div>

                    {/* SELECT PRODUCT */}
                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-1.5">
                        Cari & Pilih Item Fisik / Aksesoris
                      </label>
                      <div className="relative mb-3">
                        <Search className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 w-4 h-4" />
                        <input
                          type="text"
                          placeholder="Cari aksesoris, charger, kabel..."
                          value={physicalSearchQuery}
                          onChange={(e) => setPhysicalSearchQuery(e.target.value)}
                          className="w-full pl-9 pr-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-800 dark:text-slate-100"
                        />
                      </div>

                      {/* Horizontal Category Tab/Chip list */}
                      <div className="flex flex-nowrap items-center space-x-2 overflow-x-auto pb-2.5 mb-3 scroll-smooth w-full">
                        <button
                          type="button"
                          id="pos-cat-tab-semua"
                          onClick={() => {
                            setActivePhysicalCategoryId('semua');
                            setSelectedProductId('');
                            setScannedBarcodes([]);
                          }}
                          className={`h-10 px-4.5 rounded-full text-[12px] font-extrabold whitespace-nowrap transition-all cursor-pointer flex items-center justify-center border shrink-0 ${
                            activePhysicalCategoryId === 'semua'
                              ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-500/20'
                              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          Semua
                        </button>
                        {(physicalCategories || [])
                          .filter(cat => cat.is_active !== false)
                          .slice()
                          .sort((a, b) => a.sort_order - b.sort_order)
                          .map(cat => (
                            <button
                              key={cat.id}
                              id={`pos-cat-tab-${cat.id}`}
                              type="button"
                              onClick={() => {
                                  setActivePhysicalCategoryId(cat.id);
                                  setSelectedProductId('');
                                  setScannedBarcodes([]);
                              }}
                              className={`h-10 px-4.5 rounded-full text-[12px] font-extrabold whitespace-nowrap transition-all cursor-pointer flex items-center justify-center border shrink-0 ${
                                activePhysicalCategoryId === cat.id
                                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-500/20'
                                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                              }`}
                            >
                              {cat.name}
                            </button>
                          ))}
                      </div>

                      {/* Visually stunning physical catalog grid */}
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 sm:gap-3 max-h-[380px] overflow-y-auto pr-1.5 scrollbar-thin">
                        {products
                          .filter(p => {
                            // Check if the product belongs to our custom categories
                            const isPhysical = (physicalCategories || []).some(cat => cat.id === p.category);
                            if (!isPhysical) return false;

                            // Filter by active category tab
                            if (activePhysicalCategoryId !== 'semua' && p.category !== activePhysicalCategoryId) {
                              return false;
                            }

                            // Filter by search query
                            return p.name.toLowerCase().includes(physicalSearchQuery.toLowerCase());
                          })
                          .map((prod) => {
                            const cartItem = physicalCart.find(item => item.productId === prod.id);
                            const isSelected = !!cartItem;
                            const isOutOfStock = prod.stock <= 0;
                            return (
                              <button
                                key={prod.id}
                                type="button"
                                disabled={isOutOfStock}
                                onClick={() => {
                                  setSelectedProductId(prod.id);
                                  addProductToPhysicalCart(prod);
                                }}
                                className={`flex flex-col rounded-xl border text-left overflow-hidden transition-all relative group ${
                                  isOutOfStock
                                    ? 'opacity-40 bg-slate-50 border-slate-100 cursor-not-allowed'
                                    : isSelected
                                    ? 'border-indigo-600 bg-indigo-50/20 text-indigo-950 ring-2 ring-indigo-600/30 shadow-md'
                                    : 'border-slate-100 hover:border-slate-200 bg-white text-slate-700 hover:shadow-sm'
                                }`}
                              >
                                {/* Image Container */}
                                <div className="relative w-full aspect-video bg-slate-100 flex items-center justify-center overflow-hidden shrink-0 select-none">
                                  {prod.imageUrl ? (
                                    <img
                                      src={prod.imageUrl}
                                      alt={prod.name}
                                      className={`w-full h-full object-cover transition-transform duration-300 ${
                                        isSelected ? 'scale-105' : 'group-hover:scale-105'
                                      }`}
                                      referrerPolicy="no-referrer"
                                    />
                                  ) : (
                                    <div className="w-full h-full bg-slate-50 flex flex-col items-center justify-center text-slate-400">
                                      <Package className="w-6 h-6 mb-1 text-slate-300" />
                                      <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">No Image</span>
                                    </div>
                                  )}

                                  {/* Selection Checkmark Overlay */}
                                  {isSelected && (
                                    <div className="absolute top-1.5 right-1.5 bg-indigo-600 text-white px-1.5 py-0.5 rounded-full shadow-md animate-in zoom-in duration-150 flex items-center space-x-0.5 font-mono text-[9px] font-black">
                                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                                      <span>{cartItem.quantity}x</span>
                                    </div>
                                  )}

                                  {/* Out Of Stock Overlay */}
                                  {isOutOfStock && (
                                    <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center">
                                      <span className="bg-red-600 text-white font-black text-[9px] tracking-widest uppercase px-2 py-0.5 rounded shadow-sm">
                                        Habis
                                      </span>
                                    </div>
                                  )}

                                  {/* Operator / Brand Badge */}
                                  {!isOutOfStock && (
                                    <span className="absolute bottom-1.5 left-1.5 text-[8px] bg-slate-900/75 text-white px-1.5 py-0.2 rounded font-bold uppercase tracking-wider">
                                      {prod.operator}
                                    </span>
                                  )}
                                </div>

                                {/* Product Body */}
                                <div className="p-1.5 sm:p-2.5 flex-1 flex flex-col justify-between">
                                  <div className="space-y-1">
                                    <h5 className="font-extrabold text-[10px] sm:text-[11px] leading-tight text-slate-800 line-clamp-2 h-[24px] sm:h-[28px] overflow-hidden">
                                      {prod.name}
                                    </h5>
                                  </div>
                                  
                                  <div className="flex items-end justify-between mt-1.5 pt-1.5 border-t border-slate-50">
                                    <span className="font-mono text-emerald-600 font-extrabold text-[10px] sm:text-xs">
                                      {formatRupiah(prod.sellingPrice)}
                                    </span>
                                    <span className={`px-1 sm:px-1.5 py-0.2 rounded text-[7px] sm:text-[8px] font-bold shrink-0 ${
                                      prod.stock < 5 
                                        ? 'bg-red-50 text-red-600 animate-pulse' 
                                        : 'bg-slate-50 text-slate-500 border border-slate-100'
                                    }`}>
                                      Stok: {prod.stock}
                                    </span>
                                  </div>
                                </div>
                              </button>
                            );
                          })}
                        {products.filter(p => {
                          const isPhysical = (physicalCategories || []).some(cat => cat.id === p.category);
                          if (!isPhysical) return false;
                          if (activePhysicalCategoryId !== 'semua' && p.category !== activePhysicalCategoryId) return false;
                          return p.name.toLowerCase().includes(physicalSearchQuery.toLowerCase());
                        }).length === 0 && (
                          <div className="col-span-full py-12 text-center text-xs text-slate-400">
                            <ShoppingBag className="w-10 h-10 text-slate-300 mx-auto mb-2 animate-bounce" />
                            <p className="font-bold text-slate-500">Tidak Ada Produk</p>
                            <p className="text-slate-400 mt-1">
                              {activePhysicalCategoryId === 'semua'
                                ? 'Tidak ada produk jualan fisik yang tersedia saat ini.'
                                : `Belum ada produk jualan fisik di kategori "${(physicalCategories || []).find(c => c.id === activePhysicalCategoryId)?.name || ''}".`}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* END LEFT COLUMN */}
                    </div>

                    {/* RIGHT COLUMN: CART, CUSTOMER & CHECKOUT */}
                    <div className="lg:col-span-5 space-y-5 bg-white dark:bg-slate-900/40 p-5 rounded-[24px] border border-slate-100 dark:border-slate-800">

                      {/* QUANTITY & SELLING SPECS */}
                      <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider">
                          Daftar Keranjang Fisik ({physicalCart.length})
                        </span>
                        {physicalCart.length > 0 && (
                          <button
                            type="button"
                            onClick={() => {
                              setPhysicalCart([]);
                              setSelectedProductId('');
                            }}
                            className="text-[10px] font-bold text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 px-2 py-1 rounded-lg transition-all cursor-pointer"
                          >
                            Kosongkan Keranjang
                          </button>
                        )}
                      </div>

                      {physicalCart.length === 0 ? (
                        <div className="p-8 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-[16px] bg-slate-50/50">
                          <ShoppingBag className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                          <p className="text-xs font-bold text-slate-500">Keranjang Masih Kosong</p>
                          <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">
                            Pindai barcode atau klik menu produk di sebelah kiri untuk memasukkan barang ke keranjang ini.
                          </p>
                        </div>
                      ) : (
                        <div className="space-y-2.5 max-h-[360px] overflow-y-auto pr-1">
                          {physicalCart.map((item, idx) => {
                            const product = products.find(p => p.id === item.productId);
                            const itemOriginalSubtotal = item.sellingPrice * item.quantity;
                            let itemDiscountAmount = 0;
                            if (item.discountType === 'nominal') {
                              itemDiscountAmount = item.discountValue;
                            } else if (item.discountType === 'percent') {
                              itemDiscountAmount = Math.round((item.discountValue / 100) * itemOriginalSubtotal);
                            }
                            const itemFinalSubtotal = itemOriginalSubtotal - itemDiscountAmount;

                            return (
                              <div key={item.productId + '-' + idx} className="p-3 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl space-y-2.5 relative shadow-xs animate-in slide-in-from-top-1 duration-150">
                                <div className="flex justify-between items-start gap-2">
                                  <div>
                                    <h4 className="font-extrabold text-[11px] text-slate-800 dark:text-slate-200 leading-tight">
                                      {item.productName}
                                    </h4>
                                    <div className="flex items-center space-x-2 mt-0.5">
                                      <span className="text-[9px] font-mono font-bold text-slate-400">
                                        {formatRupiah(item.sellingPrice)}
                                      </span>
                                      {product && (
                                        <span className="text-[9px] font-semibold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/20 px-1 py-0.2 rounded">
                                          Stok: {product.stock}
                                        </span>
                                      )}
                                    </div>
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setPhysicalCart(prev => prev.filter(p => p.productId !== item.productId));
                                    }}
                                    className="p-1 hover:bg-red-50 text-slate-400 hover:text-red-500 rounded-lg transition-all cursor-pointer"
                                    title="Hapus dari keranjang"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>

                                {/* Scanned Barcodes list */}
                                {item.scannedBarcodes && item.scannedBarcodes.length > 0 && (
                                  <div className="bg-slate-50 dark:bg-slate-800/40 p-1.5 rounded-lg">
                                    <p className="text-[8px] text-indigo-500 font-bold uppercase tracking-wider mb-1">
                                      Barcode Terpindai ({item.scannedBarcodes.length}):
                                    </p>
                                    <div className="flex flex-wrap gap-1 max-h-12 overflow-y-auto pr-1">
                                      {item.scannedBarcodes.map((bc, bcIdx) => (
                                        <span
                                          key={bc + '-' + bcIdx}
                                          className="inline-flex items-center space-x-1 px-1.5 py-0.5 rounded bg-indigo-50/80 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-400 font-mono text-[9px] font-bold border border-indigo-100/50"
                                        >
                                          <span>{bc}</span>
                                          <button
                                            type="button"
                                            onClick={() => {
                                              setPhysicalCart(prev => prev.map(p => {
                                                if (p.productId === item.productId) {
                                                  const nextBCs = p.scannedBarcodes.filter(x => x !== bc);
                                                  return {
                                                    ...p,
                                                    quantity: Math.max(1, p.quantity - 1),
                                                    scannedBarcodes: nextBCs
                                                  };
                                                }
                                                return p;
                                              }));
                                            }}
                                            className="text-indigo-400 hover:text-indigo-600 p-0.2 rounded hover:bg-indigo-100 cursor-pointer"
                                          >
                                            <X className="w-2.5 h-2.5" />
                                          </button>
                                        </span>
                                      ))}
                                    </div>
                                  </div>
                                )}

                                {/* Qty & Discount selector row */}
                                <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
                                  {/* Qty Counter */}
                                  <div className="flex items-center space-x-1">
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setPhysicalCart(prev => prev.map(p => {
                                          if (p.productId === item.productId) {
                                            return { ...p, quantity: Math.max(1, p.quantity - 1) };
                                          }
                                          return p;
                                        }).filter(p => p.quantity > 0));
                                      }}
                                      className="w-6 h-6 flex items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-500 hover:bg-slate-50 font-bold text-xs select-none transition-all cursor-pointer"
                                    >
                                      -
                                    </button>
                                    <span className="w-8 text-center font-mono font-bold text-xs text-slate-800 dark:text-slate-200">
                                      {item.quantity}
                                    </span>
                                    <button
                                      type="button"
                                      disabled={product ? item.quantity >= product.stock : false}
                                      onClick={() => {
                                        setPhysicalCart(prev => prev.map(p => {
                                          if (p.productId === item.productId) {
                                            return { ...p, quantity: p.quantity + 1 };
                                          }
                                          return p;
                                        }));
                                      }}
                                      className="w-6 h-6 flex items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-500 hover:bg-slate-50 font-bold text-xs select-none transition-all disabled:opacity-40 cursor-pointer"
                                    >
                                      +
                                    </button>
                                  </div>

                                  {/* Discount Button */}
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setDiscountingCartItemId(item.productId);
                                      setShowDiscountModal(true);
                                    }}
                                    className={`flex items-center space-x-1 px-2 py-1 border font-bold text-[9px] rounded-lg transition-all cursor-pointer ${
                                      item.discountType !== 'none'
                                        ? 'border-rose-200 text-rose-700 bg-rose-50 hover:bg-rose-100 shadow-xs'
                                        : 'border-slate-200 text-slate-600 bg-white hover:bg-slate-50 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700'
                                    }`}
                                  >
                                    <Tag className="w-3 h-3" />
                                    <span>{item.discountType !== 'none' ? 'Diskon Aktif' : 'Tambah Diskon'}</span>
                                  </button>
                                </div>

                                {/* Item total with discount details */}
                                {item.discountType !== 'none' && itemDiscountAmount > 0 && (
                                  <div className="bg-rose-50/50 dark:bg-rose-950/10 border border-rose-150 rounded-lg p-2 text-[9px] space-y-0.5 text-rose-700">
                                    <div className="flex justify-between">
                                      <span>Subtotal Normal:</span>
                                      <span className="font-mono">{formatRupiah(itemOriginalSubtotal)}</span>
                                    </div>
                                    <div className="flex justify-between font-bold">
                                      <span>Potongan ({item.discountType === 'percent' ? `${item.discountValue}%` : 'Nominal'}):</span>
                                      <span className="font-mono">-{formatRupiah(itemDiscountAmount)}</span>
                                    </div>
                                  </div>
                                )}

                                <div className="flex justify-between items-center pt-1.5 border-t border-dashed border-slate-100 dark:border-slate-800">
                                  <span className="text-[9px] text-slate-400">Subtotal:</span>
                                  <span className="font-mono text-[11px] font-extrabold text-slate-800 dark:text-slate-200">
                                    {formatRupiah(itemFinalSubtotal)}
                                  </span>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}

                      {/* Cumulative summary display */}
                      {physicalCart.length > 0 && (() => {
                        let totalOriginal = 0;
                        let totalDiscounts = 0;
                        let totalFinal = 0;

                        physicalCart.forEach(item => {
                          const orig = item.sellingPrice * item.quantity;
                          let disc = 0;
                          if (item.discountType === 'nominal') {
                            disc = item.discountValue;
                          } else if (item.discountType === 'percent') {
                            disc = Math.round((item.discountValue / 100) * orig);
                          }
                          totalOriginal += orig;
                          totalDiscounts += disc;
                          totalFinal += (orig - disc);
                        });

                        return (
                          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/30 border border-slate-100 dark:border-slate-800 rounded-xl space-y-2 text-xs">
                            <div className="flex justify-between text-slate-500">
                              <span>Total Subtotal:</span>
                              <span className="font-mono font-bold">{formatRupiah(totalOriginal)}</span>
                            </div>
                            {totalDiscounts > 0 && (
                              <div className="flex justify-between text-rose-600 font-semibold">
                                <span>Total Diskon Produk:</span>
                                <span className="font-mono font-bold">-{formatRupiah(totalDiscounts)}</span>
                              </div>
                            )}
                            <div className="flex justify-between items-center pt-2 border-t border-slate-200 dark:border-slate-700">
                              <span className="font-black text-slate-800 dark:text-slate-200">Total Pembayaran:</span>
                              <span className="font-mono text-emerald-600 font-black text-base">
                                {formatRupiah(totalFinal)}
                              </span>
                            </div>
                          </div>
                        );
                      })()}
                    </div>

                    {/* CUSTOMER PHONE */}
                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-1.5">
                        Nomor HP Pelanggan (Opsional)
                      </label>
                      <input
                        type="text"
                        placeholder="Contoh: 081234567890 (kosongkan jika tidak ada)"
                        value={physicalCustomerPhone}
                        onChange={(e) => setPhysicalCustomerPhone(e.target.value.replace(/\D/g, ''))}
                        className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-900 text-slate-800 dark:text-slate-100 transition-all"
                      />
                    </div>

                    {/* METODE PEMBAYARAN */}
                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-1.5">
                        Metode Pembayaran
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setPhysicalPaymentMethod('cash')}
                          className={`py-2 px-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
                            physicalPaymentMethod === 'cash'
                              ? 'bg-emerald-50 border-emerald-500 text-emerald-700 shadow-sm'
                              : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                          }`}
                        >
                          <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                          Tunai (Laci)
                        </button>
                        <button
                          type="button"
                          onClick={() => setPhysicalPaymentMethod('transfer')}
                          className={`py-2 px-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
                            physicalPaymentMethod === 'transfer'
                              ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm'
                              : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                          }`}
                        >
                          <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
                          Transfer
                        </button>
                      </div>
                    </div>

                    {/* SELECT TARGET WALLET (ONLY IF TRANSFER CHOSEN) */}
                    {physicalPaymentMethod === 'transfer' && (
                      <div className="space-y-1">
                        <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-1">
                          E-Wallet Penerima Transfer
                        </label>
                        <select
                          value={physicalSelectedEWallet}
                          onChange={(e) => setPhysicalSelectedEWallet(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white text-slate-800 transition-all"
                        >
                          {eWallets
                            .filter((w) => w.isActive && w.id !== 'cash')
                            .map((wallet) => (
                              <option key={wallet.id} value={wallet.id}>
                                {wallet.name} ({formatRupiah(wallet.balance)})
                              </option>
                            ))}
                        </select>
                      </div>
                    )}

                    {/* PAYMENT INFO BANNER */}
                    {physicalPaymentMethod === 'cash' ? (
                      <div className="p-3 bg-amber-50/50 border border-amber-100/40 rounded-xl text-[10px] leading-relaxed text-amber-800 flex items-start space-x-2">
                        <HelpCircle className="w-3.5 h-3.5 mt-0.5 text-amber-500 shrink-0" />
                        <span>
                          <strong>Pembayaran Tunai Laci:</strong> Hasil penjualan item fisik akan masuk sebagai uang tunai langsung ke laci kasir dan direkam ke riwayat sif, tanpa memotong saldo server digital admin.
                        </span>
                      </div>
                    ) : (
                      <div className="p-3 bg-indigo-50/50 border border-indigo-100/40 rounded-xl text-[10px] leading-relaxed text-indigo-800 flex items-start space-x-2">
                        <HelpCircle className="w-3.5 h-3.5 mt-0.5 text-indigo-500 shrink-0" />
                        <span>
                          <strong>Pembayaran Transfer E-Wallet:</strong> Pelanggan mentransfer ke e-wallet toko. Saldo e-wallet terpilih akan **bertambah**, keuntungan otomatis tercatat, dan uang di laci **tidak bertambah**.
                        </span>
                      </div>
                    )}

                    {/* Form Checkout Trigger inside Right Column */}
                    <div className="pt-2">
                      <button
                        type="submit"
                        disabled={physicalCart.length === 0}
                        className={`w-full flex items-center justify-center py-3 px-2 rounded-xl font-bold text-xs tracking-wider uppercase transition-all ${
                          physicalCart.length > 0
                            ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-md shadow-emerald-500/10 active:scale-98 cursor-pointer'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500 cursor-not-allowed shadow-none'
                        }`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                        Proses Sekarang
                      </button>
                    </div>

                  {/* END RIGHT COLUMN */}
                  </div>

                {/* END GRID WRAPPER */}
                </div>
              </form>
              ) : posMode === 'edc_transfer' ? (
                <form onSubmit={handleEdcTransferSubmit}>
                  {/* Form Fields for EDC Transfer */}
                  <div className="p-5 space-y-4">
                    
                    {/* Notifications */}
                    {errorMsg && (
                      <div className="p-3 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900/40 text-red-600 dark:text-red-400 rounded-xl text-xs flex items-start space-x-1.5">
                        <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>{errorMsg}</span>
                      </div>
                    )}
                    {successMsg && (
                      <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40 text-emerald-700 dark:text-emerald-400 rounded-xl text-xs flex items-start space-x-1.5">
                        <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>{successMsg}</span>
                      </div>
                    )}

                    {/* TARGET BANK SELECTION */}
                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-1.5">
                        Bank Penerima
                      </label>
                      <div className="flex gap-1.5 mb-2">
                        {['BCA', 'BRI', 'Mandiri', 'BNI'].map((bank) => (
                          <button
                            key={bank}
                            type="button"
                            onClick={() => setEdcBank(bank)}
                            className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-all active:scale-95 ${
                              edcBank === bank
                                ? 'bg-indigo-600 border-indigo-600 text-white shadow-xs'
                                : 'bg-slate-50 hover:bg-slate-100 text-slate-500 border-slate-100 hover:border-slate-200'
                            }`}
                          >
                            {bank}
                          </button>
                        ))}
                      </div>
                      <input
                        type="text"
                        required
                        placeholder="Masukkan Bank Lainnya (Contoh: BSI, Permata, Danamon)"
                        value={edcBank}
                        onChange={(e) => setEdcBank(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-900 text-slate-800 dark:text-slate-100 transition-all"
                      />
                    </div>

                    {/* ACCOUNT NUMBER */}
                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-1.5">
                        Nomor Rekening Tujuan
                      </label>
                      <input
                        type="text"
                        inputMode="numeric"
                        required
                        placeholder="Contoh: 1234567890"
                        value={edcAccountNum}
                        onChange={(e) => setEdcAccountNum(e.target.value.replace(/\D/g, ''))}
                        className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-mono font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-900 text-slate-800 dark:text-slate-100 transition-all"
                      />
                    </div>

                    {/* ACCOUNT OWNER NAME */}
                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-1.5">
                        Nama Pemilik Rekening (Nama Penerima)
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Contoh: John Doe"
                        value={edcAccountName}
                        onChange={(e) => setEdcAccountName(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-900 text-slate-800 dark:text-slate-100 transition-all"
                      />
                    </div>

                    {/* TRANSFER AMOUNT */}
                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-1.5">
                        Nominal Transfer EDC
                      </label>
                      <div className="flex flex-wrap gap-1 mb-2">
                        {[100000, 500000, 1000000, 2000000, 5000000].map((amount) => (
                          <button
                            key={amount}
                            type="button"
                            onClick={() => setEdcAmountStr(amount.toString())}
                            className="px-2.5 py-1 text-[10px] font-mono font-bold rounded-lg bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 border border-slate-100 dark:border-slate-850 hover:border-slate-200 dark:hover:border-slate-600 transition-all active:scale-95"
                          >
                            {amount.toLocaleString('id-ID')}
                          </button>
                        ))}
                      </div>
                      <div className="relative">
                        <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-xs font-bold text-slate-400">
                          Rp
                        </span>
                        <input
                          type="text"
                          inputMode="numeric"
                          required
                          placeholder="Contoh: 1000000"
                          value={edcAmountStr}
                          onChange={(e) => setEdcAmountStr(e.target.value.replace(/\D/g, ''))}
                          className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-mono font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-900 text-slate-800 dark:text-slate-100 transition-all"
                        />
                      </div>
                      {edcAmountStr && (
                        <p className="text-[10px] text-slate-400 mt-1 font-mono">
                          Format: {getRupiahPreview(edcAmountStr)}
                        </p>
                      )}
                    </div>

                    {/* ADMIN FEE */}
                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-1.5">
                        {currentUser.role === 'admin' ? 'Biaya Admin (Masuk Uang Laci & Profit)' : 'Biaya Admin (Masuk Uang Laci)'}
                      </label>
                      <div className="flex flex-wrap gap-1 mb-2">
                        {[3000, 5000, 6500, 10000, 15000].map((fee) => (
                          <button
                            key={fee}
                            type="button"
                            onClick={() => setEdcAdminFeeStr(fee.toString())}
                            className="px-2.5 py-1 text-[10px] font-mono font-bold rounded-lg bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 border border-slate-100 dark:border-slate-850 hover:border-slate-200 dark:hover:border-slate-600 transition-all active:scale-95"
                          >
                            {fee.toLocaleString('id-ID')}
                          </button>
                        ))}
                      </div>
                      <div className="relative">
                        <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-xs font-bold text-slate-400">
                          Rp
                        </span>
                        <input
                          type="text"
                          inputMode="numeric"
                          required
                          placeholder="Contoh: 5000"
                          value={edcAdminFeeStr}
                          onChange={(e) => setEdcAdminFeeStr(e.target.value.replace(/\D/g, ''))}
                          className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-mono font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-900 text-slate-800 dark:text-slate-100 transition-all"
                        />
                      </div>
                      {edcAdminFeeStr && (
                        <p className="text-[10px] text-slate-400 mt-1 font-mono">
                          Format: {getRupiahPreview(edcAdminFeeStr)}
                        </p>
                      )}
                    </div>

                    {/* CUSTOMER PHONE */}
                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-1.5">
                        No. HP Pelanggan (Opsional)
                      </label>
                      <input
                        type="text"
                        placeholder="Contoh: 08123456789"
                        value={edcCustomerPhone}
                        onChange={(e) => setEdcCustomerPhone(e.target.value.replace(/\D/g, ''))}
                        className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-900 text-slate-800 dark:text-slate-100 transition-all"
                      />
                    </div>

                    {/* EDC SIMULATION BANNER */}
                    {edcAmountStr && (
                      <div className="p-3.5 bg-slate-50/50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800 text-[10px] space-y-2 font-medium text-slate-600 dark:text-slate-400">
                        <div className="flex items-center justify-between text-slate-800 dark:text-slate-200 border-b border-slate-100 dark:border-slate-850 pb-2">
                          <span className="font-black">Simulasi Transfer via EDC</span>
                          <span className="font-mono bg-blue-50 dark:bg-blue-950/20 text-blue-700 dark:text-blue-300 px-2 py-0.5 rounded text-[8px] font-extrabold uppercase tracking-wider">
                            EDC Card Transfer
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Nominal Transfer (dari Kartu):</span>
                          <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{formatRupiah(parseInt(edcAmountStr, 10) || 0)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Biaya Admin (Uang Laci):</span>
                          <span className="font-mono font-bold text-emerald-600">+{formatRupiah(parseInt(edcAdminFeeStr, 10) || 0)}</span>
                        </div>
                        <div className="flex justify-between border-t border-dashed border-slate-200/80 dark:border-slate-750 pt-2 font-black text-slate-800 dark:text-slate-200">
                          <span>Uang Laci Bertambah:</span>
                          <span className="font-mono text-emerald-600 font-bold">
                            +{formatRupiah(parseInt(edcAdminFeeStr, 10) || 0)}
                          </span>
                        </div>
                        <div className="flex justify-between font-black text-slate-800 dark:text-slate-200">
                          <span>Keuntungan Bersih:</span>
                          <span className="font-mono text-emerald-600 font-bold">
                            +{formatRupiah(parseInt(edcAdminFeeStr, 10) || 0)}
                          </span>
                        </div>
                        <p className="text-[9px] text-amber-600 dark:text-amber-400 font-semibold bg-amber-50 dark:bg-amber-950/20 p-2 rounded-lg mt-1 leading-normal border border-amber-100/50 dark:border-amber-900/30">
                          * Saldo server digital toko tidak berkurang. Nominal transfer didebit langsung dari kartu konsumen oleh EDC bank dan masuk ke rekening tujuan. Admin dibayar terpisah oleh konsumen secara tunai masuk ke laci.
                        </p>
                      </div>
                    )}

                  </div>

                  {/* Form Submit Trigger for EDC Transfer */}
                  <div className="p-4 bg-slate-50/50 border-t border-slate-100">
                    <button
                      type="submit"
                      disabled={!edcBank || !edcAccountNum || !edcAccountName || !edcAmountStr}
                      className={`w-full flex items-center justify-center py-3 rounded-xl font-bold text-xs tracking-wider uppercase transition-all ${
                        edcBank && edcAccountNum && edcAccountName && edcAmountStr
                          ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-500/10 active:scale-98'
                          : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                      }`}
                    >
                      <CheckCircle2 className="w-4 h-4 mr-1.5" />
                      Proses Transfer EDC
                    </button>
                  </div>
                </form>
              ) : (
                <form onSubmit={handleAddWithdrawalToQueue}>
                  {/* Form Fields for Withdrawal */}
                  <div className="p-5 space-y-4">
                    
                    {/* Notifications */}
                    {errorMsg && (
                      <div className="p-3 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900/40 text-red-600 dark:text-red-400 rounded-xl text-xs flex items-start space-x-1.5">
                        <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>{errorMsg}</span>
                      </div>
                    )}
                    {successMsg && (
                      <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40 text-emerald-700 dark:text-emerald-400 rounded-xl text-xs flex items-start space-x-1.5">
                        <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>{successMsg}</span>
                      </div>
                    )}

                    {/* WITHDRAWAL AMOUNT */}
                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-1.5">
                        Nominal Penarikan (Jumlah kiriman konsumen)
                      </label>

                      {/* Quick amount presets (5K, 10K, 20K, 50K, 100K, 200K) */}
                      <div className="flex flex-wrap gap-1 mb-2">
                        {NOMINAL_PRESETS.map((amount) => (
                          <button
                            key={amount}
                            type="button"
                            onClick={() => setWdAmountStr(amount.toString())}
                            className="px-2.5 py-1 text-[10px] font-mono font-black rounded-lg bg-rose-50/60 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/40 text-rose-700 dark:text-rose-300 border border-rose-100/50 dark:border-rose-900/50 hover:border-rose-200 dark:hover:border-rose-800 transition-all active:scale-95"
                          >
                            {amount >= 1000 ? (amount / 1000) + 'K' : amount}
                          </button>
                        ))}
                      </div>

                      <div className="relative">
                        <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-xs font-bold text-slate-400">
                          Rp
                        </span>
                        <input
                          type="text"
                          inputMode="numeric"
                          required
                          placeholder="Contoh: 100000"
                          value={wdAmountStr}
                          onChange={(e) => setWdAmountStr(e.target.value.replace(/\D/g, ''))}
                          className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-mono font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-900 text-slate-800 dark:text-slate-100 transition-all"
                        />
                      </div>
                      {wdAmountStr && (
                        <p className="text-[10px] text-slate-400 mt-1 font-mono">
                          Format: {getRupiahPreview(wdAmountStr)}
                        </p>
                      )}
                    </div>

                    {/* FEE TYPE SELECTOR */}
                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-1.5">
                        Jenis Potongan / Biaya Admin
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setWdFeeType('admin_luar')}
                          className={`p-3 rounded-xl border text-left transition-all ${
                            wdFeeType === 'admin_luar'
                              ? 'border-indigo-500 bg-indigo-50/30 dark:bg-indigo-950/20 text-indigo-950 dark:text-indigo-200 ring-1 ring-indigo-400/20'
                              : 'border-slate-100 dark:border-slate-800 hover:border-slate-200 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40 text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          <span className="block text-[10px] font-black uppercase tracking-wider">Admin Luar</span>
                          <span className="block text-[9px] mt-0.5 leading-relaxed text-slate-400">
                            Tunai luar nominal penarikan.
                          </span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setWdFeeType('admin_potong')}
                          className={`p-3 rounded-xl border text-left transition-all ${
                            wdFeeType === 'admin_potong'
                              ? 'border-indigo-500 bg-indigo-50/30 dark:bg-indigo-950/20 text-indigo-950 dark:text-indigo-200 ring-1 ring-indigo-400/20'
                              : 'border-slate-100 dark:border-slate-800 hover:border-slate-200 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40 text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          <span className="block text-[10px] font-black uppercase tracking-wider">Admin Potong</span>
                          <span className="block text-[9px] mt-0.5 leading-relaxed text-slate-400">
                            Potong langsung dari nominal.
                          </span>
                        </button>
                      </div>
                    </div>

                    {/* ADMIN FEE AMOUNT */}
                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-1.5">
                        Biaya Admin (Pendapatan/Untung Konter)
                      </label>

                      {/* Quick fee presets */}
                      <div className="flex flex-wrap gap-1 mb-2">
                        {[2000, 3000, 5000, 10000].map((fee) => (
                          <button
                            key={fee}
                            type="button"
                            onClick={() => setWdAdminFeeStr(fee.toString())}
                            className="px-2.5 py-1 text-[10px] font-mono font-bold rounded-lg bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 border border-slate-100 dark:border-slate-850 hover:border-slate-200 dark:hover:border-slate-600 transition-all active:scale-95"
                          >
                            {fee.toLocaleString('id-ID')}
                          </button>
                        ))}
                      </div>

                      <div className="relative">
                        <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-xs font-bold text-slate-400">
                          Rp
                        </span>
                        <input
                          type="text"
                          inputMode="numeric"
                          required
                          placeholder="Contoh: 5000"
                          value={wdAdminFeeStr}
                          onChange={(e) => setWdAdminFeeStr(e.target.value.replace(/\D/g, ''))}
                          className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-mono font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-900 text-slate-800 dark:text-slate-100 transition-all"
                        />
                      </div>
                      {wdAdminFeeStr && (
                        <p className="text-[10px] text-slate-400 mt-1 font-mono">
                          Format: {getRupiahPreview(wdAdminFeeStr)}
                        </p>
                      )}
                    </div>

                    {/* SELECTED TARGET WALLET INFORMATION */}
                    {selectedWalletObj ? (
                      <div className="p-3 bg-slate-50/85 dark:bg-slate-800/80 rounded-xl border border-slate-100 dark:border-slate-800 flex flex-col xs:flex-row justify-between xs:items-center gap-2">
                        <div className="flex items-center space-x-2.5 min-w-0">
                          {selectedWalletObj.logoUrl ? (
                            <img 
                              src={selectedWalletObj.logoUrl} 
                              alt={selectedWalletObj.name} 
                              className="w-7 h-7 object-cover rounded-lg border border-slate-100 dark:border-slate-800 shrink-0" 
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <span className="w-7 h-7 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 font-extrabold text-[10px] flex items-center justify-center shrink-0">
                              {selectedWalletObj.provider.substring(0, 3)}
                            </span>
                          )}
                          <div className="min-w-0">
                            <p className="text-[8px] text-slate-400 font-bold uppercase tracking-wider">Target Wallet</p>
                            <p className="font-extrabold text-slate-700 dark:text-slate-200 text-xs truncate">{selectedWalletObj.name}</p>
                          </div>
                        </div>
                        <div className="text-left xs:text-right shrink-0">
                          <p className="text-[8px] text-slate-400 font-bold uppercase tracking-wider">Sisa Saldo</p>
                          <p className="font-mono font-black text-indigo-600 dark:text-indigo-400 text-xs">{formatRupiah(selectedWalletObj.balance)}</p>
                        </div>
                      </div>
                    ) : (
                      <div className="p-3.5 bg-amber-50/50 dark:bg-amber-950/20 border border-amber-100/50 dark:border-amber-900/30 text-amber-700 dark:text-amber-400 rounded-xl text-xs font-medium">
                        Silakan pilih E-wallet di bagian atas halaman POS.
                      </div>
                    )}

                    {/* SIMULATION SUMMARY PANEL */}
                    {wdAmountStr && (
                      <div className="p-3.5 bg-slate-50/50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800 text-[10px] space-y-2 font-medium text-slate-600 dark:text-slate-400">
                        <div className="flex items-center justify-between text-slate-800 dark:text-slate-200 border-b border-slate-100 dark:border-slate-850 pb-2">
                          <span className="font-black">Simulasi Penarikan Tunai</span>
                          <span className="font-mono bg-slate-200/80 dark:bg-slate-700 text-slate-700 dark:text-slate-300 px-2 py-0.5 rounded text-[8px] font-extrabold uppercase tracking-wider">
                            {wdFeeType === 'admin_luar' ? 'Admin Luar' : 'Admin Potong'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Uang Transfer Pelanggan:</span>
                          <span className="font-mono font-bold text-slate-800 dark:text-slate-200">+{formatRupiah(parseInt(wdAmountStr, 10) || 0)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>{currentUser.role === 'admin' ? 'Biaya Admin (Profit):' : 'Biaya Admin:'}</span>
                          <span className="font-mono font-bold text-emerald-600">+{formatRupiah(parseInt(wdAdminFeeStr, 10) || 0)}</span>
                        </div>
                        {wdFeeType === 'admin_luar' ? (
                          <>
                            <div className="flex justify-between">
                              <span>Uang Fisik Diberikan ke Pelanggan:</span>
                              <span className="font-mono font-bold text-rose-500">-{formatRupiah(parseInt(wdAmountStr, 10) || 0)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Admin Diterima Kasir:</span>
                              <span className="font-mono font-bold text-emerald-600">+{formatRupiah(parseInt(wdAdminFeeStr, 10) || 0)}</span>
                            </div>
                            <div className="flex justify-between border-t border-dashed border-slate-200/80 dark:border-slate-750 pt-2 font-black text-slate-800 dark:text-slate-200">
                              <span>Net Pengurangan Laci:</span>
                              <span className="font-mono text-rose-600 font-bold">
                                -{formatRupiah((parseInt(wdAmountStr, 10) || 0) - (parseInt(wdAdminFeeStr, 10) || 0))}
                              </span>
                            </div>
                          </>
                        ) : (
                          <>
                            <div className="flex justify-between">
                              <span>Uang Fisik Diberikan ke Pelanggan:</span>
                              <span className="font-mono font-bold text-rose-500">
                                -{formatRupiah((parseInt(wdAmountStr, 10) || 0) - (parseInt(wdAdminFeeStr, 10) || 0))}
                              </span>
                            </div>
                            <div className="flex justify-between border-t border-dashed border-slate-200/80 dark:border-slate-750 pt-2 font-black text-slate-800 dark:text-slate-200">
                              <span>Net Pengurangan Laci:</span>
                              <span className="font-mono text-rose-600 font-bold">
                                -{formatRupiah((parseInt(wdAmountStr, 10) || 0) - (parseInt(wdAdminFeeStr, 10) || 0))}
                              </span>
                            </div>
                          </>
                        )}
                      </div>
                    )}

                  </div>                   {/* Form Submit Trigger for Withdrawal */}
                  <div className="p-4 bg-slate-50/50 dark:bg-slate-800/40 border-t border-slate-100 dark:border-slate-800 flex flex-row gap-2.5">
                    <button
                      type="submit"
                      disabled={!wdAmountStr || !selectedEWallet}
                      className={`flex-1 flex items-center justify-center py-3 px-2 rounded-xl font-bold text-[10px] tracking-wider uppercase transition-all border ${
                        wdAmountStr && selectedEWallet
                          ? 'border-rose-200 dark:border-rose-900/40 bg-rose-50 dark:bg-rose-950/20 text-rose-700 dark:text-rose-400 hover:bg-rose-100/50 dark:hover:bg-rose-900/40 active:scale-98'
                          : 'border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-slate-400 dark:text-slate-500 cursor-not-allowed shadow-none'
                      }`}
                    >
                      <Plus className="w-3.5 h-3.5 mr-1" />
                      + Antrean
                    </button>

                    <button
                      type="button"
                      onClick={handleWithdrawalSubmit}
                      disabled={!wdAmountStr || !selectedEWallet}
                      className={`flex-1 flex items-center justify-center py-3 px-2 rounded-xl font-bold text-[10px] tracking-wider uppercase transition-all ${
                        wdAmountStr && selectedEWallet
                          ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-md shadow-rose-500/10 active:scale-98'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                      Proses Sekarang
                    </button>
                  </div>
                </form>
              )}

            </div>
          )}
        </div>

        {/* SIDE COLUMN: RIWAYAT TRANSAKSI TERAKHIR (Android Feed Style) */}
        {posMode !== 'physical' && (
          <div className="lg:col-span-5 space-y-4">
            
            {/* TRANSACTION QUEUE (ANTREAN TRANSAKSI) */}
            <div className="glass-card p-5 rounded-[24px]">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
                <div className="flex items-center space-x-2">
                  <span className="relative flex h-2 w-2">
                    {transactionQueue.length > 0 && (
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                    )}
                    <span className={`relative inline-flex rounded-full h-2 w-2 ${transactionQueue.length > 0 ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-600'}`}></span>
                  </span>
                  <h3 className="font-extrabold text-sm text-slate-800 dark:text-slate-200 flex items-center uppercase">
                    Antrean Transaksi
                  </h3>
                </div>
                {transactionQueue.length > 0 ? (
                  <span className="bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 px-2.5 py-0.5 rounded-full text-[10px] font-black">
                    {transactionQueue.length} Transaksi
                  </span>
                ) : (
                  <span className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">
                    Kosong
                  </span>
                )}
              </div>

              {transactionQueue.length === 0 ? (
                <div className="py-6 text-center">
                  <p className="text-xs text-slate-400 dark:text-slate-500 font-medium">Belum ada transaksi dalam antrean.</p>
                  <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1">Gunakan tombol <strong className="font-bold text-indigo-600 dark:text-indigo-400">+ Antrean</strong> pada form input untuk mengisi antrean ini.</p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  <div className="max-h-56 overflow-y-auto pr-1 space-y-2 divide-y divide-slate-100 dark:divide-slate-800">
                    {transactionQueue.map((qTx) => (
                      <div key={qTx.id} className="flex items-center justify-between pt-2.5 first:pt-0">
                        <div className="min-w-0 flex-1 pr-2">
                          <div className="flex items-center space-x-1.5 flex-wrap gap-y-0.5 mb-1">
                            <span className={`px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-wider ${
                              qTx.type === 'topup' 
                                ? 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 border border-indigo-100/50 dark:border-indigo-900/40' 
                                : qTx.type === 'physical'
                                ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-100/50 dark:border-emerald-900/40'
                                : 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-100/50 dark:border-rose-900/40'
                            }`}>
                              {qTx.type === 'topup' ? 'Topup' : qTx.type === 'physical' ? 'Fisik' : 'Tarik'}
                            </span>
                            <span className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider font-mono">
                              {qTx.walletName}
                            </span>
                          </div>
                          <p className="text-xs font-black text-slate-800 dark:text-slate-200 truncate">
                            {qTx.displayName}
                          </p>
                          {qTx.item?.scannedBarcodes && qTx.item.scannedBarcodes.length > 0 && (
                            <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-mono font-bold">
                              Barcode: {qTx.item.scannedBarcodes.join(', ')}
                            </p>
                          )}
                          <p className="text-[10px] text-slate-400 dark:text-slate-500 font-medium">
                            HP: <span className="font-mono font-bold text-slate-600 dark:text-slate-400">{qTx.phone}</span>
                          </p>
                        </div>
                        <div className="flex items-center space-x-2.5 shrink-0">
                          <div className="text-right">
                            <p className="text-xs font-mono font-black text-slate-800 dark:text-slate-200">
                              {formatRupiah(qTx.sellingPrice || qTx.amount)}
                            </p>
                            {qTx.adminFee !== undefined && (
                              <p className="text-[8px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">
                                Admin {formatRupiah(qTx.adminFee)}
                              </p>
                            )}
                          </div>
                          <button
                            type="button"
                            onClick={() => setTransactionQueue(prev => prev.filter(item => item.id !== qTx.id))}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/20 rounded-lg transition-all active:scale-90"
                            title="Hapus dari antrean"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Real-time Queue Calculation Summary Panel */}
                  <div className="bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-[16px] border border-slate-100 dark:border-slate-800 space-y-2 text-[11px] text-slate-600 dark:text-slate-400">
                    <div className="flex items-center justify-between font-extrabold text-slate-850 dark:text-slate-200 border-b border-slate-100 dark:border-slate-800 pb-1.5 mb-1">
                      <span>Hitung Semua Transaksi ({queueSummary.totalItems})</span>
                      <span className="text-[8px] bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900/40 px-1.5 py-0.5 rounded font-black uppercase tracking-wider font-mono">
                        Massa
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Nilai Jual:</span>
                      <span className="font-mono font-bold text-slate-850 dark:text-slate-200">{formatRupiah(queueSummary.totalSellingPrice)}</span>
                    </div>
                    {currentUser.role === 'admin' && (
                      <div className="flex justify-between text-emerald-600 dark:text-emerald-400 font-medium">
                        <span>Total Komisi / Profit:</span>
                        <span className="font-mono font-bold">+{formatRupiah(queueSummary.totalProfit)}</span>
                      </div>
                    )}
                    <div className="flex justify-between border-t border-dashed border-slate-200 dark:border-slate-800 pt-2 font-black text-slate-800 dark:text-slate-200">
                      <span>Estimasi Kas Laci:</span>
                      <span className={`font-mono font-bold ${queueSummary.totalCashMovement >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-500'}`}>
                        {queueSummary.totalCashMovement >= 0 ? '+' : ''}{formatRupiah(queueSummary.totalCashMovement)}
                      </span>
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={handleProcessAllQueue}
                      className="w-full flex items-center justify-center py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs tracking-wider uppercase transition-all shadow-md shadow-indigo-600/10 active:scale-98"
                    >
                      <Play className="w-3.5 h-3.5 mr-1.5 fill-current" />
                      Proses Semua ({transactionQueue.length})
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className="glass-card p-5 rounded-[24px]">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
                <h3 className="font-extrabold text-sm text-slate-800 dark:text-slate-200 flex items-center uppercase">
                  <Clock className="w-4 h-4 mr-1.5 text-slate-500 dark:text-slate-400" />
                  Transaksi Terakhir
                </h3>
                <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest font-mono">
                  Real-Time Feed
                </span>
              </div>

              {/* Quick search history field */}
              <div className="relative mb-3">
                <Search className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400 dark:text-slate-500 w-4 h-4" />
                <input
                  type="text"
                  value={historySearchQuery}
                  onChange={(e) => setHistorySearchQuery(e.target.value)}
                  placeholder="Cari transaksi terakhir..."
                  className="w-full pl-9 pr-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 focus:bg-white dark:focus:bg-slate-900 transition-all"
                />
              </div>

              {/* Transactions Card List */}
              <div className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
                {filteredRecentTransactions.length === 0 ? (
                  <div className="py-12 text-center text-slate-400 dark:text-slate-500 text-xs">
                    Belum ada transaksi di konter hari ini.
                  </div>
                ) : (
                  filteredRecentTransactions.map((tx) => {
                    const firstItem = tx.items[0];
                    const walletObj = eWallets.find((w) => w.id === tx.eWalletId);
                    return (
                      <div 
                        key={tx.id}
                        className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800/80 flex items-center justify-between hover:bg-slate-100/50 dark:hover:bg-slate-800/80 transition-colors"
                      >
                        <div className="flex items-center space-x-2.5 min-w-0">
                          {walletObj?.logoUrl && (
                            <img 
                              src={walletObj.logoUrl} 
                              alt={tx.eWalletName} 
                              className="w-7 h-7 object-cover rounded-lg border border-slate-200/80 dark:border-slate-700 shadow-xs shrink-0" 
                              referrerPolicy="no-referrer"
                            />
                          )}
                          <div className="min-w-0">
                            <div className="flex items-center space-x-1.5">
                              <span className="text-[10px] font-extrabold text-slate-800 dark:text-slate-200 truncate block">
                                {firstItem ? firstItem.productName : 'Manual Order'}
                              </span>
                              <span className="text-[8px] bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 px-1 py-0.1 rounded font-bold uppercase shrink-0 font-mono">
                                {tx.eWalletName ? tx.eWalletName.split(' ')[0] : '-'}
                              </span>
                            </div>
                            <p className="text-[10px] text-slate-400 dark:text-slate-500 font-semibold font-mono mt-0.5">
                              {tx.customerPhone && tx.customerPhone !== '-' ? `No: ${tx.customerPhone} • ` : ''}{tx.invoiceNumber}
                            </p>
                            <p className="text-[9px] text-slate-400 dark:text-slate-500 font-medium mt-0.5">
                              {tx.date ? new Date(tx.date).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) : '-'}
                            </p>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <p className="text-xs font-extrabold text-slate-900 dark:text-slate-200 font-mono">
                            {formatRupiah(tx.totalAmount)}
                          </p>
                          <button
                            type="button"
                            onClick={() => {
                              setRecentTransaction(tx);
                              setShowReceipt(true);
                            }}
                            className="text-[10px] text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 font-extrabold flex items-center justify-end space-x-0.5 mt-0.5"
                          >
                            <span>Detail Transaksi</span>
                            <ExternalLink className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

          </div>
        )}

      </div>

      {/* 3. POS TRANSACTION DETAIL POPUP MODAL */}
      {showReceipt && recentTransaction && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 pb-12 sm:pb-4 z-[200] overflow-y-auto">
          <div className="bg-white rounded-[20px] shadow-2xl max-w-sm w-full overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-200 my-8">
            
            {/* Printable Detail Container */}
            <div id="print-receipt" className="p-6 bg-white text-slate-800 font-sans text-xs">
              
              {/* Detail Header */}
              <div className="flex flex-col items-center justify-center text-center pb-5 border-b border-slate-100">
                <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mb-2.5">
                  <CheckCircle2 className="w-7 h-7" />
                </div>
                <h3 className="font-extrabold text-base text-slate-900 leading-tight">Transaksi Berhasil</h3>
                <p className="text-[10px] text-emerald-600 font-extrabold bg-emerald-50 px-2.5 py-0.5 rounded-full mt-1.5 uppercase tracking-wider">
                  Status: Terbayar
                </p>
              </div>

              {/* Transaction Amount Hero */}
              {recentTransaction.type === 'edc_transfer' ? (
                <div className="py-4 px-3 text-center bg-slate-50/50 rounded-[16px] my-4 border border-slate-100 space-y-2.5">
                  <div>
                    <p className="text-[8px] text-slate-400 font-bold uppercase tracking-wider mb-0.5">Nominal Transfer EDC</p>
                    <p className="text-xl font-black text-slate-900 tracking-tight">
                      {formatRupiah((recentTransaction.items[0] as any).transferAmount || 0)}
                    </p>
                  </div>
                  <div className="flex justify-around border-t border-slate-100 pt-2 text-[10px]">
                    <div>
                      <p className="text-[8px] text-slate-400 font-bold uppercase tracking-wider">Biaya Admin</p>
                      <p className="font-extrabold text-slate-800">
                        {formatRupiah(recentTransaction.totalAmount)}
                      </p>
                    </div>
                    <div className="border-l border-slate-200"></div>
                    <div>
                      <p className="text-[8px] text-slate-400 font-bold uppercase tracking-wider">Metode Admin</p>
                      <p className="font-extrabold text-indigo-600 uppercase">Tunai Terpisah</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="py-5 text-center bg-slate-50/50 rounded-[16px] my-4 border border-slate-100">
                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider mb-0.5">Total Bayar</p>
                  <p className="text-2xl font-black text-slate-900 tracking-tight">
                    {formatRupiah(recentTransaction.totalAmount)}
                  </p>
                </div>
              )}

              {/* Detail Meta Info Grid */}
              <div className="space-y-3 py-1 border-b border-slate-100 text-[11px] text-slate-600">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-semibold uppercase tracking-wider text-[9px]">No. Transaksi</span>
                  <span className="font-mono font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded-md text-[10px]">
                    {recentTransaction.invoiceNumber}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-semibold uppercase tracking-wider text-[9px]">Waktu Transaksi</span>
                  <span className="font-bold text-slate-800">
                    {recentTransaction.date ? new Date(recentTransaction.date).toLocaleString('id-ID', {
                      dateStyle: 'medium',
                      timeStyle: 'short'
                    }) : '-'}
                  </span>
                </div>
                {recentTransaction.customerPhone && recentTransaction.customerPhone !== '-' && (
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400 font-semibold uppercase tracking-wider text-[9px]">No. Pelanggan</span>
                    <span className="font-extrabold text-slate-800">{recentTransaction.customerPhone}</span>
                  </div>
                )}
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-semibold uppercase tracking-wider text-[9px]">Kasir Operator</span>
                  <span className="font-bold text-slate-800">{recentTransaction.cashierName}</span>
                </div>
              </div>

              {/* Detail Items / Products */}
              <div className="py-4 border-b border-slate-100 space-y-3">
                <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Detail Produk</p>
                {recentTransaction.type === 'edc_transfer' ? (
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-400 font-medium">Tipe Layanan:</span>
                      <span className="font-bold text-slate-800">Transfer via EDC</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400 font-medium">Bank Penerima:</span>
                      <span className="font-bold text-slate-800">{(recentTransaction.items[0] as any).targetBank || '-'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400 font-medium">No. Rekening:</span>
                      <span className="font-mono font-bold text-slate-800">{(recentTransaction.items[0] as any).targetAccount || '-'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400 font-medium">Nama Penerima:</span>
                      <span className="font-bold text-slate-800">{(recentTransaction.items[0] as any).targetAccountName || '-'}</span>
                    </div>
                    <div className="flex justify-between border-t border-dashed border-slate-200/80 pt-2">
                      <span className="text-slate-400 font-semibold">Nominal Transfer:</span>
                      <span className="font-mono font-black text-slate-800">
                        {formatRupiah((recentTransaction.items[0] as any).transferAmount || 0)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400 font-semibold">Biaya Admin POS:</span>
                      <span className="font-mono font-black text-emerald-600">
                        {formatRupiah(recentTransaction.totalAmount)}
                      </span>
                    </div>
                  </div>
                ) : (
                  recentTransaction.items.map((item, index) => (
                    <div key={index} className="space-y-1.5 text-xs">
                      <div className="flex justify-between items-start">
                        <div className="min-w-0 pr-2">
                          <p className="font-extrabold text-slate-800 truncate leading-snug">{item.productName}</p>
                          <p className="text-[10px] text-slate-400 font-medium">
                            {((item.category || 'LAINNYA').toUpperCase())} • Qty: {item.quantity || 1}
                          </p>
                          {item.scannedBarcodes && item.scannedBarcodes.length > 0 && (
                            <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-mono font-bold mt-0.5">
                              Barcode: {item.scannedBarcodes.join(', ')}
                            </p>
                          )}
                        </div>
                        <div className="text-right shrink-0">
                          {item.discountAmount && item.discountAmount > 0 ? (
                            <>
                              <p className="font-extrabold text-slate-800">{formatRupiah(item.sellingPrice * item.quantity)}</p>
                              <p className="text-[9px] text-slate-400 line-through">@{formatRupiah(item.originalPrice || item.sellingPrice)}</p>
                            </>
                          ) : (
                            <>
                              <p className="font-extrabold text-slate-800">{formatRupiah(item.sellingPrice * item.quantity)}</p>
                              <p className="text-[9px] text-slate-400">@{formatRupiah(item.sellingPrice)}</p>
                            </>
                          )}
                        </div>
                      </div>
                      {item.discountAmount && item.discountAmount > 0 && (
                        <div className="bg-slate-50 p-2 rounded-xl text-[10px] space-y-1 border border-slate-100">
                          <div className="flex justify-between text-slate-500">
                            <span>Harga Awal ({item.quantity}x):</span>
                            <span className="font-medium font-mono">{formatRupiah((item.originalPrice || item.sellingPrice) * item.quantity)}</span>
                          </div>
                          <div className="flex justify-between text-rose-500 font-bold">
                            <span>Diskon ({item.discountType === 'percent' ? 'Persen' : 'Nominal'}):</span>
                            <span className="font-mono">-{formatRupiah(item.discountAmount)}</span>
                          </div>
                          {item.discountReason && (
                            <div className="flex justify-between text-slate-500 text-[9px] italic">
                              <span>Alasan Diskon:</span>
                              <span className="font-semibold">{item.discountReason}</span>
                            </div>
                          )}
                          <div className="flex justify-between text-slate-800 font-extrabold pt-1 border-t border-slate-200">
                            <span>Harga Akhir:</span>
                            <span className="font-mono">{formatRupiah(item.sellingPrice * item.quantity)}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>

              {/* Detail Payments & Wallets */}
              <div className="py-4 space-y-2.5 text-[11px] text-slate-600">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-semibold uppercase tracking-wider text-[9px]">Sistem Server</span>
                  <span className="font-bold text-slate-800 bg-blue-50 text-blue-700 px-2 py-0.5 rounded-md text-[10px] uppercase">
                    {recentTransaction.eWalletName || 'Tunai'}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-semibold uppercase tracking-wider text-[9px]">Metode Pembayaran</span>
                  <span className="font-bold text-slate-700">
                    {recentTransaction.items[0]?.paymentMethod === 'transfer' ? 'Transfer' : recentTransaction.eWalletId === 'cash' ? 'Tunai' : recentTransaction.type === 'physical' && recentTransaction.eWalletId !== 'cash' ? 'Transfer' : 'Tunai'}
                  </span>
                </div>
              </div>

              {/* Detail Footer */}
              <div className="text-center pt-4 border-t border-slate-100 space-y-1.5 flex flex-col items-center">
                <img 
                  src={appConfig?.logoUrl || "/logo.png"} 
                  alt="MD POS Logo" 
                  onError={(e) => {
                    if (e.currentTarget.src !== window.location.origin + "/logo.png") {
                      e.currentTarget.src = "/logo.png";
                    }
                  }} 
                  className="w-8 h-8 object-contain mb-1 rounded bg-white p-0.5 border border-slate-200" 
                  referrerPolicy="no-referrer"
                />
                <p className="font-extrabold text-slate-800 tracking-wider text-[10px]">MD POS</p>
                <p className="text-[9px] text-indigo-500 font-bold">https://mdcell.my.id</p>
                <p className="text-[8px] text-slate-400">Arsip rincian transaksi sah merchant jualan pulsa & e-wallet.</p>
              </div>
            </div>

            {/* Modal Controls (Not Printed) */}
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex">
              <button
                type="button"
                onClick={() => {
                  setShowReceipt(false);
                  setRecentTransaction(null);
                }}
                className="w-full py-2.5 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold text-center transition-all shadow-sm"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {showBatchReceipt && recentBatchTransactions.length > 0 && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 pb-12 sm:pb-4 z-[200] overflow-y-auto">
          <div className="bg-white rounded-[20px] shadow-2xl max-w-lg w-full overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-200 my-8">
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div>
                <h3 className="font-extrabold text-sm text-slate-900">Batch Transaksi Berhasil</h3>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">{recentBatchTransactions.length} Transaksi Selesai</p>
              </div>
              <button
                onClick={() => {
                  setShowBatchReceipt(false);
                  setRecentBatchTransactions([]);
                }}
                className="text-slate-400 hover:text-slate-600 font-bold text-lg"
              >
                &times;
              </button>
            </div>

            {/* List of Transactions in Batch (Scrollable UI, Hidden in Print) */}
            <div className="p-5 max-h-96 overflow-y-auto space-y-4 print:hidden">
              <div className="p-3.5 bg-emerald-50 text-emerald-800 rounded-[16px] flex items-start space-x-2 border border-emerald-100">
                <CheckCircle2 className="w-4 h-4 mt-0.5 text-emerald-600 shrink-0" />
                <div className="text-xs">
                  <p className="font-extrabold">Transaksi Berhasil Diproses!</p>
                  <p className="text-[10px] text-emerald-700 font-medium mt-0.5">Semua transaksi di antrean telah dihitung dan diproses dengan aman dalam satu operasi tunggal.</p>
                </div>
              </div>

              <div className="space-y-2.5">
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Daftar Transaksi</p>
                {recentBatchTransactions.map((tx) => (
                  <div key={tx.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between">
                    <div>
                      <p className="text-xs font-black text-slate-800">{tx.invoiceNumber}</p>
                      <p className="text-[10px] text-slate-400 mt-0.5 font-medium font-mono">
                        {tx.items[0]?.productName} • {formatRupiah(tx.totalAmount)}
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        setRecentTransaction(tx);
                        setShowReceipt(true);
                      }}
                      className="py-1 px-2.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg text-[10px] font-bold transition-all"
                    >
                      Lihat Nota
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Hidden Printable Container containing all receipts separated by page-break */}
            <div id="print-receipt-batch" className="hidden print:block p-6 bg-white text-slate-800 font-sans text-xs">
              {recentBatchTransactions.map((tx) => (
                <div key={tx.id} className="receipt-page py-6 border-b border-dashed border-slate-200 last:border-0">
                  <div className="flex flex-col items-center justify-center text-center pb-5 border-b border-slate-150">
                    <img 
                      src={appConfig?.logoUrl || "/logo.png"} 
                      alt="MD POS Logo" 
                      onError={(e) => {
                        if (e.currentTarget.src !== window.location.origin + "/logo.png") {
                          e.currentTarget.src = "/logo.png";
                        }
                      }} 
                      className="w-8 h-8 object-contain mb-1 rounded bg-white p-0.5 border border-slate-200" 
                      referrerPolicy="no-referrer"
                    />
                    <h3 className="font-extrabold text-xs text-slate-900 leading-tight">MD POS</h3>
                    <p className="text-[9px] text-indigo-500 font-bold">https://mdcell.my.id</p>
                    <p className="text-[8px] text-slate-400 uppercase tracking-widest font-mono">Arsip Rincian Transaksi Sah</p>
                  </div>

                  <div className="py-4 text-center bg-slate-50/50 rounded-[16px] my-4 border border-slate-100">
                    <p className="text-[8px] text-slate-400 font-bold uppercase tracking-wider mb-0.5">Total Bayar</p>
                    <p className="text-xl font-black text-slate-900 tracking-tight">
                      {formatRupiah(tx.totalAmount)}
                    </p>
                  </div>

                  <div className="space-y-2 py-1 border-b border-slate-150 text-[10px] text-slate-600">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400 uppercase tracking-wider text-[8px]">No. Transaksi</span>
                      <span className="font-mono font-bold text-slate-800">
                        {tx.invoiceNumber}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400 uppercase tracking-wider text-[8px]">Waktu</span>
                      <span className="font-bold text-slate-800">
                        {tx.date ? new Date(tx.date).toLocaleString('id-ID', {
                          dateStyle: 'short',
                          timeStyle: 'short'
                        }) : '-'}
                      </span>
                    </div>
                    {tx.customerPhone && tx.customerPhone !== '-' && (
                      <div className="flex justify-between items-center">
                        <span className="text-slate-400 uppercase tracking-wider text-[8px]">No. Pelanggan</span>
                        <span className="font-extrabold text-slate-800">{tx.customerPhone}</span>
                      </div>
                    )}
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400 uppercase tracking-wider text-[8px]">Kasir</span>
                      <span className="font-bold text-slate-800">{tx.cashierName}</span>
                    </div>
                  </div>

                  <div className="py-4 border-b border-slate-150 space-y-2 text-[10px]">
                    <p className="text-[8px] text-slate-400 font-bold uppercase tracking-wider">Detail Produk</p>
                    {tx.items.map((item: any, itemIdx: number) => (
                      <div key={itemIdx} className="flex justify-between items-start">
                        <div className="min-w-0 pr-2">
                          <p className="font-extrabold text-slate-800 truncate leading-snug">{item.productName}</p>
                          <p className="text-[8px] text-slate-400 font-medium font-mono">
                            Qty: {item.quantity || 1}
                          </p>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="font-extrabold text-slate-800 font-mono">{formatRupiah(item.sellingPrice * item.quantity)}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="py-4 space-y-2 text-[10px] text-slate-600">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400 uppercase tracking-wider text-[8px]">Sistem Server</span>
                      <span className="font-bold text-slate-800 uppercase">
                        {tx.eWalletName || 'Tunai'}
                      </span>
                    </div>
                  </div>

                  <div className="text-center pt-4 border-t border-slate-150 space-y-1">
                    <p className="font-extrabold text-slate-800 tracking-wider text-[9px]">TERIMA KASIH</p>
                    <p className="text-[8px] text-slate-400 font-semibold">MD POS • https://mdcell.my.id</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Modal Controls (Not Printed) */}
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex print:hidden">
              <button
                type="button"
                onClick={() => {
                  setShowBatchReceipt(false);
                  setRecentBatchTransactions([]);
                }}
                className="w-full py-2.5 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold text-center transition-all shadow-sm"
              >
                Selesai
              </button>
            </div>
          </div>
        </div>
      )}

      {showDiscountModal && (() => {
        let selProd = products.find(p => p.id === selectedProductId);
        let qty = physicalQuantity;

        if (discountingCartItemId) {
          const cartItem = physicalCart.find(i => i.productId === discountingCartItemId);
          if (cartItem) {
            selProd = products.find(p => p.id === cartItem.productId);
            qty = cartItem.quantity;
          }
        }

        if (!selProd) return null;

        const originalSubtotal = selProd.sellingPrice * qty;
        const hppSubtotal = selProd.purchasePrice * qty;
        
        let discountAmount = 0;
        if (tempDiscountType === 'nominal') {
          discountAmount = tempDiscountValue;
        } else if (tempDiscountType === 'percent') {
          discountAmount = Math.round((tempDiscountValue / 100) * originalSubtotal);
        }
        
        const finalSubtotal = originalSubtotal - discountAmount;
        const isBelowHPP = finalSubtotal < hppSubtotal;
        const isExceeding = discountAmount > originalSubtotal;
        const isDisabled = isExceeding || (isBelowHPP && !appConfig?.allowLossTransaction);
        
        return (
          <div className="fixed inset-0 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 pb-12 sm:pb-4 z-[200] overflow-y-auto">
            <div className="bg-white dark:bg-slate-900 rounded-[20px] shadow-2xl max-w-md w-full overflow-hidden border border-slate-100 dark:border-slate-800 animate-in fade-in zoom-in-95 duration-200">
              
              {/* Modal Header */}
              <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-rose-50/80 dark:bg-rose-950/40">
                <div className="flex items-center space-x-2">
                  <span className="p-2 bg-rose-100 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 rounded-xl">
                    <Tag className="w-5 h-5" />
                  </span>
                  <div>
                    <h3 className="font-black text-slate-900 dark:text-slate-100 text-sm leading-none">Tambah Diskon Produk</h3>
                    <p className="text-[10px] text-slate-400 dark:text-slate-500 font-medium mt-1">Berikan potongan harga khusus pada barang fisik</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowDiscountModal(false)}
                  className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 rounded-lg transition-all"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              
              {/* Modal Content */}
              <div className="p-5 space-y-4">
                
                {/* 1. Informasi Produk */}
                <div className="p-3.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 rounded-[16px] space-y-2">
                  <p className="text-[9px] text-slate-400 dark:text-slate-500 font-extrabold uppercase tracking-wider">Informasi Produk</p>
                  <div className="grid grid-cols-2 gap-y-1.5 text-xs">
                    <span className="text-slate-500 dark:text-slate-400">Nama Produk:</span>
                    <span className="font-extrabold text-slate-800 dark:text-slate-200 text-right truncate">{selProd.name}</span>
                    
                    <span className="text-slate-500 dark:text-slate-400">Harga Normal:</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200 text-right font-mono">{formatRupiah(selProd.sellingPrice)}</span>
                    
                    <span className="text-slate-500 dark:text-slate-400">Jumlah Beli:</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200 text-right font-mono">{qty}x</span>
                    
                    <span className="text-slate-500 dark:text-slate-400">Subtotal Awal:</span>
                    <span className="font-extrabold text-slate-800 dark:text-slate-200 text-right font-mono">{formatRupiah(originalSubtotal)}</span>
                  </div>
                </div>

                {/* 2. Jenis Diskon */}
                <div>
                  <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider mb-2">
                    Jenis Diskon
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setTempDiscountType('none');
                        setTempDiscountValue(0);
                      }}
                      className={`py-2 px-3 rounded-xl border font-bold text-xs flex flex-col items-center justify-center transition-all ${
                        tempDiscountType === 'none'
                          ? 'bg-slate-100 dark:bg-slate-800 border-slate-400 dark:border-slate-600 text-slate-800 dark:text-slate-100'
                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <span>Tanpa</span>
                      <span className="text-[10px] font-medium text-slate-400 dark:text-slate-500 mt-0.5">Diskon</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setTempDiscountType('nominal');
                        setTempDiscountValue(0);
                      }}
                      className={`py-2 px-3 rounded-xl border font-bold text-xs flex flex-col items-center justify-center transition-all ${
                        tempDiscountType === 'nominal'
                          ? 'bg-rose-50 dark:bg-rose-950/20 border-rose-500 dark:border-rose-700 text-rose-700 dark:text-rose-400 shadow-xs'
                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <span>Nominal</span>
                      <span className="text-[10px] font-medium text-rose-400 mt-0.5">Rupiah (Rp)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setTempDiscountType('percent');
                        setTempDiscountValue(0);
                      }}
                      className={`py-2 px-3 rounded-xl border font-bold text-xs flex flex-col items-center justify-center transition-all ${
                        tempDiscountType === 'percent'
                          ? 'bg-rose-50 dark:bg-rose-950/20 border-rose-500 dark:border-rose-700 text-rose-700 dark:text-rose-400 shadow-xs'
                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <span>Persen</span>
                      <span className="text-[10px] font-medium text-rose-400 mt-0.5">Persentase (%)</span>
                    </button>
                  </div>
                </div>

                {/* 3. Nilai Diskon */}
                {tempDiscountType !== 'none' && (
                  <div className="space-y-1.5 animate-in fade-in duration-200">
                    <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider">
                      {tempDiscountType === 'nominal' ? 'Nominal Diskon (Rp)' : 'Persentase Diskon (%)'}
                    </label>
                    <div className="relative">
                      {tempDiscountType === 'nominal' && (
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <span className="text-slate-400 font-bold text-xs">Rp</span>
                        </div>
                      )}
                      <input
                        type="text"
                        placeholder={tempDiscountType === 'nominal' ? 'Contoh: 5000' : 'Contoh: 10'}
                        value={tempDiscountValue === 0 ? '' : tempDiscountValue}
                        onChange={(e) => {
                          const val = parseInt(e.target.value.replace(/\D/g, ''), 10) || 0;
                          if (tempDiscountType === 'percent' && val > 100) {
                            setTempDiscountValue(100);
                          } else {
                            setTempDiscountValue(val);
                          }
                        }}
                        className={`w-full py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono font-bold focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 focus:bg-white dark:focus:bg-slate-900 text-slate-800 dark:text-slate-100 transition-all ${
                          tempDiscountType === 'nominal' ? 'pl-8' : 'px-3.5'
                        }`}
                      />
                      {tempDiscountType === 'percent' && (
                        <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none">
                          <span className="text-slate-400 font-bold text-xs">%</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* 4. Alasan Diskon */}
                {tempDiscountType !== 'none' && (
                  <div className="space-y-1.5 animate-in fade-in duration-200">
                    <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-wider">
                      Alasan Diskon
                    </label>
                    <select
                      value={tempDiscountReason}
                      onChange={(e) => setTempDiscountReason(e.target.value)}
                      className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 focus:bg-white dark:focus:bg-slate-900 text-slate-800 dark:text-slate-100 transition-all"
                    >
                      <option value="Pelanggan Setia" className="dark:bg-slate-900">Pelanggan Setia</option>
                      <option value="Promo" className="dark:bg-slate-900">Promo</option>
                      <option value="Nego" className="dark:bg-slate-900">Nego</option>
                      <option value="Barang Rusak/Cacat" className="dark:bg-slate-900">Barang Rusak/Cacat</option>
                      <option value="Clearance" className="dark:bg-slate-900">Clearance</option>
                      <option value="Karyawan" className="dark:bg-slate-900">Karyawan</option>
                      <option value="Lainnya" className="dark:bg-slate-900">Lainnya / Manual</option>
                    </select>

                    {tempDiscountReason === 'Lainnya' && (
                      <input
                        type="text"
                        placeholder="Tuliskan alasan pemberian diskon secara manual..."
                        value={tempDiscountCustomReason}
                        onChange={(e) => setTempDiscountCustomReason(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 focus:bg-white dark:focus:bg-slate-900 text-slate-800 dark:text-slate-100 transition-all animate-in fade-in duration-200"
                      />
                    )}
                  </div>
                )}

                {/* 5. Live Calculations & Validation Messages */}
                {tempDiscountType !== 'none' && (
                  <div className="p-3.5 rounded-[16px] bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-xs space-y-2">
                    <p className="text-[9px] text-slate-400 dark:text-slate-500 font-extrabold uppercase tracking-wider">Rincian Perhitungan</p>
                    
                    <div className="flex justify-between">
                      <span className="text-slate-500 dark:text-slate-400">Harga Awal (Subtotal):</span>
                      <span className="font-bold font-mono text-slate-700 dark:text-slate-200">{formatRupiah(originalSubtotal)}</span>
                    </div>

                    <div className="flex justify-between text-rose-600 dark:text-rose-400 font-semibold">
                      <span>Nilai Potongan Diskon:</span>
                      <span className="font-bold font-mono">-{formatRupiah(discountAmount)}</span>
                    </div>

                    <div className="flex justify-between font-extrabold text-slate-800 dark:text-slate-200 pt-1.5 border-t border-slate-200/60 dark:border-slate-700">
                      <span>Harga Setelah Diskon:</span>
                      <span className="font-black font-mono text-emerald-600 dark:text-emerald-400">{formatRupiah(finalSubtotal)}</span>
                    </div>

                    {/* Validations */}
                    {isBelowHPP && (
                      <div className={`p-2.5 rounded-xl border text-[11px] font-medium leading-normal flex items-start space-x-1.5 ${
                        appConfig?.allowLossTransaction 
                          ? 'bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/40 text-amber-800 dark:text-amber-400' 
                          : 'bg-rose-50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/40 text-rose-700 dark:text-rose-400'
                      }`}>
                        <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                        <div>
                          {appConfig?.allowLossTransaction ? (
                            <span>Peringatan: Harga jual setelah diskon berada di bawah batas minimum yang diizinkan. Namun, transaksi diperbolehkan karena diizinkan oleh Admin.</span>
                          ) : (
                            <span>Transaksi ditolak. Harga jual setelah diskon berada di bawah batas minimum yang diizinkan.</span>
                          )}
                        </div>
                      </div>
                    )}

                    {isExceeding && (
                      <div className="p-2.5 rounded-xl border border-rose-200 dark:border-rose-900/40 bg-rose-50 dark:bg-rose-950/20 text-rose-700 dark:text-rose-400 text-[11px] font-medium leading-normal flex items-start space-x-1.5">
                        <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>Diskon tidak boleh lebih besar dari harga produk.</span>
                      </div>
                    )}
                  </div>
                )}

              </div>

              {/* Modal Controls */}
              <div className="p-4 bg-slate-50 dark:bg-slate-800/40 border-t border-slate-100 dark:border-slate-800 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setShowDiscountModal(false)}
                  className="flex-1 py-2.5 px-3 border border-slate-200 dark:border-slate-700 hover:bg-slate-150 dark:hover:bg-slate-800 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 rounded-xl text-xs font-bold transition-all hover:text-slate-800 dark:hover:text-slate-200"
                >
                  Batal
                </button>
                <button
                  type="button"
                  disabled={isDisabled}
                  onClick={() => {
                    if (discountingCartItemId) {
                      setPhysicalCart(prev => prev.map(item => {
                        if (item.productId === discountingCartItemId) {
                          return {
                            ...item,
                            discountType: tempDiscountType,
                            discountValue: tempDiscountValue,
                            discountReason: tempDiscountReason,
                            discountCustomReason: tempDiscountCustomReason
                          };
                        }
                        return item;
                      }));
                    } else {
                      setPhysicalDiscountType(tempDiscountType);
                      setPhysicalDiscountValue(tempDiscountValue);
                      setPhysicalDiscountReason(tempDiscountReason);
                      setPhysicalDiscountCustomReason(tempDiscountCustomReason);
                    }
                    setShowDiscountModal(false);
                  }}
                  className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-bold text-center transition-all shadow-sm text-white ${
                    isDisabled
                      ? 'bg-slate-300 dark:bg-slate-800 text-slate-500 dark:text-slate-600 cursor-not-allowed shadow-none'
                      : 'bg-rose-600 hover:bg-rose-700 active:scale-98'
                  }`}
                >
                  Terapkan Diskon
                </button>
              </div>

            </div>
          </div>
        );
      })()}

      {isCameraScannerOpen && (
        <BarcodeCameraScanner
          isOpen={isCameraScannerOpen}
          onScan={(barcode) => handleScanVoucherBarcode(barcode)}
          onClose={() => setIsCameraScannerOpen(false)}
          title="Scan Barcode Voucher"
          scannedCount={unifiedScannedCount}
        />
      )}

      {isPhysicalCameraScannerOpen && (
        <BarcodeCameraScanner
          isOpen={isPhysicalCameraScannerOpen}
          onScan={(barcode) => handleScanPhysicalBarcode(barcode)}
          onClose={() => setIsPhysicalCameraScannerOpen(false)}
          title="Scan Barcode"
          scannedCount={unifiedScannedCount}
        />
      )}

      {isUnifiedScannerOpen && (
        <BarcodeCameraScanner
          isOpen={isUnifiedScannerOpen}
          onScan={(barcode) => handleUnifiedBarcodeScan(barcode)}
          onClose={() => {
            setIsUnifiedScannerOpen(false);
            setUnifiedScanSuccess('');
            setUnifiedScanError('');
          }}
          title="Scan Barcode & QR POS"
          multiScan={true}
          scannedCount={unifiedScannedCount}
        />
      )}

      {isUnifiedScannerOpen && unifiedScanSuccess && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 bg-emerald-600 text-white font-bold text-xs px-4 py-3 rounded-xl shadow-2xl z-[10000] flex items-center space-x-2 animate-bounce">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-100" />
          <span>{unifiedScanSuccess}</span>
        </div>
      )}

      {isUnifiedScannerOpen && unifiedScanError && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 bg-rose-600 text-white font-bold text-xs px-4 py-3 rounded-xl shadow-2xl z-[10000] flex items-center space-x-2 animate-bounce">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-100" />
          <span>{unifiedScanError}</span>
        </div>
      )}

      {showScanNotFoundDialog && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4 z-[10000] animate-fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[20px] p-6 max-w-sm w-full text-center space-y-6 shadow-2xl">
            <div className="w-16 h-16 bg-red-100 dark:bg-red-950/30 text-red-600 dark:text-red-400 rounded-full flex items-center justify-center mx-auto border border-red-200 dark:border-red-900/30">
              <AlertCircle className="w-8 h-8" />
            </div>
            <div className="space-y-2">
              <h3 className="text-lg font-black text-slate-800 dark:text-slate-100 uppercase tracking-wide">
                {isPhysicalCameraScannerOpen ? 'Produk Tidak Ditemukan' : 'Barcode Tidak Ditemukan'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                {isPhysicalCameraScannerOpen ? (
                  <>
                    Produk dengan barcode <span className="font-mono font-bold text-slate-700 dark:text-slate-300">"{lastScannedNotFoundBarcode}"</span> tidak terdaftar pada Produk Fisik. Silakan daftarkan barcode produk terlebih dahulu atau scan produk lainnya.
                  </>
                ) : (
                  <>
                    Barcode <span className="font-mono font-bold text-slate-700 dark:text-slate-300">"{lastScannedNotFoundBarcode}"</span> tidak terdaftar pada Produk Fisik maupun database Barcode Center.
                  </>
                )}
              </p>
              {!isPhysicalCameraScannerOpen && availableVouchersSample && availableVouchersSample.length > 0 && (
                <div className="mt-4 p-3 bg-slate-50 dark:bg-slate-950/40 rounded-[16px] border border-slate-100 dark:border-slate-800 text-left max-h-40 overflow-y-auto">
                  <p className="text-[10px] font-black uppercase text-indigo-600 dark:text-indigo-400 mb-1.5 flex justify-between">
                    <span>Voucher Tersedia di DB:</span>
                    <span className="text-slate-400 lowercase font-normal">Klik untuk menyalin</span>
                  </p>
                  <ul className="space-y-1 divide-y divide-slate-100 dark:divide-slate-800">
                    {availableVouchersSample.map((v, i) => (
                      <li key={i} className="pt-1 first:pt-0 text-[11px] font-medium text-slate-600 dark:text-slate-300 flex justify-between items-center">
                        <span 
                          onClick={() => {
                            navigator.clipboard.writeText(v.barcode);
                            alert(`Menyalin barcode: ${v.barcode}`);
                          }}
                          className="font-mono bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 px-1 py-0.5 rounded text-[10px] select-all cursor-pointer hover:bg-indigo-100 transition-colors"
                        >
                          {v.barcode}
                        </span>
                        <span className="text-slate-400 text-[10px] text-right truncate max-w-[150px]">
                          {v.name || 'Produk'}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
            <div className="flex flex-col space-y-2.5">
              <button
                id="btn-scan-again"
                onClick={() => {
                  setShowScanNotFoundDialog(false);
                }}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 active:scale-98 text-white font-black text-xs rounded-[16px] transition-all shadow-md shadow-indigo-500/20 cursor-pointer"
              >
                Scan Lagi
              </button>
              {isPhysicalCameraScannerOpen ? (
                <button
                  id="btn-close-scanner"
                  onClick={() => {
                    setShowScanNotFoundDialog(false);
                    setIsPhysicalCameraScannerOpen(false);
                  }}
                  className="w-full py-3 bg-slate-100 hover:bg-slate-200 active:scale-98 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 font-extrabold text-xs rounded-[16px] border border-slate-200 dark:border-slate-700 transition-all cursor-pointer"
                >
                  Tutup
                </button>
              ) : (
                <button
                  id="btn-input-manual"
                  onClick={() => {
                    setShowScanNotFoundDialog(false);
                    setIsUnifiedScannerOpen(false);
                  }}
                  className="w-full py-3 bg-slate-100 hover:bg-slate-200 active:scale-98 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 font-extrabold text-xs rounded-[16px] border border-slate-200 dark:border-slate-700 transition-all cursor-pointer"
                >
                  Input Manual
                </button>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
