import React, { useState, useEffect, useMemo } from 'react';
import { Product, VoucherSerial, VoucherStatus, Role } from '../types';
import { 
  Layers, 
  Search, 
  RefreshCcw, 
  FileSpreadsheet, 
  Printer, 
  Plus, 
  Trash2, 
  History, 
  AlertTriangle, 
  Check, 
  X, 
  Camera, 
  Upload, 
  Save, 
  Package,
  Eye,
  CheckCircle2,
  AlertCircle,
  QrCode,
  Lock,
  Clock,
  BookOpen,
  ArrowRight,
  Database
} from 'lucide-react';
import BarcodeCameraScanner from './BarcodeCameraScanner';
import * as XLSX from 'xlsx';

interface BarcodeCenterProps {
  products: Product[];
  currentUserRole: Role;
  onEditProduct?: (id: string, updatedProduct: Partial<Product>) => void;
  onRefreshProducts?: () => void;
  initialProductIdFilter?: string | null;
  onClearProductIdFilter?: () => void;
  currentShift?: any;
}

export default function BarcodeCenter({ 
  products, 
  currentUserRole, 
  onEditProduct,
  onRefreshProducts,
  initialProductIdFilter,
  onClearProductIdFilter,
  currentShift
}: BarcodeCenterProps) {
  const isAdmin = currentUserRole === 'admin';
  const [vouchers, setVouchers] = useState<(VoucherSerial & { productName?: string; sellingPrice?: number })[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Selected Product context
  const [selectedProductId, setSelectedProductId] = useState<string>('');

  // Search & Filters state (scoped to the selected product)
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Success / Error Alerts
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Add Barcode Panel and Tabs
  const [isAddPanelOpen, setIsAddPanelOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'manual' | 'paste' | 'excel' | 'camera'>('manual');

  // Form Fields: Manual
  const [manualBarcode, setManualBarcode] = useState('');
  const [manualSerial, setManualSerial] = useState('');
  const [manualExpiry, setManualExpiry] = useState('');
  const [manualSupplier, setManualSupplier] = useState('');
  const [manualPurchasePrice, setManualPurchasePrice] = useState<number>(0);
  const [manualNotes, setManualNotes] = useState('');

  // Form Fields: Paste
  const [pasteText, setPasteText] = useState('');
  const [pasteExpiry, setPasteExpiry] = useState('');
  const [pasteSupplier, setPasteSupplier] = useState('');
  const [pastePurchasePrice, setPastePurchasePrice] = useState<number>(0);

  // Form Fields: Excel
  const [excelRows, setExcelRows] = useState<any[]>([]);

  // Form Fields: Camera Scan
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [scannedCodes, setScannedCodes] = useState<string[]>([]);
  const [scanExpiry, setScanExpiry] = useState('');
  const [scanSupplier, setScanSupplier] = useState('');
  const [scanPurchasePrice, setScanPurchasePrice] = useState<number>(0);

  // Expanded Row for logs/history
  const [expandedHistoryId, setExpandedHistoryId] = useState<string | null>(null);

  // Row Delete Confirm Inline ID
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // New states for Mobile Banking UI Redesign
  const [currentSection, setCurrentSection] = useState<'scan-dashboard' | 'barcode-center'>('scan-dashboard');
  const [lastScannedItem, setLastScannedItem] = useState<{
    barcode: string;
    productName: string;
    time: string;
    status: 'SUCCESS' | 'FAILED';
    errorMsg?: string;
  } | null>(null);

  // Sync initial filter from products screen
  useEffect(() => {
    if (initialProductIdFilter) {
      setSelectedProductId(initialProductIdFilter);
      setIsAddPanelOpen(true);
    } else if (products.length > 0 && !selectedProductId) {
      // Default to first multi-barcode product if any, otherwise first product
      const firstMassal = products.find(p => p.barcodeType === 'massal');
      if (firstMassal) {
        setSelectedProductId(firstMassal.id);
      } else {
        setSelectedProductId(products[0].id);
      }
    }
  }, [initialProductIdFilter, products]);

  // Autofill form inputs based on the selected product
  useEffect(() => {
    if (selectedProductId) {
      const selectedProduct = products.find(p => p.id === selectedProductId);
      if (selectedProduct) {
        setManualPurchasePrice(selectedProduct.purchasePrice || 0);
        setManualSupplier(selectedProduct.operator || '');
        
        setPastePurchasePrice(selectedProduct.purchasePrice || 0);
        setPasteSupplier(selectedProduct.operator || '');
        
        setScanPurchasePrice(selectedProduct.purchasePrice || 0);
        setScanSupplier(selectedProduct.operator || '');
      }
    }
  }, [selectedProductId, products]);

  // Fetch vouchers from server
  const loadVouchers = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/vouchers');
      if (res.ok) {
        const data = await res.json();
        setVouchers(data);
      } else {
        setErrorMsg('Gagal memuat data dari database.');
      }
    } catch (err) {
      setErrorMsg('Kesalahan jaringan saat memuat data barcode.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadVouchers();
  }, []);

  const showAlert = (type: 'success' | 'error', message: string) => {
    if (type === 'success') {
      setSuccessMsg(message);
      setErrorMsg('');
      setTimeout(() => setSuccessMsg(''), 4000);
    } else {
      setErrorMsg(message);
      setSuccessMsg('');
      setTimeout(() => setErrorMsg(''), 5000);
    }
  };

  const cleanScannedCode = (input: string): string => {
    const cleanedInput = input.replace(/[^\x20-\x7E]/g, '').trim();
    if (!cleanedInput) return '';
    if (cleanedInput.startsWith('http://') || cleanedInput.startsWith('https://')) {
      try {
        const url = new URL(cleanedInput);
        const params = ['code', 'id', 'sn', 'barcode', 'serial', 'v', 'k', 'sn_voucher'];
        for (const p of params) {
          const val = url.searchParams.get(p);
          if (val) return val.trim();
        }
        const segments = url.pathname.split('/').filter(Boolean);
        if (segments.length > 0) return segments[segments.length - 1].trim();
      } catch (e) {}
    }
    return cleanedInput.replace(/^["'\[\(]+|["'\]\)]+$/g, '');
  };

  // Instant status update
  const handleStatusChange = async (id: string, nextStatus: VoucherStatus) => {
    try {
      const res = await fetch(`/api/vouchers/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: nextStatus })
      });
      if (res.ok) {
        showAlert('success', `Status barcode berhasil diubah menjadi ${nextStatus}.`);
        loadVouchers();
        if (onRefreshProducts) onRefreshProducts();
      } else {
        showAlert('error', 'Gagal memperbarui status barcode.');
      }
    } catch (err) {
      showAlert('error', 'Kesalahan jaringan saat mengubah status.');
    }
  };

  // Delete Voucher
  const handleDeleteVoucher = async (id: string) => {
    try {
      const res = await fetch(`/api/vouchers/${id}`, { method: 'DELETE' });
      if (res.ok) {
        showAlert('success', 'Barcode berhasil dihapus secara permanen.');
        setDeletingId(null);
        loadVouchers();
        if (onRefreshProducts) onRefreshProducts();
      } else {
        showAlert('error', 'Gagal menghapus barcode.');
      }
    } catch (err) {
      showAlert('error', 'Kesalahan jaringan saat menghapus barcode.');
    }
  };

  // Submit Mass Barcodes
  const submitVouchers = async (items: any[]) => {
    if (items.length === 0) {
      showAlert('error', 'Tidak ada barcode valid untuk disimpan.');
      return;
    }
    try {
      const res = await fetch('/api/vouchers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(items)
      });
      const data = await res.json();
      if (res.ok) {
        showAlert('success', `Berhasil menyimpan ${items.length} barcode untuk produk ini.`);
        loadVouchers();
        if (onRefreshProducts) onRefreshProducts();
        
        // Reset states
        setManualBarcode('');
        setManualSerial('');
        setManualNotes('');
        setPasteText('');
        setExcelRows([]);
        setScannedCodes([]);
        setIsAddPanelOpen(false);
      } else {
        showAlert('error', data.error || 'Gagal menyimpan barcode.');
      }
    } catch (err) {
      showAlert('error', 'Terjadi kesalahan jaringan.');
    }
  };

  // MANUAL TAB SUBMIT
  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductId) {
      showAlert('error', 'Silakan pilih produk terlebih dahulu!');
      return;
    }
    if (!manualBarcode.trim()) {
      showAlert('error', 'Kode barcode tidak boleh kosong!');
      return;
    }
    const item = {
      productId: selectedProductId,
      barcode: cleanScannedCode(manualBarcode),
      serialNumber: manualSerial.trim() || null,
      expiredDate: manualExpiry || null,
      supplier: manualSupplier.trim() || 'Manual Input',
      purchasePrice: Number(manualPurchasePrice || 0),
      notes: manualNotes.trim() || 'Diinput manual via Barcode Center'
    };
    submitVouchers([item]);
  };

  // PASTE TAB SUBMIT
  const handlePasteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductId) {
      showAlert('error', 'Silakan pilih produk terlebih dahulu!');
      return;
    }
    if (!pasteText.trim()) {
      showAlert('error', 'Tempel teks barcode terlebih dahulu!');
      return;
    }

    const lines = pasteText.split('\n').filter(l => l.trim().length > 0);
    const items = lines.map(line => {
      const parts = line.split(/[,\t;]/);
      const barcodeRaw = parts[0] || '';
      const serialRaw = parts[1] || '';
      const expiryRaw = parts[2] || '';

      return {
        productId: selectedProductId,
        barcode: cleanScannedCode(barcodeRaw),
        serialNumber: serialRaw.trim() || null,
        expiredDate: expiryRaw.trim() || pasteExpiry || null,
        supplier: pasteSupplier.trim() || 'Paste Input',
        purchasePrice: Number(pastePurchasePrice || 0),
        notes: 'Ditempel via Barcode Center'
      };
    }).filter(it => it.barcode.length > 0);

    submitVouchers(items);
  };

  // EXCEL FILE READER
  const handleExcelUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const bstr = event.target?.result;
        const workbook = XLSX.read(bstr, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const rawJson: any[] = XLSX.utils.sheet_to_json(worksheet);

        const mapped = rawJson.map(row => {
          const bVal = row.barcode || row.Barcode || row['Barcode/Serial'] || row['barcode_code'] || '';
          const sVal = row.serial_number || row.serial || row['Serial'] || row['SerialNumber'] || '';
          const expVal = row.expired_date || row.expired || row['Expired'] || row['expiredDate'] || '';
          const supVal = row.supplier || row.Supplier || '';
          const pPrice = row.purchase_price || row.purchasePrice || row['Harga Beli'] || 0;
          const notesVal = row.notes || row.Notes || '';

          return {
            barcode: cleanScannedCode(String(bVal)),
            serialNumber: sVal ? String(sVal).trim() : null,
            expiredDate: expVal ? String(expVal).trim() : null,
            supplier: supVal ? String(supVal).trim() : '',
            purchasePrice: Number(pPrice),
            notes: notesVal ? String(notesVal).trim() : ''
          };
        }).filter(r => r.barcode.length > 0);

        if (mapped.length === 0) {
          showAlert('error', 'Tidak ditemukan kode barcode yang valid di file Excel.');
        } else {
          setExcelRows(mapped);
          showAlert('success', `Berhasil memuat ${mapped.length} baris dari file Excel.`);
        }
      } catch (err) {
        showAlert('error', 'Gagal memproses file Excel.');
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleExcelSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductId) {
      showAlert('error', 'Pilih produk terlebih dahulu!');
      return;
    }
    if (excelRows.length === 0) {
      showAlert('error', 'Silakan unggah file Excel terlebih dahulu!');
      return;
    }

    const items = excelRows.map(row => ({
      ...row,
      productId: selectedProductId,
      supplier: row.supplier || 'Excel Import',
      notes: row.notes || 'Diimpor via Excel'
    }));

    submitVouchers(items);
  };

  // CAMERA SCAN BARCODE
  const handleCameraScanSuccess = (code: string) => {
    const clean = cleanScannedCode(code);
    if (clean) {
      if (!scannedCodes.includes(clean)) {
        setScannedCodes(prev => [...prev, clean]);
      }
      setLastScannedItem({
        barcode: clean,
        productName: selectedProduct ? selectedProduct.name : 'Voucher / Produk Massal',
        time: new Date().toLocaleTimeString('id-ID'),
        status: 'SUCCESS'
      });
    }
  };

  const handleCameraSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductId) {
      showAlert('error', 'Pilih produk terlebih dahulu!');
      return;
    }
    if (scannedCodes.length === 0) {
      showAlert('error', 'Belum ada barcode yang terpindai!');
      return;
    }

    const items = scannedCodes.map(code => ({
      productId: selectedProductId,
      barcode: code,
      expiredDate: scanExpiry || null,
      supplier: scanSupplier.trim() || 'Camera Scan',
      purchasePrice: Number(scanPurchasePrice || 0),
      notes: 'Dipindai langsung via kamera'
    }));

    submitVouchers(items);
  };

  // EXPORT CURRENT LIST TO CSV
  const handleExportCSV = () => {
    if (productFilteredVouchers.length === 0) {
      alert('Tidak ada data barcode untuk diexport.');
      return;
    }
    const headers = ['ID,Barcode,Serial Number,Supplier,Harga Modal,Status,Expired,Notes'];
    const rows = productFilteredVouchers.map(v => [
      v.id,
      `"${v.barcode}"`,
      v.serialNumber ? `"${v.serialNumber}"` : '""',
      `"${v.supplier || '-'}"`,
      v.purchasePrice,
      v.status,
      v.expiredDate || '-',
      `"${v.notes || '-'}"`
    ].join(','));
    const csvContent = "data:text/csv;charset=utf-8," + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    const selectedProd = products.find(p => p.id === selectedProductId);
    const prodNameClean = selectedProd ? selectedProd.name.replace(/[^a-zA-Z0-9]/g, '_') : 'Product';
    link.setAttribute("download", `BARCODE_${prodNameClean}_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // PRINT CURRENT FILTERED LIST TO PDF
  const handlePrintPDF = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const selectedProd = products.find(p => p.id === selectedProductId);

    const tableRows = productFilteredVouchers.map(v => `
      <tr>
        <td style="padding: 8px; border-bottom: 1px solid #ddd; font-family: monospace;">${v.barcode}</td>
        <td style="padding: 8px; border-bottom: 1px solid #ddd; font-family: monospace;">${v.serialNumber || '-'}</td>
        <td style="padding: 8px; border-bottom: 1px solid #ddd;">${v.supplier || '-'}</td>
        <td style="padding: 8px; border-bottom: 1px solid #ddd; text-align: right;">Rp ${(v.purchasePrice || 0).toLocaleString('id-ID')}</td>
        <td style="padding: 8px; border-bottom: 1px solid #ddd; text-align: center; font-weight: bold;">${v.status}</td>
        <td style="padding: 8px; border-bottom: 1px solid #ddd; text-align: center;">${v.expiredDate || '-'}</td>
      </tr>
    `).join('');

    printWindow.document.write(`
      <html>
        <head>
          <title>Laporan Barcode - ${selectedProd ? selectedProd.name : 'Produk'}</title>
          <style>
            body { font-family: sans-serif; margin: 40px; color: #333; }
            h2 { text-align: center; margin-bottom: 5px; text-transform: uppercase; }
            h3 { text-align: center; font-weight: normal; margin-top: 0; color: #666; }
            p { text-align: center; font-size: 11px; color: #888; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 11px; }
            th { background-color: #f5f5f5; padding: 10px; border-bottom: 2px solid #ddd; text-align: left; }
          </style>
        </head>
        <body>
          <h2>Laporan Kode Barcode Produk</h2>
          <h3>Produk: ${selectedProd ? selectedProd.name : '-'}</h3>
          <p>Dicetak pada: ${new Date().toLocaleString('id-ID')}</p>
          <table>
            <thead>
              <tr>
                <th>Kode Barcode</th>
                <th>No. Seri (SN)</th>
                <th>Supplier</th>
                <th style="text-align: right;">Harga Modal</th>
                <th style="text-align: center;">Status</th>
                <th style="text-align: center;">Kadaluarsa</th>
              </tr>
            </thead>
            <tbody>
              ${tableRows}
            </tbody>
          </table>
          <script>window.onload = function() { window.print(); window.close(); }</script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  // Selected Product details helper
  const selectedProduct = useMemo(() => {
    return products.find(p => p.id === selectedProductId) || null;
  }, [products, selectedProductId]);

  // Vouchers strictly filtered for the selected product
  const productVouchers = useMemo(() => {
    return vouchers.filter(v => v.productId === selectedProductId);
  }, [vouchers, selectedProductId]);

  // Stats summaries specifically for the selected product
  const productStats = useMemo(() => {
    const total = productVouchers.length;
    const ready = productVouchers.filter(v => v.status === 'READY').length;
    const sold = productVouchers.filter(v => v.status === 'SOLD').length;
    const returned = productVouchers.filter(v => v.status === 'RETURNED').length;
    const damaged = productVouchers.filter(v => v.status === 'DAMAGED').length;
    const expired = productVouchers.filter(v => v.status === 'EXPIRED').length;

    return { total, ready, sold, returned, damaged, expired };
  }, [productVouchers]);

  // Scoped search and status filtering
  const productFilteredVouchers = useMemo(() => {
    return productVouchers.filter(v => {
      // Search
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = !q || 
        v.barcode.toLowerCase().includes(q) || 
        (v.serialNumber && v.serialNumber.toLowerCase().includes(q)) || 
        (v.supplier && v.supplier.toLowerCase().includes(q)) ||
        (v.notes && v.notes.toLowerCase().includes(q));

      if (!matchesSearch) return false;

      // Status
      if (statusFilter !== 'ALL' && v.status !== statusFilter) return false;

      return true;
    });
  }, [productVouchers, searchQuery, statusFilter]);

  const isShiftOpen = !!currentShift;

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 bg-slate-50 min-h-screen">
      
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-xl lg:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Layers className="w-6 h-6 text-primary shrink-0" />
            Pusat Barcode &amp; Serial
          </h1>
          <p className="text-slate-500 text-xs mt-0.5">
            Pusat pengelolaan dan pencatatan barcode/serial untuk masing-masing tipe produk jualan.
          </p>
        </div>
        
        {/* CLEAR BACK NAVIGATION TO PRODUCT LIST */}
        {initialProductIdFilter && onClearProductIdFilter && (
          <button
            onClick={() => {
              onClearProductIdFilter();
            }}
            className="self-start md:self-auto px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-xl border border-slate-200 transition-colors shadow-2xs"
          >
            &larr; Kembali ke Daftar Produk
          </button>
        )}
      </div>

      {/* ALERT NOTIFICATIONS */}
      {successMsg && (
        <div className="mb-4 bg-emerald-50 border border-emerald-200 text-emerald-800 p-3.5 rounded-xl text-xs flex items-center space-x-2 animate-in fade-in duration-200">
          <CheckCircle2 className="w-4.5 h-4.5 text-emerald-600 shrink-0" />
          <span className="font-semibold">{successMsg}</span>
        </div>
      )}
      {errorMsg && (
        <div className="mb-4 bg-rose-50 border border-rose-200 text-rose-800 p-3.5 rounded-xl text-xs flex items-center space-x-2 animate-in fade-in duration-200">
          <AlertCircle className="w-4.5 h-4.5 text-rose-600 shrink-0" />
          <span className="font-semibold">{errorMsg}</span>
        </div>
      )}


          {/* STEP 1: PRODUCT SELECTION HEADER BAR (The Default Filter Enforcer) */}
          <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-white rounded-[20px] p-5 mb-6 shadow-lg relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-5">
          <Layers className="w-40 h-40" />
        </div>
        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-3 gap-6 items-center">
          
          {/* Dropdown selector */}
          <div className="lg:col-span-1">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">
              Silakan Pilih Produk:
            </label>
            <select
              value={selectedProductId}
              onChange={(e) => {
                setSelectedProductId(e.target.value);
                setSearchQuery('');
                setStatusFilter('ALL');
              }}
              className="w-full text-xs font-black px-4 py-3 bg-slate-800 border border-slate-700 rounded-[16px] outline-none focus:border-emerald-500 text-white transition-all cursor-pointer shadow-inner"
            >
              <option value="" disabled>-- Pilih Produk Jualan --</option>
              {products.map(p => (
                <option key={p.id} value={p.id} className="text-slate-900 font-bold">
                  [{p.barcodeType === 'massal' ? 'Multi' : 'Single'}] {p.name}
                </option>
              ))}
            </select>
          </div>

          {/* Current product details */}
          <div className="lg:col-span-2">
            {selectedProduct ? (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 animate-in fade-in duration-200">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-black tracking-tight text-white line-clamp-1">{selectedProduct.name}</h2>
                    <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-md ${selectedProduct.barcodeType === 'massal' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-indigo-500/20 text-indigo-400'}`}>
                      {selectedProduct.barcodeType === 'massal' ? 'Multi Barcode' : 'Single Barcode'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1 line-clamp-1">
                    Kategori: <span className="font-extrabold uppercase text-white">{selectedProduct.category}</span> &bull; Operator: <span className="font-extrabold text-white">{selectedProduct.operator}</span>
                  </p>
                </div>

                <div className="flex flex-wrap gap-1.5 shrink-0">
                  <button
                    onClick={() => setIsAddPanelOpen(!isAddPanelOpen)}
                    className="flex items-center space-x-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-sm transition-all"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Tambah Barcode</span>
                  </button>
                  <button
                    onClick={loadVouchers}
                    className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl border border-slate-700 transition-colors"
                    title="Refresh Data"
                  >
                    <RefreshCcw className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-400 font-bold">
                Silakan pilih salah satu produk dari menu dropdown untuk mengelola kode barcode atau nomor seri voucher.
              </p>
            )}
          </div>

        </div>
      </div>

      {/* ALERTS */}
      {successMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl mb-6 flex items-center space-x-2 animate-in slide-in-from-top-2">
          <Check className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}
      {errorMsg && (
        <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold rounded-xl mb-6 flex items-center space-x-2 animate-in slide-in-from-top-2">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {selectedProduct ? (
        <>
          {/* STATS WIDGET FOR SELECTED PRODUCT */}
          <div className="grid grid-cols-2 lg:grid-cols-6 gap-3 mb-6">
            <div className="bg-white p-3 rounded-[16px] border border-slate-200 flex items-center justify-between">
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Barcode</p>
                <p className="text-lg font-black text-slate-900 font-mono mt-0.5">{productStats.total}</p>
              </div>
              <div className="p-2 bg-slate-50 text-slate-500 rounded-lg"><Layers className="w-4 h-4" /></div>
            </div>
            <div className="bg-white p-3 rounded-[16px] border border-slate-200 flex items-center justify-between">
              <div>
                <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider">READY</p>
                <p className="text-lg font-black text-emerald-700 font-mono mt-0.5">{productStats.ready}</p>
              </div>
              <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg"><Check className="w-4 h-4" /></div>
            </div>
            <div className="bg-white p-3 rounded-[16px] border border-slate-200 flex items-center justify-between">
              <div>
                <p className="text-[10px] font-bold text-blue-600 uppercase tracking-wider">SOLD</p>
                <p className="text-lg font-black text-blue-700 font-mono mt-0.5">{productStats.sold}</p>
              </div>
              <div className="p-2 bg-blue-50 text-blue-600 rounded-lg"><CheckCircle2 className="w-4 h-4" /></div>
            </div>
            <div className="bg-white p-3 rounded-[16px] border border-slate-200 flex items-center justify-between">
              <div>
                <p className="text-[10px] font-bold text-orange-600 uppercase tracking-wider">RETUR</p>
                <p className="text-lg font-black text-orange-700 font-mono mt-0.5">{productStats.returned}</p>
              </div>
              <div className="p-2 bg-orange-50 text-orange-600 rounded-lg"><RefreshCcw className="w-4 h-4" /></div>
            </div>
            <div className="bg-white p-3 rounded-[16px] border border-slate-200 flex items-center justify-between">
              <div>
                <p className="text-[10px] font-bold text-rose-600 uppercase tracking-wider">RUSAK</p>
                <p className="text-lg font-black text-rose-700 font-mono mt-0.5">{productStats.damaged}</p>
              </div>
              <div className="p-2 bg-rose-50 text-rose-600 rounded-lg"><AlertTriangle className="w-4 h-4" /></div>
            </div>
            <div className="bg-white p-3 rounded-[16px] border border-slate-200 flex items-center justify-between">
              <div>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">EXPIRED</p>
                <p className="text-lg font-black text-slate-800 font-mono mt-0.5">{productStats.expired}</p>
              </div>
              <div className="p-2 bg-slate-100 text-slate-500 rounded-lg"><X className="w-4 h-4" /></div>
            </div>
          </div>

          {/* ADD BARCODE / IMPORT PANEL FOR THE SELECTED PRODUCT */}
          {isAddPanelOpen && (
            <div className="bg-white rounded-[20px] border border-slate-200 p-4 lg:p-6 mb-6 shadow-sm animate-in zoom-in-95 duration-200">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                <h3 className="text-xs font-black text-slate-900 tracking-wider uppercase flex items-center gap-1.5">
                  <Plus className="w-4.5 h-4.5 text-emerald-600" />
                  Tambah Barcode Untuk: {selectedProduct.name}
                </h3>
                <button
                  onClick={() => setIsAddPanelOpen(false)}
                  className="text-slate-400 hover:text-slate-600 text-xs font-bold"
                >
                  Sembunyikan
                </button>
              </div>

              {/* TABS INTERFACE */}
              <div className="flex border-b border-slate-200 mb-5 overflow-x-auto">
                <button
                  onClick={() => setActiveTab('manual')}
                  className={`px-4 py-2 text-xs font-extrabold uppercase tracking-wider border-b-2 transition-all whitespace-nowrap ${
                    activeTab === 'manual' 
                      ? 'border-emerald-600 text-emerald-600' 
                      : 'border-transparent text-slate-400 hover:text-slate-600'
                  }`}
                >
                  Input Manual
                </button>
                <button
                  onClick={() => setActiveTab('paste')}
                  className={`px-4 py-2 text-xs font-extrabold uppercase tracking-wider border-b-2 transition-all whitespace-nowrap ${
                    activeTab === 'paste' 
                      ? 'border-emerald-600 text-emerald-600' 
                      : 'border-transparent text-slate-400 hover:text-slate-600'
                  }`}
                >
                  Paste Teks
                </button>
                <button
                  onClick={() => setActiveTab('excel')}
                  className={`px-4 py-2 text-xs font-extrabold uppercase tracking-wider border-b-2 transition-all whitespace-nowrap ${
                    activeTab === 'excel' 
                      ? 'border-emerald-600 text-emerald-600' 
                      : 'border-transparent text-slate-400 hover:text-slate-600'
                  }`}
                >
                  Unggah Excel
                </button>
                <button
                  onClick={() => setActiveTab('camera')}
                  className={`px-4 py-2 text-xs font-extrabold uppercase tracking-wider border-b-2 transition-all whitespace-nowrap ${
                    activeTab === 'camera' 
                      ? 'border-emerald-600 text-emerald-600' 
                      : 'border-transparent text-slate-400 hover:text-slate-600'
                  }`}
                >
                  Pindai Kamera
                </button>
              </div>

              {/* TAB CONTENT: MANUAL */}
              {activeTab === 'manual' && (
                <form onSubmit={handleManualSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Kode Barcode *</label>
                    <input
                      type="text"
                      placeholder="Scan atau ketik barcode..."
                      value={manualBarcode}
                      onChange={(e) => setManualBarcode(e.target.value)}
                      className="w-full text-xs font-semibold px-3 py-2 border border-slate-200 rounded-lg outline-none focus:border-emerald-500 font-mono"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Nomor Seri SN (Optional)</label>
                    <input
                      type="text"
                      placeholder="Contoh: SN-120045"
                      value={manualSerial}
                      onChange={(e) => setManualSerial(e.target.value)}
                      className="w-full text-xs font-semibold px-3 py-2 border border-slate-200 rounded-lg outline-none focus:border-emerald-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Tanggal Kadaluarsa (Optional)</label>
                    <input
                      type="date"
                      value={manualExpiry}
                      onChange={(e) => setManualExpiry(e.target.value)}
                      className="w-full text-xs font-semibold px-3 py-2 border border-slate-200 rounded-lg outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Supplier</label>
                    <input
                      type="text"
                      placeholder="Contoh: Tri Mandiri"
                      value={manualSupplier}
                      onChange={(e) => setManualSupplier(e.target.value)}
                      className="w-full text-xs font-semibold px-3 py-2 border border-slate-200 rounded-lg outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Harga Modal (Rp)</label>
                    <input
                      type="number"
                      placeholder="0"
                      value={manualPurchasePrice || ''}
                      onChange={(e) => setManualPurchasePrice(Number(e.target.value))}
                      className="w-full text-xs font-semibold px-3 py-2 border border-slate-200 rounded-lg outline-none focus:border-emerald-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Catatan Tambahan (Optional)</label>
                    <input
                      type="text"
                      placeholder="Contoh: Voucher Fisik 5GB"
                      value={manualNotes}
                      onChange={(e) => setManualNotes(e.target.value)}
                      className="w-full text-xs font-semibold px-3 py-2 border border-slate-200 rounded-lg outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div className="md:col-span-2 lg:col-span-3 flex justify-end mt-2">
                    <button
                      type="submit"
                      className="flex items-center space-x-1 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl transition-all shadow-sm cursor-pointer"
                    >
                      <Save className="w-4 h-4" />
                      <span>Simpan Barcode</span>
                    </button>
                  </div>
                </form>
              )}

              {/* TAB CONTENT: PASTE */}
              {activeTab === 'paste' && (
                <form onSubmit={handlePasteSubmit} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                      Tempel Barcode Anda (Satu Barcode per Baris)
                    </label>
                    <p className="text-[10px] text-slate-400 mb-1">
                      Format: <code className="bg-slate-100 px-1 py-0.5 rounded text-rose-600">kode_barcode, no_seri(optional), expired(optional YYYY-MM-DD)</code>
                    </p>
                    <textarea
                      placeholder="9234812379&#10;8934789123,SN90012,2026-12-31&#10;1200389123,SN90013"
                      rows={5}
                      value={pasteText}
                      onChange={(e) => setPasteText(e.target.value)}
                      className="w-full text-xs font-mono px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-emerald-500"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Expired Global</label>
                      <input
                        type="date"
                        value={pasteExpiry}
                        onChange={(e) => setPasteExpiry(e.target.value)}
                        className="w-full text-xs font-semibold px-3 py-2 border border-slate-200 rounded-lg outline-none focus:border-emerald-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Supplier Global</label>
                      <input
                        type="text"
                        placeholder="Nama Supplier"
                        value={pasteSupplier}
                        onChange={(e) => setPasteSupplier(e.target.value)}
                        className="w-full text-xs font-semibold px-3 py-2 border border-slate-200 rounded-lg outline-none focus:border-emerald-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Modal Global</label>
                      <input
                        type="number"
                        placeholder="Harga Modal"
                        value={pastePurchasePrice || ''}
                        onChange={(e) => setPastePurchasePrice(Number(e.target.value))}
                        className="w-full text-xs font-semibold px-3 py-2 border border-slate-200 rounded-lg outline-none focus:border-emerald-500 font-mono"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end mt-2">
                    <button
                      type="submit"
                      className="flex items-center space-x-1 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl transition-all shadow-sm cursor-pointer"
                    >
                      <Save className="w-4 h-4" />
                      <span>Simpan Semua Barcode</span>
                    </button>
                  </div>
                </form>
              )}

              {/* TAB CONTENT: EXCEL */}
              {activeTab === 'excel' && (
                <form onSubmit={handleExcelSubmit} className="space-y-4">
                  <div className="border-2 border-dashed border-slate-200 rounded-[16px] p-6 text-center hover:border-emerald-500 transition-colors relative bg-slate-50">
                    <input
                      type="file"
                      accept=".xlsx, .xls, .csv"
                      onChange={handleExcelUpload}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                    <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                    <p className="text-xs font-bold text-slate-700">Pilih atau Seret File Excel/CSV di Sini</p>
                    <p className="text-[10px] text-slate-400 mt-1 uppercase">Mendukung file XLSX, XLS, CSV</p>
                    <p className="text-[9px] text-slate-400 mt-0.5">Kolom yang dibaca: barcode, serial_number, expired_date, supplier, purchase_price, notes</p>
                  </div>

                  {excelRows.length > 0 && (
                    <div className="bg-slate-50 p-3 rounded-[16px] border border-slate-100">
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wide mb-2">Pratinjau {excelRows.length} Baris Pertama</p>
                      <div className="overflow-x-auto max-h-48 overflow-y-auto">
                        <table className="w-full text-left text-[10px] font-mono border-collapse">
                          <thead>
                            <tr className="border-b border-slate-200 text-slate-400">
                              <th className="py-1 px-2">Barcode</th>
                              <th className="py-1 px-2">No Seri</th>
                              <th className="py-1 px-2">Expired</th>
                              <th className="py-1 px-2 text-right">Modal</th>
                            </tr>
                          </thead>
                          <tbody>
                            {excelRows.slice(0, 5).map((row, idx) => (
                              <tr key={idx} className="border-b border-slate-100 text-slate-600">
                                <td className="py-1 px-2">{row.barcode}</td>
                                <td className="py-1 px-2">{row.serialNumber || '-'}</td>
                                <td className="py-1 px-2">{row.expiredDate || '-'}</td>
                                <td className="py-1 px-2 text-right">Rp {(row.purchasePrice || 0).toLocaleString('id-ID')}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  <div className="flex justify-end mt-2">
                    <button
                      type="submit"
                      disabled={excelRows.length === 0}
                      className={`flex items-center space-x-1 px-5 py-2.5 text-white font-extrabold text-xs rounded-xl transition-all shadow-sm cursor-pointer ${
                        excelRows.length === 0 ? 'bg-slate-300 cursor-not-allowed' : 'bg-emerald-600 hover:bg-emerald-700'
                      }`}
                    >
                      <Save className="w-4 h-4" />
                      <span>Simpan Semua Barcode Excel</span>
                    </button>
                  </div>
                </form>
              )}

              {/* TAB CONTENT: CAMERA */}
              {activeTab === 'camera' && (
                <form onSubmit={handleCameraSubmit} className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-[16px] border border-slate-100">
                    <div>
                      <p className="text-xs font-bold text-slate-700">Pindai Beruntun Menggunakan Kamera</p>
                      <p className="text-[10px] text-slate-400 mt-0.5">Sistem akan menyimpan daftar barcode yang sukses di-beep secara berurutan.</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsScannerOpen(true)}
                      className="flex items-center space-x-1 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition-all cursor-pointer"
                    >
                      <Camera className="w-4 h-4 text-emerald-400" />
                      <span>Buka Kamera Scan</span>
                    </button>
                  </div>

                  {scannedCodes.length > 0 && (
                    <div className="bg-slate-50 p-3 rounded-[16px] border border-slate-100">
                      <div className="flex items-center justify-between mb-2">
                        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">
                          Berhasil Dipindai ({scannedCodes.length} Barcode)
                        </p>
                        <button
                          type="button"
                          onClick={() => setScannedCodes([])}
                          className="text-[10px] text-rose-600 hover:underline font-bold"
                        >
                          Reset Hasil Scan
                        </button>
                      </div>
                      <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto p-1 bg-white border border-slate-100 rounded-lg">
                        {scannedCodes.map((code, idx) => (
                          <span key={idx} className="inline-flex items-center gap-1 text-[10px] font-mono font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md border border-slate-200">
                            <span>{code}</span>
                            <button type="button" onClick={() => setScannedCodes(prev => prev.filter(c => c !== code))} className="text-slate-400 hover:text-slate-600">×</button>
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Kadaluarsa Global</label>
                      <input
                        type="date"
                        value={scanExpiry}
                        onChange={(e) => setScanExpiry(e.target.value)}
                        className="w-full text-xs font-semibold px-3 py-2 border border-slate-200 rounded-lg outline-none focus:border-emerald-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Supplier Global</label>
                      <input
                        type="text"
                        placeholder="Nama Supplier"
                        value={scanSupplier}
                        onChange={(e) => setScanSupplier(e.target.value)}
                        className="w-full text-xs font-semibold px-3 py-2 border border-slate-200 rounded-lg outline-none focus:border-emerald-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Harga Modal Global</label>
                      <input
                        type="number"
                        placeholder="Harga Modal"
                        value={scanPurchasePrice || ''}
                        onChange={(e) => setScanPurchasePrice(Number(e.target.value))}
                        className="w-full text-xs font-semibold px-3 py-2 border border-slate-200 rounded-lg outline-none focus:border-emerald-500 font-mono"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end mt-2">
                    <button
                      type="submit"
                      disabled={scannedCodes.length === 0}
                      className={`flex items-center space-x-1 px-5 py-2.5 text-white font-extrabold text-xs rounded-xl transition-all shadow-sm cursor-pointer ${
                        scannedCodes.length === 0 ? 'bg-slate-300 cursor-not-allowed' : 'bg-emerald-600 hover:bg-emerald-700'
                      }`}
                    >
                      <Save className="w-4 h-4" />
                      <span>Simpan Semua Barcode Kamera</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* SEARCH & FILTER FOR SELECTED PRODUCT */}
          <div className="bg-white rounded-[16px] border border-slate-200 p-4 mb-6 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3 flex-1 max-w-xl">
              {/* SEARCH */}
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="Cari kode barcode, SN, supplier..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full text-xs font-semibold pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 focus:bg-white transition-all"
                />
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                {searchQuery && (
                  <button onClick={() => setSearchQuery('')} className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 text-lg">&times;</button>
                )}
              </div>

              {/* STATUS FILTER */}
              <div className="w-full md:w-48">
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full text-xs font-semibold px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none cursor-pointer"
                >
                  <option value="ALL">Semua Status</option>
                  <option value="READY">READY (Ready)</option>
                  <option value="SOLD">SOLD (Terjual)</option>
                  <option value="RETURNED">RETURNED (Retur)</option>
                  <option value="DAMAGED">DAMAGED (Rusak)</option>
                  <option value="EXPIRED">EXPIRED (Kadaluarsa)</option>
                </select>
              </div>
            </div>

            {/* EXPORT / PRINT CONTROLS */}
            <div className="flex items-center gap-2">
              <button
                onClick={handleExportCSV}
                className="flex items-center space-x-1 px-3 py-2.5 bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs rounded-xl border border-slate-200 transition-all cursor-pointer"
                title="Unduh Data Excel/CSV"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                <span>Ekspor CSV</span>
              </button>

              <button
                onClick={handlePrintPDF}
                className="flex items-center space-x-1 px-3 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition-all shadow-sm cursor-pointer"
                title="Cetak Laporan PDF"
              >
                <Printer className="w-4 h-4" />
                <span>Cetak PDF</span>
              </button>
            </div>
          </div>

          {/* BARCODE LIST TABLE */}
          <div className="bg-white rounded-[16px] border border-slate-200 overflow-hidden shadow-sm">
            {isLoading ? (
              <div className="py-12 text-center text-slate-400 font-semibold space-y-2">
                <RefreshCcw className="w-8 h-8 animate-spin mx-auto text-emerald-600" />
                <p className="text-xs">Menyinkronkan data barcode...</p>
              </div>
            ) : productFilteredVouchers.length === 0 ? (
              <div className="py-12 text-center text-slate-400 font-semibold space-y-2">
                <Package className="w-8 h-8 mx-auto text-slate-300" />
                <p className="text-xs">Tidak ada data barcode yang cocok untuk kriteria penyaringan.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-slate-800">
                  <thead>
                    <tr className="bg-slate-50/70 border-b border-slate-200 text-slate-400 text-[10px] font-black uppercase tracking-wider">
                      <th className="py-3 px-4">Kode Barcode</th>
                      <th className="py-3 px-4">No. Seri (SN)</th>
                      <th className="py-3 px-4">Supplier</th>
                      <th className="py-3 px-4 text-right">Modal</th>
                      <th className="py-3 px-4 text-center">Status</th>
                      <th className="py-3 px-4 text-center">Kadaluarsa</th>
                      <th className="py-3 px-4 text-center">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs font-medium">
                    {productFilteredVouchers.map((v) => {
                      const isExpanded = expandedHistoryId === v.id;
                      
                      return (
                        <React.Fragment key={v.id}>
                          <tr className="hover:bg-slate-50/30 transition-colors">
                            <td className="py-3 px-4 font-mono font-bold text-slate-900 select-all">
                              {v.barcode}
                            </td>
                            <td className="py-3 px-4 font-mono text-slate-500">
                              {v.serialNumber || '-'}
                            </td>
                            <td className="py-3 px-4 text-slate-500">
                              {v.supplier || '-'}
                            </td>
                            <td className="py-3 px-4 text-right font-bold text-slate-900 font-mono">
                              Rp {(v.purchasePrice || 0).toLocaleString('id-ID')}
                            </td>
                            <td className="py-3 px-4 text-center">
                              {/* STATUS UPDATE DROPDOWN */}
                              <select
                                value={v.status}
                                onChange={(e) => handleStatusChange(v.id, e.target.value as VoucherStatus)}
                                className={`text-[10px] font-black uppercase px-2 py-1 rounded-lg outline-none cursor-pointer ${
                                  v.status === 'READY' 
                                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                                    : v.status === 'SOLD'
                                      ? 'bg-blue-50 text-blue-700 border border-blue-200'
                                      : v.status === 'RETURNED'
                                        ? 'bg-orange-50 text-orange-700 border border-orange-200'
                                        : v.status === 'DAMAGED'
                                          ? 'bg-rose-50 text-rose-700 border border-rose-200'
                                          : 'bg-slate-100 text-slate-700 border border-slate-350'
                                }`}
                              >
                                <option value="READY">READY</option>
                                <option value="SOLD">SOLD</option>
                                <option value="RETURNED">RETURNED</option>
                                <option value="DAMAGED">DAMAGED</option>
                                <option value="EXPIRED">EXPIRED</option>
                              </select>
                            </td>
                            <td className="py-3 px-4 text-center text-slate-600 font-mono">
                              {v.expiredDate || <span className="text-slate-300">-</span>}
                            </td>
                            <td className="py-3 px-4 text-center">
                              <div className="flex items-center justify-center space-x-1.5">
                                <button
                                  onClick={() => setExpandedHistoryId(isExpanded ? null : v.id)}
                                  className={`p-1.5 rounded-lg border transition-all ${
                                    isExpanded 
                                      ? 'bg-slate-900 border-slate-900 text-white' 
                                      : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-500'
                                  }`}
                                  title="Lihat Log Catatan"
                                >
                                  <History className="w-3.5 h-3.5" />
                                </button>

                                {deletingId === v.id ? (
                                  <div className="flex items-center space-x-1">
                                    <button
                                      onClick={() => handleDeleteVoucher(v.id)}
                                      className="bg-rose-600 hover:bg-rose-700 text-white font-black text-[9px] px-2 py-1 rounded-md"
                                    >
                                      Yakin?
                                    </button>
                                    <button
                                      onClick={() => setDeletingId(null)}
                                      className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-[9px] px-1.5 py-1 rounded-md"
                                    >
                                      Batal
                                    </button>
                                  </div>
                                ) : (
                                  isAdmin && (
                                    <button
                                      onClick={() => setDeletingId(v.id)}
                                      className="p-1.5 bg-white hover:bg-rose-50 border border-slate-200 hover:border-rose-100 text-slate-400 hover:text-rose-600 rounded-lg transition-all"
                                      title="Hapus"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  )
                                )}
                              </div>
                            </td>
                          </tr>

                          {/* EXPANDED LOGS ROW */}
                          {isExpanded && (
                            <tr className="bg-slate-50/50">
                              <td colSpan={7} className="py-2.5 px-4 text-[11px] text-slate-600 border-t border-slate-100">
                                <div className="flex items-start space-x-2">
                                  <div className="mt-0.5 text-emerald-600"><Eye className="w-3.5 h-3.5" /></div>
                                  <div>
                                    <span className="font-extrabold text-slate-800">Catatan/Log:</span>{' '}
                                    <span className="italic">{v.notes || 'Tidak ada catatan tambahan untuk barcode ini.'}</span>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="bg-white rounded-[20px] border border-slate-200 p-12 text-center text-slate-400 max-w-lg mx-auto">
          <Layers className="w-12 h-12 text-slate-200 mx-auto mb-3 animate-pulse" />
          <p className="font-bold text-slate-700 text-sm">Tidak Ada Produk Terpilih</p>
          <p className="text-xs text-slate-400 mt-1">Silakan pilih produk jualan di menu pilihan bagian atas untuk mulai mengelola database barcode.</p>
        </div>
      )}

      {/* CONTINUOUS CAMERA SCANNER MODAL */}
      <BarcodeCameraScanner
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScan={handleCameraScanSuccess}
        multiScan={true}
        scannedCount={scannedCodes.length}
      />
    </div>
  );
}
