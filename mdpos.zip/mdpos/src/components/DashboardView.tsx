import React, { useState, useEffect, useMemo } from 'react';
import { Transaction, Shift, User, EWallet } from '../types';
import { getJakartaDateString, formatWIBTimeOnly } from '../utils/dateUtils';
import { AppConfig } from './SettingsView';
import { 
  TrendingUp, 
  Coins, 
  Clock, 
  User as UserIcon, 
  Wallet, 
  DollarSign, 
  Play, 
  Lock, 
  Sparkles, 
  Activity,
  Printer,
  X,
  Flame,
  Award,
  ShoppingBag,
  Bell,
  Search,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  QrCode,
  Package,
  CheckCircle,
  AlertCircle,
  Calendar,
  Layers,
  ChevronRight,
  History,
  TrendingDown
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { CardWatermark } from './CardWatermark';

interface DashboardViewProps {
  currentUser: User;
  transactions: Transaction[];
  eWallets: EWallet[];
  currentShift: Shift | null;
  shifts: Shift[];
  onStartShift: (initialCash: number, cashierId: string, cashierName: string) => Promise<Shift>;
  onCloseShift: (closedBy: string) => Promise<Shift | null>;
  appConfig?: AppConfig;
  setActiveTab?: (tab: string) => void;
}

// ==========================================
// Reusable Highly-Polished UI Components
// ==========================================

// 1. Page Header Component
interface PageHeaderProps {
  title: string;
  subtitle: string;
  currentUser: User;
  onSearchClick?: () => void;
  onNotificationClick?: () => void;
}

function PageHeader({ title, subtitle }: PageHeaderProps) {
  return (
    <div className="flex flex-row items-center justify-between gap-2 pb-1.5 border-b border-slate-100 dark:border-slate-800">
      <div>
        <h1 className="text-lg sm:text-2xl font-black text-slate-800 dark:text-slate-100 tracking-tight flex items-center gap-1.5">
          {title}
          <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></span>
        </h1>
        <p className="text-[10px] sm:text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5 hidden sm:block">{subtitle}</p>
      </div>
    </div>
  );
}

// 2. Hero Welcome Card Component
interface HeroCardProps {
  currentUser: User;
  currentShift: Shift | null;
  shiftDuration: string;
}

function HeroCard({ currentUser, currentShift, shiftDuration }: HeroCardProps) {
  const [time, setTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      setTime(new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ' WIB');
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const greeting = useMemo(() => {
    const hour = new Date().getHours();
    if (hour < 11) return 'Selamat Pagi';
    if (hour < 15) return 'Selamat Siang';
    if (hour < 19) return 'Selamat Sore';
    return 'Selamat Malam';
  }, []);

  return (
    <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-sky-500 text-white rounded-xl p-3.5 sm:p-4 shadow-sm relative overflow-hidden">
      {/* Decorative vector overlays */}
      <div className="absolute right-[-40px] top-[-40px] w-48 h-48 rounded-full bg-white/5 blur-3xl pointer-events-none"></div>
      <div className="absolute left-[-30px] bottom-[-30px] w-32 h-32 rounded-full bg-sky-300/10 blur-2xl pointer-events-none"></div>
      <CardWatermark type="shift" position="bottom-right" size="md" className="text-white/6 dark:text-white/6 scale-105" />

      <div className="relative z-10 flex flex-col justify-center">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-0.5 bg-white/10 text-white text-[7.5px] sm:text-[8px] font-black tracking-widest uppercase px-1.5 py-0.5 rounded-full border border-white/10 backdrop-blur-xs">
            <Sparkles className="w-2 h-2 text-amber-300 fill-amber-300" />
            <span>PORTAL KASIR</span>
          </div>
          <h2 className="text-base sm:text-xl font-black tracking-tight text-white leading-tight">
            {greeting}, {currentUser.name}!
          </h2>
          <div className="text-[8px] sm:text-[10px] text-sky-100/90 font-medium font-mono flex items-center gap-1 mt-1">
            <Calendar className="w-3 h-3 text-sky-300" />
            <span>{new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
            <span className="opacity-50">•</span>
            <span>{time}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// 3. Quick Action Card Button Component
interface QuickActionCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  onClick: () => void;
  accentColor: 'blue' | 'emerald' | 'amber' | 'purple';
}

function QuickActionCard({ title, description, icon, onClick, accentColor }: QuickActionCardProps) {
  let ringColor = 'hover:border-blue-500/50 hover:shadow-blue-500/5 dark:hover:border-blue-500/40';
  let iconBg = 'bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400';
  if (accentColor === 'emerald') {
    ringColor = 'hover:border-emerald-500/50 hover:shadow-emerald-500/5 dark:hover:border-emerald-500/40';
    iconBg = 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400';
  } else if (accentColor === 'amber') {
    ringColor = 'hover:border-amber-500/50 hover:shadow-amber-500/5 dark:hover:border-amber-500/40';
    iconBg = 'bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400';
  } else if (accentColor === 'purple') {
    ringColor = 'hover:border-purple-500/50 hover:shadow-purple-500/5 dark:hover:border-purple-500/40';
    iconBg = 'bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400';
  }

  return (
    <button
      onClick={onClick}
      className={`w-full text-left p-2.5 sm:p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/80 rounded-[12px] sm:rounded-[18px] shadow-xs hover:shadow-sm transition-all duration-300 cursor-pointer transform hover:scale-[1.01] active:scale-[0.99] group ${ringColor}`}
    >
      <div className="flex items-center gap-2 sm:gap-3">
        <div className={`p-1.5 sm:p-2 rounded-lg sm:rounded-xl transition-all duration-300 group-hover:scale-110 shrink-0 ${iconBg}`}>
          {icon}
        </div>
        <div className="min-w-0">
          <h4 className="font-extrabold text-[10px] sm:text-[11px] text-slate-800 dark:text-slate-100 tracking-wide uppercase truncate leading-tight">{title}</h4>
          <p className="text-[9px] sm:text-[10px] text-slate-500 dark:text-slate-400 font-medium mt-0.5 leading-tight truncate">{description}</p>
        </div>
      </div>
    </button>
  );
}

// 4. Stat Card Component
interface StatCardProps {
  title: string;
  value: string;
  subtitle: string;
  icon: React.ReactNode;
  trend?: {
    type: 'up' | 'down';
    label: string;
  };
  bgColor?: string;
  isPositive?: boolean;
  className?: string;
}

function StatCard({ title, value, subtitle, icon, trend, bgColor, isPositive, className = "" }: StatCardProps) {
  const borderHighlight = isPositive ? 'border-l-4 border-l-emerald-500' : 'border-l-4 border-l-blue-500';

  return (
    <div className={`glass-card rounded-[20px] p-4 relative overflow-hidden card-hover ${borderHighlight} ${className}`}>
      <CardWatermark type="dashboard" position="bottom-right" size="sm" className="opacity-5 sm:opacity-8 text-indigo-500/5 dark:text-indigo-400/5" />
      <div className="flex items-start justify-between gap-2">
        <div className="space-y-1 min-w-0">
          <span className="text-[8px] sm:text-[9px] text-slate-400 dark:text-slate-500 font-black uppercase tracking-widest block truncate">
            {title}
          </span>
          <h3 className="text-base sm:text-lg md:text-xl font-black text-slate-800 dark:text-slate-100 font-mono tracking-tight pt-0.5 truncate leading-none">
            {value}
          </h3>
          <p className="text-[9px] sm:text-[10px] text-slate-500 dark:text-slate-400 font-medium leading-tight pt-0.5 truncate">{subtitle}</p>
        </div>

        <div className={`p-2 rounded-xl shrink-0 transition-transform duration-300 hover:scale-105 ${bgColor || 'bg-slate-50 dark:bg-slate-850 text-slate-600'}`}>
          {icon}
        </div>
      </div>

      {trend && (
        <div className="mt-1.5 pt-1.5 border-t border-slate-100 dark:border-slate-800 flex items-center gap-1 text-[8px] sm:text-[9px] font-bold leading-none">
          {trend.type === 'up' ? (
            <span className="flex items-center gap-0.5 text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/20 px-1 py-0.5 rounded text-[8px]">
              <ArrowUpRight className="w-2.5 h-2.5" />
              {trend.label}
            </span>
          ) : (
            <span className="flex items-center gap-0.5 text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/20 px-1 py-0.5 rounded text-[8px]">
              <ArrowDownRight className="w-2.5 h-2.5" />
              {trend.label}
            </span>
          )}
          <span className="text-slate-400 dark:text-slate-500 font-medium truncate">vs Sif Lalu</span>
        </div>
      )}
    </div>
  );
}

// 5. Chart Card Container Component
interface ChartCardProps {
  title: string;
  subtitle: string;
  children: React.ReactNode;
  badge?: string;
}

function ChartCard({ title, subtitle, children, badge }: ChartCardProps) {
  return (
    <div className="glass-card rounded-[24px] p-4 sm:p-5 hover:shadow-lg transition-all duration-300">
      <div className="flex items-center justify-between gap-4 mb-3 border-b border-slate-100/40 dark:border-slate-800/40 pb-2">
        <div>
          <h3 className="font-extrabold text-[11px] sm:text-xs text-slate-800 dark:text-slate-100 tracking-tight flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-blue-500" />
            <span>{title}</span>
          </h3>
          <p className="text-[8px] sm:text-[9px] text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider mt-0.5 leading-none">{subtitle}</p>
        </div>
        {badge && (
          <span className="text-[7px] sm:text-[8px] font-black text-indigo-600 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-100/50 dark:border-indigo-900/30 px-2 py-0.5 rounded-full uppercase tracking-wider shrink-0 leading-none">
            {badge}
          </span>
        )}
      </div>
      <div className="h-36 sm:h-56 w-full">
        {children}
      </div>
    </div>
  );
}// 6. Section Card Layout Component
interface SectionCardProps {
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  action?: React.ReactNode;
  className?: string;
}

function SectionCard({ title, subtitle, icon, children, action, className = "" }: SectionCardProps) {
  return (
    <div className={`glass-card rounded-2xl p-4 flex flex-col h-full hover:shadow-lg transition-all duration-300 ${className}`}>
      <div className="flex items-start justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-1.5 mb-2.5">
        <div className="flex items-center gap-1.5">
          <div className="p-1 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200/40 dark:border-slate-800 text-blue-500 shrink-0">
            {icon}
          </div>
          <div>
            <h3 className="font-extrabold text-[10px] sm:text-[10.5px] text-slate-800 dark:text-slate-100 tracking-wide uppercase leading-tight">{title}</h3>
            <p className="text-[8px] sm:text-[8.5px] text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider mt-0.5 leading-none">{subtitle}</p>
          </div>
        </div>
        {action}
      </div>
      <div className="flex-1">
        {children}
      </div>
    </div>
  );
}

// 7. Empty State Component
interface EmptyStateProps {
  title: string;
  description: string;
  icon: React.ReactNode;
}

function EmptyState({ title, description, icon }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center text-center p-6 bg-slate-50/50 dark:bg-slate-850/20 rounded-[16px] border border-dashed border-slate-200 dark:border-slate-800 min-h-[180px]">
      <div className="p-2 bg-white dark:bg-slate-900 rounded-xl shadow-xs text-slate-400 dark:text-slate-600 mb-2.5">
        {icon}
      </div>
      <h4 className="font-bold text-[11px] text-slate-700 dark:text-slate-300 uppercase tracking-wider">{title}</h4>
      <p className="text-[10px] text-slate-400 dark:text-slate-500 max-w-xs mt-1 leading-relaxed">{description}</p>
    </div>
  );
}

// 8. Activity Timeline Event Row
interface ActivityTimelineItemProps {
  key?: React.Key;
  title: string;
  time: string;
  description: string;
  icon: React.ReactNode;
  color: 'blue' | 'emerald' | 'amber' | 'rose';
  isLast?: boolean;
}

function ActivityTimelineItem({ title, time, description, icon, color, isLast }: ActivityTimelineItemProps) {
  let badgeColor = 'bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 border-blue-100 dark:border-blue-900/40';
  let dotLine = 'border-blue-200 dark:border-blue-900/40';
  if (color === 'emerald') {
    badgeColor = 'bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/40';
    dotLine = 'border-emerald-200 dark:border-emerald-900/40';
  } else if (color === 'amber') {
    badgeColor = 'bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 border-amber-100 dark:border-amber-900/40';
    dotLine = 'border-amber-200 dark:border-amber-900/40';
  } else if (color === 'rose') {
    badgeColor = 'bg-rose-50 dark:bg-rose-950 text-rose-600 dark:text-rose-400 border-rose-100 dark:border-rose-900/40';
    dotLine = 'border-rose-200 dark:border-rose-900/40';
  }

  return (
    <div className="flex gap-3 group">
      <div className="flex flex-col items-center">
        <div className={`w-7 h-7 rounded-lg border flex items-center justify-center shrink-0 ${badgeColor}`}>
          {icon}
        </div>
        {!isLast && (
          <div className={`w-0.5 flex-1 border-l border-dashed my-1 ${dotLine}`}></div>
        )}
      </div>
      <div className="flex-1 pb-3">
        <div className="flex items-center justify-between mb-0.5 gap-2">
          <h4 className="font-bold text-[11px] text-slate-800 dark:text-slate-100 group-hover:text-blue-600 transition-colors leading-tight">{title}</h4>
          <span className="text-[8px] font-black text-slate-400 dark:text-slate-500 font-mono tracking-wider shrink-0">{time}</span>
        </div>
        <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium leading-relaxed">{description}</p>
      </div>
    </div>
  );
}

// 9. Recent Transaction Row Component
interface RecentTransactionProps {
  key?: React.Key;
  id: string;
  invoice: string;
  time: string;
  type: 'pembelian' | 'penjualan' | 'withdrawal' | 'topup';
  amount: string;
  itemsCount: number;
  status: 'success' | 'pending' | 'failed';
}

function RecentTransaction({ id, invoice, time, type, amount, itemsCount, status }: RecentTransactionProps) {
  let badgeStyle = "bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/30";
  let label = "Top-Up / Penjualan";
  let icon = <ArrowUpRight className="w-3 h-3 text-emerald-500" />;

  if (type === 'withdrawal') {
    badgeStyle = "bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-400 border-rose-100 dark:border-rose-900/30";
    label = "Tarik Tunai";
    icon = <ArrowDownRight className="w-3 h-3 text-rose-500" />;
  }

  return (
    <div className="flex items-center justify-between p-2.5 rounded-xl border border-slate-100 dark:border-slate-800/80 bg-white dark:bg-slate-900 hover:border-blue-500/20 hover:shadow-xs transition-all duration-200">
      <div className="flex items-center gap-2.5">
        <div className={`w-7 h-7 rounded-lg border flex items-center justify-center shrink-0 ${
          type === 'withdrawal' ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-100/50 dark:border-rose-900/30' : 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-100/50 dark:border-emerald-900/30'
        }`}>
          {icon}
        </div>
        <div className="min-w-0">
          <div className="flex items-center gap-1.5">
            <span className="font-mono font-bold text-[11px] text-slate-800 dark:text-slate-100 tracking-tight leading-none">{invoice}</span>
            <span className="text-[7px] font-black bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 px-1 py-0.5 rounded uppercase tracking-widest leading-none">
              WIB
            </span>
          </div>
          <div className="flex items-center gap-1.5 mt-0.5 text-[9px] text-slate-400 dark:text-slate-500 font-semibold leading-none">
            <span>{time}</span>
            <span>•</span>
            <span className="capitalize">{label}</span>
            <span>•</span>
            <span>{itemsCount} Item</span>
          </div>
        </div>
      </div>

      <div className="text-right shrink-0">
        <span className="font-mono font-extrabold text-[11px] text-slate-800 dark:text-slate-100 block leading-none">{amount}</span>
        <span className={`text-[7px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded-full border mt-0.5 inline-block leading-none ${badgeStyle}`}>
          {status}
        </span>
      </div>
    </div>
  );
}

// ==========================================
// Main DashboardView Component
// ==========================================

export default function DashboardView({
  currentUser,
  transactions,
  eWallets,
  currentShift,
  shifts,
  onStartShift,
  onCloseShift,
  appConfig,
  setActiveTab
}: DashboardViewProps) {
  const [initialCashInput, setInitialCashInput] = useState<number>(100000);
  const [shiftSuccessMsg, setShiftSuccessMsg] = useState('');
  const [showShiftRecap, setShowShiftRecap] = useState(false);
  const [recapShift, setRecapShift] = useState<Shift | null>(null);
  const [activeMobileTab, setActiveMobileTab] = useState<'transactions' | 'shift' | 'products' | 'activity'>('transactions');

  // 1. Shift live elapsed duration timer
  const [shiftDuration, setShiftDuration] = useState<string>('00:00:00');

  useEffect(() => {
    if (!currentShift) {
      setShiftDuration('00:00:00');
      return;
    }

    const calculateDuration = () => {
      const start = new Date(currentShift.startTime).getTime();
      const now = new Date().getTime();
      const diff = Math.max(0, now - start);

      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      const pad = (num: number) => String(num).padStart(2, '0');
      return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
    };

    setShiftDuration(calculateDuration());

    const timer = setInterval(() => {
      setShiftDuration(calculateDuration());
    }, 1000);

    return () => clearInterval(timer);
  }, [currentShift]);

  // Formatting helpers
  const formatRupiah = (num: number | null | undefined) => {
    if (num === undefined || num === null || isNaN(num)) return 'Rp 0';
    return 'Rp ' + num.toLocaleString('id-ID');
  };

  const formatDateTime = (isoString: string) => {
    return formatWIBTimeOnly(isoString);
  };

  // Metrics & Stats Calculations (Active Shift and Balances)
  const stats = useMemo(() => {
    let totalSalesShift = 0;
    let totalProfitShift = 0;
    let transactionCountShift = 0;
    let totalWithdrawalShift = 0;

    if (currentShift) {
      const shiftTrxs = transactions.filter(
        (tx) => tx.date >= currentShift.startTime && tx.status === 'success'
      );

      totalSalesShift = shiftTrxs.reduce((acc, tx) => {
        return tx.type === 'withdrawal' ? acc : acc + tx.totalAmount;
      }, 0);

      totalWithdrawalShift = shiftTrxs.reduce((acc, tx) => {
        return tx.type === 'withdrawal' ? acc + (tx.totalAmount - (tx.adminFee || 0)) : acc;
      }, 0);

      totalProfitShift = shiftTrxs.reduce((acc, tx) => acc + tx.totalProfit, 0);
      transactionCountShift = shiftTrxs.length;
    }

    let cashInDrawer = 0;
    if (currentShift) {
      const totalSalesInShift = currentShift.totalSales || 0;
      const totalWithdrawalsInShift = currentShift.totalWithdrawals || 0;
      cashInDrawer = currentShift.initialCash + totalSalesInShift - (currentShift.totalTransferSales || 0) - totalWithdrawalsInShift;
    }

    const totalEWalletBalance = eWallets
      .filter((w) => w.isActive)
      .reduce((acc, w) => acc + Number(w.balance || 0), 0);

    return {
      totalSalesShift,
      totalProfitShift,
      transactionCountShift,
      totalWithdrawalShift,
      cashInDrawer,
      totalEWalletBalance
    };
  }, [transactions, eWallets, currentShift]);

  // Generate Chart Data for the last 7 days of sales
  const salesChartData = useMemo(() => {
    const dataList = [];
    const today = new Date();
    
    for (let i = 6; i >= 0; i--) {
      const targetDate = new Date();
      targetDate.setDate(today.getDate() - i);
      const dateString = getJakartaDateString(targetDate);
      
      const dayLabel = targetDate.toLocaleDateString('id-ID', { 
        weekday: 'short', 
        day: 'numeric' 
      });

      const dayTrxs = transactions.filter(
        (tx) => tx.status === 'success' && getJakartaDateString(tx.date) === dateString
      );

      const revenue = dayTrxs.reduce((acc, tx) => tx.type === 'withdrawal' ? acc : acc + tx.totalAmount, 0);
      const profit = dayTrxs.reduce((acc, tx) => acc + tx.totalProfit, 0);

      dataList.push({
        date: dateString,
        label: dayLabel,
        'Omset Penjualan': revenue,
        'Keuntungan Bersih': profit,
      });
    }
    return dataList;
  }, [transactions]);

  // Calculate best-selling products from successful transactions
  const bestSellingProducts = useMemo(() => {
    const productMap: Record<string, { name: string; category: string; quantity: number; totalRevenue: number }> = {};
    
    const successfulTrxs = transactions.filter(tx => tx.status === 'success');
    
    successfulTrxs.forEach(tx => {
      if (tx.items) {
        tx.items.forEach(item => {
          const name = item.productName || 'Produk Tidak Dikenal';
          const category = item.category || 'Lainnya';
          
          if (!productMap[name]) {
            productMap[name] = {
              name,
              category,
              quantity: 0,
              totalRevenue: 0,
            };
          }
          
          const qty = Number(item.quantity || 0);
          productMap[name].quantity += qty;
          productMap[name].totalRevenue += qty * Number(item.sellingPrice || 0);
        });
      }
    });
    
    return Object.values(productMap)
      .sort((a, b) => b.quantity - a.quantity)
      .slice(0, 5);
  }, [transactions]);

  // Find max quantity sold to scale progress bars
  const maxSoldQuantity = useMemo(() => {
    if (bestSellingProducts.length === 0) return 1;
    return Math.max(...bestSellingProducts.map(p => p.quantity), 1);
  }, [bestSellingProducts]);

  // Recent 5 Transactions
  const recentTransactions = useMemo(() => {
    return transactions
      .slice(0, 5);
  }, [transactions]);

  // Active logs & operational activity list
  const operationalTimeline = useMemo(() => {
    const list = [];
    const todayStr = getJakartaDateString(new Date());

    if (currentShift) {
      list.push({
        id: 'shift-start',
        title: 'Sif Operasional Dibuka',
        time: formatWIBTimeOnly(currentShift.startTime),
        description: `Sif dimulai oleh ${currentShift.cashierName} dengan modal awal laci ${formatRupiah(currentShift.initialCash)}`,
        icon: <Play className="w-3.5 h-3.5" />,
        color: 'blue' as const
      });
    }

    const todayTrxs = transactions
      .filter(t => getJakartaDateString(t.date) === todayStr && t.status === 'success')
      .slice(0, 3);

    todayTrxs.forEach((t) => {
      const isWith = t.type === 'withdrawal';
      list.push({
        id: t.id,
        title: isWith ? 'Tarik Tunai Berhasil' : 'Transaksi POS Sukses',
        time: formatWIBTimeOnly(t.date),
        description: isWith
          ? `${t.eWalletName} sebesar ${formatRupiah(t.totalAmount)} (Biaya Admin ${formatRupiah(t.adminFee)})`
          : `Pembelian senilai ${formatRupiah(t.totalAmount)} oleh kasir ${t.cashierName}`,
        icon: isWith ? <ArrowDownRight className="w-3.5 h-3.5" /> : <ShoppingBag className="w-3.5 h-3.5" />,
        color: isWith ? 'rose' as const : 'emerald' as const
      });
    });

    if (list.length === 0) {
      list.push({
        id: 'empty',
        title: 'Hari Kerja Dimulai',
        time: '--:-- WIB',
        description: 'Menunggu pembukaan sif pertama atau transaksi pos masuk hari ini.',
        icon: <Activity className="w-3.5 h-3.5" />,
        color: 'amber' as const
      });
    }

    return list;
  }, [currentShift, transactions]);

  // Start shift from dashboard handler
  const handleStartShiftSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onStartShift(initialCashInput, currentUser.id, currentUser.name);
    setShiftSuccessMsg('Sif kasir berhasil dibuka! Selamat bertugas.');
    setTimeout(() => setShiftSuccessMsg(''), 4000);
  };

  const handleCloseShiftClick = async () => {
    if (!currentShift) return;
    
    const shiftTransactions = transactions.filter(
      t => t.date >= currentShift.startTime && t.status === 'success'
    );
    const topupTransactions = shiftTransactions.filter(t => t.type !== 'withdrawal');
    const withdrawalTransactions = shiftTransactions.filter(t => t.type === 'withdrawal');

    const totalSales = topupTransactions.reduce((acc, curr) => acc + curr.totalAmount, 0);
    const totalWithdrawals = withdrawalTransactions.reduce((acc, curr) => acc + (curr.totalAmount - (curr.adminFee || 0)), 0);
    const totalProfit = shiftTransactions.reduce((acc, curr) => acc + curr.totalProfit, 0);
    const transactionCount = shiftTransactions.length;

    const closed = await onCloseShift(currentUser.name);
    if (closed) {
      const finalRecap: Shift = {
        ...closed,
        totalSales,
        totalWithdrawals,
        totalProfit,
        transactionCount
      };
      setRecapShift(finalRecap);
      setShowShiftRecap(true);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="p-2 sm:p-4 lg:p-6 space-y-3 sm:space-y-4 max-w-7xl mx-auto w-full animate-in fade-in duration-150">
      
      {/* 1. Page Header Component */}
      <PageHeader 
        title="Dashboard Utama" 
        subtitle="Selamat datang di portal analisis kasir dan finansial toko."
        currentUser={currentUser}
      />

      {/* 2. Welcome & Shift Control Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 sm:gap-4">
        {/* Left Column: Hero Welcome Card */}
        <div className="lg:col-span-8">
          <HeroCard 
            currentUser={currentUser}
            currentShift={currentShift}
            shiftDuration={shiftDuration}
          />
        </div>
        
        {/* Right Column: Shift Manager Console Widget */}
        <div className="lg:col-span-4">
          <SectionCard
            title="Sif &amp; Kontrol Laci Kasir"
            subtitle="Konsol penguncian kas laci"
            icon={<Lock className="w-3.5 h-3.5 text-blue-500" />}
          >
            {currentShift ? (
              <div className="space-y-2 h-full flex flex-col justify-between">
                <div className="bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-800 rounded-xl p-2.5 text-center">
                  <span className="text-[9px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block">SIF AKTIF BERJALAN</span>
                  <div className="text-xl font-black font-mono tracking-widest text-slate-800 dark:text-slate-100 animate-pulse my-0.5">
                    {shiftDuration}
                  </div>
                  <div className="inline-flex items-center gap-1 text-[10px] text-slate-600 dark:text-slate-350 font-bold bg-white dark:bg-slate-950 border border-slate-200/60 dark:border-slate-850 px-2 py-0.5 rounded-lg shadow-2xs">
                    <UserIcon className="w-2.5 h-2.5 text-blue-500" />
                    <span>Petugas: {currentShift.cashierName}</span>
                  </div>
                </div>

                <button
                  onClick={handleCloseShiftClick}
                  className="w-full flex items-center justify-center gap-1 py-1.5 px-3 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all duration-200 active:scale-98 shadow-xs cursor-pointer"
                >
                  <Lock className="w-3 h-3" />
                  <span>Akhiri &amp; Rekap Sif</span>
                </button>
              </div>
            ) : (
              <div className="space-y-2 h-full flex flex-col justify-between">
                <div className="text-center py-2 bg-rose-50/40 dark:bg-rose-950/15 border border-rose-100 dark:border-rose-900/20 rounded-xl p-2 flex flex-col items-center">
                  <Lock className="w-4 h-4 text-rose-500 mb-0.5 animate-bounce" />
                  <span className="text-[9px] font-bold text-rose-800 dark:text-rose-400 uppercase tracking-wider">Laci Kasir Terkunci</span>
                  <p className="text-[8px] text-slate-500 dark:text-slate-400 mt-0.5 max-w-xs leading-normal">
                    Sif kasir belum dibuka. Anda harus mengawali sif untuk memproses transaksi.
                  </p>
                </div>

                {currentUser.role === 'admin' ? (
                  <form onSubmit={handleStartShiftSubmit} className="bg-slate-50/50 dark:bg-slate-900/50 p-2 rounded-xl border border-slate-200/60 dark:border-slate-800 space-y-2">
                    {shiftSuccessMsg && (
                      <div className="text-[10px] font-bold text-green-700 dark:text-green-400 bg-green-50 dark:bg-green-950/20 p-1.5 rounded-lg border border-green-100 dark:border-green-900/20">
                        {shiftSuccessMsg}
                      </div>
                    )}
                    <div>
                      <label className="block text-[8px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-0.5">
                        Modal Awal Laci Tunai
                      </label>
                      <div className="relative rounded-lg shadow-xs">
                        <div className="absolute inset-y-0 left-0 pl-2 flex items-center pointer-events-none">
                          <span className="text-slate-400 dark:text-slate-500 text-[10px] font-extrabold">Rp</span>
                        </div>
                        <input
                          type="number"
                          required
                          min={0}
                          value={initialCashInput}
                          onChange={(e) => setInitialCashInput(Number(e.target.value))}
                          className="block w-full pl-6 pr-2 py-1 text-[10.5px] border border-slate-250 dark:border-slate-750 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white dark:bg-slate-950 font-extrabold text-slate-850 dark:text-slate-100"
                        />
                      </div>
                    </div>

                    <div className="flex gap-1">
                      {[50000, 100000, 200000].map((preset) => (
                        <button
                          key={preset}
                          type="button"
                          onClick={() => setInitialCashInput(preset)}
                          className={`flex-1 py-0.5 px-1 border rounded-lg text-[8px] font-black transition-all cursor-pointer ${
                            initialCashInput === preset
                              ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                              : 'bg-white dark:bg-slate-950 text-slate-600 dark:text-slate-350 border-slate-200 dark:border-slate-850 hover:bg-slate-50 dark:hover:bg-slate-900'
                          }`}
                        >
                          {preset / 1000}K
                        </button>
                      ))}
                    </div>

                    <button
                      type="submit"
                      className="w-full py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-[10px] flex items-center justify-center gap-1 cursor-pointer active:scale-98 transition-all"
                    >
                      <Play className="w-2.5 h-2.5" />
                      <span>Buka Sif Kasir</span>
                    </button>
                  </form>
                ) : (
                  <div className="bg-amber-50/50 dark:bg-amber-950/15 border border-amber-100/60 dark:border-amber-900/20 p-2 rounded-xl text-center">
                    <p className="text-[10px] font-bold text-amber-800 dark:text-amber-400">
                      Sif Hanya Bisa Dimulai oleh Admin
                    </p>
                    <p className="text-[8px] text-slate-500 dark:text-slate-400 mt-0.5 leading-normal">
                      Silakan hubungi Administrator Pemilik untuk membuka laci kasir agar Anda dapat bertransaksi.
                    </p>
                  </div>
                )}
              </div>
            )}
          </SectionCard>
        </div>
      </div>

      {/* 3. Ringkasan Bisnis / Operational Metric Stat Cards */}
      <div className={`grid grid-cols-2 ${currentUser.role === 'admin' ? 'lg:grid-cols-5' : 'lg:grid-cols-2'} gap-2 sm:gap-4`}>
        <StatCard
          title="Uang Laci Fisik"
          value={currentShift ? formatRupiah(stats.cashInDrawer) : 'Rp 0'}
          subtitle={currentShift ? `Modal Sif: ${formatRupiah(currentShift.initialCash)}` : 'Sif kasir belum aktif'}
          icon={<Coins className="w-4 h-4 sm:w-5 h-5 text-emerald-500" />}
          bgColor="bg-emerald-50 dark:bg-emerald-950/40"
          isPositive={true}
        />
        {currentUser.role === 'admin' && (
          <StatCard
            title="Omset Pulsa/TopUp"
            value={formatRupiah(stats.totalSalesShift)}
            subtitle={`${stats.transactionCountShift} transaksi Sif berjalan`}
            icon={<TrendingUp className="w-4 h-4 sm:w-5 h-5 text-blue-500" />}
            bgColor="bg-blue-50 dark:bg-blue-950/40"
            isPositive={false}
            trend={{ type: 'up', label: '+12.4%' }}
          />
        )}
        <StatCard
          title="Tarik Tunai Laci"
          value={formatRupiah(stats.totalWithdrawalShift)}
          subtitle="Kas keluar dari laci fisik"
          icon={<TrendingDown className="w-4 h-4 sm:w-5 h-5 text-rose-500" />}
          bgColor="bg-rose-50 dark:bg-rose-950/40"
          isPositive={false}
        />
        {currentUser.role === 'admin' && (
          <StatCard
            title="Laba Bersih Sif"
            value={formatRupiah(stats.totalProfitShift)}
            subtitle="Akumulasi keuntungan Sif"
            icon={<DollarSign className="w-4 h-4 sm:w-5 h-5 text-emerald-500" />}
            bgColor="bg-emerald-50 dark:bg-emerald-950/40"
            isPositive={true}
          />
        )}
        {currentUser.role === 'admin' && (
          <StatCard
            title="Saldo Digital Server"
            value={formatRupiah(stats.totalEWalletBalance)}
            subtitle="Total balance merchant"
            icon={<Wallet className="w-4 h-4 sm:w-5 h-5 text-amber-500" />}
            bgColor="bg-amber-50 dark:bg-amber-950/40"
            isPositive={false}
            className="col-span-2 lg:col-span-1"
          />
        )}
      </div>

      {/* 4. ChartCard with AreaChart Recharts (Spacious Full Width) */}
      {currentUser.role === 'admin' && (
        <ChartCard 
          title="Tren Finansial (7 Hari)" 
          subtitle="Omset vs Laba Bersih Realtime"
          badge="Normal"
        >
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={salesChartData}
              margin={{ top: 10, right: 15, left: -20, bottom: 0 }}
            >
              <defs>
                <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.25}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.25}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(148, 163, 184, 0.12)" />
              <XAxis 
                dataKey="label" 
                tickLine={false}
                axisLine={false}
                style={{ fontSize: '10px', fontWeight: 'bold', fill: 'currentColor', opacity: 0.5 }}
              />
              <YAxis 
                tickLine={false}
                axisLine={false}
                tickFormatter={(val) => `${val / 1000}k`}
                style={{ fontSize: '10px', fontWeight: 'bold', fill: 'currentColor', opacity: 0.5 }}
              />
              <Tooltip 
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-slate-900/95 backdrop-blur-md border border-slate-700/80 p-3 rounded-2xl shadow-xl text-slate-100 font-sans space-y-1.5 min-w-[170px]">
                        <p className="font-extrabold text-[11px] text-slate-200 border-b border-slate-800 pb-1.5">
                          {label}
                        </p>
                        <div className="space-y-1">
                          {payload.map((entry: any, index: number) => (
                            <div key={`item-${index}`} className="flex items-center justify-between text-[11px] font-bold gap-3">
                              <span className="flex items-center gap-1.5" style={{ color: entry.color }}>
                                <span className="w-2 h-2 rounded-full inline-block shrink-0" style={{ backgroundColor: entry.color }} />
                                <span>{entry.name}:</span>
                              </span>
                              <span className="text-white font-mono font-black">{formatRupiah(Number(entry.value))}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Area 
                type="monotone" 
                dataKey="Omset Penjualan" 
                stroke="#3b82f6" 
                strokeWidth={2.5}
                fillOpacity={1} 
                fill="url(#colorRevenue)" 
              />
              <Area 
                type="monotone" 
                dataKey="Keuntungan Bersih" 
                stroke="#10b981" 
                strokeWidth={2}
                fillOpacity={1} 
                fill="url(#colorProfit)" 
              />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>
      )}

      {/* Mobile & Tablet Tab Selector (Hidden on Desktop) */}
      <div className="lg:hidden flex border border-slate-200 dark:border-slate-800 rounded-xl p-1 bg-slate-50 dark:bg-slate-950/40 gap-1 shadow-2xs">
        <button
          onClick={() => setActiveMobileTab('transactions')}
          className={`flex-1 py-1.5 text-center text-[10px] font-extrabold rounded-lg transition-all cursor-pointer ${
            activeMobileTab === 'transactions'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-550 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-850'
          }`}
        >
          Transaksi
        </button>
        <button
          onClick={() => setActiveMobileTab('products')}
          className={`flex-1 py-1.5 text-center text-[10px] font-extrabold rounded-lg transition-all cursor-pointer ${
            activeMobileTab === 'products'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-550 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-850'
          }`}
        >
          Terlaris
        </button>
        <button
          onClick={() => setActiveMobileTab('activity')}
          className={`flex-1 py-1.5 text-center text-[10px] font-extrabold rounded-lg transition-all cursor-pointer ${
            activeMobileTab === 'activity'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-550 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-850'
          }`}
        >
          Aktivitas
        </button>
      </div>

      {/* 5. Main Content Grid (Charts & Operational Splits) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 sm:gap-4">
        
        {/* Left Span: Chart & Transactions */}
        <div className="lg:col-span-8 space-y-3 sm:space-y-4">
          


          {/* SectionCard: Recent Transactions */}
          <div className={activeMobileTab === 'transactions' ? 'block' : 'hidden lg:block'}>
            <SectionCard
              title="Daftar Transaksi Terakhir"
              subtitle="Daftar aktivitas kasir masuk/keluar mutakhir"
              icon={<History className="w-4 h-4 text-blue-500" />}
              action={
                <button
                  onClick={() => setActiveTab && setActiveTab('pos')}
                  className="text-[10px] font-black text-blue-600 dark:text-blue-400 uppercase hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>Menu Kasir</span>
                  <ChevronRight className="w-3 h-3" />
                </button>
              }
            >
              {recentTransactions.length > 0 ? (
                <div className="space-y-3">
                  {recentTransactions.map((tx) => (
                    <RecentTransaction
                      key={tx.id}
                      id={tx.id}
                      invoice={tx.invoiceNumber}
                      time={formatDateTime(tx.date)}
                      type={tx.type as any}
                      amount={formatRupiah(tx.totalAmount)}
                      itemsCount={tx.items?.length || 1}
                      status={tx.status as any}
                    />
                  ))}
                </div>
              ) : (
                <EmptyState
                  title="Transaksi Belum Ditemukan"
                  description="Belum ada transaksi terekam pada server database in-memory konter saat ini."
                  icon={<ShoppingBag className="w-8 h-8 text-slate-350" />}
                />
              )}
            </SectionCard>
          </div>

        </div>

        {/* Right Column: Top Products & Activity Timeline */}
        <div className="lg:col-span-4 space-y-3 sm:space-y-4">
          
          {/* Top Selling Products Horizontal list */}
          <div className={activeMobileTab === 'products' ? 'block' : 'hidden lg:block'}>
            <SectionCard
              title="Produk Terlaris"
              subtitle="Katalog terpopuler berdasarkan kuantitas"
              icon={<Flame className="w-4 h-4 text-amber-500 animate-pulse" />}
            >
              {bestSellingProducts.length > 0 ? (
                <div className="space-y-3">
                  {bestSellingProducts.map((p, idx) => {
                    const rank = idx + 1;
                    const percentWidth = Math.max(10, Math.round((p.quantity / maxSoldQuantity) * 100));

                    let badgeClass = "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700";
                    if (rank === 1) badgeClass = "bg-amber-100 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-900/40";
                    else if (rank === 2) badgeClass = "bg-slate-200 dark:bg-slate-700 text-slate-850 dark:text-slate-200 border-slate-300 dark:border-slate-600";
                    else if (rank === 3) badgeClass = "bg-orange-50 dark:bg-amber-900/10 text-orange-700 dark:text-orange-400 border-orange-200/50 dark:border-orange-900/30";

                    return (
                      <div key={p.name} className="p-3 bg-slate-50/50 dark:bg-slate-850/50 border border-slate-100 dark:border-slate-800/80 rounded-2xl">
                        <div className="flex items-center gap-2.5 justify-between">
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className={`w-6 h-6 rounded-lg flex items-center justify-center font-black border text-[10px] shrink-0 ${badgeClass}`}>
                              {rank}
                            </div>
                            <div className="truncate">
                              <span className="font-bold text-xs text-slate-800 dark:text-slate-100 block truncate leading-tight">{p.name}</span>
                              <span className="text-[9px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">{p.category}</span>
                            </div>
                          </div>
                          <div className="text-right shrink-0">
                            <span className="text-xs font-black text-slate-800 dark:text-slate-100 block font-mono">{p.quantity} Pcs</span>
                          </div>
                        </div>

                        <div className="w-full bg-slate-200 dark:bg-slate-800 rounded-full h-1 mt-2.5 overflow-hidden">
                          <div 
                            className={`h-full rounded-full ${
                              rank === 1 ? 'bg-amber-500' : rank === 2 ? 'bg-blue-500' : 'bg-slate-400'
                            }`}
                            style={{ width: `${percentWidth}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <EmptyState
                  title="Produk Terlaris Kosong"
                  description="Analisis produk terpopuler akan otomatis muncul setelah transaksi penjualan divalidasi."
                  icon={<Award className="w-8 h-8 text-slate-350" />}
                />
              )}
            </SectionCard>
          </div>

          {/* Activity Timeline Widget */}
          <div className={activeMobileTab === 'activity' ? 'block' : 'hidden lg:block'}>
            <SectionCard
              title="Aktivitas Hari Ini"
              subtitle="Timeline operasional real-time"
              icon={<Activity className="w-4 h-4 text-blue-500" />}
            >
              <div className="space-y-1">
                {operationalTimeline.map((ev, index) => (
                  <ActivityTimelineItem
                    key={ev.id || index}
                    title={ev.title}
                    time={ev.time}
                    description={ev.description}
                    icon={ev.icon}
                    color={ev.color}
                    isLast={index === operationalTimeline.length - 1}
                  />
                ))}
              </div>
            </SectionCard>
          </div>

        </div>

      </div>

      {/* 6. SHIFT RECAP POPUP MODAL (PRINTING RECAP) */}
      {showShiftRecap && recapShift && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 pb-12 sm:pb-4 z-[200] overflow-y-auto">
          <div className="bg-white rounded-[24px] shadow-2xl max-w-sm w-full overflow-hidden border border-slate-150 animate-in fade-in zoom-in-95 duration-250 my-8">
            
            <div id="print-shift-recap" className="p-6 bg-white text-slate-800 font-mono text-xs">
              <div className="text-center space-y-1 pb-4 border-b border-dashed border-slate-300">
                <h3 className="font-extrabold text-base tracking-tight text-slate-900">REKAP TUTUP SIF</h3>
                <p className="text-[10px] text-slate-500 font-bold uppercase">{appConfig?.name || "MD POS CELL"}</p>
                <p className="text-[9px] text-slate-400">Laporan Tutupan Sif Otomatis</p>
              </div>

              <div className="py-4 space-y-1.5 border-b border-dashed border-slate-300 text-[11px] text-slate-600">
                <div className="flex justify-between">
                  <span>Sif ID:</span>
                  <span className="font-bold text-slate-900">{recapShift.id.split('-')[1] || recapShift.id}</span>
                </div>
                <div className="flex justify-between">
                  <span>Mulai Sif:</span>
                  <span>{new Date(recapShift.startTime).toLocaleTimeString('id-ID')}</span>
                </div>
                <div className="flex justify-between">
                  <span>Selesai Sif:</span>
                  <span>{recapShift.endTime ? new Date(recapShift.endTime).toLocaleTimeString('id-ID') : '-'}</span>
                </div>
                <div className="flex justify-between">
                  <span>Operator Sif:</span>
                  <span className="font-bold text-slate-900">{recapShift.cashierName}</span>
                </div>
                <div className="flex justify-between">
                  <span>Ditutup Oleh:</span>
                  <span>{recapShift.closedBy || '-'}</span>
                </div>
              </div>

              <div className="py-4 space-y-2 border-b border-dashed border-slate-300">
                <div className="flex justify-between font-bold text-slate-950 text-[11px]">
                  <span>MODAL AWAL LACI:</span>
                  <span>{formatRupiah(recapShift.initialCash)}</span>
                </div>
                {currentUser.role === 'admin' && (
                  <div className="flex justify-between text-slate-600 text-[11px]">
                    <span>TOTAL PENJUALAN SIF:</span>
                    <span className="font-bold text-slate-950">+{formatRupiah(recapShift.totalSales)}</span>
                  </div>
                )}
                {currentUser.role === 'admin' && recapShift.totalTransferSales && recapShift.totalTransferSales > 0 ? (
                  <div className="flex justify-between text-slate-600 text-[11px]">
                    <span>TRANSFER (NONTUNAI):</span>
                    <span className="font-bold text-blue-600">-{formatRupiah(recapShift.totalTransferSales)}</span>
                  </div>
                ) : null}
                <div className="flex justify-between text-slate-600 text-[11px]">
                  <span>TOTAL PENARIKAN LACI:</span>
                  <span className="font-bold text-rose-600">-{formatRupiah(recapShift.totalWithdrawals || 0)}</span>
                </div>
                {currentUser.role === 'admin' && (
                  <div className="flex justify-between text-slate-600 text-[11px]">
                    <span>KEUNTUNGAN SIF:</span>
                    <span className="font-bold text-emerald-600">+{formatRupiah(recapShift.totalProfit)}</span>
                  </div>
                )}
                {recapShift.totalDiscounts && recapShift.totalDiscounts > 0 ? (
                  <div className="flex justify-between text-rose-600 font-bold text-[11px]">
                    <span>TOTAL DISKON SIF:</span>
                    <span>-{formatRupiah(recapShift.totalDiscounts)}</span>
                  </div>
                ) : null}
                <div className="flex justify-between text-slate-600 text-[11px]">
                  <span>TOTAL TRANSAKSI SIF:</span>
                  <span>{recapShift.transactionCount} Item</span>
                </div>
              </div>

              {currentUser.role === 'admin' && (
                <div className="py-4 space-y-1.5">
                  <div className="flex flex-col bg-slate-50 p-3 rounded-xl border border-slate-200 text-center">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">TOTAL UANG LACI SEHARUSNYA:</span>
                    <span className="text-lg font-black text-slate-950 font-mono mt-1">
                      {formatRupiah(recapShift.initialCash + recapShift.totalSales - (recapShift.totalTransferSales || 0) - (recapShift.totalWithdrawals || 0))}
                    </span>
                  </div>
                </div>
              )}

              <div className="text-center pt-4 border-t border-dashed border-slate-300 space-y-1">
                <p className="font-bold text-slate-950 text-[10px]">REKAP SELESAI</p>
                <p className="text-[9px] text-slate-500">Silakan cocokan uang fisik di laci kasir.</p>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-100 flex space-x-2">
              <button
                type="button"
                onClick={handlePrint}
                className="flex-1 flex items-center justify-center py-2.5 px-3 bg-slate-900 hover:bg-black text-white rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer"
              >
                <Printer className="w-4 h-4 mr-1.5" />
                Cetak Laporan
              </button>
              <button
                type="button"
                onClick={() => setShowShiftRecap(false)}
                className="py-2.5 px-4 bg-white hover:bg-slate-150 border border-slate-200 text-slate-600 rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                Tutup
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
