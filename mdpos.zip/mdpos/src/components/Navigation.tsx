import { useState, useMemo, useRef, FormEvent, useEffect } from 'react';
import { Role, User, Product, EWallet, Shift } from '../types';
import { 
  LayoutDashboard, 
  Receipt, 
  ArrowDownLeft, 
  ShoppingBag, 
  CreditCard, 
  Wallet, 
  Layers, 
  BarChart3, 
  Users as UsersIcon, 
  Settings, 
  Info, 
  LogOut, 
  ChevronLeft, 
  ChevronRight, 
  Search, 
  Menu as MenuIcon, 
  X,
  Sun,
  Moon,
  BookOpen,
  Lock,
  ShieldAlert,
  Check,
  History,
  QrCode
} from 'lucide-react';
import { AppConfig } from './SettingsView';

export type ActiveTab = 'dashboard' | 'pos' | 'withdrawal' | 'physical_pos' | 'edc_transfer' | 'products' | 'ewallets' | 'reports' | 'accounting' | 'users' | 'settings' | 'about' | 'vouchers' | 'logs';


interface NavigationProps {
  currentUser: User;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onLogout: () => void;
  products?: Product[];
  eWallets?: EWallet[];
  currentShift?: Shift | null;
  appConfig?: AppConfig;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  users?: User[];
  onEditUser?: (id: string, updatedUser: Partial<User>) => void;
  onScanClick?: () => void;
}

export default function Navigation({ 
  currentUser, 
  activeTab, 
  setActiveTab, 
  onLogout,
  products = [],
  eWallets = [],
  currentShift = null,
  appConfig = {
    name: 'MD POS',
    slogan: 'KONTER POS MODERN',
    lowStockLimit: 5,
    currency: 'Rp',
    receiptFooter: 'Terima kasih telah berbelanja!',
  },
  theme,
  toggleTheme,
  users = [],
  onEditUser,
  onScanClick
}: NavigationProps) {
  const isAdmin = currentUser.role === 'admin';

  // Profile Edit / SaaS settings states
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [profileName, setProfileName] = useState(currentUser.name);
  const [profileUsername, setProfileUsername] = useState(currentUser.username);
  const [profileEmail, setProfileEmail] = useState(currentUser.email);
  const [profileAvatarColor, setProfileAvatarColor] = useState(currentUser.avatarColor);
  const [profilePassword, setProfilePassword] = useState('');
  const [profileError, setProfileError] = useState('');
  const [profileSuccess, setProfileSuccess] = useState('');
  const [logoError, setLogoError] = useState(false);

  const handleOpenProfileModal = () => {
    setProfileName(currentUser.name);
    setProfileUsername(currentUser.username);
    setProfileEmail(currentUser.email);
    setProfileAvatarColor(currentUser.avatarColor);
    setProfilePassword('');
    setProfileError('');
    setProfileSuccess('');
    setIsProfileModalOpen(true);
  };

  const handleSaveProfile = (e: FormEvent) => {
    e.preventDefault();
    setProfileError('');
    setProfileSuccess('');

    if (!profileName.trim() || !profileUsername.trim() || !profileEmail.trim()) {
      setProfileError('Semua kolom wajib diisi.');
      return;
    }

    const cleanUsername = profileUsername.toLowerCase().trim().replace(/\s+/g, '');

    // Check duplicate username against other users
    if (users && onEditUser) {
      const isDuplicate = users.some(
        (u) => u.username === cleanUsername && u.id !== currentUser.id
      );
      if (isDuplicate) {
        setProfileError('Username sudah digunakan oleh operator lain.');
        return;
      }

      const payload: any = {
        name: profileName.trim(),
        username: cleanUsername,
        email: profileEmail.trim(),
        avatarColor: profileAvatarColor,
      };

      if (profilePassword.trim() !== '') {
        payload.password = profilePassword;
      }

      onEditUser(currentUser.id, payload);

      setProfileSuccess('Profil berhasil diperbarui!');
      setTimeout(() => {
        setIsProfileModalOpen(false);
      }, 1500);
    }
  };

  // Responsive Drawer/Sidebar states
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  useEffect(() => {
    if (isDrawerOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isDrawerOpen]);
  const [isCollapsed, setIsCollapsed] = useState(() => {
    const saved = localStorage.getItem('pos_sidebar_collapsed');
    return saved ? JSON.parse(saved) : false;
  });
  const [searchQuery, setSearchQuery] = useState('');
  const searchInputRef = useRef<HTMLInputElement>(null);

  const [isGlobalScannerOpen, setIsGlobalScannerOpen] = useState(false);

  useEffect(() => {
    const handleScannerStatus = (e: any) => {
      setIsGlobalScannerOpen(!!e.detail.isOpen);
    };
    window.addEventListener('scanner-status', handleScannerStatus);
    return () => {
      window.removeEventListener('scanner-status', handleScannerStatus);
    };
  }, []);

  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      if (width >= 768 && width < 1024) {
        setIsCollapsed(true);
      } else if (width >= 1024) {
        const saved = localStorage.getItem('pos_sidebar_collapsed');
        setIsCollapsed(saved ? JSON.parse(saved) : false);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Keyboard shortcut (Ctrl+K or Cmd+K) to focus menu search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isCollapsed) {
          setIsCollapsed(false);
        }
        setTimeout(() => {
          searchInputRef.current?.focus();
        }, 50);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isCollapsed]);

  const toggleCollapse = () => {
    const newVal = !isCollapsed;
    setIsCollapsed(newVal);
    localStorage.setItem('pos_sidebar_collapsed', JSON.stringify(newVal));
  };

  const handleSearchClick = () => {
    if (isCollapsed) {
      setIsCollapsed(false);
      setTimeout(() => searchInputRef.current?.focus(), 100);
    }
  };

  // Badges calculation
  const lowStockCount = useMemo(() => {
    return products.filter(p => {
      // Only count physical goods and vouchers that track inventory
      const isPhysicalOrVoucher = p.category === 'barang_fisik' || p.category === 'voucher_fisik' || (p.barcodeType && p.barcodeType !== 'none');
      if (!isPhysicalOrVoucher) return false;
      const limit = p.minStockLimit ?? appConfig?.lowStockLimit ?? 5;
      return p.stock <= limit;
    }).length;
  }, [products, appConfig]);

  const lowBalanceCount = useMemo(() => {
    return eWallets.filter(w => {
      // Exclude cash drawer from low digital balance alert
      if (w.id === 'cash' || w.name.toLowerCase().includes('tunai') || w.name.toLowerCase().includes('laci')) return false;
      if (!w.isActive) return false;
      return w.balance < 100000;
    }).length;
  }, [eWallets]);

  // Menu items config with categories
  const menuItems = [
    { id: 'dashboard', name: 'Dashboard Konten', nameShort: 'Dash', icon: LayoutDashboard, category: 'Utama', adminOnly: false },
    { id: 'pos', name: 'Transaksi POS', nameShort: 'Transaksi', icon: Receipt, category: 'Utama', adminOnly: false },
    
    { id: 'physical_pos', name: 'POS Item Fisik', nameShort: 'Fisik', icon: ShoppingBag, category: 'Transaksi Khusus', adminOnly: false },
    { id: 'edc_transfer', name: 'Transfer via EDC', nameShort: 'EDC', icon: CreditCard, category: 'Transaksi Khusus', adminOnly: false },
    { id: 'withdrawal', name: 'Tarik Tunai', nameShort: 'Tarik', icon: ArrowDownLeft, category: 'Transaksi Khusus', adminOnly: false },
    
    { id: 'products', name: 'Stok Produk', nameShort: 'Stok', icon: Layers, category: 'Manajemen', adminOnly: true },
    { id: 'vouchers', name: 'Barcode Center', nameShort: 'Barcode', icon: Layers, category: 'Manajemen', adminOnly: true },
    { id: 'ewallets', name: 'E-Wallet', nameShort: 'Wallet', icon: Wallet, category: 'Manajemen', adminOnly: true },
    { id: 'reports', name: isAdmin ? 'Laporan Penjualan' : 'Riwayat Transaksi', nameShort: isAdmin ? 'Laporan' : 'Riwayat', icon: isAdmin ? BarChart3 : History, category: isAdmin ? 'Manajemen' : 'Utama', adminOnly: false },
    { id: 'accounting', name: 'Pembukuan (Accounting)', nameShort: 'Pembukuan', icon: BookOpen, category: 'Manajemen', adminOnly: true },
    { id: 'users', name: 'Operator', nameShort: 'Operator', icon: UsersIcon, category: 'Manajemen', adminOnly: true },
    
    { id: 'settings', name: 'Pengaturan', nameShort: 'Atur', icon: Settings, category: 'Sistem', adminOnly: true },
    { id: 'logs', name: 'Log Sistem & Error', nameShort: 'Log', icon: ShieldAlert, category: 'Sistem', adminOnly: true },
    { id: 'about', name: 'Tentang Aplikasi', nameShort: 'Tentang', icon: Info, category: 'Sistem', adminOnly: false },
  ] as const;

  // Filtered menu items based on Search and Admin Role
  const filteredMenuItems = useMemo(() => {
    return menuItems.filter(item => {
      if (item.adminOnly && !isAdmin) return false;
      if (!searchQuery) return true;
      return item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
             item.category.toLowerCase().includes(searchQuery.toLowerCase());
    });
  }, [searchQuery, isAdmin]);

  // Categories present in filtered list
  const categories = useMemo(() => {
    const list = new Set<string>();
    filteredMenuItems.forEach(item => list.add(item.category));
    return Array.from(list);
  }, [filteredMenuItems]);

  // Helper to render badge on side item
  const renderBadge = (id: string, isSidebarCollapsed: boolean) => {
    if (id === 'products' && lowStockCount > 0) {
      return (
        <span className={`bg-rose-500 text-white font-extrabold flex items-center justify-center rounded-full shrink-0 ${
          isSidebarCollapsed 
            ? 'absolute top-1 right-1 w-4 h-4 text-[8px]' 
            : 'px-2 py-0.5 text-[10px]'
        }`}>
          {lowStockCount}
        </span>
      );
    }
    if (id === 'ewallets' && lowBalanceCount > 0) {
      return (
        <span className={`bg-amber-500 text-white font-extrabold flex items-center justify-center rounded-full shrink-0 ${
          isSidebarCollapsed 
            ? 'absolute top-1 right-1 w-4 h-4 text-[8px]' 
            : 'px-2 py-0.5 text-[10px]'
        }`}>
          {lowBalanceCount}
        </span>
      );
    }
    if (id === 'dashboard' && currentShift) {
      return (
        <span className={`bg-emerald-500 text-white font-bold flex items-center justify-center rounded-full shrink-0 ${
          isSidebarCollapsed 
            ? 'absolute top-1 right-1 w-2.5 h-2.5 animate-pulse' 
            : 'px-1.5 py-0.5 text-[8px] tracking-wider uppercase'
        }`}>
          {isSidebarCollapsed ? '' : 'Open'}
        </span>
      );
    }
    return null;
  };

  if (isGlobalScannerOpen) {
    return null;
  }

  const activeItemLabel = menuItems.find(i => i.id === activeTab)?.name || 'MD POS';

  return (
    <>
      {/* ========================================== */}
      {/* MOBILE TOP BAR                             */}
      {/* ========================================== */}
      <div id="mobile-top-bar" className={`lg:hidden flex items-center justify-between px-4 py-3 sticky top-0 z-30 shadow-xs transition-all duration-200 glass-nav ${
        theme === 'dark' ? 'text-slate-100' : 'text-slate-800'
      }`}>
        <div className="flex items-center space-x-3">
          <button 
            onClick={() => setIsDrawerOpen(true)}
            className={`p-1.5 rounded-xl transition-colors focus:outline-none ${
              theme === 'dark' ? 'text-slate-300 hover:bg-slate-800' : 'text-slate-600 hover:bg-slate-100'
            }`}
            title="Menu Drawer"
          >
            <MenuIcon className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-2">
            {!logoError ? (
              <img 
                src={appConfig.logoUrl || "/logo.png"} 
                alt="Logo" 
                onError={(e) => {
                  if (e.currentTarget.src !== window.location.origin + "/logo.png") {
                    e.currentTarget.src = "/logo.png";
                  } else {
                    setLogoError(true);
                  }
                }} 
                className="w-8 h-8 object-contain shrink-0 rounded-lg shadow-2xs" 
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-black text-sm shadow-sm shadow-indigo-600/20">
                {appConfig.name.charAt(0)}
              </div>
            )}
            <div className="flex flex-col">
              <span className={`font-black tracking-tight text-xs leading-none transition-colors duration-200 ${theme === 'dark' ? 'text-slate-100' : 'text-slate-900'}`}>{appConfig.name}</span>
              <span className={`text-[8px] font-bold uppercase tracking-wider mt-0.5 transition-colors duration-200 ${theme === 'dark' ? 'text-slate-400' : 'text-slate-400'}`}>{appConfig.slogan}</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          {/* Global Theme Toggle (Mobile) */}
          <button
            type="button"
            onClick={toggleTheme}
            className={`p-1.5 rounded-xl transition-colors focus:outline-none ${
              theme === 'dark' ? 'text-amber-400 hover:bg-slate-800' : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100'
            }`}
            title={theme === 'dark' ? "Mode Terang" : "Mode Gelap"}
          >
            {theme === 'dark' ? <Sun className="w-4.5 h-4.5 text-amber-500" /> : <Moon className="w-4.5 h-4.5" />}
          </button>

          <button
            type="button"
            onClick={handleOpenProfileModal}
            className={`flex items-center space-x-1.5 px-2.5 py-1 rounded-full border transition-all duration-200 cursor-pointer hover:scale-105 active:scale-95 ${
              theme === 'dark' ? 'bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-100' : 'bg-slate-50 border border-slate-200/60 hover:bg-slate-100 text-slate-800'
            }`}
            title="Edit Profil Saya"
          >
            <div className={`w-4 h-4 rounded-full ${currentUser.avatarColor} text-white flex items-center justify-center font-bold text-[8px]`}>
              {currentUser.name.charAt(0)}
            </div>
            <span className={`text-[9px] font-bold truncate max-w-[70px] ${theme === 'dark' ? 'text-slate-300' : 'text-slate-600'}`}>
              {currentUser.name.split(' ')[0]}
            </span>
          </button>
        </div>
      </div>

      {/* ========================================== */}
      {/* MOBILE BOTTOM NAVIGATION (Premium Floating Dock with Single Continuous SVG Notch) */}
      {/* ========================================== */}
      <div className="lg:hidden fixed bottom-3 sm:bottom-4 left-3 right-3 sm:left-6 sm:right-6 max-w-lg mx-auto h-[62px] z-40 pointer-events-auto">
        {/* Single Continuous SVG Background Dock Layer with Seamless Deep Notch */}
        <div 
          className="absolute inset-0 pointer-events-none z-0 transition-all duration-300"
          style={{
            filter: theme === 'dark' 
              ? 'drop-shadow(0 16px 36px rgba(0, 0, 0, 0.45))' 
              : 'drop-shadow(0 12px 28px rgba(0, 0, 0, 0.12))'
          }}
        >
          <svg 
            className="w-full h-full text-white/95 dark:text-slate-900/95 backdrop-blur-xl" 
            viewBox="0 0 400 62" 
            preserveAspectRatio="none"
          >
            <path 
              d="M 28,0 L 138,0 C 160,0 166,33 200,33 C 234,33 240,0 262,0 L 372,0 A 28,28 0 0 1 400,28 L 400,34 A 28,28 0 0 1 372,62 L 28,62 A 28,28 0 0 1 0,34 L 0,28 A 28,28 0 0 1 28,0 Z" 
              fill="currentColor"
              stroke={theme === 'dark' ? 'rgba(51, 65, 85, 0.85)' : 'rgba(226, 232, 240, 0.85)'}
              strokeWidth="1.5"
              vectorEffect="non-scaling-stroke"
            />
          </svg>
        </div>

        {/* Floating Navigation Items Bar */}
        <nav 
          id="mobile-bottom-nav" 
          className="relative w-full h-full flex items-center justify-between px-2 z-20"
        >
          {/* Item 1: Dashboard */}
          <button
            type="button"
            onClick={() => setActiveTab('dashboard')}
            className="flex flex-col items-center justify-center py-1 focus:outline-none transition-all active:scale-95 touch-manipulation flex-1 group z-20"
          >
            <div className={`p-1.5 px-3 rounded-2xl mb-0.5 transition-all duration-200 ${
              activeTab === 'dashboard' 
                ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 scale-105 shadow-xs' 
                : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 group-hover:scale-105'
            }`}>
              <LayoutDashboard className="w-5 h-5 transition-transform group-active:scale-90" />
            </div>
            <span className={`text-[10px] tracking-tight transition-all duration-200 ${
              activeTab === 'dashboard' 
                ? 'text-blue-600 dark:text-blue-400 font-extrabold' 
                : 'text-slate-500 dark:text-slate-400 font-semibold'
            }`}>
              Dashboard
            </span>
          </button>

          {/* Item 2: Transaksi */}
          <button
            type="button"
            onClick={() => setActiveTab('pos')}
            className="flex flex-col items-center justify-center py-1 focus:outline-none transition-all active:scale-95 touch-manipulation flex-1 group z-20"
          >
            <div className={`p-1.5 px-3 rounded-2xl mb-0.5 transition-all duration-200 ${
              activeTab === 'pos' 
                ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 scale-105 shadow-xs' 
                : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 group-hover:scale-105'
            }`}>
              <Receipt className="w-5 h-5 transition-transform group-active:scale-90" />
            </div>
            <span className={`text-[10px] tracking-tight transition-all duration-200 ${
              activeTab === 'pos' 
                ? 'text-blue-600 dark:text-blue-400 font-extrabold' 
                : 'text-slate-500 dark:text-slate-400 font-semibold'
            }`}>
              Transaksi
            </span>
          </button>

          {/* Item 3: [SCAN BARCODE] Floating Action Button inside Concave Notch */}
          <div className="flex-1 relative flex flex-col items-center justify-end pb-1 h-full z-30">
            {/* Floating Action Button (FAB) */}
            <button
              type="button"
              onClick={() => {
                if (onScanClick) {
                  onScanClick();
                }
              }}
              className={`absolute -top-[32px] left-1/2 -translate-x-1/2 w-14 h-14 rounded-full flex flex-col items-center justify-center transition-all duration-300 ease-out active:scale-92 hover:scale-105 cursor-pointer z-50 overflow-hidden ${
                !currentShift
                  ? 'bg-slate-200/90 dark:bg-slate-800/90 text-slate-700 dark:text-slate-200 border border-slate-300/80 dark:border-slate-700/80 shadow-[0_8px_20px_rgba(0,0,0,0.12)] dark:shadow-[0_10px_24px_rgba(0,0,0,0.35)]'
                  : 'bg-gradient-to-tr from-blue-700 via-blue-600 to-indigo-500 text-white shadow-[0_12px_28px_rgba(37,99,235,0.45)] dark:shadow-[0_14px_32px_rgba(37,99,235,0.55)] hover:shadow-[0_16px_36px_rgba(37,99,235,0.6)]'
              }`}
            >
              {/* Subtle inner highlight */}
              <span className="absolute inset-0 rounded-full bg-white/10 opacity-50 pointer-events-none" />

              {/* Ripple Flash Effect */}
              <span className="absolute inset-0 bg-white/25 rounded-full scale-0 active:scale-100 transition-all duration-300 pointer-events-none opacity-0 active:opacity-100" />
              
              <QrCode className="w-6.5 h-6.5 relative z-10" />
              
              {/* Lock badge if shift closed */}
              {!currentShift && (
                <div className="absolute top-1 right-1 bg-amber-500 text-white p-0.5 rounded-full border border-white dark:border-slate-900 shadow-xs animate-bounce z-20">
                  <Lock className="w-2.5 h-2.5 font-bold" />
                </div>
              )}
            </button>
            
            {/* Scan Label below button */}
            <span className="text-[10px] font-bold tracking-tight text-slate-500 dark:text-slate-400">
              Scan
            </span>
          </div>

          {/* Item 4: Laporan / Riwayat */}
          <button
            type="button"
            onClick={() => setActiveTab('reports')}
            className="flex flex-col items-center justify-center py-1 focus:outline-none transition-all active:scale-95 touch-manipulation flex-1 group z-20"
          >
            <div className={`p-1.5 px-3 rounded-2xl mb-0.5 transition-all duration-200 ${
              activeTab === 'reports' 
                ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 scale-105 shadow-xs' 
                : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 group-hover:scale-105'
            }`}>
              {isAdmin ? (
                <BarChart3 className="w-5 h-5 transition-transform group-active:scale-90" />
              ) : (
                <History className="w-5 h-5 transition-transform group-active:scale-90" />
              )}
            </div>
            <span className={`text-[10px] tracking-tight transition-all duration-200 ${
              activeTab === 'reports' 
                ? 'text-blue-600 dark:text-blue-400 font-extrabold' 
                : 'text-slate-500 dark:text-slate-400 font-semibold'
            }`}>
              {isAdmin ? 'Laporan' : 'Riwayat'}
            </span>
          </button>

          {/* Item 5: Menu */}
          <button
            type="button"
            onClick={() => setIsDrawerOpen(true)}
            className="flex flex-col items-center justify-center py-1 focus:outline-none transition-all active:scale-95 touch-manipulation flex-1 group z-20"
          >
            <div className={`p-1.5 px-3 rounded-2xl mb-0.5 transition-all duration-200 ${
              isDrawerOpen
                ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 scale-105 shadow-xs' 
                : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 group-hover:scale-105'
            }`}>
              <MenuIcon className="w-5 h-5 transition-transform group-active:scale-90" />
            </div>
            <span className={`text-[10px] tracking-tight transition-colors duration-200 ${
              isDrawerOpen
                ? 'text-blue-600 dark:text-blue-400 font-extrabold' 
                : 'text-slate-500 dark:text-slate-400 font-semibold'
            }`}>
              Menu
            </span>
          </button>
        </nav>
      </div>

      {/* ========================================== */}
      {/* MOBILE NAVIGATION DRAWER (HAMBURGER)      */}
      {/* ========================================== */}
      {isDrawerOpen && (
        <div 
          id="mobile-drawer-overlay" 
          onClick={() => setIsDrawerOpen(false)}
          className="lg:hidden fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[100] transition-opacity cursor-pointer animate-fade-in"
        >
          <div 
            onClick={(e) => e.stopPropagation()}
            className="fixed inset-y-0 left-0 max-w-[280px] w-[80vw] bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 shadow-2xl flex flex-col h-full overflow-hidden z-[101] border-r border-slate-200 dark:border-slate-800 cursor-default"
          >
            {/* Drawer Header */}
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center space-x-2">
                {!logoError ? (
                  <img 
                    src={appConfig.logoUrl || "/logo.png"} 
                    alt="Logo" 
                    onError={(e) => {
                      if (e.currentTarget.src !== window.location.origin + "/logo.png") {
                        e.currentTarget.src = "/logo.png";
                      } else {
                        setLogoError(true);
                      }
                    }} 
                    className="w-8 h-8 object-contain shrink-0 rounded-lg shadow-2xs" 
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-8 h-8 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-black text-sm">
                    {appConfig.name.charAt(0)}
                  </div>
                )}
                <div>
                  <h2 className="font-extrabold text-slate-900 text-sm leading-none">{appConfig.name}</h2>
                  <span className="text-[8px] text-slate-400 font-semibold tracking-wider uppercase mt-1 block">{appConfig.slogan}</span>
                </div>
              </div>
              <button 
                onClick={() => setIsDrawerOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:bg-slate-150 hover:text-slate-700 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Drawer Search */}
            <div className="p-3 border-b border-slate-100">
              <div className="flex items-center space-x-2 px-3 py-2 bg-slate-100 rounded-[16px]">
                <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <input
                  type="text"
                  placeholder="Cari fitur/menu..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-transparent border-none text-xs focus:outline-none placeholder-slate-400 text-slate-700 font-medium"
                />
                {searchQuery && (
                  <button onClick={() => setSearchQuery('')} className="p-0.5 hover:bg-slate-200 rounded-full">
                    <X className="w-3 h-3 text-slate-400" />
                  </button>
                )}
              </div>
            </div>

            {/* Drawer Menu List */}
            <div className="flex-1 overflow-y-auto p-3 space-y-4">
              {categories.map((category) => (
                <div key={category} className="space-y-1">
                  <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-wider px-3 py-1">
                    {category}
                  </h3>
                  <div className="space-y-0.5">
                    {filteredMenuItems
                      .filter(item => item.category === category)
                      .map((item) => {
                        const isSelected = activeTab === item.id;
                        const Icon = item.icon;
                        return (
                          <button
                            key={item.id}
                            onClick={() => {
                              setActiveTab(item.id as ActiveTab);
                              setIsDrawerOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-[16px] font-bold text-xs transition-all ${
                              isSelected
                                ? 'glass-selected'
                                : 'text-slate-600 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:text-slate-300'
                            }`}
                          >
                            <div className="flex items-center space-x-2.5">
                              <Icon className={`w-4 h-4 ${isSelected ? 'text-white' : 'text-slate-400'}`} />
                              <span>{item.name}</span>
                            </div>
                            {renderBadge(item.id, false)}
                          </button>
                        );
                      })}
                  </div>
                </div>
              ))}

              {filteredMenuItems.length === 0 && (
                <div className="text-center py-8 text-slate-400">
                  <p className="text-xs font-semibold">Tidak ada menu ditemukan</p>
                </div>
              )}
            </div>

            {/* Drawer Profile & Theme & Logout */}
            <div className="p-3 border-t border-slate-100 bg-slate-50 space-y-2">
              <div className="flex items-center justify-between px-2.5 py-2.5 bg-white border border-slate-200/60 rounded-[16px] shadow-xs">
                <div className="flex items-center space-x-2">
                  {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-500" /> : <Moon className="w-4 h-4 text-slate-400" />}
                  <span className="text-xs font-bold text-slate-600">Mode Gelap</span>
                </div>
                <button
                  type="button"
                  onClick={toggleTheme}
                  className="px-2.5 py-1 text-[10px] font-black uppercase tracking-wide bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg transition-all"
                >
                  {theme === 'dark' ? 'Nonaktif' : 'Aktifkan'}
                </button>
              </div>
              <button
                type="button"
                onClick={handleOpenProfileModal}
                className="w-full flex items-center space-x-2.5 px-2.5 py-2 rounded-[16px] bg-white hover:bg-slate-50 border border-slate-200/60 shadow-xs cursor-pointer text-left transition-all"
                title="Edit Profil Saya"
              >
                <div className={`w-8 h-8 rounded-xl ${currentUser.avatarColor} text-white flex items-center justify-center font-bold text-xs`}>
                  {currentUser.name.charAt(0)}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-bold text-slate-800 text-xs truncate leading-none">{currentUser.name}</p>
                  <span className="text-[8px] bg-slate-100 border border-slate-200 text-slate-500 px-1.5 py-0.5 rounded-md font-bold uppercase tracking-wider mt-1 inline-block">
                    {isAdmin ? 'Admin' : 'Kasir'}
                  </span>
                </div>
              </button>
              <button
                onClick={onLogout}
                className="w-full flex items-center space-x-2 px-3 py-2.5 rounded-[16px] font-bold text-xs text-rose-600 hover:bg-rose-50 hover:text-rose-700 transition-all"
              >
                <LogOut className="w-4 h-4" />
                <span>Keluar Akun</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================== */}
      {/* DESKTOP SIDEBAR NAVIGATION (MD3 STYLE)     */}
      {/* ========================================== */}
      <aside 
        id="desktop-sidebar" 
        className={`hidden lg:flex flex-col sticky top-0 h-screen transition-[width] duration-300 shadow-xs z-30 glass-sidebar select-none ${
          theme === 'dark' ? 'text-slate-100' : 'text-slate-800'
        } ${
          isCollapsed ? 'w-[68px]' : 'w-[260px]'
        }`}
      >
        {/* Brand Header */}
        <div className={`p-4 border-b flex items-center transition-all ${
          theme === 'dark' ? 'border-slate-800' : 'border-slate-100'
        } ${
          isCollapsed ? 'justify-center' : 'justify-between'
        }`}>
          {!isCollapsed ? (
            <div className="flex items-center justify-between w-full">
              <div className="flex items-center space-x-3 min-w-0">
                {!logoError ? (
                  <img 
                    src={appConfig.logoUrl || "/logo.png"} 
                    alt="Logo" 
                    onError={(e) => {
                      if (e.currentTarget.src !== window.location.origin + "/logo.png") {
                        e.currentTarget.src = "/logo.png";
                      } else {
                        setLogoError(true);
                      }
                    }} 
                    className="w-10 h-10 object-contain shrink-0 rounded-xl shadow-2xs" 
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-[16px] bg-indigo-600 flex items-center justify-center text-white font-black text-lg shadow-md shadow-indigo-600/20 shrink-0">
                    {appConfig.name.charAt(0)}
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <h1 className={`font-black leading-none tracking-tight text-base truncate ${theme === 'dark' ? 'text-slate-100' : 'text-slate-900'}`}>{appConfig.name}</h1>
                  <span className="text-[9px] text-slate-400 font-bold tracking-wider uppercase mt-1 block truncate">{appConfig.slogan}</span>
                </div>
              </div>
              <button
                onClick={toggleCollapse}
                className={`p-1.5 rounded-xl transition-colors focus:outline-none shrink-0 ml-2 ${
                  theme === 'dark' ? 'text-slate-400 hover:bg-slate-800 hover:text-slate-200' : 'text-slate-400 hover:bg-slate-100 hover:text-slate-700'
                }`}
                title="Collapse Sidebar"
              >
                <MenuIcon className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <button
              onClick={toggleCollapse}
              className={`p-2.5 rounded-[16px] transition-colors focus:outline-none shrink-0 ${
                theme === 'dark' ? 'text-slate-400 hover:bg-slate-800 hover:text-slate-200' : 'text-slate-400 hover:bg-slate-100 hover:text-slate-700'
              }`}
              title="Expand Sidebar"
            >
              <MenuIcon className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Menu Search Bar */}
        {!isCollapsed ? (
          <div className={`p-3 border-b transition-colors ${theme === 'dark' ? 'border-slate-800/80 bg-slate-900/40' : 'border-slate-100 bg-slate-50/60'}`}>
            <div className={`group relative flex items-center space-x-2 px-3 py-2 transition-all rounded-xl border ${
              theme === 'dark' 
                ? 'bg-slate-800/80 border-slate-700/60 focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-500/20 focus-within:bg-slate-800' 
                : 'bg-white border-slate-200/80 shadow-3xs focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-500/15 focus-within:bg-white'
            }`}>
              <Search className="w-3.5 h-3.5 text-slate-400 group-focus-within:text-indigo-500 transition-colors shrink-0" />
              <input
                ref={searchInputRef}
                type="text"
                placeholder="Cari menu POS..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={`w-full bg-transparent border-none text-xs focus:outline-none placeholder-slate-400 font-semibold ${
                  theme === 'dark' ? 'text-slate-100' : 'text-slate-800'
                }`}
              />
              {searchQuery ? (
                <button 
                  onClick={() => setSearchQuery('')} 
                  className="p-1 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors shrink-0 cursor-pointer"
                  title="Bersihkan Pencarian"
                >
                  <X className="w-3 h-3" />
                </button>
              ) : (
                <kbd className="hidden lg:inline-flex items-center gap-0.5 text-[9px] font-mono px-1.5 py-0.5 rounded-md font-bold tracking-tight text-slate-400 bg-slate-100 dark:bg-slate-700/60 border border-slate-200 dark:border-slate-600/60 shrink-0 select-none">
                  Ctrl+K
                </kbd>
              )}
            </div>
          </div>
        ) : (
          <div className="p-3 border-b border-slate-100 dark:border-slate-800 flex justify-center bg-slate-50/50 dark:bg-slate-900/30">
            <button 
              onClick={handleSearchClick}
              className="p-2.5 rounded-xl text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 transition-all shrink-0 cursor-pointer group"
              title="Cari Menu (Ctrl+K)"
            >
              <Search className="w-4 h-4 group-hover:scale-110 transition-transform" />
            </button>
          </div>
        )}

        {/* Menu Items with Categories */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-4">
          {categories.map((category) => (
            <div key={category} className="space-y-1">
              {!isCollapsed && (
                <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-wider px-3.5 py-1 block">
                  {category}
                </h3>
              )}
              <div className="space-y-0.5">
                {filteredMenuItems
                  .filter(item => item.category === category)
                  .map((item) => {
                    const isSelected = activeTab === item.id;
                    const Icon = item.icon;
                    return (
                      <button
                        key={item.id}
                        onClick={() => setActiveTab(item.id as ActiveTab)}
                        className={`w-full flex items-center rounded-[16px] font-bold text-xs transition-all relative ${
                          isCollapsed ? 'justify-center p-3' : 'justify-between px-3.5 py-3'
                        } ${
                          isSelected
                            ? 'glass-selected'
                            : theme === 'dark'
                              ? 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                              : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                        }`}
                        title={isCollapsed ? item.name : undefined}
                      >
                        <div className="flex items-center space-x-3">
                          <Icon className={`w-4 h-4 shrink-0 ${isSelected ? 'text-white' : 'text-slate-400'}`} />
                          {!isCollapsed && <span className="truncate">{item.name}</span>}
                        </div>
                        <div className="flex items-center space-x-1 shrink-0">
                          {item.adminOnly && !isAdmin && !isCollapsed && (
                            <Lock className="w-3 h-3 text-slate-400 shrink-0" />
                          )}
                          {renderBadge(item.id, isCollapsed)}
                        </div>
                      </button>
                    );
                  })}
              </div>
            </div>
          ))}

          {filteredMenuItems.length === 0 && (
            <div className="text-center py-8 text-slate-400">
              {!isCollapsed ? (
                <p className="text-xs font-semibold">Tidak ada menu ditemukan</p>
              ) : (
                <X className="w-4 h-4 mx-auto" />
              )}
            </div>
          )}
        </nav>

        {/* Collapsible Sidebar Footer */}
        <div className={`mt-auto shrink-0 p-3 border-t space-y-2 ${
          theme === 'dark' ? 'border-slate-800 bg-slate-900/50' : 'border-slate-100 bg-slate-50/50'
        }`}>
          {/* Global Theme Toggle (Desktop) */}
          {!isCollapsed ? (
            <button
              type="button"
              onClick={toggleTheme}
              className={`w-full flex items-center justify-between px-3.5 py-2 border rounded-[16px] shadow-xs transition-all text-xs font-bold focus:outline-none ${
                theme === 'dark' 
                  ? 'bg-slate-850 border-slate-750 text-slate-300 hover:bg-slate-800' 
                  : 'bg-white border-slate-200/60 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                {theme === 'dark' ? (
                  <Sun className="w-4 h-4 text-amber-500 shrink-0" />
                ) : (
                  <Moon className="w-4 h-4 text-slate-400 shrink-0" />
                )}
                <span>Mode Gelap</span>
              </div>
              <span className={`text-[9px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded ${
                theme === 'dark' ? 'bg-indigo-500 text-white' : 'bg-slate-100 text-slate-500'
              }`}>
                {theme === 'dark' ? 'Aktif' : 'Off'}
              </span>
            </button>
          ) : (
            <button 
              type="button"
              onClick={toggleTheme}
              className={`w-10 h-10 rounded-xl border flex items-center justify-center shadow-xs hover:scale-105 active:scale-95 transition-all mx-auto focus:outline-none ${
                theme === 'dark' 
                  ? 'bg-slate-800 border-slate-750 text-slate-300 hover:bg-slate-750' 
                  : 'bg-white border-slate-200/60 text-slate-500 hover:bg-slate-50'
              }`}
              title={theme === 'dark' ? "Mode Terang" : "Mode Gelap"}
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-500" /> : <Moon className="w-4 h-4 text-slate-400" />}
            </button>
          )}

          {/* Active Operator Badge */}
          {!isCollapsed ? (
            <button
              type="button"
              onClick={handleOpenProfileModal}
              className={`w-full flex items-center space-x-2.5 px-3 py-2.5 border rounded-[16px] shadow-xs hover:scale-[1.02] cursor-pointer text-left transition-all ${
                theme === 'dark' ? 'bg-slate-850 border-slate-750 hover:bg-slate-800' : 'bg-white border-slate-200/60 hover:bg-slate-100'
              }`}
              title="Ubah Profil & Username Saya"
            >
              <div className={`w-9 h-9 rounded-xl ${currentUser.avatarColor} text-white flex items-center justify-center font-bold text-sm shrink-0 shadow-xs`}>
                {currentUser.name.charAt(0)}
              </div>
              <div className="min-w-0 flex-1">
                <p className={`font-bold text-xs truncate leading-none ${theme === 'dark' ? 'text-slate-250' : 'text-slate-800'}`}>{currentUser.name}</p>
                <div className="flex items-center space-x-1.5 mt-1">
                  {isAdmin ? (
                    <span className="text-[8px] bg-emerald-50 text-emerald-600 border border-emerald-200/50 px-1.5 py-0.5 rounded font-black uppercase tracking-wider">
                      Admin
                    </span>
                  ) : (
                    <span className="text-[8px] bg-indigo-50 text-indigo-600 border border-indigo-200/50 px-1.5 py-0.5 rounded font-black uppercase tracking-wider">
                      Kasir
                    </span>
                  )}
                </div>
              </div>
            </button>
          ) : (
            <button 
              type="button"
              onClick={handleOpenProfileModal}
              className={`w-10 h-10 rounded-xl ${currentUser.avatarColor} text-white flex items-center justify-center font-bold text-sm mx-auto shadow-xs border hover:scale-105 transition-all cursor-pointer ${
                theme === 'dark' ? 'border-slate-800 bg-slate-850 hover:bg-slate-800' : 'border-white/25 bg-white hover:bg-slate-100'
              }`}
              title={`Ubah Profil Saya: ${currentUser.name} (${isAdmin ? 'Admin' : 'Kasir'})`}
            >
              {currentUser.name.charAt(0)}
            </button>
          )}

          {/* Logout Button */}
          <button
            onClick={onLogout}
            className={`w-full flex items-center rounded-[16px] font-bold text-xs text-rose-600 transition-all ${
              isCollapsed ? 'justify-center p-3' : 'space-x-3 px-3.5 py-3'
            } ${
              theme === 'dark' ? 'hover:bg-rose-950/30' : 'hover:bg-rose-50'
            }`}
            title="Keluar Akun"
          >
            <LogOut className="w-4 h-4 shrink-0 text-rose-500" />
            {!isCollapsed && <span>Keluar Akun</span>}
          </button>

          {/* Toggle Expand/Collapse (Desktop Only) */}
          <div className={`hidden md:flex border-t pt-2 justify-center ${theme === 'dark' ? 'border-slate-800' : 'border-slate-150'}`}>
            <button
              onClick={toggleCollapse}
              className={`p-1.5 rounded-full transition-colors ${
                theme === 'dark' ? 'text-slate-500 hover:text-slate-300 hover:bg-slate-800' : 'text-slate-400 hover:text-slate-700 hover:bg-slate-150'
              }`}
              title={isCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
            >
              {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </aside>

      {/* PROFILE/SAAS EDIT MODAL */}
      {isProfileModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 pb-12 sm:pb-4 z-[999]">
          <div className="bg-white dark:bg-slate-900 rounded-[20px] shadow-2xl max-w-md w-full overflow-hidden border border-slate-100 dark:border-slate-800 animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 bg-slate-950 text-white flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-sm tracking-wide uppercase">
                  UBAH PROFIL & USERNAME
                </h3>
                <p className="text-[10px] text-indigo-400 font-semibold mt-0.5 uppercase">SaaS Akun Operator</p>
              </div>
              <button 
                onClick={() => setIsProfileModalOpen(false)} 
                className="p-1 bg-slate-900 rounded-lg text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="p-5 space-y-4">
              {profileError && (
                <div className="p-3 bg-red-50 dark:bg-red-950/20 border border-red-100 dark:border-red-900/40 text-red-700 dark:text-red-400 rounded-xl text-xs font-bold flex items-center space-x-2">
                  <ShieldAlert className="w-4 h-4 text-red-500 shrink-0" />
                  <span>{profileError}</span>
                </div>
              )}
              {profileSuccess && (
                <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/40 text-emerald-700 dark:text-emerald-400 rounded-xl text-xs font-bold flex items-center space-x-2">
                  <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>{profileSuccess}</span>
                </div>
              )}
              
              {/* Full Name */}
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">
                  Nama Lengkap
                </label>
                <input
                  type="text"
                  required
                  value={profileName}
                  onChange={(e) => setProfileName(e.target.value)}
                  placeholder="Contoh: Rian Hidayat"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800 dark:text-slate-100 font-sans"
                />
              </div>

              {/* Username */}
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">
                  Username Operator
                </label>
                <input
                  type="text"
                  required
                  value={profileUsername}
                  onChange={(e) => setProfileUsername(e.target.value)}
                  placeholder="Contoh: rianhdy"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono text-slate-800 dark:text-slate-100"
                />
                <p className="text-[10px] text-slate-400 mt-1 font-sans">Username ini digunakan untuk login ke sistem POS.</p>
              </div>

              {/* Email Address */}
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">
                  Alamat Email
                </label>
                <input
                  type="email"
                  required
                  value={profileEmail}
                  onChange={(e) => setProfileEmail(e.target.value)}
                  placeholder="Contoh: rian@email.com"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800 dark:text-slate-100 font-sans"
                />
              </div>

              {/* PIN / Password Akses */}
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">
                  Ubah PIN / Password Akses <span className="text-slate-400 dark:text-slate-500 lowercase italic font-normal">(kosongkan jika tidak diubah)</span>
                </label>
                <input
                  type="password"
                  value={profilePassword}
                  onChange={(e) => setProfilePassword(e.target.value)}
                  placeholder="•••••• (tetap sama)"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono tracking-widest text-slate-800 dark:text-slate-100"
                />
              </div>

              {/* Avatar Color Choice */}
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">
                  Pilih Warna Avatar
                </label>
                <div className="flex flex-wrap gap-2 mt-1.5">
                  {[
                    'bg-blue-600',
                    'bg-emerald-500',
                    'bg-blue-500',
                    'bg-indigo-500',
                    'bg-purple-500',
                    'bg-orange-500',
                    'bg-rose-500',
                    'bg-slate-600'
                  ].map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setProfileAvatarColor(color)}
                      className={`w-6 h-6 rounded-lg ${color} border-2 transition-all cursor-pointer ${
                        profileAvatarColor === color 
                          ? 'border-slate-950 dark:border-white scale-110 shadow-md shadow-slate-950/10' 
                          : 'border-transparent hover:scale-105'
                      }`}
                    />
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end space-x-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsProfileModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 rounded-xl text-xs font-bold cursor-pointer font-sans"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold cursor-pointer font-sans"
                >
                  Simpan Perubahan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
