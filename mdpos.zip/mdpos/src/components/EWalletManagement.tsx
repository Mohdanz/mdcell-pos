import React, { useState, useMemo } from 'react';
import { EWallet, EWalletHistory, Role } from '../types';
import { 
  Plus, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Wallet, 
  History, 
  Calendar, 
  CheckCircle2, 
  AlertCircle,
  AlertTriangle,
  ToggleLeft,
  ToggleRight,
  Edit2,
  Trash2,
  Filter,
  X
} from 'lucide-react';

interface EWalletManagementProps {
  eWallets: EWallet[];
  histories: EWalletHistory[];
  currentUserRole: Role;
  onAddEWallet: (wallet: Omit<EWallet, 'id'>) => void;
  onEditEWallet: (id: string, updatedWallet: Partial<EWallet>) => void;
  onDeleteEWallet: (id: string) => void;
  onDepositEWallet: (id: string, amount: number, description: string) => void;
}

export default function EWalletManagement({
  eWallets,
  histories,
  currentUserRole,
  onAddEWallet,
  onEditEWallet,
  onDeleteEWallet,
  onDepositEWallet
}: EWalletManagementProps) {
  const isAdmin = currentUserRole === 'admin';

  // E-Wallet Form State
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  const [editingWallet, setEditingWallet] = useState<EWallet | null>(null);
  const [walletName, setWalletName] = useState('');
  const [walletProvider, setWalletProvider] = useState<'DANA' | 'OVO' | 'GoPay' | 'ShopeePay' | 'LinkAja' | 'Lainnya'>('DANA');
  const [walletBalance, setWalletBalance] = useState(0);
  const [walletDescription, setWalletDescription] = useState('');
  const [walletLogoUrl, setWalletLogoUrl] = useState('');
  const [walletCategory, setWalletCategory] = useState<'ewallet' | 'aplikasi'>('ewallet');

  // Deposit Form State
  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
  const [selectedWalletForDeposit, setSelectedWalletForDeposit] = useState<EWallet | null>(null);
  const [depositAmount, setDepositAmount] = useState(100000);
  const [depositDescription, setDepositDescription] = useState('Top Up / Tambah Saldo Server');

  // Filter History State
  const [filterWalletId, setFilterWalletId] = useState<string>('semua');
  const [filterHistoryType, setFilterHistoryType] = useState<'semua' | 'debit' | 'credit'>('semua');

  // Custom visual confirm & error states
  const [formError, setFormError] = useState('');
  const [depositError, setDepositError] = useState('');
  const [walletToDelete, setWalletToDelete] = useState<EWallet | null>(null);

  // Total balance summation
  const totalBalanceSum = useMemo(() => {
    return eWallets.filter(w => w.id !== 'cash' && w.isActive).reduce((acc, w) => acc + Number(w.balance || 0), 0);
  }, [eWallets]);

  // Filter ledger list
  const filteredHistories = useMemo(() => {
    return histories
      .filter((h) => {
        const matchWallet = filterWalletId === 'semua' || h.eWalletId === filterWalletId;
        const matchType = filterHistoryType === 'semua' || h.type === filterHistoryType;
        return matchWallet && matchType;
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()); // newest first
  }, [histories, filterWalletId, filterHistoryType]);

  const handleOpenAddWallet = () => {
    setEditingWallet(null);
    setWalletName('');
    setWalletProvider('DANA');
    setWalletBalance(0);
    setWalletDescription('');
    setWalletLogoUrl('');
    setWalletCategory('ewallet');
    setFormError('');
    setIsWalletModalOpen(true);
  };

  const handleOpenEditWallet = (wallet: EWallet) => {
    setEditingWallet(wallet);
    setWalletName(wallet.name);
    setWalletProvider(wallet.provider);
    setWalletBalance(wallet.balance);
    setWalletDescription(wallet.description);
    setWalletLogoUrl(wallet.logoUrl || '');
    setWalletCategory(wallet.category || 'ewallet');
    setFormError('');
    setIsWalletModalOpen(true);
  };

  const handleOpenDeposit = (wallet: EWallet) => {
    setSelectedWalletForDeposit(wallet);
    setDepositAmount(100000);
    setDepositDescription('Top Up / Tambah Saldo Server');
    setDepositError('');
    setIsDepositModalOpen(true);
  };

  const handleSaveWallet = (e: React.FormEvent) => {
    e.preventDefault();
    if (!walletName.trim()) {
      setFormError('Nama e-wallet wajib diisi');
      return;
    }

    const payload = {
      name: walletName.trim(),
      provider: walletProvider,
      balance: Number(walletBalance),
      description: walletDescription.trim(),
      isActive: editingWallet ? editingWallet.isActive : true,
      logoUrl: walletLogoUrl.trim() || undefined,
      category: walletCategory
    };

    if (editingWallet) {
      onEditEWallet(editingWallet.id, payload);
    } else {
      onAddEWallet(payload);
    }
    setIsWalletModalOpen(false);
  };

  const handleSaveDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedWalletForDeposit) return;
    if (depositAmount <= 0) {
      setDepositError('Jumlah deposit harus lebih besar dari 0');
      return;
    }

    onDepositEWallet(selectedWalletForDeposit.id, Number(depositAmount), depositDescription.trim());
    setIsDepositModalOpen(false);
    setSelectedWalletForDeposit(null);
  };

  const handleToggleActive = (wallet: EWallet) => {
    if (!isAdmin) return;
    onEditEWallet(wallet.id, { isActive: !wallet.isActive });
  };

  const handleDeleteWallet = (wallet: EWallet) => {
    setWalletToDelete(wallet);
  };

  const formatRupiah = (num: number | null | undefined) => {
    if (num === undefined || num === null || isNaN(num)) return 'Rp 0';
    return 'Rp ' + num.toLocaleString('id-ID');
  };

  const getWalletTheme = (provider: string, name: string = '', isActive: boolean = true) => {
    if (!isActive) {
      return {
        bg: 'bg-gradient-to-br from-slate-200 via-slate-150 to-slate-300 dark:from-slate-800 dark:via-slate-750 dark:to-slate-900 border border-slate-300/40 dark:border-slate-700 opacity-60 grayscale',
        textPrimary: 'text-slate-600 dark:text-slate-300',
        textSecondary: 'text-slate-400 dark:text-slate-500',
        badge: 'bg-slate-300/50 text-slate-700 border border-slate-400/20',
        iconBtn: 'text-slate-400 hover:text-slate-600 hover:bg-slate-200/40',
        depositBtn: 'text-slate-500 hover:text-slate-700 bg-slate-200/30 hover:bg-slate-200/50 border border-slate-300/30',
        watermark: 'NONAKTIF',
        glow: 'shadow-xs',
        chip: 'from-slate-300 via-slate-400 to-slate-300 border-slate-400/20'
      };
    }

    const p = `${provider || ''} ${name || ''}`.toLowerCase();

    if (p.includes('dana')) {
      return {
        bg: 'bg-gradient-to-br from-sky-500 via-blue-600 to-indigo-700 border border-sky-300/40',
        textPrimary: 'text-white font-black',
        textSecondary: 'text-blue-100/90',
        badge: 'bg-white/20 text-white border border-white/30 backdrop-blur-md',
        iconBtn: 'text-blue-100 hover:text-white hover:bg-white/15',
        depositBtn: 'text-white bg-white/20 hover:bg-white/30 border border-white/25 shadow-xs backdrop-blur-md',
        watermark: 'DANA',
        glow: 'shadow-lg shadow-blue-500/20 hover:shadow-xl hover:shadow-blue-500/30',
        chip: 'from-amber-300 via-yellow-400 to-amber-500 border-amber-200/30'
      };
    }
    if (p.includes('ovo')) {
      return {
        bg: 'bg-gradient-to-br from-purple-800 via-indigo-900 to-purple-950 border border-purple-400/40',
        textPrimary: 'text-white font-black',
        textSecondary: 'text-purple-100/90',
        badge: 'bg-white/20 text-white border border-white/30 backdrop-blur-md',
        iconBtn: 'text-purple-100 hover:text-white hover:bg-white/15',
        depositBtn: 'text-white bg-white/20 hover:bg-white/30 border border-white/25 shadow-xs backdrop-blur-md',
        watermark: 'OVO',
        glow: 'shadow-lg shadow-purple-500/20 hover:shadow-xl hover:shadow-purple-500/30',
        chip: 'from-amber-300 via-yellow-400 to-amber-500 border-amber-200/30'
      };
    }
    if (p.includes('gopay') || p.includes('go-pay') || p.includes('gojek')) {
      return {
        bg: 'bg-gradient-to-br from-teal-500 via-emerald-600 to-teal-800 border border-teal-300/40',
        textPrimary: 'text-white font-black',
        textSecondary: 'text-emerald-100/90',
        badge: 'bg-white/20 text-white border border-white/30 backdrop-blur-md',
        iconBtn: 'text-teal-100 hover:text-white hover:bg-white/15',
        depositBtn: 'text-white bg-white/20 hover:bg-white/30 border border-white/25 shadow-xs backdrop-blur-md',
        watermark: 'GOPAY',
        glow: 'shadow-lg shadow-emerald-500/20 hover:shadow-xl hover:shadow-emerald-500/30',
        chip: 'from-amber-300 via-yellow-400 to-amber-500 border-amber-200/30'
      };
    }
    if (p.includes('shopee') || p.includes('shopeepay')) {
      return {
        bg: 'bg-gradient-to-br from-orange-500 via-orange-600 to-red-600 border border-orange-300/40',
        textPrimary: 'text-white font-black',
        textSecondary: 'text-orange-100/90',
        badge: 'bg-white/20 text-white border border-white/30 backdrop-blur-md',
        iconBtn: 'text-orange-100 hover:text-white hover:bg-white/15',
        depositBtn: 'text-white bg-white/20 hover:bg-white/30 border border-white/25 shadow-xs backdrop-blur-md',
        watermark: 'SHOPEE',
        glow: 'shadow-lg shadow-orange-500/20 hover:shadow-xl hover:shadow-orange-500/30',
        chip: 'from-amber-300 via-yellow-400 to-amber-500 border-amber-200/30'
      };
    }
    if (p.includes('linkaja') || p.includes('link aja')) {
      return {
        bg: 'bg-gradient-to-br from-red-600 via-rose-600 to-red-800 border border-rose-400/40',
        textPrimary: 'text-white font-black',
        textSecondary: 'text-rose-100/90',
        badge: 'bg-white/20 text-white border border-white/30 backdrop-blur-md',
        iconBtn: 'text-rose-100 hover:text-white hover:bg-white/15',
        depositBtn: 'text-white bg-white/20 hover:bg-white/30 border border-white/25 shadow-xs backdrop-blur-md',
        watermark: 'LINKAJA',
        glow: 'shadow-lg shadow-red-500/20 hover:shadow-xl hover:shadow-red-500/30',
        chip: 'from-amber-300 via-yellow-400 to-amber-500 border-amber-200/30'
      };
    }
    if (p.includes('bca')) {
      return {
        bg: 'bg-gradient-to-br from-blue-900 via-indigo-900 to-slate-900 border border-blue-500/40',
        textPrimary: 'text-white font-black',
        textSecondary: 'text-blue-100/90',
        badge: 'bg-blue-500/30 text-blue-100 border border-blue-400/30 backdrop-blur-md',
        iconBtn: 'text-blue-200 hover:text-white hover:bg-white/15',
        depositBtn: 'text-white bg-white/20 hover:bg-white/30 border border-white/25 shadow-xs backdrop-blur-md',
        watermark: 'BCA',
        glow: 'shadow-lg shadow-indigo-600/20 hover:shadow-xl hover:shadow-indigo-600/30',
        chip: 'from-amber-300 via-yellow-400 to-amber-500 border-amber-200/30'
      };
    }
    if (p.includes('bri')) {
      return {
        bg: 'bg-gradient-to-br from-sky-700 via-blue-800 to-slate-900 border border-sky-400/40',
        textPrimary: 'text-white font-black',
        textSecondary: 'text-sky-100/90',
        badge: 'bg-sky-500/30 text-sky-100 border border-sky-400/30 backdrop-blur-md',
        iconBtn: 'text-sky-200 hover:text-white hover:bg-white/15',
        depositBtn: 'text-white bg-white/20 hover:bg-white/30 border border-white/25 shadow-xs backdrop-blur-md',
        watermark: 'BRI',
        glow: 'shadow-lg shadow-sky-600/20 hover:shadow-xl hover:shadow-sky-600/30',
        chip: 'from-amber-300 via-yellow-400 to-amber-500 border-amber-200/30'
      };
    }
    if (p.includes('bni')) {
      return {
        bg: 'bg-gradient-to-br from-teal-700 via-cyan-800 to-slate-900 border border-teal-400/40',
        textPrimary: 'text-white font-black',
        textSecondary: 'text-teal-100/90',
        badge: 'bg-orange-500/30 text-orange-100 border border-orange-400/30 backdrop-blur-md',
        iconBtn: 'text-teal-200 hover:text-white hover:bg-white/15',
        depositBtn: 'text-white bg-white/20 hover:bg-white/30 border border-white/25 shadow-xs backdrop-blur-md',
        watermark: 'BNI',
        glow: 'shadow-lg shadow-teal-600/20 hover:shadow-xl hover:shadow-teal-600/30',
        chip: 'from-amber-300 via-yellow-400 to-amber-500 border-amber-200/30'
      };
    }
    if (p.includes('mandiri')) {
      return {
        bg: 'bg-gradient-to-br from-blue-950 via-slate-900 to-amber-950 border border-amber-500/30',
        textPrimary: 'text-white font-black',
        textSecondary: 'text-amber-100/90',
        badge: 'bg-amber-500/30 text-amber-200 border border-amber-400/30 backdrop-blur-md',
        iconBtn: 'text-amber-200 hover:text-white hover:bg-white/15',
        depositBtn: 'text-white bg-white/20 hover:bg-white/30 border border-white/25 shadow-xs backdrop-blur-md',
        watermark: 'MANDIRI',
        glow: 'shadow-lg shadow-amber-500/20 hover:shadow-xl hover:shadow-amber-500/30',
        chip: 'from-amber-300 via-yellow-400 to-amber-500 border-amber-200/30'
      };
    }
    if (p.includes('seabank') || p.includes('sea bank')) {
      return {
        bg: 'bg-gradient-to-br from-orange-600 via-amber-600 to-slate-900 border border-orange-400/40',
        textPrimary: 'text-white font-black',
        textSecondary: 'text-orange-100/90',
        badge: 'bg-white/20 text-white border border-white/30 backdrop-blur-md',
        iconBtn: 'text-orange-100 hover:text-white hover:bg-white/15',
        depositBtn: 'text-white bg-white/20 hover:bg-white/30 border border-white/25 shadow-xs backdrop-blur-md',
        watermark: 'SEABANK',
        glow: 'shadow-lg shadow-orange-500/20 hover:shadow-xl hover:shadow-orange-500/30',
        chip: 'from-amber-300 via-yellow-400 to-amber-500 border-amber-200/30'
      };
    }
    if (p.includes('isaku') || p.includes('i-saku') || p.includes('indomaret')) {
      return {
        bg: 'bg-gradient-to-br from-sky-600 via-blue-700 to-indigo-900 border border-sky-400/40',
        textPrimary: 'text-white font-black',
        textSecondary: 'text-sky-100/90',
        badge: 'bg-white/20 text-white border border-white/30 backdrop-blur-md',
        iconBtn: 'text-sky-100 hover:text-white hover:bg-white/15',
        depositBtn: 'text-white bg-white/20 hover:bg-white/30 border border-white/25 shadow-xs backdrop-blur-md',
        watermark: 'I-SAKU',
        glow: 'shadow-lg shadow-sky-500/20 hover:shadow-xl hover:shadow-sky-500/30',
        chip: 'from-amber-300 via-yellow-400 to-amber-500 border-amber-200/30'
      };
    }

    const cleanWatermark = (name || provider || 'WALLET').substring(0, 10).toUpperCase();
    return {
      bg: 'bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-800 border border-indigo-500/30',
      textPrimary: 'text-white font-black',
      textSecondary: 'text-slate-200/90',
      badge: 'bg-white/15 text-white border border-white/20 backdrop-blur-md',
      iconBtn: 'text-slate-200 hover:text-white hover:bg-white/10',
      depositBtn: 'text-white bg-white/20 hover:bg-white/30 border border-white/25 shadow-xs backdrop-blur-md',
      watermark: cleanWatermark,
      glow: 'shadow-lg shadow-indigo-900/25 hover:shadow-xl hover:shadow-indigo-900/35',
      chip: 'from-amber-300 via-yellow-400 to-amber-500 border-amber-200/30'
    };
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 bg-slate-50">
      
      {/* 1. Header Area */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">MANAJEMEN SALDO E-WALLET</h1>
          <p className="text-slate-500 text-sm">Input modal server, pelacakan saldo keluar-masuk, dan mutasi akun real-time</p>
        </div>

        {isAdmin && (
          <button
            onClick={handleOpenAddWallet}
            className="inline-flex items-center justify-center px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl shadow-lg shadow-blue-500/20 transition-all space-x-1.5 self-start sm:self-auto"
          >
            <Plus className="w-5 h-5" />
            <span>Tambah E-Wallet</span>
          </button>
        )}
      </div>

      {/* 2. Total Capital Info Banner */}
      <div className="p-6 rounded-[20px] bg-gradient-to-r from-blue-700 to-slate-900 text-white shadow-lg flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        <div>
          <span className="text-blue-200 text-xs font-bold uppercase tracking-widest">Total Sisa Modal Server</span>
          <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight font-mono mt-1">
            {formatRupiah(totalBalanceSum)}
          </h2>
          <p className="text-blue-100 text-xs mt-1.5 opacity-85">
            Akumulasi dari seluruh server & e-wallet konter yang berstatus Aktif.
          </p>
        </div>
        <div className="p-4 bg-blue-800/40 rounded-xl border border-blue-500/30 flex items-center space-x-2">
          <Wallet className="w-8 h-8 text-blue-300" />
          <div className="text-xs">
            <span className="font-semibold block">Sistem Terintegrasi</span>
            <span className="opacity-80">Saldo memotong otomatis setiap transaksi jualan.</span>
          </div>
        </div>
      </div>

      {/* 3. Bento Grid of E-Wallets */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4 mb-6">
        {eWallets.filter(w => w.id !== 'cash').map((wallet) => {
          const theme = getWalletTheme(wallet.provider, wallet.name, wallet.isActive);
          return (
            <div 
              key={wallet.id} 
              className={`p-4 rounded-[22px] relative overflow-hidden flex flex-col justify-between h-44 transition-all duration-300 group ${theme.bg} ${theme.glow} ${
                wallet.isActive ? 'hover:-translate-y-1 hover:scale-[1.01]' : ''
              }`}
            >
              {/* Card Glare reflection sweep */}
              <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent opacity-70 pointer-events-none z-10" />

              {/* Card Watermark */}
              <div className="absolute right-[-10px] bottom-[-15px] text-[60px] font-black tracking-tighter text-white/5 select-none pointer-events-none italic uppercase leading-none font-sans z-0">
                {theme.watermark}
              </div>

              <div className="relative z-10">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-2">
                    {wallet.logoUrl ? (
                      <div className="w-9 h-9 rounded-xl bg-white shadow-md border border-white/30 shrink-0 flex items-center justify-center overflow-hidden transition-transform group-hover:scale-105">
                        <img 
                          src={wallet.logoUrl} 
                          alt={wallet.name} 
                          className="w-full h-full object-cover" 
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    ) : (
                      <div className="w-8 h-8 rounded-xl bg-white/20 backdrop-blur-md border border-white/30 text-white flex items-center justify-center font-black text-xs shadow-inner shrink-0">
                        {wallet.name.charAt(0).toUpperCase()}
                      </div>
                    )}
                    <span className={`px-2 py-0.5 rounded-md text-[8px] font-black tracking-wider ${theme.badge}`}>
                      {wallet.category === 'aplikasi' ? 'Aplikasi' : 'E-Wallet'}
                    </span>
                  </div>

                  <div className="flex items-center space-x-1.5">
                    {isAdmin && (
                      <div className="flex items-center space-x-0.5">
                        <button
                          onClick={() => handleOpenEditWallet(wallet)}
                          className={`p-1 rounded-lg transition-colors ${theme.iconBtn}`}
                          title="Edit E-Wallet"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteWallet(wallet)}
                          className={`p-1 rounded-lg transition-colors text-rose-300 hover:text-white hover:bg-rose-500/20`}
                          title="Hapus E-Wallet"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleToggleActive(wallet)}
                          className={`p-1 rounded-lg transition-colors ${theme.iconBtn}`}
                          title={wallet.isActive ? "Nonaktifkan E-Wallet" : "Aktifkan E-Wallet"}
                        >
                          {wallet.isActive ? (
                            <ToggleRight className="w-4.5 h-4.5 text-emerald-300" />
                          ) : (
                            <ToggleLeft className="w-4.5 h-4.5 opacity-50" />
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                <h3 className={`font-black text-xs mt-2.5 leading-snug truncate drop-shadow-xs ${theme.textPrimary}`} title={wallet.name}>
                  {wallet.name}
                </h3>
                <p className={`text-[10px] line-clamp-1 mt-0.5 min-h-[16px] leading-tight ${theme.textSecondary}`}>{wallet.description || 'Tidak ada keterangan'}</p>
              </div>

              <div className="relative z-10">
                <p className="text-lg font-black font-mono mt-1 tracking-tight drop-shadow-xs text-white">
                  {formatRupiah(wallet.balance)}
                </p>

                <div className="flex items-center justify-between border-t border-white/15 pt-2 mt-1.5 text-[11px]">
                  {isAdmin ? (
                    <button
                      onClick={() => handleOpenDeposit(wallet)}
                      className={`font-black flex items-center space-x-1 py-1 px-2.5 rounded-lg text-[10px] transition-all cursor-pointer ${theme.depositBtn}`}
                    >
                      <ArrowUpRight className="w-3.5 h-3.5" />
                      <span>Isi Saldo</span>
                    </button>
                  ) : (
                    <span className={`${theme.textSecondary} text-[10px]`}>Hanya Admin</span>
                  )}
                  <span className="text-[9px] font-bold text-white/70 tracking-wider uppercase font-mono">
                    {wallet.provider}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* 4. Ledger Audit Trail Logs / Mutation History */}
      <div className="bg-white rounded-[20px] border border-slate-100 shadow-sm p-5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-slate-100 pb-4 mb-4 gap-4">
          <h2 className="text-base font-bold text-slate-800 flex items-center">
            <History className="w-4 h-4 mr-1.5 text-slate-600" />
            Mutasi & Riwayat Keluar-Masuk Saldo
          </h2>

          {/* Mutation Filters */}
          <div className="flex items-center space-x-2 flex-wrap gap-y-2">
            <div className="flex items-center space-x-1 text-xs text-slate-400 font-semibold mr-1">
              <Filter className="w-3.5 h-3.5" />
              <span>Saring:</span>
            </div>
            
            <select
              value={filterWalletId}
              onChange={(e) => setFilterWalletId(e.target.value)}
              className="p-1.5 border border-slate-200 bg-slate-50 rounded-xl text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="semua">Semua Dompet</option>
              {eWallets.filter(w => w.id !== 'cash').map(w => (
                <option key={w.id} value={w.id}>{w.name}</option>
              ))}
            </select>

            <select
              value={filterHistoryType}
              onChange={(e) => setFilterHistoryType(e.target.value as 'semua' | 'debit' | 'credit')}
              className="p-1.5 border border-slate-200 bg-slate-50 rounded-xl text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="semua">Semua Tipe</option>
              <option value="debit">Uang Masuk (Deposit)</option>
              <option value="credit">Uang Keluar (Transaksi)</option>
            </select>
          </div>
        </div>

        {/* Mutation Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/70 border-b border-slate-100 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                <th className="py-2 px-4">Waktu & Tanggal</th>
                <th className="py-2 px-4">E-Wallet Target</th>
                <th className="py-2 px-4">Keterangan / Aktivitas</th>
                <th className="py-2 px-4 text-center">Tipe</th>
                <th className="py-2 px-4 text-right">Jumlah Nominal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
              {filteredHistories.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-10 text-center text-slate-400">
                    <History className="w-10 h-10 text-slate-200 mx-auto mb-1 animate-pulse" />
                    <p className="font-semibold text-slate-500 text-xs">Belum ada catatan mutasi</p>
                    <p className="text-[10px] text-slate-400">Seluruh pemotongan transaksi akan tercatat otomatis di sini.</p>
                  </td>
                </tr>
              ) : (
                filteredHistories.map((h) => {
                  const isCredit = h.type === 'credit';
                  return (
                    <tr key={h.id} className="hover:bg-slate-50/30 transition-colors">
                      <td className="py-3 px-4 font-mono text-slate-500 whitespace-nowrap">
                        <span className="flex items-center">
                          <Calendar className="w-3.5 h-3.5 mr-1 text-slate-400" />
                          {h.date ? new Date(h.date).toLocaleString('id-ID') : '-'}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-bold text-slate-800 whitespace-nowrap">
                        <div className="flex items-center space-x-2">
                          {(() => {
                            const walletObj = eWallets.find((w) => w.id === h.eWalletId);
                            return walletObj?.logoUrl ? (
                              <img 
                                src={walletObj.logoUrl} 
                                alt={h.eWalletName} 
                                className="w-6 h-6 object-cover rounded-md border border-slate-200 shrink-0" 
                                referrerPolicy="no-referrer"
                              />
                            ) : null;
                          })()}
                          <span>{h.eWalletName}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 max-w-xs truncate" title={h.description}>
                        {h.description}
                      </td>
                      <td className="py-3 px-4 text-center whitespace-nowrap">
                        {isCredit ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold bg-red-50 text-red-700 border border-red-100">
                            <ArrowDownLeft className="w-3 h-3 mr-0.5" /> Keluar
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-100">
                            <ArrowUpRight className="w-3 h-3 mr-0.5" /> Masuk
                          </span>
                        )}
                      </td>
                      <td className={`py-3 px-4 text-right font-mono font-bold whitespace-nowrap ${
                        isCredit ? 'text-red-600' : 'text-emerald-600'
                      }`}>
                        {isCredit ? '-' : '+'}{formatRupiah(h.amount)}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 5. ADD/EDIT E-WALLET MODAL */}
      {isWalletModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 pb-12 sm:pb-4 z-[200] overflow-y-auto">
          <div className="bg-white rounded-[20px] shadow-2xl max-w-md w-full max-h-[90vh] flex flex-col overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 bg-slate-950 text-white flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-extrabold text-sm tracking-wide">
                  {editingWallet ? 'EDIT REKENING E-WALLET' : 'DAFTARKAN E-WALLET BARU'}
                </h3>
                <p className="text-[10px] text-blue-400 font-semibold mt-0.5">Spesifikasi Server Konter</p>
              </div>
              <button onClick={() => setIsWalletModalOpen(false)} className="p-1 bg-slate-900 rounded-lg text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveWallet} className="p-5 space-y-4 overflow-y-auto flex-1">
              {formError && (
                <div className="p-3 bg-red-50 border border-red-100 text-red-700 rounded-xl text-xs font-bold flex items-center space-x-2 animate-in fade-in duration-200">
                  <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Nama Dompet / Rekening
                </label>
                <input
                  type="text"
                  required
                  value={walletName}
                  onChange={(e) => {
                    const val = e.target.value;
                    setWalletName(val);
                    // Auto-detect provider
                    const lowerName = val.toLowerCase();
                    if (lowerName.includes('dana')) {
                      setWalletProvider('DANA');
                    } else if (lowerName.includes('ovo')) {
                      setWalletProvider('OVO');
                    } else if (lowerName.includes('gopay') || lowerName.includes('go-pay') || lowerName.includes('go pay')) {
                      setWalletProvider('GoPay');
                    } else if (lowerName.includes('shopee')) {
                      setWalletProvider('ShopeePay');
                    } else if (lowerName.includes('linkaja') || lowerName.includes('link aja')) {
                      setWalletProvider('LinkAja');
                    } else {
                      setWalletProvider('Lainnya');
                    }
                  }}
                  placeholder="Contoh: DANA Server Nasional Utama"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Saldo Awal (Rp)
                </label>
                <input
                  type="number"
                  required
                  min={0}
                  disabled={!!editingWallet} // can only modify via deposit to prevent cheating
                  value={walletBalance}
                  onChange={(e) => setWalletBalance(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono font-semibold disabled:bg-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
                  Kategori Akun
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setWalletCategory('ewallet')}
                    className={`p-2.5 rounded-xl border text-left flex flex-col transition-all ${
                      walletCategory === 'ewallet'
                        ? 'bg-blue-50 border-blue-500 text-blue-900 ring-1 ring-blue-400'
                        : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <span className="font-bold text-xs">E-Wallet</span>
                    <span className="text-[9px] text-slate-400 mt-0.5 leading-snug font-medium">Bisa Tarik Saldo & Penjualan (Muncul di Tarik Tunai)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setWalletCategory('aplikasi')}
                    className={`p-2.5 rounded-xl border text-left flex flex-col transition-all ${
                      walletCategory === 'aplikasi'
                        ? 'bg-blue-50 border-blue-500 text-blue-900 ring-1 ring-blue-400'
                        : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <span className="font-bold text-xs">Aplikasi</span>
                    <span className="text-[9px] text-slate-400 mt-0.5 leading-snug font-medium">Hanya Transaksi Penjualan (Tidak untuk Tarik Tunai)</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Keterangan / Deskripsi
                </label>
                <textarea
                  rows={2}
                  value={walletDescription}
                  onChange={(e) => setWalletDescription(e.target.value)}
                  placeholder="Contoh: Saldo dari chip agen Mkios untuk pengisian reguler."
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Logo / Gambar Icon Dompet
                </label>
                <div className="flex items-start space-x-3 bg-slate-50 p-3 rounded-[16px] border border-slate-200">
                  <div className="w-12 h-12 rounded-xl bg-slate-200 border border-slate-300 flex items-center justify-center overflow-hidden shrink-0">
                    {walletLogoUrl ? (
                      <img src={walletLogoUrl} alt="Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <Wallet className="w-6 h-6 text-slate-400" />
                    )}
                  </div>
                  <div className="flex-1 space-y-1.5">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onloadend = () => {
                            setWalletLogoUrl(reader.result as string);
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                      className="block w-full text-[10px] text-slate-500 file:mr-2 file:py-1 file:px-2 file:rounded-md file:border-0 file:text-[10px] file:font-bold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 cursor-pointer"
                    />
                    <div className="text-[9px] text-slate-400">Atau tempel URL gambar langsung:</div>
                    <input
                      type="text"
                      placeholder="https://example.com/logo.png"
                      value={walletLogoUrl}
                      onChange={(e) => setWalletLogoUrl(e.target.value)}
                      className="w-full px-2 py-1 border border-slate-300 rounded-lg text-[10px] focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono"
                    />
                  </div>
                </div>
              </div>

              {editingWallet && (
                <p className="text-[10px] text-slate-400 bg-slate-50 p-2.5 rounded-lg border">
                  Informasi Saldo hanya dapat disesuaikan melalui fitur <strong>Isi Saldo</strong> atau otomatis berkurang via transaksi POS.
                </p>
              )}

              <div className="flex justify-end space-x-2 border-t pt-3 mt-2">
                <button
                  type="button"
                  onClick={() => setIsWalletModalOpen(false)}
                  className="px-3 py-1.5 bg-slate-100 text-slate-700 text-xs font-bold rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-1.5 bg-blue-600 text-white text-xs font-bold rounded-xl shadow-lg shadow-blue-500/20"
                >
                  {editingWallet ? 'Simpan Edit' : 'Tambah E-Wallet'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 6. DEPOSIT / TOP UP MODAL */}
      {isDepositModalOpen && selectedWalletForDeposit && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 pb-12 sm:pb-4 z-[200]">
          <div className="bg-white rounded-[20px] shadow-2xl max-w-sm w-full overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 bg-slate-950 text-white flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-sm tracking-wide">DEPOSIT / ISI SALDO SERVER</h3>
                <p className="text-[10px] text-blue-400 font-semibold mt-0.5">Tambah Likuiditas Konter</p>
              </div>
              <button 
                onClick={() => {
                  setIsDepositModalOpen(false);
                  setSelectedWalletForDeposit(null);
                }} 
                className="p-1 bg-slate-900 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveDeposit} className="p-5 space-y-4">
              {depositError && (
                <div className="p-3 bg-red-50 border border-red-100 text-red-700 rounded-xl text-xs font-bold flex items-center space-x-2 animate-in fade-in duration-200">
                  <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
                  <span>{depositError}</span>
                </div>
              )}
              <div className="p-3 bg-blue-50 border border-blue-100 rounded-xl">
                <p className="text-xs font-semibold text-blue-800">Menambahkan saldo ke:</p>
                <p className="font-bold text-slate-900 text-xs mt-1">{selectedWalletForDeposit.name}</p>
                <span className="text-[10px] text-slate-500 font-mono block mt-1">Saldo saat ini: {formatRupiah(selectedWalletForDeposit.balance)}</span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Jumlah Top Up (Rp)
                </label>
                <input
                  type="number"
                  required
                  min={1000}
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(Number(e.target.value))}
                  className="w-full px-3 py-2.5 border border-slate-300 rounded-xl text-sm font-mono font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Keterangan Deposit
                </label>
                <input
                  type="text"
                  required
                  value={depositDescription}
                  onChange={(e) => setDepositDescription(e.target.value)}
                  placeholder="Contoh: Deposit saldo server via Mandiri Transfer"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="border-t pt-3 flex justify-between items-center text-xs">
                <span className="text-slate-500 font-medium">Estimasi Saldo Baru:</span>
                <span className="font-bold text-emerald-600 font-mono text-sm">{formatRupiah(Number(selectedWalletForDeposit.balance || 0) + Number(depositAmount))}</span>
              </div>

              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsDepositModalOpen(false);
                    setSelectedWalletForDeposit(null);
                  }}
                  className="px-3 py-2 bg-slate-100 text-slate-700 text-xs font-bold rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-2 bg-blue-600 text-white text-xs font-bold rounded-xl shadow-lg shadow-blue-500/20"
                >
                  Kirim Deposit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 7. CUSTOM WALLET DELETE CONFIRMATION MODAL */}
      {walletToDelete && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 pb-12 sm:pb-4 z-[200]">
          <div className="bg-white rounded-[16px] shadow-2xl max-w-sm w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200 p-6">
            <div className="flex items-center space-x-3 text-red-600 mb-4">
              <div className="p-2 bg-red-50 rounded-lg">
                <AlertTriangle className="w-6 h-6 animate-bounce" />
              </div>
              <h3 className="font-bold text-lg text-slate-900">Hapus E-Wallet?</h3>
            </div>
            
            {walletToDelete.balance > 0 ? (
              <div className="space-y-3 mb-6">
                <p className="text-sm text-slate-600 leading-relaxed">
                  Peringatan: E-Wallet <strong className="text-slate-900 font-bold">"{walletToDelete.name}"</strong> masih memiliki saldo sebesar <strong className="text-red-600 font-extrabold">{formatRupiah(walletToDelete.balance)}</strong>.
                </p>
                <p className="text-xs text-slate-500 bg-amber-50 p-2.5 rounded-lg border border-amber-200 leading-relaxed font-semibold">
                  Apakah Anda benar-benar yakin ingin menghapus akun e-wallet ini bersama dengan sisa saldonya?
                </p>
              </div>
            ) : (
              <p className="text-sm text-slate-600 mb-6 leading-relaxed">
                Apakah Anda yakin ingin menghapus e-wallet <strong className="text-slate-900 font-bold">"{walletToDelete.name}"</strong>? Tindakan ini tidak dapat dibatalkan.
              </p>
            )}

            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => setWalletToDelete(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteEWallet(walletToDelete.id);
                  setWalletToDelete(null);
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold text-xs transition-colors shadow-lg shadow-red-500/20"
              >
                Ya, Hapus
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
