import React, { useState } from 'react';
import { User, Role } from '../types';
import { 
  Plus, 
  ShieldCheck, 
  User as UserIcon, 
  Mail, 
  Trash2, 
  Edit, 
  ShieldAlert,
  UserCheck,
  X
} from 'lucide-react';

interface UserManagementProps {
  users: User[];
  currentUser: User;
  onAddUser: (user: Omit<User, 'id'> & { password?: string }) => void;
  onEditUser: (id: string, updatedUser: Partial<User> & { password?: string }) => void;
  onDeleteUser: (id: string) => void;
}

export default function UserManagement({
  users,
  currentUser,
  onAddUser,
  onEditUser,
  onDeleteUser
}: UserManagementProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  // Custom visual confirm & error states
  const [formError, setFormError] = useState('');
  const [userToDelete, setUserToDelete] = useState<User | null>(null);
  const [selfDeleteAlertOpen, setSelfDeleteAlertOpen] = useState(false);

  // Form states
  const [username, setUsername] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<Role>('kasir');
  const [avatarColor, setAvatarColor] = useState('bg-teal-500');
  const [password, setPassword] = useState('');

  const avatarColors = [
    'bg-blue-600',
    'bg-emerald-500',
    'bg-blue-500',
    'bg-indigo-500',
    'bg-purple-500',
    'bg-orange-500',
    'bg-rose-500',
    'bg-slate-600'
  ];

  const handleOpenAdd = () => {
    setEditingUser(null);
    setUsername('');
    setName('');
    setEmail('');
    setRole('kasir');
    setAvatarColor('bg-indigo-500');
    setPassword('');
    setFormError('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (user: User) => {
    setEditingUser(user);
    setUsername(user.username);
    setName(user.name);
    setEmail(user.email);
    setRole(user.role);
    setAvatarColor(user.avatarColor);
    setPassword('');
    setFormError('');
    setIsModalOpen(true);
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();

    if (!username.trim() || !name.trim() || !email.trim()) {
      setFormError('Semua kolom harus diisi.');
      return;
    }

    const payload: any = {
      username: username.toLowerCase().trim().replace(/\s+/g, ''),
      name: name.trim(),
      email: email.trim(),
      role,
      avatarColor
    };

    if (password.trim() !== '') {
      payload.password = password;
    } else if (!editingUser) {
      // For new operators, if password is left blank, default to '123456'
      payload.password = '123456';
    }

    // Check for duplicate username across other users
    const isDuplicate = users.some(u => u.username === payload.username && u.id !== (editingUser?.id || ''));
    if (isDuplicate) {
      setFormError('Username sudah digunakan oleh operator lain.');
      return;
    }

    if (editingUser) {
      onEditUser(editingUser.id, payload);
    } else {
      onAddUser(payload);
    }

    setIsModalOpen(false);
  };

  const handleDelete = (user: User) => {
    if (user.id === currentUser.id) {
      setSelfDeleteAlertOpen(true);
      return;
    }

    setUserToDelete(user);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 bg-slate-50">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">KELOLA OPERATOR / TEAM</h1>
          <p className="text-slate-500 text-sm">Atur kewenangan akses masuk kasir (Kasir) dan pemilik konter (Admin)</p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center justify-center px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl shadow-lg shadow-blue-500/20 transition-all space-x-1.5 self-start sm:self-auto"
        >
          <Plus className="w-5 h-5" />
          <span>Tambah Operator</span>
        </button>
      </div>

      {/* Operator Security Policy Indicator banner */}
      <div className="p-4 rounded-xl bg-slate-100 border border-slate-200 text-xs text-slate-600 mb-6 flex items-start space-x-2.5">
        <ShieldAlert className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold text-slate-700 block mb-0.5">Kebijakan Hak Akses Multi-Role:</span>
          <span>
            Setiap operator memiliki hak khusus. <strong>Role Kasir</strong> hanya memiliki akses masuk POS Kasir, mencetak detail transaksi, serta memantau persediaan stok produk jualan. <strong>Role Admin</strong> memiliki akses total mutlak termasuk merubah stok, menginput modal saldo e-wallet, mengelola kasir lain, dan melihat rangkuman statistik profit jualan harian.
          </span>
        </div>
      </div>

      {/* Grid List of users */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {users.map((user) => {
          const isMe = user.id === currentUser.id;
          const isAdmin = user.role === 'admin';

          return (
            <div 
              key={user.id} 
              className="bg-white rounded-[20px] border border-slate-100 p-5 shadow-sm flex flex-col justify-between h-44 relative overflow-hidden"
            >
              <div>
                <div className="flex items-center space-x-3">
                  {/* Avatar */}
                  <div className={`w-11 h-11 rounded-xl ${user.avatarColor} text-white flex items-center justify-center font-bold text-lg shadow-xs`}>
                    {user.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-950 text-sm flex items-center">
                      <span>{user.name}</span>
                      {isMe && (
                        <span className="ml-1.5 bg-blue-50 text-blue-700 text-[8px] font-extrabold px-1.5 py-0.2 rounded uppercase">
                          Saya
                        </span>
                      )}
                    </h3>
                    <p className="text-xs text-slate-400 font-mono mt-0.5">@{user.username}</p>
                  </div>
                </div>

                {/* Email details */}
                <div className="flex items-center text-xs text-slate-500 mt-4 space-x-1.5">
                  <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="truncate">{user.email}</span>
                </div>
              </div>

              {/* Bottom controls */}
              <div className="flex items-center justify-between border-t border-slate-100 pt-3 mt-4 text-xs">
                {isAdmin ? (
                  <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-100 uppercase">
                    <ShieldCheck className="w-3.5 h-3.5 mr-0.5" /> Administrator
                  </span>
                ) : (
                  <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-100 uppercase">
                    <UserCheck className="w-3.5 h-3.5 mr-0.5" /> Operator Kasir
                  </span>
                )}

                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => handleOpenEdit(user)}
                    className="p-1 text-slate-400 hover:text-slate-600 rounded"
                    title="Edit Profil"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  
                  {!isMe && (
                    <button
                      onClick={() => handleDelete(user)}
                      className="p-1 text-red-400 hover:text-red-600 rounded"
                      title="Hapus Akun"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* ADD/EDIT OPERATOR MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 pb-12 sm:pb-4 z-[200]">
          <div className="bg-white rounded-[20px] shadow-2xl max-w-md w-full overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 bg-slate-950 text-white flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-sm tracking-wide uppercase">
                  {editingUser ? 'EDIT OPERATOR POS' : 'DAFTARKAN OPERATOR BARU'}
                </h3>
                <p className="text-[10px] text-blue-400 font-semibold mt-0.5 uppercase">Kewenangan Team</p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="p-1 bg-slate-900 rounded-lg text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveUser} className="p-5 space-y-4">
              {formError && (
                <div className="p-3 bg-red-50 border border-red-100 text-red-700 rounded-xl text-xs font-bold flex items-center space-x-2 animate-in fade-in duration-200">
                  <ShieldAlert className="w-4 h-4 text-red-500 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}
              
              {/* Full Name */}
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Nama Lengkap Operator
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Contoh: Rian Hidayat"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Username & Role */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Username Log In
                  </label>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Contoh: rianhdy"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Hak Akses (Role)
                  </label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value as Role)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                  >
                    <option value="kasir">Kasir (Cashier)</option>
                    <option value="admin">Admin (Owner)</option>
                  </select>
                </div>
              </div>

              {/* Email Address */}
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Alamat Email
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Contoh: rian.kasir@gmail.com"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* PIN / Password Akses */}
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1">
                  PIN / Password Akses {editingUser && <span className="text-slate-400 lowercase italic font-normal">(kosongkan jika tidak diubah)</span>}
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={editingUser ? "•••••• (tetap sama)" : "Masukkan PIN / password baru"}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono tracking-widest bg-white"
                />
                {!editingUser && (
                  <p className="text-[10px] text-slate-400 mt-1 font-sans font-normal normal-case">
                    Jika dikosongkan, password bawaan otomatis diatur ke <span className="font-mono bg-slate-100 px-1 rounded">123456</span>.
                  </p>
                )}
              </div>

              {/* Avatar Color Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
                  Pilih Tema Warna Profil
                </label>
                <div className="flex items-center space-x-2 flex-wrap gap-y-2">
                  {avatarColors.map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setAvatarColor(color)}
                      className={`w-7 h-7 rounded-full ${color} transition-all border-2 ${
                        avatarColor === color 
                          ? 'border-slate-900 ring-2 ring-slate-400/50 scale-110' 
                          : 'border-transparent hover:scale-105'
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div className="flex justify-end space-x-2 border-t pt-3 mt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3 py-1.5 bg-slate-100 text-slate-700 text-xs font-bold rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-1.5 bg-blue-600 text-white text-xs font-bold rounded-xl shadow-lg shadow-blue-500/20"
                >
                  {editingUser ? 'Simpan Edit' : 'Tambah Operator'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 5. CUSTOM SELF-DELETE WARNING MODAL */}
      {selfDeleteAlertOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 pb-12 sm:pb-4 z-[200]">
          <div className="bg-white rounded-[16px] shadow-2xl max-w-sm w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200 p-6">
            <div className="flex items-center space-x-3 text-red-600 mb-4">
              <div className="p-2 bg-red-50 rounded-lg">
                <ShieldAlert className="w-6 h-6 animate-pulse" />
              </div>
              <h3 className="font-bold text-lg text-slate-900">Aksi Ditolak</h3>
            </div>
            <p className="text-sm text-slate-600 mb-6 leading-relaxed">
              Anda tidak bisa menghapus akun Anda sendiri (<strong className="text-slate-900 font-bold">{currentUser.name}</strong>) yang sedang aktif digunakan untuk masuk ke sistem.
            </p>
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setSelfDeleteAlertOpen(false)}
                className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold text-xs transition-colors"
              >
                Mengerti
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. CUSTOM OPERATOR DELETE CONFIRMATION MODAL */}
      {userToDelete && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 pb-12 sm:pb-4 z-[200]">
          <div className="bg-white rounded-[16px] shadow-2xl max-w-sm w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200 p-6">
            <div className="flex items-center space-x-3 text-red-600 mb-4">
              <div className="p-2 bg-red-50 rounded-lg">
                <Trash2 className="w-6 h-6 animate-bounce" />
              </div>
              <h3 className="font-bold text-lg text-slate-900">Hapus Operator?</h3>
            </div>
            <p className="text-sm text-slate-600 mb-6 leading-relaxed">
              Apakah Anda yakin ingin menghapus akses operator <strong className="text-slate-900 font-bold">"{userToDelete.name}"</strong> dari sistem POS ini? Seluruh riwayat transaksi yang bersangkutan akan tetap tersimpan demi keamanan pembukuan.
            </p>
            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => setUserToDelete(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteUser(userToDelete.id);
                  setUserToDelete(null);
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold text-xs transition-colors shadow-lg shadow-red-500/20"
              >
                Ya, Hapus
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
