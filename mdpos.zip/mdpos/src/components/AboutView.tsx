import React, { useState } from 'react';
import { Info, Cpu, CheckCircle2, ShieldCheck, HelpCircle } from 'lucide-react';
import { AppConfig } from './SettingsView';

interface AboutViewProps {
  appConfig?: AppConfig;
}

export default function AboutView({ appConfig }: AboutViewProps) {
  const [logoError, setLogoError] = useState(false);

  return (
    <div id="about-view-container" className="p-6 max-w-4xl mx-auto space-y-6">
      {/* Hero Header */}
      <div className="flex items-center space-x-4 bg-white dark:bg-slate-900 p-5 rounded-[20px] border border-slate-100 dark:border-slate-800 shadow-sm">
        {!logoError ? (
          <img 
            src={appConfig?.logoUrl || "/logo.png"} 
            alt="MD POS Logo" 
            onError={(e) => {
              if (e.currentTarget.src !== window.location.origin + "/logo.png") {
                e.currentTarget.src = "/logo.png";
              } else {
                setLogoError(true);
              }
            }} 
            className="w-14 h-14 object-contain shrink-0 rounded-[16px] bg-slate-900/5 dark:bg-slate-800 p-1 border border-slate-200 dark:border-slate-700" 
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="p-2.5 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 rounded-[16px] border border-indigo-100 dark:border-indigo-900/40 shrink-0">
            <Info className="w-8 h-8" />
          </div>
        )}
        <div>
          <h1 className="text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight">{appConfig?.name || "MD POS"}</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider">
            Website Resmi:{' '}
            <a 
              href="https://mdcell.my.id" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-indigo-500 hover:underline"
            >
              https://mdcell.my.id
            </a>
          </p>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Main Specs Card */}
        <div className="md:col-span-2 bg-white dark:bg-slate-900 rounded-[20px] border border-slate-200/80 dark:border-slate-800 p-6 space-y-4">
          <div>
            <div className="flex items-center space-x-2 text-indigo-600 dark:text-indigo-400 mb-1">
              <Cpu className="w-5 h-5" />
              <span className="text-xs font-bold uppercase tracking-wider">Spesifikasi Sistem</span>
            </div>
            <h2 className="text-lg font-extrabold text-slate-900 dark:text-slate-100">MD POS Engine v3.2.0</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mt-1">
              MD POS adalah sistem kasir (Point-of-Sale) berkinerja tinggi yang dirancang secara modern dan responsif untuk konter pulsa, paket kuota, dan transaksi E-Wallet. Sistem ini terintegrasi penuh dengan database PostgreSQL melalui Drizzle ORM untuk menjaga integritas data dan kecepatan transaksi yang handal.
            </p>
          </div>

          <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-3">
            <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">Fitur Utama Terintegrasi:</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-medium text-slate-600 dark:text-slate-300">
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-500 shrink-0" />
                <span>Multi-Metode POS Jualan</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-500 shrink-0" />
                <span>Tarik Tunai & EDC Transfer</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-500 shrink-0" />
                <span>Backup Database Otomatis & Manual</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-500 shrink-0" />
                <span>Sesi Operator Kasir (Shift)</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-500 shrink-0" />
                <span>Laporan & Log Audit Lengkap</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-500 shrink-0" />
                <span>Peringatan Limit Stok Produk</span>
              </div>
            </div>
          </div>
        </div>

        {/* Legal/Licensing Card */}
        <div className="bg-white dark:bg-slate-900 rounded-[20px] border border-slate-200/80 dark:border-slate-800 p-6 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center space-x-2 text-emerald-600 dark:text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
              <span className="text-xs font-bold uppercase tracking-wider">Lisensi</span>
            </div>
            <h2 className="text-lg font-extrabold text-slate-900 dark:text-slate-100">Enterprise Ready</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Dilisensikan secara penuh untuk operasional konter retail nasional. Sistem ini dilindungi enkripsi data sesi demi mencegah manipulasi audit saldo kasir.
            </p>
          </div>
          <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider text-center">
            M3 DESIGN SYSTEM APPROVED
          </div>
        </div>
      </div>

      {/* Accordion Guide Card */}
      <div className="bg-white dark:bg-slate-900 rounded-[20px] border border-slate-200/80 dark:border-slate-800 p-6 space-y-4">
        <div className="flex items-center space-x-2 text-amber-600 dark:text-amber-400">
          <HelpCircle className="w-5 h-5" />
          <span className="text-xs font-bold uppercase tracking-wider">Bantuan Cepat</span>
        </div>
        <h2 className="text-lg font-extrabold text-slate-900 dark:text-slate-100">Alur Penggunaan Kasir & Operator</h2>
        <div className="space-y-3 text-xs text-slate-600 dark:text-slate-300">
          <div className="p-3 bg-slate-50 dark:bg-slate-850 rounded-[16px] border border-slate-100 dark:border-slate-800">
            <p className="font-bold text-slate-800 dark:text-slate-200 mb-1">1. Membuka Sesi Kasir (Mulai Shift)</p>
            <p className="leading-relaxed">Masuk ke Dashboard utama, klik tombol "Buka Sesi Shift Baru" dan masukkan modal uang laci (cash drawer) Anda sebelum melakukan transaksi apa pun.</p>
          </div>
          <div className="p-3 bg-slate-50 dark:bg-slate-850 rounded-[16px] border border-slate-100 dark:border-slate-800">
            <p className="font-bold text-slate-800 dark:text-slate-200 mb-1">2. Melakukan Transaksi</p>
            <p className="leading-relaxed">Pilih tab POS yang sesuai di sidebar: Transaksi POS untuk topup pulsa/ewallet, POS Item Fisik untuk barang retail, EDC untuk transfer EDC, atau Tarik Tunai.</p>
          </div>
          <div className="p-3 bg-slate-50 dark:bg-slate-850 rounded-[16px] border border-slate-100 dark:border-slate-800">
            <p className="font-bold text-slate-800 dark:text-slate-200 mb-1">3. Menutup Sesi Kasir (Tutup Shift)</p>
            <p className="leading-relaxed">Setelah shift kerja berakhir, buka kembali Dashboard, lalu pilih tombol "Tutup Shift" untuk menghitung rekonsiliasi laci kas.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
