import React, { useState, useEffect, useMemo } from 'react';
import { Product, Role, PhysicalCategory, VoucherSerial, VoucherStatus, Transaction } from '../types';
import { 
  X, 
  Info, 
  DollarSign, 
  Package, 
  Layers, 
  History, 
  Check, 
  AlertTriangle, 
  FileText, 
  FileSpreadsheet, 
  Search, 
  Clock, 
  TrendingUp,
  HelpCircle,
  Eye
} from 'lucide-react';
import * as XLSX from 'xlsx';

interface ProductDetailModalProps {
  product: Product;
  currentUserRole: Role;
  physicalCategories: PhysicalCategory[];
  onClose: () => void;
  onEditProduct?: (id: string, updatedProduct: Partial<Product>) => void;
}

type TabType = 'info' | 'price' | 'stock' | 'history';

export default function ProductDetailModal({
  product,
  currentUserRole,
  physicalCategories,
  onClose
}: ProductDetailModalProps) {
  const [activeTab, setActiveTab] = useState<TabType>('info');

  // 1. BARCODE & SERIAL TAB STATE
  const [vouchers, setVouchers] = useState<VoucherSerial[]>([]);
  const [isVouchersLoading, setIsVouchersLoading] = useState(false);
  const [barcodeSearch, setBarcodeSearch] = useState('');
  const [barcodeStatusFilter, setBarcodeStatusFilter] = useState<string>('ALL');

  // 2. HISTORY TAB STATE
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isHistoryLoading, setIsHistoryLoading] = useState(false);

  // Fetch product's barcodes/vouchers
  const loadVouchers = async () => {
    setIsVouchersLoading(true);
    try {
      const res = await fetch('/api/vouchers');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          const filtered = data.filter((v: any) => v.productId === product.id);
          setVouchers(filtered);
        }
      }
    } catch (err) {
      console.error('Gagal memuat data barcode/serial:', err);
    } finally {
      setIsVouchersLoading(false);
    }
  };

  // Fetch transaction history
  const loadTransactions = async () => {
    setIsHistoryLoading(true);
    try {
      const res = await fetch('/api/transactions');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          setTransactions(data);
        }
      }
    } catch (err) {
      console.error('Gagal memuat riwayat transaksi:', err);
    } finally {
      setIsHistoryLoading(false);
    }
  };

  useEffect(() => {
    loadVouchers();
    loadTransactions();
  }, [product.id]);

  const isVoucherTracked = useMemo(() => {
    const catLower = product.category.toLowerCase();
    return catLower === 'cat-voucher' || catLower === 'voucher_fisik' || catLower.includes('voucher');
  }, [product.category]);

  // Barcode stats
  const barcodeStats = useMemo(() => {
    const total = vouchers.length;
    const ready = vouchers.filter(v => v.status === 'READY').length;
    const sold = vouchers.filter(v => v.status === 'SOLD').length;
    const damaged = vouchers.filter(v => v.status === 'DAMAGED').length;
    const returned = vouchers.filter(v => v.status === 'RETURNED').length;
    const expired = vouchers.filter(v => v.status === 'EXPIRED').length;

    const countMap: Record<string, number> = {};
    vouchers.forEach(v => {
      countMap[v.barcode] = (countMap[v.barcode] || 0) + 1;
    });
    const duplicateList = Object.keys(countMap).filter(b => countMap[b] > 1);
    const duplicateCount = duplicateList.length;

    return { total, ready, sold, damaged, returned, expired, duplicateCount, duplicateList };
  }, [vouchers]);

  // Filtered barcodes list
  const filteredVouchers = useMemo(() => {
    return vouchers.filter(v => {
      const matchSearch = v.barcode.toLowerCase().includes(barcodeSearch.toLowerCase()) ||
                          (v.serialNumber || '').toLowerCase().includes(barcodeSearch.toLowerCase()) ||
                          (v.supplier || '').toLowerCase().includes(barcodeSearch.toLowerCase()) ||
                          (v.notes || '').toLowerCase().includes(barcodeSearch.toLowerCase());
      const matchStatus = barcodeStatusFilter === 'ALL' || v.status === barcodeStatusFilter;
      return matchSearch && matchStatus;
    });
  }, [vouchers, barcodeSearch, barcodeStatusFilter]);

  // EXPORT EXCEL
  const handleExportExcel = () => {
    if (filteredVouchers.length === 0) return;

    const sheetData = filteredVouchers.map(v => {
      const row: any = {
        'Barcode': v.barcode,
        'Serial Number': v.serialNumber || '-',
        'Expired Date': v.expiredDate || '-',
        'Supplier': v.supplier || '-',
        'Status': v.status,
        'Catatan': v.notes || '-'
      };
      if (currentUserRole === 'admin') {
        row['Harga Modal'] = v.purchasePrice;
      }
      return row;
    });

    const worksheet = XLSX.utils.json_to_sheet(sheetData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Stok Barcode');
    XLSX.writeFile(workbook, `STOK_BARCODE_${product.name.replace(/\s+/g, '_')}_${Date.now()}.xlsx`);
  };

  // EXPORT CSV
  const handleExportCSV = () => {
    if (filteredVouchers.length === 0) return;

    const isAdmin = currentUserRole === 'admin';
    const headers = [
      isAdmin
        ? 'Barcode,SerialNumber,ExpiredDate,Supplier,HargaModal,Status,Catatan'
        : 'Barcode,SerialNumber,ExpiredDate,Supplier,Status,Catatan'
    ];
    const rows = filteredVouchers.map(v => {
      const cols = [
        `"${v.barcode}"`,
        `"${v.serialNumber || ''}"`,
        `"${v.expiredDate || ''}"`,
        `"${v.supplier || ''}"`
      ];
      if (isAdmin) {
        cols.push(v.purchasePrice.toString());
      }
      cols.push(`"${v.status}"`);
      cols.push(`"${v.notes || ''}"`);
      return cols.join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + headers.concat(rows).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `STOK_BARCODE_${product.name.replace(/\s+/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // HISTORY DATA: FILTER FOR THIS PRODUCT
  const productTransactions = useMemo(() => {
    const list: { tx: Transaction; qty: number; totalSales: number; profit: number }[] = [];
    transactions.forEach(tx => {
      if (tx.items && Array.isArray(tx.items)) {
        tx.items.forEach(item => {
          if (item.productId === product.id) {
            list.push({
              tx,
              qty: item.quantity,
              totalSales: item.sellingPrice * item.quantity,
              profit: (item.sellingPrice - item.purchasePrice) * item.quantity
            });
          }
        });
      }
    });
    return list.sort((a, b) => new Date(b.tx.date).getTime() - new Date(a.tx.date).getTime());
  }, [transactions, product.id]);

  // Combined mutation timeline for vouchers
  const voucherHistoriesCombined = useMemo(() => {
    const list: { barcode: string; event: string; date: string; details: string }[] = [];
    vouchers.forEach(v => {
      if (v.history && Array.isArray(v.history)) {
        v.history.forEach((h: any) => {
          list.push({
            barcode: v.barcode,
            event: h.event,
            date: h.date,
            details: h.details || h.detail || ''
          });
        });
      }
    });
    return list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [vouchers]);

  const getStatusColor = (status: VoucherStatus) => {
    switch (status) {
      case 'READY': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'SOLD': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'RETURNED': return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'DAMAGED': return 'bg-red-100 text-red-800 border-red-200';
      case 'EXPIRED': return 'bg-slate-100 text-slate-800 border-slate-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getProductStockStatus = () => {
    if (product.stock <= 0) return { label: 'HABIS', style: 'bg-red-600 text-white' };
    if (product.stock <= product.minStockLimit) return { label: 'KRITIS', style: 'bg-amber-500 text-white' };
    return { label: 'AMAN', style: 'bg-emerald-600 text-white' };
  };

  const productStockStatus = getProductStockStatus();
  const currentCategoryName = physicalCategories.find(cat => cat.id === product.category)?.name || product.category;

  return (
    <div id="product-detail-overlay" className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-2.5 sm:p-4 pb-12 sm:pb-4 z-[200] overflow-hidden font-sans antialiased">
      <div className="bg-white rounded-[20px] shadow-2xl max-w-5xl w-full max-h-[88vh] sm:max-h-[90vh] h-[88vh] sm:h-[90vh] flex flex-col border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* MODAL MAIN HEADER */}
        <div className="p-6 bg-slate-950 text-white flex items-center justify-between shrink-0 border-b border-slate-800">
          <div className="flex items-center space-x-3.5">
            <div className="w-12 h-12 bg-blue-600 rounded-[16px] flex items-center justify-center text-white shadow-lg shrink-0">
              <Eye className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-extrabold text-base tracking-tight uppercase">{product.name}</h3>
              <div className="flex items-center space-x-2 mt-1">
                <span className="text-[10px] text-emerald-400 font-extrabold uppercase bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                  {product.operator}
                </span>
                <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-full ${productStockStatus.style}`}>
                  {productStockStatus.label} ({product.stock} Unit)
                </span>
                <span className="text-[9px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
                  Mode Lihat Saja
                </span>
              </div>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 bg-slate-900 hover:bg-slate-800 active:scale-95 text-slate-400 hover:text-white rounded-xl flex items-center justify-center transition-all border border-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* FOUR-TABS CONTROL BAR */}
        <div className="bg-slate-50 px-6 py-3 border-b border-slate-200 flex items-center justify-start shrink-0 overflow-x-auto gap-2 scrollbar-none">
          <button
            onClick={() => setActiveTab('info')}
            className={`px-4 py-2 text-xs font-black tracking-wider uppercase rounded-xl transition-all shrink-0 inline-flex items-center space-x-1.5 cursor-pointer ${
              activeTab === 'info' 
                ? 'bg-slate-950 text-white shadow-md' 
                : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200'
            }`}
          >
            <Info className="w-4 h-4" />
            <span>Informasi Produk</span>
          </button>
          
          {currentUserRole === 'admin' && (
            <button
              onClick={() => setActiveTab('price')}
              className={`px-4 py-2 text-xs font-black tracking-wider uppercase rounded-xl transition-all shrink-0 inline-flex items-center space-x-1.5 cursor-pointer ${
                activeTab === 'price' 
                  ? 'bg-slate-950 text-white shadow-md' 
                  : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200'
              }`}
            >
              <DollarSign className="w-4 h-4" />
              <span>Harga</span>
            </button>
          )}

          <button
            onClick={() => setActiveTab('stock')}
            className={`px-4 py-2 text-xs font-black tracking-wider uppercase rounded-xl transition-all shrink-0 inline-flex items-center space-x-1.5 cursor-pointer ${
              activeTab === 'stock' 
                ? 'bg-slate-950 text-white shadow-md' 
                : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>Stok & Barcode</span>
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`px-4 py-2 text-xs font-black tracking-wider uppercase rounded-xl transition-all shrink-0 inline-flex items-center space-x-1.5 cursor-pointer ${
              activeTab === 'history' 
                ? 'bg-slate-950 text-white shadow-md' 
                : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200'
            }`}
          >
            <History className="w-4 h-4" />
            <span>Riwayat</span>
          </button>
        </div>

        {/* MODAL MAIN SCROLLABLE CONTENT BODY */}
        <div className="flex-1 overflow-hidden flex flex-col min-h-0 bg-slate-50/30">
          
          {/* TAB 1: INFORMASI PRODUK (READ-ONLY) */}
          {activeTab === 'info' && (
            <div className="flex-1 overflow-y-auto p-6 md:p-8 max-w-4xl mx-auto w-full">
              <div className="bg-white p-8 rounded-[20px] border border-slate-200 shadow-sm grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
                
                {/* Product Image Panel */}
                <div className="md:col-span-4 flex flex-col items-center">
                  <div className="w-full aspect-square rounded-[16px] bg-slate-50 border border-slate-200 flex items-center justify-center overflow-hidden relative shadow-inner">
                    {product.imageUrl ? (
                      <img 
                        src={product.imageUrl} 
                        alt={product.name} 
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover" 
                      />
                    ) : (
                      <Package className="w-16 h-16 text-slate-300" />
                    )}
                  </div>
                </div>

                {/* Information Specs list */}
                <div className="md:col-span-8 space-y-6">
                  <div>
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Nama Produk</span>
                    <h4 className="text-xl font-extrabold text-slate-900 leading-tight">{product.name}</h4>
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Kategori Jualan</span>
                      <span className="text-sm font-bold text-slate-800 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200/60 inline-block">
                        {currentCategoryName}
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Operator / Brand</span>
                      <span className="text-sm font-bold text-slate-800 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200/60 inline-block">
                        {product.operator}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Metode Barcode</span>
                      <span className="text-sm font-bold text-slate-800 capitalize">
                        {product.barcodeType === 'single' ? 'Single Barcode' : product.barcodeType === 'massal' ? 'Massal / Voucher Serial' : 'Tidak Ada'}
                      </span>
                    </div>

                    {product.barcode && (
                      <div>
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Kode Barcode</span>
                        <span className="text-xs font-black font-mono text-indigo-600 bg-indigo-50 border border-indigo-100 px-2.5 py-1 rounded-lg inline-block">
                          {product.barcode}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="pt-4 border-t border-slate-100">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1.5">Deskripsi / Catatan Produk</span>
                    <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-4 rounded-[16px] border border-slate-100">
                      {product.description || 'Tidak ada deskripsi atau spesifikasi catatan tambahan untuk produk ini.'}
                    </p>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* TAB 2: HARGA PRODUK (READ-ONLY) */}
          {activeTab === 'price' && (
            <div className="flex-1 overflow-y-auto p-6 md:p-8 max-w-3xl mx-auto w-full">
              <div className="bg-white p-8 rounded-[20px] border border-slate-200 shadow-sm space-y-6">
                <h4 className="text-xs font-black text-slate-400 tracking-wider uppercase flex items-center space-x-2">
                  <DollarSign className="w-4.5 h-4.5 text-emerald-500" />
                  <span>ANALISIS PROFITABILITAS DAN SKEMA HARGA</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {/* Harga Beli / Modal */}
                  <div className="bg-slate-50 p-5 rounded-[16px] border border-slate-200">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Harga Modal (Kulakan)</span>
                    <p className="text-2xl font-black text-slate-800 font-mono">
                      Rp {product.purchasePrice.toLocaleString('id-ID')}
                    </p>
                  </div>

                  {/* Harga Jual */}
                  <div className="bg-slate-50 p-5 rounded-[16px] border border-slate-200">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Harga Jual Konsumen</span>
                    <p className="text-2xl font-black text-slate-800 font-mono">
                      Rp {product.sellingPrice.toLocaleString('id-ID')}
                    </p>
                  </div>
                </div>

                {/* Profit Analysis Dashboard Card */}
                {product.purchasePrice > 0 && product.sellingPrice > 0 && (
                  <div className={`p-6 rounded-[16px] border transition-all ${
                    product.sellingPrice >= product.purchasePrice 
                      ? 'bg-emerald-50 border-emerald-100 text-emerald-900' 
                      : 'bg-red-50 border-red-100 text-red-900'
                  }`}>
                    <div className="flex items-center space-x-2.5 mb-4">
                      <TrendingUp className={`w-5 h-5 ${product.sellingPrice >= product.purchasePrice ? 'text-emerald-600' : 'text-red-500'}`} />
                      <span className="text-xs font-black uppercase tracking-wider">Kalkulasi Keuntungan Jualan</span>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-6">
                      <div>
                        <p className="text-[9px] font-bold opacity-60 uppercase">Keuntungan Bersih (Profit)</p>
                        <p className="text-xl font-black font-mono mt-1">
                          Rp {(product.sellingPrice - product.purchasePrice).toLocaleString('id-ID')}
                        </p>
                      </div>
                      <div>
                        <p className="text-[9px] font-bold opacity-60 uppercase">Margin Keuntungan</p>
                        <p className="text-xl font-black font-mono mt-1">
                          {((product.sellingPrice - product.purchasePrice) / product.purchasePrice * 100).toFixed(1)}%
                        </p>
                      </div>
                    </div>

                    {product.sellingPrice < product.purchasePrice && (
                      <div className="mt-4 pt-4 border-t border-red-200">
                        <p className="text-xs font-semibold leading-relaxed text-red-700">
                          ⚠️ Perhatian: Harga jual produk ini di bawah harga modal. Penjualan ini akan tercatat dalam kondisi merugi.
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: STOK PRODUK & DAFTAR BARCODE (READ-ONLY) */}
          {activeTab === 'stock' && (
            <div className="flex-1 overflow-hidden flex flex-col md:flex-row min-h-0">
              
              {/* INNER LEFT: STOCK METRICS CARD (Width 280px) */}
              <div className="w-full md:w-[280px] bg-slate-50 p-5 border-r border-slate-200 overflow-y-auto shrink-0 flex flex-col space-y-4">
                <h4 className="text-xs font-black text-slate-400 tracking-wider uppercase flex items-center space-x-1.5">
                  <Layers className="w-4.5 h-4.5 text-slate-400" />
                  <span>STATUS STOK</span>
                </h4>

                <div className="space-y-3">
                  <div className="bg-white p-4 rounded-[16px] border border-slate-200">
                    <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wide">Sisa Stok Saat Ini</span>
                    <p className="text-xl font-black text-slate-950 font-mono mt-1">{product.stock} Unit</p>
                    <span className={`inline-flex px-2 py-0.5 mt-2 text-[9px] font-black rounded-full ${productStockStatus.style}`}>
                      {productStockStatus.label}
                    </span>
                  </div>

                  <div className="bg-white p-4 rounded-[16px] border border-slate-200">
                    <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wide">Batas Minimal (Limit Warning)</span>
                    <p className="text-lg font-black text-slate-950 font-mono mt-1">{product.minStockLimit} Unit</p>
                    <p className="text-[8px] text-slate-400 font-semibold mt-1">
                      Peringatan KRITIS muncul jika sisa stok kurang dari angka ini.
                    </p>
                  </div>

                  {/* Voucher tracking statistics */}
                  {isVoucherTracked && (
                    <div className="bg-white p-4 rounded-[16px] border border-slate-200 space-y-2">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-wide block">Data Voucher Serial</span>
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-500">Total Terdaftar:</span>
                        <span className="font-bold text-slate-800">{barcodeStats.total}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-500">Ready / Aktif:</span>
                        <span className="font-bold text-emerald-600">{barcodeStats.ready}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-500">Terjual (Sold):</span>
                        <span className="font-bold text-blue-600">{barcodeStats.sold}</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* INNER RIGHT: BARCODE LIST (READ-ONLY) */}
              <div className="flex-1 overflow-hidden flex flex-col p-6 min-h-0 bg-white">
                <div className="flex-1 overflow-hidden flex flex-col min-h-0">
                  <h4 className="text-xs font-black text-slate-400 tracking-wider uppercase mb-3.5 flex items-center space-x-1.5">
                    <Layers className="w-4.5 h-4.5 text-slate-400" />
                    <span>DAFTAR BARCODE / KODE VOUCHER</span>
                  </h4>

                  {isVoucherTracked || vouchers.length > 0 ? (
                    <>
                      {/* Filter & Export toolbar */}
                      <div className="flex flex-col sm:flex-row gap-3 mb-4 shrink-0">
                        <div className="relative flex-1">
                          <Search className="absolute left-3.5 top-2.5 w-4 h-4 text-slate-400" />
                          <input
                            type="text"
                            placeholder="Cari barcode, serial, supplier..."
                            value={barcodeSearch}
                            onChange={(e) => setBarcodeSearch(e.target.value)}
                            className="w-full bg-slate-50 hover:bg-slate-100 focus:bg-white text-slate-800 placeholder-slate-400 text-xs font-semibold rounded-xl pl-9 pr-4 py-2.5 border border-slate-200 focus:border-slate-800 outline-none transition-all"
                          />
                        </div>

                        <select
                          value={barcodeStatusFilter}
                          onChange={(e) => setBarcodeStatusFilter(e.target.value)}
                          className="bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-xl px-4 py-2.5 border border-slate-200 focus:border-slate-800 outline-none transition-all cursor-pointer"
                        >
                          <option value="ALL">Semua Status</option>
                          <option value="READY">READY (Ready)</option>
                          <option value="SOLD">SOLD (Terjual)</option>
                          <option value="RETURNED">RETURNED (Retur)</option>
                          <option value="DAMAGED">DAMAGED (Rusak)</option>
                          <option value="EXPIRED">EXPIRED (Expired)</option>
                        </select>

                        <div className="flex space-x-1">
                          <button
                            onClick={handleExportExcel}
                            className="p-2.5 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-xl border border-slate-200 transition-all cursor-pointer"
                            title="Export Excel (.xlsx)"
                          >
                            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                          </button>
                          <button
                            onClick={handleExportCSV}
                            className="p-2.5 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-xl border border-slate-200 transition-all cursor-pointer"
                            title="Export CSV (.csv)"
                          >
                            <FileText className="w-4 h-4 text-blue-500" />
                          </button>
                        </div>
                      </div>

                      {/* Table display */}
                      <div className="flex-1 overflow-y-auto border border-slate-100 rounded-[16px] bg-slate-50/25">
                        {isVouchersLoading ? (
                          <div className="py-24 text-center">
                            <div className="w-8 h-8 border-4 border-slate-800 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
                            <p className="text-slate-500 font-semibold text-xs">Memuat daftar barcode...</p>
                          </div>
                        ) : filteredVouchers.length === 0 ? (
                          <div className="py-24 text-center text-slate-400">
                            <Layers className="w-12 h-12 text-slate-300 mx-auto mb-2 animate-pulse" />
                            <p className="font-bold text-slate-500 text-xs">Tidak ada barcode terdaftar</p>
                            <p className="text-[10px] text-slate-400 mt-1">Silakan kelola atau tambahkan barcode di form "Edit Produk".</p>
                          </div>
                        ) : (
                          <table className="w-full text-left border-collapse">
                            <thead>
                              <tr className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-wider border-b border-slate-150">
                                <th className="py-3 px-4">Barcode</th>
                                <th className="py-3 px-4">Serial Number</th>
                                <th className="py-3 px-4">Kadaluarsa</th>
                                <th className="py-3 px-4">Supplier</th>
                                <th className="py-3 px-4 text-center">Status</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 text-xs font-semibold text-slate-700">
                              {filteredVouchers.map((v) => {
                                const isDuplicate = barcodeStats.duplicateList.includes(v.barcode);
                                return (
                                  <tr key={v.id} className={`hover:bg-slate-50/50 transition-colors ${isDuplicate ? 'bg-amber-50/45' : ''}`}>
                                    <td className="py-3 px-4 font-mono font-bold text-slate-900 max-w-[150px] truncate" title={v.barcode}>
                                      {v.barcode}
                                      {isDuplicate && (
                                        <span className="ml-1.5 inline-flex px-1 bg-amber-500 text-white rounded text-[8px] font-black uppercase">Duplikat</span>
                                      )}
                                    </td>
                                    <td className="py-3 px-4 font-mono text-slate-500 max-w-[120px] truncate">
                                      {v.serialNumber || '-'}
                                    </td>
                                    <td className="py-3 px-4 text-slate-600">
                                      {v.expiredDate ? (
                                        <span className="inline-flex items-center">
                                          <Clock className="w-3.5 h-3.5 mr-1 text-slate-400 shrink-0" />
                                          {new Date(v.expiredDate).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}
                                        </span>
                                      ) : '-'}
                                    </td>
                                    <td className="py-3 px-4 text-slate-500 truncate max-w-[100px]">
                                      {v.supplier || '-'}
                                    </td>
                                    <td className="py-3 px-4 text-center">
                                      <span className={`inline-flex px-2 py-0.5 text-[9px] font-black rounded-full border ${getStatusColor(v.status)}`}>
                                        {v.status}
                                      </span>
                                    </td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        )}
                      </div>
                    </>
                  ) : (
                    <div className="bg-slate-50 p-8 rounded-[16px] text-center text-slate-400 max-w-md mx-auto mt-8 border border-slate-250 border-dashed">
                      <Layers className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                      <p className="font-bold text-slate-600 text-xs uppercase">Bukan Produk Massal / Voucher</p>
                      <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">
                        Produk ini dikelola dengan stok manual atau tidak memiliki data barcode serial yang terdaftar.
                      </p>
                    </div>
                  )}
                </div>
              </div>

            </div>
          )}

          {/* TAB 4: RIWAYAT PRODUK (READ-ONLY) */}
          {activeTab === 'history' && (
            <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-6">
              
              {/* Product sales timeline */}
              <div className="bg-white p-6 rounded-[20px] border border-slate-200 shadow-sm">
                <h4 className="text-xs font-black text-slate-400 tracking-wider uppercase mb-4 flex items-center space-x-2">
                  <TrendingUp className="w-4.5 h-4.5 text-emerald-500" />
                  <span>RIWAYAT TRANSAKSI PENJUALAN PRODUK</span>
                </h4>

                {isHistoryLoading ? (
                  <div className="py-8 text-center text-slate-400 text-xs">Memuat histori jualan...</div>
                ) : productTransactions.length === 0 ? (
                  <div className="py-12 text-center text-slate-400 text-xs">
                    <HelpCircle className="w-10 h-10 text-slate-300 mx-auto mb-2 animate-pulse" />
                    <span>Belum ada transaksi penjualan untuk produk jualan ini.</span>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-wider border-b border-slate-100">
                          <th className="py-3 px-4">Tanggal Transaksi</th>
                          <th className="py-3 px-4">Nomor Invoice</th>
                          <th className="py-3 px-4">Kasir</th>
                          <th className="py-3 px-4 text-center">Jumlah Qty</th>
                          <th className="py-3 px-4 text-right">Total Transaksi</th>
                          {currentUserRole === 'admin' && <th className="py-3 px-4 text-right">Profit Bersih</th>}
                          <th className="py-3 px-4">HP Konsumen</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-slate-700 font-semibold">
                        {productTransactions.map(({ tx, qty, totalSales, profit }, idx) => (
                          <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                            <td className="py-3 px-4 text-slate-500">
                              {new Date(tx.date).toLocaleDateString('id-ID', {
                                day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
                              })}
                            </td>
                            <td className="py-3 px-4 font-mono font-extrabold text-blue-600">{tx.invoiceNumber}</td>
                            <td className="py-3 px-4 text-slate-800 font-bold">{tx.cashierName}</td>
                            <td className="py-3 px-4 text-center font-mono">{qty} Unit</td>
                            <td className="py-3 px-4 text-right font-mono text-slate-900">
                              Rp {totalSales.toLocaleString('id-ID')}
                            </td>
                            {currentUserRole === 'admin' && (
                              <td className="py-3 px-4 text-right font-mono text-emerald-600">
                                +Rp {profit.toLocaleString('id-ID')}
                              </td>
                            )}
                            <td className="py-3 px-4 text-slate-500 font-mono">{tx.customerPhone || '-'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Barcode action histories (Only if voucher product) */}
              {isVoucherTracked && (
                <div className="bg-white p-6 rounded-[20px] border border-slate-200 shadow-sm">
                  <h4 className="text-xs font-black text-slate-400 tracking-wider uppercase mb-4 flex items-center space-x-2">
                    <History className="w-4.5 h-4.5 text-purple-500" />
                    <span>LOG MUTASI KELUAR MASUK GUDANG BARCODE</span>
                  </h4>

                  {isVouchersLoading ? (
                    <div className="py-8 text-center text-slate-400 text-xs">Memuat log mutasi...</div>
                  ) : voucherHistoriesCombined.length === 0 ? (
                    <div className="py-12 text-center text-slate-400 text-xs">
                      <HelpCircle className="w-10 h-10 text-slate-300 mx-auto mb-2 animate-pulse" />
                      <span>Belum ada log mutasi terdaftar.</span>
                    </div>
                  ) : (
                    <div className="relative border-l border-slate-200 pl-4 space-y-4 max-h-96 overflow-y-auto">
                      {voucherHistoriesCombined.map((log, idx) => (
                        <div key={idx} className="relative">
                          <span className="absolute -left-[21px] top-1 w-3.5 h-3.5 rounded-full bg-slate-100 border-2 border-slate-400 flex items-center justify-center">
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-600"></span>
                          </span>
                          <div>
                            <span className="text-[9px] font-black uppercase text-slate-400 block font-mono">
                              {new Date(log.date).toLocaleString('id-ID', {
                                day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
                              })}
                            </span>
                            <div className="flex flex-wrap items-center gap-1.5 mt-0.5">
                              <span className="text-xs font-black text-slate-900 font-mono bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">
                                {log.barcode}
                              </span>
                              <span className="text-xs font-bold text-slate-850">: {log.event}</span>
                            </div>
                            {log.details && (
                              <span className="text-[10px] text-slate-500 mt-1 block bg-slate-50 p-2 rounded-lg border border-slate-100 font-medium">
                                {log.details}
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

            </div>
          )}

        </div>

      </div>
    </div>
  );
}
