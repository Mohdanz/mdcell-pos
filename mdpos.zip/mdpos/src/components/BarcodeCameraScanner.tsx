import React, { useEffect, useRef, useState } from 'react';
import { 
  Camera, 
  RefreshCw, 
  Zap, 
  ZapOff, 
  X, 
  AlertCircle, 
  Check,
  ChevronDown
} from 'lucide-react';
import {
  BrowserMultiFormatReader,
  DecodeHintType,
  BarcodeFormat,
  BinaryBitmap,
  HybridBinarizer,
  GlobalHistogramBinarizer,
  HTMLCanvasElementLuminanceSource
} from '@zxing/library';

// Extend window type for BarcodeDetector
declare global {
  interface Window {
    BarcodeDetector?: any;
  }
}

interface BarcodeCameraScannerProps {
  isOpen: boolean;
  onScan: (barcode: string) => void;
  onClose: () => void;
  title?: string;
  multiScan?: boolean;
  scannedCount?: number;
}

export default function BarcodeCameraScanner({
  isOpen,
  onScan,
  onClose,
  title = 'Scan Barcode / QR Code',
  multiScan = false,
  scannedCount = 0
}: BarcodeCameraScannerProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const zxingReaderRef = useRef<BrowserMultiFormatReader | null>(null);
  const nativeDetectorRef = useRef<any>(null);
  const animationFrameRef = useRef<number | null>(null);
  
  // Offscreen canvas and loop optimization references
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const lastScanTimeRef = useRef<number>(0);
  const cooldownUntilRef = useRef<number>(0);
  const scanAttemptsRef = useRef<number>(0);
  const lastVideoTimeRef = useRef<number>(-1);
  const isDecodingRef = useRef<boolean>(true);
  const recentScansRef = useRef<{ [barcode: string]: number }>({});
  const lastAutoZoomTimeRef = useRef<number>(0);
  const digitalZoomRef = useRef<number>(1.0);

  const [permissionState, setPermissionState] = useState<'prompt' | 'granted' | 'denied' | 'loading'>('loading');
  const [errorMessage, setErrorMessage] = useState('');
  const [cameras, setCameras] = useState<MediaDeviceInfo[]>([]);
  const [selectedCameraId, setSelectedCameraId] = useState<string>('');
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [isFlashOn, setIsFlashOn] = useState(false);
  const [hasFlashSupport, setHasFlashSupport] = useState(false);
  const [activeDetector, setActiveDetector] = useState<'native' | 'zxing' | 'none'>('none');
  const [isDetecting, setIsDetecting] = useState<boolean>(true);
  const [lastScannedResult, setLastScannedResult] = useState<string>('');

  // Native zoom support states
  const [isZoomSupported, setIsZoomSupported] = useState(false);
  const [zoomRange, setZoomRange] = useState({ min: 1, max: 4 });
  const [currentZoom, setCurrentZoom] = useState(1);
  const [digitalZoom, setDigitalZoom] = useState(1.0);

  // Dynamic feedback and scan quality state
  const [detectionQuality, setDetectionQuality] = useState<'analyzing' | 'low_light' | 'stabilizing' | 'ready' | 'detected'>('analyzing');
  const [isCameraMenuOpen, setIsCameraMenuOpen] = useState(false);

  // Safe applyConstraints helper to catch errors like "The associated Track is in an invalid state" or mock stream driver quirks gracefully
  const safeApplyConstraints = async (track: MediaStreamTrack | undefined, constraints: any) => {
    if (!track) return;
    if (track.readyState !== 'live') {
      console.warn('Track is not live (state: ' + track.readyState + '), skipping applyConstraints.');
      return;
    }
    try {
      await track.applyConstraints(constraints);
    } catch (e) {
      console.warn('applyConstraints rejected or failed on track:', e);
    }
  };

  // Single, unified useEffect to manage camera stream lifecycle and setup
  useEffect(() => {
    if (!isOpen) {
      stopAllStreams();
      window.dispatchEvent(new CustomEvent('scanner-status', { detail: { isOpen: false } }));
      return;
    }

    window.dispatchEvent(new CustomEvent('scanner-status', { detail: { isOpen: true } }));

    let isActive = true;
    isDecodingRef.current = true;
    recentScansRef.current = {};
    lastAutoZoomTimeRef.current = 0;
    digitalZoomRef.current = 1.0;

    async function startScanner() {
      // Check if desired camera is already active
      const currentTrack = streamRef.current?.getVideoTracks()[0];
      const currentActiveId = currentTrack?.getSettings ? currentTrack.getSettings().deviceId : null;
      
      if (currentActiveId && selectedCameraId && currentActiveId === selectedCameraId) {
        setPermissionState('granted');
        await setupBarcodeDetection();
        return;
      }

      setPermissionState('loading');
      setErrorMessage('');
      setIsFlashOn(false);
      setHasFlashSupport(false);
      setIsDetecting(true);
      setLastScannedResult('');
      setDetectionQuality('analyzing');
      setIsZoomSupported(false);
      setDigitalZoom(1.0);
      setCurrentZoom(1);

      // Clean up previous stream/readers first
      stopAllStreams();
      isDecodingRef.current = true;

      try {
        const constraints: MediaStreamConstraints = {
          audio: false,
          video: {
            deviceId: selectedCameraId ? { ideal: selectedCameraId } : undefined,
            facingMode: selectedCameraId ? undefined : facingMode,
            width: { ideal: 1280 },
            height: { ideal: 720 },
            aspectRatio: { ideal: 1.7777777778 }, // 16:9
            frameRate: { ideal: 30 }
          }
        };

        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        if (!isActive) {
          stream.getTracks().forEach(t => t.stop());
          return;
        }

        streamRef.current = stream;
        setPermissionState('granted');

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.setAttribute('playsinline', 'true'); // Required for iOS
          
          // Wait for video metadata to load and play
          await videoRef.current.play();

          // Check for flashlight/torch, zoom and autofocus support
          const videoTrack = stream.getVideoTracks()[0];
          if (videoTrack) {
            const capabilities = videoTrack.getCapabilities ? videoTrack.getCapabilities() : {};
            
            // 1. Flash support
            if ('torch' in capabilities) {
              setHasFlashSupport(true);
            } else {
              setHasFlashSupport(false);
            }

            // 2. Zoom support
            if ('zoom' in capabilities) {
              setIsZoomSupported(true);
              setZoomRange({
                min: (capabilities as any).zoom.min || 1,
                max: (capabilities as any).zoom.max || 4
              });
              setCurrentZoom((capabilities as any).zoom.min || 1);
            } else {
              setIsZoomSupported(false);
            }

            // 3. Continuous autofocus application
            if ('focusMode' in capabilities) {
              const focusModes = (capabilities as any).focusMode || [];
              if (focusModes.includes('continuous')) {
                await safeApplyConstraints(videoTrack, {
                  advanced: [{ focusMode: 'continuous' }]
                } as any);
              }
            }
          }
        }

        // Enumerate video input devices once permission is granted
        const devices = await navigator.mediaDevices.enumerateDevices();
        const videoDevices = devices.filter(device => device.kind === 'videoinput');
        if (isActive) {
          setCameras(videoDevices);

          // If no specific camera ID selected, find or prefer back/rear camera
          if (!selectedCameraId && videoDevices.length > 0) {
            const backCamera = videoDevices.find(device => 
              device.label.toLowerCase().includes('back') || 
              device.label.toLowerCase().includes('rear') ||
              device.label.toLowerCase().includes('environment')
            );

            if (backCamera) {
              setSelectedCameraId(backCamera.deviceId);
              setFacingMode('environment');
            } else {
              setSelectedCameraId(videoDevices[0].deviceId);
            }
          }
        }

        // Initialize Barcode Detector (Native BarcodeDetector or Fallback ZXing)
        await setupBarcodeDetection();

      } catch (err: any) {
        console.warn('Camera access info:', err);
        if (isActive) {
          if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
            setPermissionState('denied');
            setErrorMessage('Izin akses kamera ditolak. Silakan aktifkan izin kamera di pengaturan browser Anda untuk menggunakan fitur scan.');
          } else {
            setPermissionState('denied');
            setErrorMessage(`Gagal mengakses kamera: ${err.message || 'Kesalahan tidak diketahui'}`);
          }
        }
      }
    }

    startScanner();

    return () => {
      isActive = false;
      stopAllStreams();
      window.dispatchEvent(new CustomEvent('scanner-status', { detail: { isOpen: false } }));
    };
  }, [isOpen, selectedCameraId, facingMode]);

  // Adjust flashlight track when state changes
  useEffect(() => {
    const track = streamRef.current?.getVideoTracks()[0];
    if (track && hasFlashSupport) {
      safeApplyConstraints(track, {
        advanced: [{ torch: isFlashOn }]
      } as any);
    }
  }, [isFlashOn, hasFlashSupport]);

  // Adjust zoom track dynamically (Supports hardware zoom with digital fallback)
  const handleZoomChange = async (value: number) => {
    const targetZoom = Math.max(zoomRange.min, Math.min(zoomRange.max, value));
    setCurrentZoom(targetZoom);
    digitalZoomRef.current = targetZoom;
    
    // Try to apply native zoom if supported
    const track = streamRef.current?.getVideoTracks()[0];
    if (track && isZoomSupported && track.readyState === 'live') {
      try {
        await track.applyConstraints({
          advanced: [{ zoom: targetZoom }]
        } as any);
      } catch (e) {
        console.warn('Failed to apply native zoom constraint, falling back to digital zoom:', e);
        // Fallback to digital zoom
        setDigitalZoom(targetZoom);
      }
    } else {
      // Fallback to digital zoom
      setDigitalZoom(targetZoom);
    }
  };

  // Setup Barcode Detector logic
  async function setupBarcodeDetection() {
    const video = videoRef.current;
    if (!video) return;

    // Supported formats we are interested in (Requirements 6)
    const nativeFormats = ['code_128', 'code_39', 'ean_13', 'ean_8', 'upc_a', 'upc_e', 'itf', 'qr_code'];
    const zxingFormats = [
      BarcodeFormat.CODE_128,
      BarcodeFormat.CODE_39,
      BarcodeFormat.EAN_13,
      BarcodeFormat.EAN_8,
      BarcodeFormat.UPC_A,
      BarcodeFormat.UPC_E,
      BarcodeFormat.ITF,
      BarcodeFormat.QR_CODE
    ];

    // 1. Pre-initialize ZXing MultiFormat Reader as the reliable standby fallback
    try {
      const hints = new Map();
      hints.set(DecodeHintType.POSSIBLE_FORMATS, zxingFormats);
      hints.set(DecodeHintType.TRY_HARDER, true);

      const reader = new BrowserMultiFormatReader(hints);
      zxingReaderRef.current = reader;
    } catch (err) {
      console.error('Failed to pre-initialize standby ZXing reader:', err);
    }

    // 2. Try Native BarcodeDetector
    const supportsNative = 'BarcodeDetector' in window;
    let nativeActive = false;
    if (supportsNative) {
      try {
        const nativeDetector = new (window as any).BarcodeDetector({ formats: nativeFormats });
        nativeDetectorRef.current = nativeDetector;
        setActiveDetector('native');
        nativeActive = true;
      } catch (err) {
        console.warn('Native BarcodeDetector initialization failed, falling back to pure ZXing:', err);
      }
    }

    if (!nativeActive) {
      if (zxingReaderRef.current) {
        setActiveDetector('zxing');
      } else {
        setActiveDetector('none');
        setErrorMessage('Gagal memuat engine pembaca barcode.');
      }
    }

    setDetectionQuality('ready');
    startContinuousDetectionLoop();
  }

  // Continuous Detection Frame Loop
  function startContinuousDetectionLoop() {
    // Prevent duplicate animation frames
    if (animationFrameRef.current !== null) {
      cancelAnimationFrame(animationFrameRef.current);
    }

    const detectFrame = async () => {
      // If stream has been cleaned up, stop the loop completely
      if (!streamRef.current) return;

      const video = videoRef.current;
      if (!video || video.paused || video.ended || video.readyState < 2) {
        if (streamRef.current) {
          animationFrameRef.current = requestAnimationFrame(detectFrame);
        }
        return;
      }

      // Lock decoding synchronously if we're paused, scanning is locked, or during a cooldown
      if (!isDecodingRef.current) {
        if (streamRef.current) {
          animationFrameRef.current = requestAnimationFrame(detectFrame);
        }
        return;
      }

      // Requirement 7: Jangan memproses frame yang sama berulang-ulang
      if (video.currentTime === lastVideoTimeRef.current) {
        if (streamRef.current) {
          animationFrameRef.current = requestAnimationFrame(detectFrame);
        }
        return;
      }
      lastVideoTimeRef.current = video.currentTime;

      // Throttle scanning to about 25 FPS (every 40ms) to ensure lightweight CPU consumption while staying snappy
      const now = performance.now();
      if (now - lastScanTimeRef.current < 40) {
        if (streamRef.current) {
          animationFrameRef.current = requestAnimationFrame(detectFrame);
        }
        return;
      }
      lastScanTimeRef.current = now;

      // Skip decoding if global cooldown period is active
      if (now < cooldownUntilRef.current) {
        if (streamRef.current) {
          animationFrameRef.current = requestAnimationFrame(detectFrame);
        }
        return;
      }

      // Automatically cycle zoom and focus to search for barcode without button press
      const ZOOM_CYCLE_INTERVAL = 3500; // 3.5 seconds per zoom level
      if (lastAutoZoomTimeRef.current === 0) {
        lastAutoZoomTimeRef.current = now;
      } else if (now - lastAutoZoomTimeRef.current > ZOOM_CYCLE_INTERVAL) {
        lastAutoZoomTimeRef.current = now;
        
        // Define standard auto-zoom levels: standard (1.0x) -> zoomed-in medium (1.5x) -> zoomed-in high (2.2x) -> repeat
        const zoomLevels = [1.0, 1.5, 2.2, 1.0];
        const currentCycleIndex = Math.floor(now / ZOOM_CYCLE_INTERVAL) % zoomLevels.length;
        const nextZoom = zoomLevels[currentCycleIndex];
        
        handleZoomChange(nextZoom);
        
        // Trigger focus refresh to ensure sharp focus at the new zoom level
        triggerFocus();
      }

      const videoWidth = video.videoWidth;
      const videoHeight = video.videoHeight;
      if (!videoWidth || !videoHeight) {
        if (streamRef.current) {
          animationFrameRef.current = requestAnimationFrame(detectFrame);
        }
        return;
      }

      try {
        if (!canvasRef.current) {
          canvasRef.current = document.createElement('canvas');
        }
        const canvas = canvasRef.current;

        const container = video.parentElement;
        const containerWidth = container ? container.clientWidth : 640;
        const containerHeight = container ? container.clientHeight : 480;

        // Calculate object-cover crop coordinates matching screen positioning
        const videoRatio = videoWidth / videoHeight;
        const containerRatio = containerWidth / containerHeight;

        let scale = 1;
        let offsetX = 0;
        let offsetY = 0;

        if (videoRatio > containerRatio) {
          scale = containerHeight / videoHeight;
          const renderedWidth = videoWidth * scale;
          offsetX = (renderedWidth - containerWidth) / 2;
        } else {
          scale = containerWidth / videoWidth;
          const renderedHeight = videoHeight * scale;
          offsetY = (renderedHeight - containerHeight) / 2;
        }

        // Screen size of visual target reticle (Requirement 6: 300x200 center box)
        const rectWidth = 300;
        const rectHeight = 200;
        const rectX = (containerWidth - rectWidth) / 2;
        const rectY = (containerHeight - rectHeight) / 2;

        // Expand scanning area slightly by 1.25x for better barcode tolerance (Requirement 9)
        const expansion = 1.25;
        const wWidth = rectWidth * expansion;
        const wHeight = rectHeight * expansion;
        const wX = rectX - (wWidth - rectWidth) / 2;
        const wY = rectY - (wHeight - rectHeight) / 2;

        // Convert back to original source video coordinates
        let sx = (wX + offsetX) / scale;
        let sy = (wY + offsetY) / scale;
        let sWidth = wWidth / scale;
        let sHeight = wHeight / scale;

        // Apply digital zoom factor if digital zoom is currently active (> 1.0)
        const activeDigitalZoom = digitalZoomRef.current;
        if (activeDigitalZoom > 1.0) {
          const originalSWidth = sWidth;
          const originalSHeight = sHeight;
          
          sWidth = sWidth / activeDigitalZoom;
          sHeight = sHeight / activeDigitalZoom;
          
          // Center the zoomed-in coordinates
          sx = sx + (originalSWidth - sWidth) / 2;
          sy = sy + (originalSHeight - sHeight) / 2;
        }

        // Safeguard video bounding constraints
        if (sx < 0) { sx = 0; sWidth = videoWidth; }
        if (sy < 0) { sy = 0; sHeight = videoHeight; }
        if (sx + sWidth > videoWidth) { sWidth = videoWidth - sx; }
        if (sy + sHeight > videoHeight) { sHeight = videoHeight - sy; }

        // Dynamic alternate frame strategies to read barcode at multiple angles & distance tolerances
        const rotationIndex = scanAttemptsRef.current % 4; // 0 = 0deg, 1 = 90deg, 2 = 0deg, 3 = 270deg
        const useFullFrame = scanAttemptsRef.current > 0 && scanAttemptsRef.current % 12 === 0;
        scanAttemptsRef.current += 1;

        // Draw rotated / straight cropped region onto our canvas with zero aspect ratio distortion
        const isRotated = !useFullFrame && (rotationIndex === 1 || rotationIndex === 3);
        const targetWidth = useFullFrame ? videoWidth : (isRotated ? Math.round(sHeight) : Math.round(sWidth));
        const targetHeight = useFullFrame ? videoHeight : (isRotated ? Math.round(sWidth) : Math.round(sHeight));

        if (canvas.width !== targetWidth || canvas.height !== targetHeight) {
          canvas.width = targetWidth;
          canvas.height = targetHeight;
        }

        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.save();
          
          // Requirement 9: High-performance contrast stretch / grayscale filter on canvas to sharpen code edges
          if ('filter' in ctx) {
            ctx.filter = 'contrast(1.7) brightness(1.15) grayscale(1.0)';
          }

          if (useFullFrame) {
            // Alternating step: Scan full frame to catch barcodes slightly out of center bounds
            ctx.drawImage(video, 0, 0, videoWidth, videoHeight, 0, 0, canvas.width, canvas.height);
          } else if (isRotated) {
            const angle = rotationIndex === 1 ? 90 : 270;
            ctx.translate(canvas.width / 2, canvas.height / 2);
            ctx.rotate((angle * Math.PI) / 180);
            ctx.drawImage(video, sx, sy, sWidth, sHeight, -sWidth / 2, -sHeight / 2, sWidth, sHeight);
          } else {
            ctx.drawImage(video, sx, sy, sWidth, sHeight, 0, 0, canvas.width, canvas.height);
          }
          ctx.restore();

          // Requirement 10: Analyze lighting & quality dynamically from frame pixels (sampled to keep CPU load low)
          if (scanAttemptsRef.current % 15 === 0) {
            try {
              const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
              const data = imgData.data;
              let colorSum = 0;
              let count = 0;
              // Sample every 128th pixel to be lightning fast and keep responsiveness smooth
              for (let i = 0; i < data.length; i += 128) {
                colorSum += (data[i] + data[i+1] + data[i+2]) / 3;
                count++;
              }
              const avgBrightness = colorSum / count;
              if (avgBrightness < 55) {
                setDetectionQuality('low_light');
              } else if (scanAttemptsRef.current > 40) {
                setDetectionQuality('stabilizing');
              } else {
                setDetectionQuality('ready');
              }
            } catch (e) {
              // Fail silently on canvas security/read limitations
            }
          }

          let detectedBarcode = '';

          // 1. Try Native BarcodeDetector first (Requirement 1)
          if (activeDetector === 'native' && nativeDetectorRef.current) {
            try {
              const detected = await nativeDetectorRef.current.detect(canvas);
              if (detected && detected.length > 0) {
                detectedBarcode = detected[0].rawValue;
              }
            } catch (e) {
              console.warn('Native BarcodeDetector runtime failure:', e);
            }
          }

          // 2. Fallback to ZXing synchronously on offscreen canvas
          if (!detectedBarcode && zxingReaderRef.current) {
            try {
              const luminanceSource = new HTMLCanvasElementLuminanceSource(canvas);
              
              // Sequence/Alternate binarizers for absolute maximum reading tolerance
              let binarizer;
              if (scanAttemptsRef.current % 2 === 0) {
                binarizer = new HybridBinarizer(luminanceSource);
              } else {
                binarizer = new GlobalHistogramBinarizer(luminanceSource);
              }
              
              const binaryBitmap = new BinaryBitmap(binarizer);
              const result = zxingReaderRef.current.decodeBitmap(binaryBitmap);
              if (result) {
                detectedBarcode = result.getText();
              }
            } catch (e) {
              // Fallback fallback: try the opposite binarizer immediately to double reading chance on tough barcodes
              try {
                const luminanceSource = new HTMLCanvasElementLuminanceSource(canvas);
                const otherBinarizer = (scanAttemptsRef.current % 2 !== 0) 
                  ? new HybridBinarizer(luminanceSource)
                  : new GlobalHistogramBinarizer(luminanceSource);
                const binaryBitmap = new BinaryBitmap(otherBinarizer);
                const result = zxingReaderRef.current.decodeBitmap(binaryBitmap);
                if (result) {
                  detectedBarcode = result.getText();
                }
              } catch (err2) {}
            }
          }

          if (detectedBarcode && isDecodingRef.current) {
            handleSuccessfulScan(detectedBarcode);
          }
        }
      } catch (err) {
        console.warn('Error in continuous frame scan loop:', err);
      }

      if (streamRef.current) {
        animationFrameRef.current = requestAnimationFrame(detectFrame);
      }
    };

    if (streamRef.current) {
      animationFrameRef.current = requestAnimationFrame(detectFrame);
    }
  }

  function handleSuccessfulScan(barcode: string) {
    const now = performance.now();
    const lastScanOfThisBarcode = recentScansRef.current[barcode] || 0;
    
    // Cooldown rules for real-time continuous scanning (Requirement 2):
    // 1. Same barcode: 1800ms cooldown (prevents duplicate reads of the exact same item)
    // 2. Different barcode: 800ms cooldown (allows scanning multiple different items very fast)
    const isSameBarcode = barcode === lastScannedResult;
    const cooldownPeriod = isSameBarcode ? 1800 : 800;

    if (now - lastScanOfThisBarcode < cooldownPeriod) {
      // Still in cooldown period, skip to avoid double scan trigger
      return;
    }

    recentScansRef.current[barcode] = now;
    setLastScannedResult(barcode);
    setDetectionQuality('detected');

    // 1. Audio register beep via high-performance Web Audio API
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(1400, audioCtx.currentTime); // Sweet clean POS beep
      gainNode.gain.setValueAtTime(0.08, audioCtx.currentTime);
      
      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.1); // Fast 100ms chirp
    } catch (e) {
      // Audio context might be blocked or unsupported, fail silently
    }

    // 2. Tactile vibration feedback (supported on Chrome Android)
    if (navigator.vibrate) {
      try {
        navigator.vibrate(100); 
      } catch (e) {
        // Fail silently
      }
    }

    // Dispatch barcode result instantly to parent
    onScan(barcode);

    // Automatically return to ready state after 800ms visual feedback
    setTimeout(() => {
      setDetectionQuality('ready');
    }, 800);
  }

  function stopAllStreams() {
    isDecodingRef.current = false;

    // Cancel continuous scanning animation frame
    if (animationFrameRef.current !== null) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }

    // Stop Media Stream Tracks
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => {
        try {
          track.stop();
        } catch (e) {}
      });
      streamRef.current = null;
    }

    // Reset ZXing Reader
    if (zxingReaderRef.current) {
      try {
        zxingReaderRef.current.reset();
      } catch (e) {}
      zxingReaderRef.current = null;
    }

    // Reset Video source
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }

    nativeDetectorRef.current = null;
    setActiveDetector('none');
    setIsDetecting(true);
    scanAttemptsRef.current = 0;
    lastVideoTimeRef.current = -1;
    lastAutoZoomTimeRef.current = 0;
    digitalZoomRef.current = 1.0;
  }

  // Force autofocus recalculation and cycle state
  const triggerFocus = async () => {
    const track = streamRef.current?.getVideoTracks()[0];
    if (track && track.readyState === 'live') {
      try {
        const capabilities = track.getCapabilities ? track.getCapabilities() : {};
        
        // Try resetting focusMode constraint to force hardware search cycle
        if ('focusMode' in capabilities) {
          const focusModes = (capabilities as any).focusMode || [];
          if (focusModes.includes('single-shot') && focusModes.includes('continuous')) {
            await safeApplyConstraints(track, {
              advanced: [{ focusMode: 'single-shot' }]
            } as any);
            setTimeout(async () => {
              await safeApplyConstraints(track, {
                advanced: [{ focusMode: 'continuous' }]
              } as any);
            }, 200);
          } else if (focusModes.includes('continuous')) {
            await safeApplyConstraints(track, {
              advanced: [{ focusMode: 'continuous' }]
            } as any);
          }
        }
        
        // Industry refocus trick: flash torch briefly to force light balance re-adaptation
        if (hasFlashSupport && !isFlashOn) {
          await safeApplyConstraints(track, { advanced: [{ torch: true }] } as any);
          setTimeout(async () => {
            await safeApplyConstraints(track, { advanced: [{ torch: false }] } as any);
          }, 120);
        }
        
        // Update user quality status
        setDetectionQuality('ready');
        
        // Play focus feedback chirp
        try {
          const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
          const osc = audioCtx.createOscillator();
          const gain = audioCtx.createGain();
          osc.connect(gain);
          gain.connect(audioCtx.destination);
          osc.frequency.setValueAtTime(800, audioCtx.currentTime);
          gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
          osc.start();
          osc.stop(audioCtx.currentTime + 0.08);
        } catch (e) {}
      } catch (e) {
        console.warn('Focus recalculation application failed:', e);
      }
    }
  };

  // Handle switching front/back camera (manual toggle)
  const toggleFacingMode = () => {
    setIsFlashOn(false);
    const nextMode = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextMode);
    
    if (cameras.length > 0) {
      const targetLabel = nextMode === 'environment' ? 'back' : 'front';
      const matchedDevice = cameras.find(d => 
        d.label.toLowerCase().includes(targetLabel) || 
        d.label.toLowerCase().includes(nextMode === 'environment' ? 'rear' : 'selfie')
      );
      if (matchedDevice) {
        setSelectedCameraId(matchedDevice.deviceId);
      } else {
        // Toggle device index as fallback
        const currentIdx = cameras.findIndex(c => c.deviceId === selectedCameraId);
        const nextIdx = (currentIdx + 1) % cameras.length;
        setSelectedCameraId(cameras[nextIdx].deviceId);
      }
    }
  };

  // Switch to specific camera ID from dropdown
  const handleCameraChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setIsFlashOn(false);
    setSelectedCameraId(e.target.value);
  };

  if (!isOpen) return null;

  return (
    <div id="barcode-scanner-overlay" className="fixed inset-0 bg-slate-950 z-[9999] flex flex-col justify-between text-white font-sans antialiased select-none">
      
      {/* Header - Minimal, Low Profile */}
      <div className="px-4 py-3 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 flex items-center justify-between z-30 shrink-0 h-14">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-500 border border-blue-500/30 flex items-center justify-center shrink-0">
            <Camera className="w-4 h-4 text-blue-400" />
          </div>
          <div>
            <h3 className="font-semibold text-xs sm:text-sm text-slate-100 tracking-tight leading-none">{title}</h3>
            <p className="text-[11px] text-slate-400 mt-0.5">POS Quick Scanner</p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => {
            stopAllStreams();
            onClose();
          }}
          className="w-8 h-8 rounded-full bg-slate-800/80 hover:bg-slate-700 active:scale-95 text-slate-300 hover:text-white flex items-center justify-center transition-all cursor-pointer border border-slate-700/50"
          aria-label="Tutup Scanner"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Main Scanner Stage */}
      <div className="flex-1 relative flex flex-col items-center justify-center overflow-hidden">
        
        {permissionState === 'loading' && (
          <div className="text-center space-y-3 z-20">
            <RefreshCw className="w-9 h-9 text-blue-500 animate-spin mx-auto" />
            <p className="text-xs text-slate-300 font-medium">Menginisialisasi kamera...</p>
          </div>
        )}

        {permissionState === 'denied' && (
          <div className="max-w-md w-full bg-slate-900/90 border border-red-500/30 rounded-2xl p-6 text-center space-y-4 z-20 m-4 shadow-2xl backdrop-blur-md">
            <div className="w-11 h-11 bg-red-500/15 text-red-400 rounded-full flex items-center justify-center mx-auto border border-red-500/30">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <h4 className="font-bold text-sm text-slate-100">Akses Kamera Ditolak</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                {errorMessage}
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                stopAllStreams();
                onClose();
              }}
              className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs rounded-xl transition-all cursor-pointer border border-slate-700"
            >
              Tutup
            </button>
          </div>
        )}

        {/* Camera Video Stream */}
        <video
          ref={videoRef}
          className={`absolute inset-0 w-full h-full object-cover ${permissionState === 'granted' ? 'block' : 'hidden'}`}
          muted
          playsInline
        />

        {permissionState === 'granted' && (
          <>
            {/* Camera Overlay Mask - Darkened Outside Area with Crisp Unblurred Scanner Viewport */}
            <div className="absolute inset-0 pointer-events-none flex flex-col justify-between z-10">
              {/* Top shade */}
              <div className="flex-1 w-full bg-slate-950/50 transition-colors duration-300" />
              
              {/* Middle row containing scanner reticle */}
              <div className="h-[200px] w-full flex">
                <div className="flex-1 bg-slate-950/50 transition-colors duration-300" />
                
                {/* Precision Corner Bracket Scanner Box (280x200 or 320x200) - Uncovered Glass Area */}
                <div className="w-[280px] sm:w-[320px] h-[200px] relative flex items-center justify-center">
                  
                  {/* Outer subtle guide hairline */}
                  <div className={`absolute inset-0 rounded-xl border transition-colors duration-300 ${
                    detectionQuality === 'detected'
                      ? 'border-emerald-500/30'
                      : 'border-blue-500/20'
                  }`} />

                  {/* Top-Left Corner Bracket */}
                  <div className={`absolute -top-[1.5px] -left-[1.5px] w-7 h-7 border-t-[3px] border-l-[3px] rounded-tl-lg transition-all duration-300 ${
                    detectionQuality === 'detected' 
                      ? 'border-emerald-400 drop-shadow-[0_0_6px_rgba(52,211,153,0.7)]' 
                      : 'border-blue-500 drop-shadow-[0_0_6px_rgba(59,130,246,0.6)]'
                  }`} />
                  
                  {/* Top-Right Corner Bracket */}
                  <div className={`absolute -top-[1.5px] -right-[1.5px] w-7 h-7 border-t-[3px] border-r-[3px] rounded-tr-lg transition-all duration-300 ${
                    detectionQuality === 'detected' 
                      ? 'border-emerald-400 drop-shadow-[0_0_6px_rgba(52,211,153,0.7)]' 
                      : 'border-blue-500 drop-shadow-[0_0_6px_rgba(59,130,246,0.6)]'
                  }`} />
                  
                  {/* Bottom-Left Corner Bracket */}
                  <div className={`absolute -bottom-[1.5px] -left-[1.5px] w-7 h-7 border-b-[3px] border-l-[3px] rounded-bl-lg transition-all duration-300 ${
                    detectionQuality === 'detected' 
                      ? 'border-emerald-400 drop-shadow-[0_0_6px_rgba(52,211,153,0.7)]' 
                      : 'border-blue-500 drop-shadow-[0_0_6px_rgba(59,130,246,0.6)]'
                  }`} />
                  
                  {/* Bottom-Right Corner Bracket */}
                  <div className={`absolute -bottom-[1.5px] -right-[1.5px] w-7 h-7 border-b-[3px] border-r-[3px] rounded-br-lg transition-all duration-300 ${
                    detectionQuality === 'detected' 
                      ? 'border-emerald-400 drop-shadow-[0_0_6px_rgba(52,211,153,0.7)]' 
                      : 'border-blue-500 drop-shadow-[0_0_6px_rgba(59,130,246,0.6)]'
                  }`} />

                  {/* Smooth 60fps Laser Scanning Line with Tight Neon Glow */}
                  <div 
                    className={`absolute left-2 right-2 h-[2px] rounded-full transition-all duration-300 ${
                      detectionQuality === 'detected'
                        ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.9)] opacity-90'
                        : 'bg-gradient-to-r from-transparent via-blue-400 to-transparent shadow-[0_0_8px_rgba(59,130,246,0.9)] animate-[scanLaser_2s_infinite_ease-in-out]'
                    }`}
                    style={{
                      willChange: 'transform',
                      animationPlayState: detectionQuality === 'detected' ? 'paused' : 'running'
                    }}
                  />

                  {/* Success Checkmark Icon Badge */}
                  {detectionQuality === 'detected' && (
                    <div className="w-12 h-12 rounded-full bg-emerald-950/80 border border-emerald-400/80 text-emerald-400 flex items-center justify-center animate-in zoom-in-50 duration-200 shadow-[0_0_16px_rgba(16,185,129,0.4)] backdrop-blur-xs">
                      <Check className="w-6 h-6 stroke-[3]" />
                    </div>
                  )}
                </div>
                
                <div className="flex-1 bg-slate-950/50 transition-colors duration-300" />
              </div>

              {/* Bottom shade */}
              <div className="flex-1 w-full bg-slate-950/50 transition-colors duration-300 flex flex-col items-center justify-start pt-6 px-4">
                
                {/* Status Indicator Pill */}
                <div className="flex flex-col items-center space-y-2 pointer-events-auto">
                  <div className={`inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full border text-xs font-semibold backdrop-blur-md shadow-lg transition-all duration-300 ${
                    detectionQuality === 'detected'
                      ? 'bg-emerald-950/90 border-emerald-500/50 text-emerald-300 shadow-emerald-900/30'
                      : detectionQuality === 'low_light'
                      ? 'bg-amber-950/90 border-amber-500/50 text-amber-300'
                      : 'bg-slate-900/90 border-slate-800 text-slate-200'
                  }`}>
                    {detectionQuality === 'detected' ? (
                      <>
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping shrink-0" />
                        <span>Barcode Terdeteksi</span>
                      </>
                    ) : detectionQuality === 'low_light' ? (
                      <>
                        <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0" />
                        <span>Pencahayaan Redup</span>
                      </>
                    ) : (
                      <>
                        <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse shrink-0" />
                        <span>Siap Memindai</span>
                      </>
                    )}
                  </div>

                  {lastScannedResult && (
                    <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-lg bg-blue-950/80 border border-blue-500/30 text-blue-200 text-xs font-mono font-bold shadow-md">
                      <span className="text-[10px] text-blue-400 font-sans uppercase font-medium">Terakhir:</span>
                      <span>{lastScannedResult}</span>
                    </div>
                  )}
                </div>

              </div>
            </div>

            {errorMessage && (
              <div className="absolute top-16 left-4 right-4 bg-red-900/90 border border-red-500/40 text-white p-3 rounded-xl text-xs flex items-center space-x-2 shadow-2xl backdrop-blur-md z-30">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                <span className="font-medium">{errorMessage}</span>
              </div>
            )}
          </>
        )}
      </div>

      {/* Control Panel Footer */}
      {permissionState === 'granted' && (
        <div className="p-4 sm:p-5 bg-slate-950/95 border-t border-slate-800/80 flex flex-col space-y-3 z-30 shrink-0">
          
          {/* Custom Camera Selection Dropdown (if > 1 camera detected) */}
          {cameras.length > 1 && (
            <div className="relative max-w-xs mx-auto w-full">
              <button
                type="button"
                onClick={() => setIsCameraMenuOpen(!isCameraMenuOpen)}
                className="w-full h-9 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 text-xs rounded-xl px-3 flex items-center justify-between font-medium transition-colors cursor-pointer"
              >
                <span className="truncate">
                  {cameras.find(c => c.deviceId === selectedCameraId)?.label || 'Pilih Kamera'}
                </span>
                <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${isCameraMenuOpen ? 'rotate-180' : ''}`} />
              </button>

              {isCameraMenuOpen && (
                <div className="absolute bottom-11 left-0 right-0 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden z-50 p-1.5 space-y-1 backdrop-blur-xl">
                  {cameras.map((camera, idx) => (
                    <button
                      key={camera.deviceId}
                      type="button"
                      onClick={() => {
                        setIsFlashOn(false);
                        setSelectedCameraId(camera.deviceId);
                        setIsCameraMenuOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 text-xs rounded-lg flex items-center justify-between transition-colors cursor-pointer ${
                        camera.deviceId === selectedCameraId
                          ? 'bg-blue-600/20 text-blue-400 font-semibold border border-blue-500/30'
                          : 'text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <span className="truncate">{camera.label || `Kamera ${idx + 1}`}</span>
                      {camera.deviceId === selectedCameraId && <Check className="w-3.5 h-3.5 text-blue-400 shrink-0 ml-2" />}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Action Buttons Row - Uniform sizing, heights, borders & order */}
          <div className="flex items-center justify-center space-x-2.5 max-w-md mx-auto w-full">
            
            {/* 1. Senter (Flash) */}
            <button
              type="button"
              onClick={() => setIsFlashOn(!isFlashOn)}
              disabled={!hasFlashSupport}
              className={`h-11 sm:h-12 flex-1 rounded-xl flex items-center justify-center space-x-2 px-3 text-xs font-semibold transition-all cursor-pointer ${
                !hasFlashSupport 
                  ? 'opacity-40 cursor-not-allowed bg-slate-900 text-slate-500 border border-slate-800/80' 
                  : isFlashOn 
                    ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/25 active:scale-95 font-bold border border-amber-400' 
                    : 'bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 active:scale-95'
              }`}
            >
              {isFlashOn ? <Zap className="w-4 h-4 fill-current" /> : <ZapOff className="w-4 h-4 text-slate-400" />}
              <span>{isFlashOn ? 'Senter On' : 'Senter'}</span>
            </button>

            {/* 2. Selesai Pindai */}
            <button
              type="button"
              onClick={() => {
                stopAllStreams();
                onClose();
              }}
              className="h-11 sm:h-12 flex-1 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs rounded-xl flex items-center justify-center space-x-2 px-3 shadow-lg shadow-blue-600/30 active:scale-95 transition-all cursor-pointer border border-blue-400/30"
            >
              <Check className="w-4 h-4" />
              <span>
                {multiScan && scannedCount > 0 ? `Selesai (${scannedCount})` : 'Selesai Pindai'}
              </span>
            </button>

            {/* 3. Ganti Kamera */}
            <button
              type="button"
              onClick={toggleFacingMode}
              className="h-11 sm:h-12 flex-1 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 font-semibold text-xs rounded-xl flex items-center justify-center space-x-2 px-3 active:scale-95 transition-all cursor-pointer"
            >
              <RefreshCw className="w-4 h-4 text-slate-400" />
              <span>Ganti Kamera</span>
            </button>
          </div>

        </div>
      )}

      {/* 60fps GPU Accelerated Scan Laser Animation */}
      <style>{`
        @keyframes scanLaser {
          0% { top: 8px; }
          50% { top: 188px; }
          100% { top: 8px; }
        }
      `}</style>
    </div>
  );
}
