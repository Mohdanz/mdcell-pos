import { 
  INITIAL_USERS, 
  INITIAL_PRODUCTS, 
  INITIAL_EWALLETS, 
  INITIAL_PHYSICAL_CATEGORIES,
  INITIAL_VOUCHER_SERIALS
} from '../data/initialData.js';

// In-memory demo/mock database state
export const demoDb = {
  users: [] as any[],
  physicalCategories: [] as any[],
  products: [] as any[],
  eWallets: [] as any[],
  transactions: [] as any[],
  eWalletHistories: [] as any[],
  shifts: [] as any[],
  journalEntries: [] as any[],
  journalLines: [] as any[],
  accounts: [] as any[],
  voucherSerials: [] as any[],
  systemLogs: [] as any[],
  accountingBudgets: [] as any[],
};

export let isDemoModeActive = false;

// Set demo mode active state
export function setDemoModeActive(active: boolean) {
  isDemoModeActive = active;
  if (active && demoDb.users.length === 0) {
    initDemoDb();
  }
}

// Chart of Accounts used in the application
export const CHART_OF_ACCOUNTS = [
  { code: '101', name: 'Kas di Tangan (Drawer)', category: 'Asset', normalBalance: 'Debit' },
  { code: '102', name: 'Saldo E-Wallet & Bank', category: 'Asset', normalBalance: 'Debit' },
  { code: '103', name: 'Persediaan Barang Dagang', category: 'Asset', normalBalance: 'Debit' },
  { code: '301', name: 'Modal Pemilik', category: 'Equity', normalBalance: 'Credit' },
  { code: '302', name: 'Laba Ditahan', category: 'Equity', normalBalance: 'Credit' },
  { code: '401', name: 'Pendapatan Penjualan', category: 'Revenue', normalBalance: 'Credit' },
  { code: '402', name: 'Pendapatan Jasa & Komisi', category: 'Revenue', normalBalance: 'Credit' },
  { code: '501', name: 'Harga Pokok Penjualan (HPP)', category: 'Expense', normalBalance: 'Debit' },
  { code: '502', name: 'Beban Selisih Kas Shift', category: 'Expense', normalBalance: 'Debit' },
  { code: '503', name: 'Beban Diskon & Promosi', category: 'Expense', normalBalance: 'Debit' },
  { code: '504', name: 'Beban Listrik & Internet', category: 'Expense', normalBalance: 'Debit' },
  { code: '505', name: 'Beban Sewa Konter', category: 'Expense', normalBalance: 'Debit' },
  { code: '506', name: 'Beban Gaji & Operator', category: 'Expense', normalBalance: 'Debit' },
  { code: '507', name: 'Beban Operasional Lain', category: 'Expense', normalBalance: 'Debit' },
];

export function initDemoDb() {
  console.log('✨ Initializing empty in-memory Preview database...');
  
  demoDb.users = JSON.parse(JSON.stringify(INITIAL_USERS)).map((u: any) => ({
    ...u,
    avatarColor: u.avatarColor || 'bg-slate-500',
    password: u.password || '123456'
  }));

  demoDb.physicalCategories = JSON.parse(JSON.stringify(INITIAL_PHYSICAL_CATEGORIES));
  demoDb.eWallets = JSON.parse(JSON.stringify(INITIAL_EWALLETS));
  demoDb.products = JSON.parse(JSON.stringify(INITIAL_PRODUCTS));

  demoDb.accounts = JSON.parse(JSON.stringify(CHART_OF_ACCOUNTS));
  demoDb.transactions = [];
  demoDb.eWalletHistories = [];
  demoDb.shifts = [];
  demoDb.journalEntries = [];
  demoDb.journalLines = [];
  demoDb.voucherSerials = JSON.parse(JSON.stringify(INITIAL_VOUCHER_SERIALS));
  demoDb.accountingBudgets = [];
  
  demoDb.systemLogs = [
    {
      id: 'log-1',
      level: 'INFO',
      category: 'System',
      message: 'Mode Preview Diaktifkan (State Kosong)',
      details: 'Aplikasi MD POS berjalan dalam Mode Preview. Seluruh data transaksi, produk, saldo, dan pembukuan dimulai dari kosong (0) tanpa data fiktif.',
      createdAt: new Date().toISOString()
    }
  ];

  console.log('✅ Preview database initialized successfully with completely empty states!');
}

// System logging for demo mode
function logDemoEvent(level: string, category: string, message: string, details?: string) {
  demoDb.systemLogs.unshift({
    id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    level,
    category,
    message,
    details: details || '',
    createdAt: new Date().toISOString()
  });
}

// Express request handler interceptor middleware
export function handleDemoRequest(req: any, res: any, next: any) {
  const nowStr = new Date().toISOString();

  if (!isDemoModeActive) {
    return next();
  }

  const { method, path: reqPath } = req;
  
  // Only intercept API calls
  if (!reqPath.startsWith('/api/')) {
    return next();
  }

  console.log(`[DEMO MODE INTERCEPT] ${method} ${reqPath}`);

  try {
    // -------------------------------------------------------------
    // AUTH LOGINS
    // -------------------------------------------------------------
    if (method === 'POST' && reqPath === '/api/auth/login') {
      const { username, password } = req.body;
      if (!username || !password) {
        return res.status(400).json({ error: 'Username dan Password wajib diisi.' });
      }

      const cleanUsername = username.toLowerCase().trim();
      const user = demoDb.users.find(u => u.username.toLowerCase() === cleanUsername);

      if (!user) {
        logDemoEvent('WARNING', 'Auth', `Upaya masuk gagal (Mode Demo): Username tidak ditemukan (${cleanUsername})`);
        return res.status(401).json({ error: 'Username atau Password salah.' });
      }

      if (user.password !== password) {
        logDemoEvent('WARNING', 'Auth', `Upaya masuk gagal (Mode Demo): Sandi salah untuk user (${cleanUsername})`);
        return res.status(401).json({ error: 'Username atau Password salah.' });
      }

      const { password: _, ...userWithoutPassword } = user;
      logDemoEvent('INFO', 'Auth', `User berhasil masuk (Mode Demo): ${user.name} (${user.role})`);
      return res.json(userWithoutPassword);
    }

    // -------------------------------------------------------------
    // USERS CRUD
    // -------------------------------------------------------------
    if (reqPath === '/api/users') {
      if (method === 'GET') {
        const sanitized = demoDb.users.map(({ password, ...rest }) => rest);
        return res.json(sanitized);
      }
      if (method === 'POST') {
        const newUser = req.body;
        const generatedId = newUser.id || `u-${Date.now()}`;
        const userObj = {
          id: generatedId,
          username: newUser.username,
          name: newUser.name,
          role: newUser.role,
          email: newUser.email,
          avatarColor: newUser.avatarColor || 'bg-slate-500',
          password: newUser.password || '123456',
        };
        demoDb.users.push(userObj);
        const { password, ...rest } = userObj;
        return res.status(201).json(rest);
      }
    }

    if (reqPath.startsWith('/api/users/')) {
      const id = reqPath.split('/').pop();
      if (method === 'PUT') {
        const index = demoDb.users.findIndex(u => u.id === id);
        if (index !== -1) {
          const updated = req.body;
          demoDb.users[index] = {
            ...demoDb.users[index],
            username: updated.username,
            name: updated.name,
            role: updated.role,
            email: updated.email,
            avatarColor: updated.avatarColor,
            ...(updated.password ? { password: updated.password } : {})
          };
          const { password, ...rest } = demoDb.users[index];
          return res.json(rest);
        }
        return res.status(404).json({ error: 'User tidak ditemukan' });
      }
      if (method === 'DELETE') {
        demoDb.users = demoDb.users.filter(u => u.id !== id);
        return res.json({ success: true });
      }
    }

    // -------------------------------------------------------------
    // CATEGORIES CRUD
    // -------------------------------------------------------------
    if (reqPath === '/api/physical-categories') {
      if (method === 'GET') {
        return res.json(demoDb.physicalCategories);
      }
      if (method === 'POST') {
        const body = req.body;
        demoDb.physicalCategories.push(body);
        return res.status(201).json(body);
      }
    }

    if (reqPath.startsWith('/api/physical-categories/')) {
      const id = reqPath.split('/').pop();
      if (method === 'PUT') {
        const index = demoDb.physicalCategories.findIndex(c => c.id === id);
        if (index !== -1) {
          demoDb.physicalCategories[index] = { ...demoDb.physicalCategories[index], ...req.body };
          return res.json(demoDb.physicalCategories[index]);
        }
        return res.status(404).json({ error: 'Kategori tidak ditemukan' });
      }
      if (method === 'DELETE') {
        demoDb.physicalCategories = demoDb.physicalCategories.filter(c => c.id !== id);
        return res.json({ success: true });
      }
    }

    // -------------------------------------------------------------
    // PRODUCTS CRUD
    // -------------------------------------------------------------
    if (reqPath === '/api/products') {
      if (method === 'GET') {
        // Return products with dynamic stock calculations for massal barcodes
        const productsWithStock = demoDb.products.map(p => {
          if (p.barcodeType === 'massal') {
            const voucherCount = demoDb.voucherSerials.filter(v => v.productId === p.id && v.status === 'READY').length;
            return { ...p, stock: voucherCount };
          }
          return p;
        });
        return res.json(productsWithStock);
      }
      if (method === 'POST') {
        const body = req.body;
        const newProd = {
          id: body.id || `p-${Date.now()}`,
          name: body.name,
          category: body.category,
          operator: body.operator || 'Lainnya',
          purchasePrice: Number(body.purchasePrice || 0),
          sellingPrice: Number(body.sellingPrice || 0),
          stock: Number(body.stock || 0),
          minStockLimit: Number(body.minStockLimit || 5),
          description: body.description || '',
          imageUrl: body.imageUrl || null,
          barcodeType: body.barcodeType || 'none',
          barcode: body.barcode || null,
        };
        demoDb.products.push(newProd);
        return res.status(201).json(newProd);
      }
    }

    if (reqPath.startsWith('/api/products/')) {
      const id = reqPath.split('/').pop();
      if (method === 'PUT') {
        const index = demoDb.products.findIndex(p => p.id === id);
        if (index !== -1) {
          demoDb.products[index] = {
            ...demoDb.products[index],
            ...req.body,
            purchasePrice: Number(req.body.purchasePrice ?? demoDb.products[index].purchasePrice),
            sellingPrice: Number(req.body.sellingPrice ?? demoDb.products[index].sellingPrice),
            stock: Number(req.body.stock ?? demoDb.products[index].stock),
            minStockLimit: Number(req.body.minStockLimit ?? demoDb.products[index].minStockLimit),
          };
          return res.json(demoDb.products[index]);
        }
        return res.status(404).json({ error: 'Produk tidak ditemukan' });
      }
      if (method === 'DELETE') {
        demoDb.products = demoDb.products.filter(p => p.id !== id);
        return res.json({ success: true });
      }
    }

    // -------------------------------------------------------------
    // EWALLETS CRUD
    // -------------------------------------------------------------
    if (reqPath === '/api/ewallets') {
      if (method === 'GET') {
        return res.json(demoDb.eWallets);
      }
      if (method === 'POST') {
        const body = req.body;
        const newWallet = {
          id: body.id || `ew-${Date.now()}`,
          name: body.name,
          provider: body.provider,
          balance: Number(body.balance || 0),
          description: body.description || '',
          isActive: body.isActive !== false,
          logoUrl: body.logoUrl || null,
          category: body.category || 'ewallet'
        };
        demoDb.eWallets.push(newWallet);
        return res.status(201).json(newWallet);
      }
    }

    if (reqPath.startsWith('/api/ewallets/')) {
      const id = reqPath.split('/').pop();
      if (method === 'PUT') {
        const index = demoDb.eWallets.findIndex(w => w.id === id);
        if (index !== -1) {
          demoDb.eWallets[index] = {
            ...demoDb.eWallets[index],
            ...req.body,
            balance: Number(req.body.balance ?? demoDb.eWallets[index].balance),
          };
          return res.json(demoDb.eWallets[index]);
        }
        return res.status(404).json({ error: 'E-Wallet tidak ditemukan' });
      }
      if (method === 'DELETE') {
        demoDb.eWallets = demoDb.eWallets.filter(w => w.id !== id);
        return res.json({ success: true });
      }
    }

    // -------------------------------------------------------------
    // EWALLET HISTORIES
    // -------------------------------------------------------------
    if (reqPath === '/api/ewallet-histories') {
      if (method === 'GET') {
        return res.json(demoDb.eWalletHistories);
      }
      if (method === 'POST') {
        const body = req.body;
        const newHist = {
          id: body.id || `eh-${Date.now()}`,
          eWalletId: body.eWalletId,
          eWalletName: body.eWalletName,
          amount: Number(body.amount || 0),
          type: body.type, // 'in' or 'out'
          transactionId: body.transactionId || null,
          description: body.description || '',
          date: body.date || new Date().toISOString()
        };
        demoDb.eWalletHistories.push(newHist);
        
        // Update balance of the e-wallet
        const wallet = demoDb.eWallets.find(w => w.id === body.eWalletId);
        if (wallet) {
          if (body.type === 'in') {
            wallet.balance = (Number(wallet.balance) || 0) + Number(body.amount);
          } else {
            wallet.balance = (Number(wallet.balance) || 0) - Number(body.amount);
          }
        }
        return res.status(201).json(newHist);
      }
    }

    // -------------------------------------------------------------
    // SHIFTS
    // -------------------------------------------------------------
    if (reqPath === '/api/shifts') {
      if (method === 'GET') {
        return res.json(demoDb.shifts);
      }
      if (method === 'POST') {
        const body = req.body;
        const newShift = {
          id: body.id || `sh-${Date.now()}`,
          cashierId: body.cashierId,
          cashierName: body.cashierName,
          startTime: body.startTime || new Date().toISOString(),
          endTime: null,
          initialCash: Number(body.initialCash || 0),
          actualEndCash: null,
          totalSales: 0,
          totalWithdrawals: 0,
          totalTransferSales: 0,
          cashDifference: 0,
          notes: body.notes || '',
          status: 'open'
        };
        demoDb.shifts.push(newShift);
        logDemoEvent('INFO', 'Shift', `Shift dibuka oleh ${body.cashierName} dengan kas laci Rp ${Number(body.initialCash).toLocaleString('id-ID')}`);
        return res.status(201).json(newShift);
      }
    }

    if (reqPath.startsWith('/api/shifts/')) {
      const id = reqPath.split('/').pop();
      if (method === 'PUT') {
        const index = demoDb.shifts.findIndex(s => s.id === id);
        if (index !== -1) {
          demoDb.shifts[index] = {
            ...demoDb.shifts[index],
            ...req.body,
            endTime: req.body.endTime || demoDb.shifts[index].endTime,
            actualEndCash: req.body.actualEndCash !== undefined ? Number(req.body.actualEndCash) : demoDb.shifts[index].actualEndCash,
            cashDifference: req.body.cashDifference !== undefined ? Number(req.body.cashDifference) : demoDb.shifts[index].cashDifference,
            totalSales: req.body.totalSales !== undefined ? Number(req.body.totalSales) : demoDb.shifts[index].totalSales,
            totalWithdrawals: req.body.totalWithdrawals !== undefined ? Number(req.body.totalWithdrawals) : demoDb.shifts[index].totalWithdrawals,
            totalTransferSales: req.body.totalTransferSales !== undefined ? Number(req.body.totalTransferSales) : demoDb.shifts[index].totalTransferSales,
          };
          if (req.body.status === 'closed') {
            logDemoEvent('INFO', 'Shift', `Shift ditutup oleh ${demoDb.shifts[index].cashierName}. Selisih kas: Rp ${Number(demoDb.shifts[index].cashDifference).toLocaleString('id-ID')}`);
          }
          return res.json(demoDb.shifts[index]);
        }
        return res.status(404).json({ error: 'Shift tidak ditemukan' });
      }
    }

    // -------------------------------------------------------------
    // TRANSACTIONS
    // -------------------------------------------------------------
    if (reqPath === '/api/transactions') {
      if (method === 'GET') {
        return res.json(demoDb.transactions);
      }
      if (method === 'POST') {
        const body = req.body;
        const id = body.id || `tx-${Date.now()}`;
        const newTx = {
          ...body,
          id,
          date: body.date || new Date().toISOString(),
          totalAmount: Number(body.totalAmount || 0),
          totalProfit: Number(body.totalProfit || 0),
          adminFee: Number(body.adminFee || 0),
          items: body.items || [],
        };
        demoDb.transactions.push(newTx);
        return res.status(201).json(newTx);
      }
    }

    // -------------------------------------------------------------
    // BATCH CHECKOUT TRANSACTIONS
    // -------------------------------------------------------------
    if (method === 'POST' && reqPath === '/api/transactions/batch') {
      const { txs, shiftId, cashierId, cashierName } = req.body;
      if (!Array.isArray(txs) || txs.length === 0) {
        return res.status(400).json({ error: 'Tidak ada transaksi untuk diproses.' });
      }

      // Check shift
      const activeShift = demoDb.shifts.find(s => s.id === shiftId);
      if (!activeShift) {
        return res.status(400).json({ error: 'Shift aktif tidak ditemukan.' });
      }

      const savedTransactions = [];
      const nowStr = new Date().toISOString();

      // Date helper
      const formatter = new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Asia/Jakarta',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
      });
      const dateCode = formatter.format(new Date()).replace(/-/g, '');

      // Get count for today's sequence
      const todayPrefix = `TRX-${dateCode}-`;
      let txSequenceCount = demoDb.transactions.filter(t => t.invoiceNumber && t.invoiceNumber.startsWith(todayPrefix)).length;

      for (const txData of txs) {
        const { customerPhone, item, eWalletId } = txData;
        const isWithdrawal = item.type === 'withdrawal' || item.category === 'withdrawal';
        const isDigital = ['pulsa', 'paket_data', 'token_pln', 'topup_game', 'withdrawal', 'edc_transfer'].includes(item.category) || isWithdrawal;
        const isPhysical = !isDigital || eWalletId === 'cash';
        const salesVal = Number(item.sellingPrice || 0) * Number(item.quantity || 1);

        let targetProduct = null;
        if (!isWithdrawal && item.productId !== 'manual' && item.productId !== 'edc_transfer') {
          targetProduct = demoDb.products.find(p => p.id === item.productId);
          if (!targetProduct) {
            return res.status(404).json({ error: `Produk ${item.productName || item.productId} tidak ditemukan.` });
          }
          
          if (targetProduct.barcodeType !== 'massal') {
            if (targetProduct.stock < item.quantity) {
              return res.status(400).json({ error: `Stok produk ${targetProduct.name} tidak cukup. Sisa stok: ${targetProduct.stock}` });
            }
          }
        }

        let dbWallet = demoDb.eWallets.find(w => w.id === eWalletId);
        if (eWalletId === 'cash' && !dbWallet) {
          dbWallet = { id: 'cash', name: 'Uang Tunai Laci', provider: 'Lainnya', balance: 0 };
        }

        if (!dbWallet) {
          return res.status(404).json({ error: 'E-Wallet tidak ditemukan.' });
        }

        // Deduct balances / stocks
        if (isPhysical) {
          if (dbWallet.id !== 'cash') {
            dbWallet.balance = (Number(dbWallet.balance) || 0) + (item.sellingPrice * item.quantity);
          }
          if (targetProduct && targetProduct.barcodeType !== 'massal') {
            targetProduct.stock = Math.max(0, targetProduct.stock - item.quantity);
          }
        } else {
          if (isWithdrawal) {
            const cashNeeded = item.withdrawalType === 'admin_potong' ? (Number(item.amount || 0) - Number(item.adminFee || 0)) : Number(item.amount || 0);
            const currentWithdrawals = Number(activeShift.totalWithdrawals || 0);
            const currentCashInDrawer = Number(activeShift.initialCash || 0) + Number(activeShift.totalSales || 0) - Number(activeShift.totalTransferSales || 0) - currentWithdrawals;
            
            if (currentCashInDrawer < cashNeeded) {
              return res.status(400).json({ 
                error: `Uang di laci kasir tidak cukup untuk penarikan sebesar Rp ${(Number(item.amount) || 0).toLocaleString('id-ID')}. Sisa laci: Rp ${(Number(currentCashInDrawer) || 0).toLocaleString('id-ID')}` 
              });
            }
            // Update wallet balance for withdrawals (add withdrawal cash back to provider balance)
            dbWallet.balance = (Number(dbWallet.balance) || 0) + Number(item.amount);
          } else {
            const deductionAmount = Number(item.purchasePrice || 0) * Number(item.quantity || 1);
            if (Number(dbWallet.balance || 0) < deductionAmount) {
              return res.status(400).json({ 
                error: `Saldo ${dbWallet.name} tidak cukup. Dibutuhkan: Rp ${(Number(deductionAmount) || 0).toLocaleString('id-ID')}, Saldo saat ini: Rp ${(Number(dbWallet.balance) || 0).toLocaleString('id-ID')}` 
              });
            }
            dbWallet.balance = (Number(dbWallet.balance) || 0) - deductionAmount;
          }
        }

        // Generate invoice number
        txSequenceCount++;
        const specificPrefix = item.type === 'edc_transfer'
          ? `TRX-EDC-${dateCode}-`
          : isWithdrawal 
          ? `TRX-WD-${dateCode}-` 
          : isPhysical 
          ? `TRX-FSK-${dateCode}-` 
          : `TRX-${dateCode}-`;
        const invoiceNumber = specificPrefix + String(txSequenceCount).padStart(3, '0');

        const newTxId = `tx-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
        const newTransaction = {
          id: newTxId,
          invoiceNumber,
          date: nowStr,
          customerPhone: customerPhone || '',
          items: [item],
          totalAmount: isWithdrawal ? Number(item.amount) : (Number(item.sellingPrice) * Number(item.quantity)),
          totalProfit: isWithdrawal ? Number(item.adminFee) : (Number(item.profit) * Number(item.quantity)),
          cashierId: cashierId || activeShift.cashierId,
          cashierName: cashierName || activeShift.cashierName,
          eWalletId: dbWallet.id,
          eWalletName: dbWallet.name,
          status: 'success',
          type: item.type === 'edc_transfer' ? 'edc_transfer' : isWithdrawal ? 'withdrawal' : isPhysical ? 'physical' : 'topup',
          withdrawalType: isWithdrawal ? item.withdrawalType : undefined,
          adminFee: isWithdrawal ? Number(item.adminFee) : undefined
        };

        // Save transaction
        demoDb.transactions.unshift(newTransaction);
        savedTransactions.push(newTransaction);

        // Process voucher states (SOLD/FEFO)
        const isVoucher = item.category === 'cat-voucher' || item.category === 'Voucher Internet' || (targetProduct && (targetProduct.category === 'cat-voucher' || targetProduct.category === 'Voucher Internet'));
        if (isVoucher) {
          const scannedBarcodes = item.scannedBarcodes || item.voucherBarcodes || [];
          if (scannedBarcodes.length > 0) {
            for (const bc of scannedBarcodes) {
              const v = demoDb.voucherSerials.find(v => v.barcode === bc && v.status === 'READY');
              if (v) {
                v.status = 'SOLD';
                v.soldTransactionId = newTxId;
                v.soldAt = nowStr;
                v.history = v.history || [];
                v.history.push({ event: 'Terjual', date: nowStr, details: `Terjual via Invoice ${invoiceNumber} oleh Kasir ${cashierName} (Mode Demo)` });
              }
            }
          } else if (item.productId && item.productId !== 'manual') {
            const readyVouchers = demoDb.voucherSerials
              .filter(v => v.productId === item.productId && v.status === 'READY')
              .sort((a, b) => new Date(a.expiredDate || '').getTime() - new Date(b.expiredDate || '').getTime())
              .slice(0, Number(item.quantity || 1));
            
            for (const v of readyVouchers) {
              v.status = 'SOLD';
              v.soldTransactionId = newTxId;
              v.soldAt = nowStr;
              v.history = v.history || [];
              v.history.push({ event: 'Terjual', date: nowStr, details: `Terjual via Invoice ${invoiceNumber} oleh Kasir ${cashierName} (FEFO Mode Demo)` });
            }
          }
        }

        // Add ewallet history
        if (isPhysical && dbWallet.id !== 'cash') {
          demoDb.eWalletHistories.unshift({
            id: `eh-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            eWalletId: dbWallet.id,
            eWalletName: dbWallet.name,
            amount: Number(item.sellingPrice) * Number(item.quantity),
            type: 'in',
            transactionId: newTxId,
            description: `Penjualan fisik ${item.productName || 'Produk'} (Inv: ${invoiceNumber})`,
            date: nowStr
          });
        } else if (!isPhysical) {
          if (isWithdrawal) {
            demoDb.eWalletHistories.unshift({
              id: `eh-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
              eWalletId: dbWallet.id,
              eWalletName: dbWallet.name,
              amount: Number(item.amount),
              type: 'in',
              transactionId: newTxId,
              description: `Tarik Tunai masuk saldo e-wallet konter (Inv: ${invoiceNumber})`,
              date: nowStr
            });
          } else {
            demoDb.eWalletHistories.unshift({
              id: `eh-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
              eWalletId: dbWallet.id,
              eWalletName: dbWallet.name,
              amount: Number(item.purchasePrice) * Number(item.quantity),
              type: 'out',
              transactionId: newTxId,
              description: `Pengeluaran modal topup ${item.productName || 'Produk'} (Inv: ${invoiceNumber})`,
              date: nowStr
            });
          }
        }

        // Update shift totals
        if (isWithdrawal) {
          const cashOut = item.withdrawalType === 'admin_potong' ? (Number(item.amount) - Number(item.adminFee)) : Number(item.amount);
          activeShift.totalWithdrawals = (Number(activeShift.totalWithdrawals) || 0) + cashOut;
        } else {
          if (eWalletId === 'cash') {
            activeShift.totalSales = (Number(activeShift.totalSales) || 0) + salesVal;
          } else {
            activeShift.totalTransferSales = (Number(activeShift.totalTransferSales) || 0) + salesVal;
          }
        }

        // Log general ledger journal entries
        const entryId = `je-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
        demoDb.journalEntries.push({
          id: entryId,
          referenceNumber: invoiceNumber,
          description: isWithdrawal ? `Transaksi Tarik Tunai - ${dbWallet.name}` : `Transaksi Penjualan - ${item.productName}`,
          date: nowStr,
          totalDebit: isWithdrawal ? Number(item.amount) : salesVal,
          totalCredit: isWithdrawal ? Number(item.amount) : salesVal,
          createdBy: cashierName,
        });

        if (isWithdrawal) {
          const cashPaid = item.withdrawalType === 'admin_potong' ? (Number(item.amount) - Number(item.adminFee)) : Number(item.amount);
          demoDb.journalLines.push(
            { id: `jl-${Date.now()}-1`, journalEntryId: entryId, accountCode: '102', debit: Number(item.amount), credit: 0 }, // Saldo E-Wallet Debit
            { id: `jl-${Date.now()}-2`, journalEntryId: entryId, accountCode: '101', debit: 0, credit: cashPaid }, // Kas Drawer Credit
            { id: `jl-${Date.now()}-3`, journalEntryId: entryId, accountCode: '402', debit: 0, credit: Number(item.adminFee) } // Pendapatan Komisi Credit
          );
        } else {
          const purchaseVal = Number(item.purchasePrice) * Number(item.quantity);
          const profitVal = Number(item.profit) * Number(item.quantity);
          
          if (eWalletId === 'cash') {
            demoDb.journalLines.push(
              { id: `jl-${Date.now()}-1`, journalEntryId: entryId, accountCode: '101', debit: salesVal, credit: 0 }, // Kas Drawer Debit
              { id: `jl-${Date.now()}-2`, journalEntryId: entryId, accountCode: '401', debit: 0, credit: salesVal }  // Pendapatan Credit
            );
          } else {
            demoDb.journalLines.push(
              { id: `jl-${Date.now()}-1`, journalEntryId: entryId, accountCode: '102', debit: salesVal, credit: 0 }, // E-wallet Debit
              { id: `jl-${Date.now()}-2`, journalEntryId: entryId, accountCode: '401', debit: 0, credit: salesVal }  // Pendapatan Credit
            );
          }
        }
      }

      logDemoEvent('INFO', 'Database', `Berhasil checkout ${savedTransactions.length} transaksi batch dalam Mode Demo.`);
      return res.json({ success: true, count: savedTransactions.length, txs: savedTransactions });
    }

    // -------------------------------------------------------------
    // VOUCHER MANAGEMENT
    // -------------------------------------------------------------
    if (reqPath === '/api/vouchers') {
      if (method === 'GET') {
        const joinedVouchers = demoDb.voucherSerials.map(v => {
          const prod = demoDb.products.find(p => p.id === v.productId);
          return {
            ...v,
            productName: prod ? prod.name : 'Produk Tidak Diketahui',
            productCategory: prod ? prod.category : '',
            operator: prod ? prod.operator : '',
            sellingPrice: prod ? prod.sellingPrice : 0,
          };
        });
        return res.json(joinedVouchers);
      }
      if (method === 'POST') {
        const body = req.body;
        const count = Number(body.count || 1);
        const addedVouchers = [];
        
        for (let i = 0; i < count; i++) {
          const voucherId = `vs-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
          const barcodeVal = count === 1 ? body.barcode : `${body.barcode}${i + 1}`;
          const serialVal = count === 1 ? body.serialNumber : (body.serialNumber ? `${body.serialNumber}${i + 1}` : '');
          
          const newVoucher = {
            id: voucherId,
            productId: body.productId,
            barcode: barcodeVal,
            serialNumber: serialVal,
            expiredDate: body.expiredDate || null,
            supplier: body.supplier || '',
            purchasePrice: Number(body.purchasePrice || 0),
            status: body.status || 'READY',
            notes: body.notes || '',
            soldTransactionId: null,
            soldAt: null,
            history: [{ event: 'Pendaftaran', date: nowStr, details: 'Pendaftaran kode voucher di Barcode Center (Mode Demo)' }],
            createdAt: nowStr,
            updatedAt: nowStr
          };
          
          demoDb.voucherSerials.push(newVoucher);
          addedVouchers.push(newVoucher);
        }

        logDemoEvent('INFO', 'Product', `Berhasil menambahkan ${count} barcode serial massal dalam Mode Demo.`);
        return res.status(201).json({ success: true, count, vouchers: addedVouchers });
      }
    }

    if (reqPath.startsWith('/api/vouchers/barcode/')) {
      if (method === 'GET') {
        const barcodeParam = reqPath.split('/').pop() || '';
        const v = demoDb.voucherSerials.find(v => v.barcode === barcodeParam);
        if (v) {
          const prod = demoDb.products.find(p => p.id === v.productId);
          return res.json({
            ...v,
            productName: prod ? prod.name : 'Produk Tidak Diketahui',
            productCategory: prod ? prod.category : '',
            operator: prod ? prod.operator : '',
            sellingPrice: prod ? prod.sellingPrice : 0,
          });
        }
        return res.status(404).json({ error: 'Barcode tidak terdaftar' });
      }
    }

    if (reqPath.startsWith('/api/vouchers/')) {
      const id = reqPath.split('/').pop();
      if (method === 'PUT') {
        const index = demoDb.voucherSerials.findIndex(v => v.id === id);
        if (index !== -1) {
          const old = demoDb.voucherSerials[index];
          const updated = {
            ...old,
            ...req.body,
            purchasePrice: Number(req.body.purchasePrice ?? old.purchasePrice),
            updatedAt: nowStr
          };
          demoDb.voucherSerials[index] = updated;
          return res.json(updated);
        }
        return res.status(404).json({ error: 'Barcode tidak ditemukan' });
      }
      if (method === 'DELETE') {
        demoDb.voucherSerials = demoDb.voucherSerials.filter(v => v.id !== id);
        return res.json({ success: true });
      }
    }

    // -------------------------------------------------------------
    // ACCOUNTING (JOURNAL & LEDGER & BUDGETS)
    // -------------------------------------------------------------
    if (reqPath === '/api/accounting/journal') {
      if (method === 'GET') {
        const joinedEntries = demoDb.journalEntries.map(entry => {
          const lines = demoDb.journalLines.filter(l => l.journalEntryId === entry.id);
          return {
            ...entry,
            lines,
          };
        });
        return res.json(joinedEntries);
      }
      if (method === 'POST') {
        const body = req.body;
        const entryId = body.id || `je-${Date.now()}`;
        
        demoDb.journalEntries.push({
          id: entryId,
          referenceNumber: body.referenceNumber || `MAN-${Date.now()}`,
          description: body.description,
          date: body.date || nowStr,
          totalDebit: Number(body.totalDebit || 0),
          totalCredit: Number(body.totalCredit || 0),
          createdBy: body.createdBy || 'Admin',
        });

        if (Array.isArray(body.lines)) {
          body.lines.forEach((l: any) => {
            demoDb.journalLines.push({
              id: `jl-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
              journalEntryId: entryId,
              accountCode: l.accountCode,
              debit: Number(l.debit || 0),
              credit: Number(l.credit || 0),
            });
          });
        }
        return res.status(201).json({ success: true, id: entryId });
      }
      if (method === 'DELETE') {
        demoDb.journalEntries = [];
        demoDb.journalLines = [];
        return res.json({ success: true });
      }
    }

    if (reqPath === '/api/accounting/budgets') {
      if (method === 'GET') {
        return res.json(demoDb.accountingBudgets);
      }
      if (method === 'POST') {
        const body = req.body;
        const newBudget = {
          id: body.id || `bg-${Date.now()}`,
          name: body.name,
          category: body.category,
          amountLimit: Number(body.amountLimit || 0),
          amountUsed: Number(body.amountUsed || 0),
          period: body.period || 'Bulanan',
          startDate: body.startDate || nowStr,
          endDate: body.endDate || null,
          createdAt: nowStr,
        };
        demoDb.accountingBudgets.push(newBudget);
        return res.status(201).json(newBudget);
      }
    }

    if (reqPath.startsWith('/api/accounting/budgets/')) {
      const id = reqPath.split('/').pop();
      if (method === 'DELETE') {
        demoDb.accountingBudgets = demoDb.accountingBudgets.filter(b => b.id !== id);
        return res.json({ success: true });
      }
    }

    // -------------------------------------------------------------
    // SYSTEM LOGS
    // -------------------------------------------------------------
    if (reqPath === '/api/system/logs') {
      if (method === 'GET') {
        return res.json(demoDb.systemLogs);
      }
      if (method === 'DELETE') {
        demoDb.systemLogs = [];
        return res.json({ success: true });
      }
    }

    // -------------------------------------------------------------
    // BACKUPS (MOCKED IN DEMO MODE)
    // -------------------------------------------------------------
    if (reqPath === '/api/system/backups') {
      if (method === 'GET') {
        return res.json([
          { id: 'b-demo-1', filename: 'backup_demo_initial.sql', size: '150 KB', createdAt: nowStr, status: 'success' }
        ]);
      }
      if (method === 'POST') {
        return res.status(201).json({ success: true, filename: `backup_demo_${Date.now()}.sql` });
      }
    }

    if (reqPath.startsWith('/api/system/backups/')) {
      return res.json({ success: true });
    }

    // -------------------------------------------------------------
    // MOCK APP SETTINGS (Local JSON file reads, etc. can be intercepted here)
    // -------------------------------------------------------------
    if (reqPath === '/api/settings') {
      if (method === 'GET') {
        return res.json({
          name: 'MD POS (Preview)',
          slogan: 'KONTER POS MODERN - MODE PREVIEW',
          lowStockLimit: 5,
          currency: 'Rp',
          receiptFooter: 'Terima kasih telah berbelanja!',
        });
      }
      if (method === 'POST') {
        return res.json(req.body);
      }
    }

    // Fallback if endpoint didn't trigger specific intercepts
    return res.status(404).json({ error: `Endpoint ${method} ${reqPath} tidak didukung dalam Mode Preview.` });

  } catch (err: any) {
    console.error(`Error processing DEMO request [${method} ${reqPath}]:`, err);
    return res.status(500).json({ error: 'Internal demo handler error', details: err.message });
  }
}
