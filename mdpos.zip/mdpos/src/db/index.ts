import { drizzle as drizzlePg } from 'drizzle-orm/node-postgres';
import pg from 'pg';
import * as schema from './schema.js';
import dotenv from 'dotenv';
import { migrate as migratePg } from 'drizzle-orm/node-postgres/migrator';
import path from 'path';
import fs from 'fs';

// Load environment variables
dotenv.config();

const databaseUrl = process.env.DATABASE_URL || 'postgresql://md_user:md_password_secure@localhost:5432/md_pos_db';

const { Pool } = pg;
export const pool = new Pool({
  connectionString: databaseUrl,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

export const db = drizzlePg(pool, { schema });

// Validate database connection and run schema migrations
export async function testDbConnection() {
  console.log('🔄 Checking PostgreSQL connection...');
  let client;
  try {
    client = await pool.connect();
    await client.query('SELECT 1');
    console.log('✅ PostgreSQL Connected');
    console.log('✅ Drizzle ORM Initialized with PostgreSQL');
    await runMigrations();
  } catch (err: any) {
    let cleanMessage = 'Database offline';
    if (err.code === 'ECONNREFUSED') {
      cleanMessage = 'Database tidak aktif (ECONNREFUSED) - Berjalan dalam Mode Demo/Preview';
    } else if (err.code === '28P01' || (err.message && err.message.includes('password authentication failed'))) {
      cleanMessage = 'Autentikasi gagal (Password Authentication Failed).';
    } else {
      cleanMessage = err.message || String(err);
    }
    console.log(`ℹ️ Status database: ${cleanMessage}`);
    
    // Throw a clean error so the server can transition into demo mode quietly
    const enrichedError = new Error(cleanMessage);
    (enrichedError as any).code = err.code;
    throw enrichedError;
  } finally {
    if (client) {
      client.release();
    }
  }
}

async function runMigrations() {
  try {
    const migrationsDir = path.join(process.cwd(), 'drizzle');
    if (fs.existsSync(migrationsDir)) {
      console.log('🔄 Running migrations...');
      await migratePg(db, { migrationsFolder: migrationsDir });
      console.log('✅ Migrations completed successfully!');
    } else {
      console.warn('⚠️ Migrations folder not found at:', migrationsDir);
    }
  } catch (err) {
    console.error('❌ Failed to run schema migrations:', err);
    throw err;
  }
}
