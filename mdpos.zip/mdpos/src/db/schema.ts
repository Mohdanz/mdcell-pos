import { pgTable, serial, text, integer, doublePrecision, timestamp, boolean, jsonb, uniqueIndex } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

// Users / Cashiers Table
export const users = pgTable('users', {
  id: text('id').primaryKey(), // We use standard text IDs or Firebase UID
  username: text('username').notNull().unique(),
  name: text('name').notNull(),
  role: text('role').notNull(), // 'admin' | 'kasir'
  email: text('email').notNull(),
  avatarColor: text('avatar_color').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  password: text('password').notNull().default('123456'), // PIN/password bawaan 123456
});

// Physical Categories Table
export const physicalCategories = pgTable('physical_categories', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  icon: text('icon'),
  sortOrder: integer('sort_order').notNull().default(0),
  isActive: boolean('is_active').notNull().default(true),
  createdAt: text('created_at').notNull(),
  updatedAt: text('updated_at').notNull(),
});

// Products Table
export const products = pgTable('products', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  category: text('category').notNull(),
  operator: text('operator').notNull(),
  purchasePrice: doublePrecision('purchase_price').notNull(),
  sellingPrice: doublePrecision('selling_price').notNull(),
  stock: integer('stock').notNull().default(0),
  minStockLimit: integer('min_stock_limit').notNull().default(5),
  description: text('description').notNull().default(''),
  imageUrl: text('image_url'),
  barcodeType: text('barcode_type').notNull().default('none'),
  barcode: text('barcode'),
});

// E-Wallets Table
export const eWallets = pgTable('ewallets', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  provider: text('provider').notNull(), // 'DANA' | 'OVO' | 'GoPay' | 'ShopeePay' | 'LinkAja' | 'Lainnya'
  balance: doublePrecision('balance').notNull().default(0),
  description: text('description').notNull().default(''),
  isActive: boolean('is_active').notNull().default(true),
  logoUrl: text('logo_url'),
  category: text('category').default('ewallet'),
});

// Transactions Table
export const transactions = pgTable('transactions', {
  id: text('id').primaryKey(),
  invoiceNumber: text('invoice_number').notNull().unique(),
  date: text('date').notNull(), // ISO Date string
  customerPhone: text('customer_phone').notNull().default(''),
  totalAmount: doublePrecision('total_amount').notNull(),
  totalProfit: doublePrecision('total_profit').notNull(),
  cashierId: text('cashier_id').references(() => users.id),
  cashierName: text('cashier_name').notNull(),
  eWalletId: text('ewallet_id').references(() => eWallets.id),
  eWalletName: text('ewallet_name').notNull(),
  status: text('status').notNull().default('success'), // 'success' | 'failed' | 'pending'
  type: text('type').default('topup'), // 'topup' | 'withdrawal' | 'physical' | 'edc_transfer'
  withdrawalType: text('withdrawal_type'), // 'admin_luar' | 'admin_potong'
  adminFee: doublePrecision('admin_fee').default(0),
  items: jsonb('items').notNull(), // JSONB containing TransactionItem[]
});

// E-Wallet History Mutations
export const eWalletHistories = pgTable('ewallet_histories', {
  id: text('id').primaryKey(),
  eWalletId: text('ewallet_id').references(() => eWallets.id),
  eWalletName: text('ewallet_name').notNull(),
  amount: doublePrecision('amount').notNull(),
  type: text('type').notNull(), // 'debit' | 'credit'
  transactionId: text('transaction_id'),
  description: text('description').notNull(),
  date: text('date').notNull(), // ISO Date string
});

// Shift Table
export const shifts = pgTable('shifts', {
  id: text('id').primaryKey(),
  cashierId: text('cashier_id').references(() => users.id),
  cashierName: text('cashier_name').notNull(),
  startTime: text('start_time').notNull(),
  endTime: text('end_time'),
  initialCash: doublePrecision('initial_cash').notNull(),
  totalSales: doublePrecision('total_sales').notNull().default(0),
  totalTransferSales: doublePrecision('total_transfer_sales').default(0),
  totalWithdrawals: doublePrecision('total_withdrawals').default(0),
  totalProfit: doublePrecision('total_profit').notNull().default(0),
  totalDiscounts: doublePrecision('total_discounts').default(0),
  transactionCount: integer('transaction_count').notNull().default(0),
  status: text('status').notNull().default('open'), // 'open' | 'closed'
  closedBy: text('closed_by'),
});

// ==========================================
// ACCOUNTING TABLES
// ==========================================

// Chart of Accounts (COA) Table
export const accounts = pgTable('accounts', {
  code: text('code').primaryKey(), // e.g., '101', '401'
  name: text('name').notNull(),
  category: text('category').notNull(), // 'Asset' | 'Liability' | 'Equity' | 'Revenue' | 'Expense'
  normalBalance: text('normal_balance').notNull(), // 'Debit' | 'Credit'
});

// General Journal Entries
export const journalEntries = pgTable('journal_entries', {
  id: text('id').primaryKey(),
  date: text('date').notNull(), // ISO string or YYYY-MM-DD
  reference: text('reference').notNull(), // Invoice, Shift ID, manual reference
  description: text('description').notNull(),
  isManual: boolean('is_manual').default(false),
  createdAt: timestamp('created_at').defaultNow(),
});

// Journal Ledger Lines (Debit & Credit Entries)
export const journalLines = pgTable('journal_lines', {
  id: serial('id').primaryKey(),
  entryId: text('entry_id').references(() => journalEntries.id, { onDelete: 'cascade' }).notNull(),
  accountCode: text('account_code').references(() => accounts.code).notNull(),
  accountName: text('account_name').notNull(),
  type: text('type').notNull(), // 'debit' | 'credit'
  amount: doublePrecision('amount').notNull(),
});

// Budget Plan Table
export const budgets = pgTable('budgets', {
  id: text('id').primaryKey(),
  accountCode: text('account_code').references(() => accounts.code).notNull(),
  accountName: text('account_name').notNull(),
  limit: doublePrecision('limit').notNull(),
  period: text('period').notNull(), // YYYY-MM
});

// Relations Definitions
export const journalEntriesRelations = relations(journalEntries, ({ many }) => ({
  lines: many(journalLines),
}));

export const journalLinesRelations = relations(journalLines, ({ one }) => ({
  entry: one(journalEntries, {
    fields: [journalLines.entryId],
    references: [journalEntries.id],
  }),
  account: one(accounts, {
    fields: [journalLines.accountCode],
    references: [accounts.code],
  }),
}));

// Voucher Serials Table
export const voucherSerials = pgTable('voucher_serials', {
  id: text('id').primaryKey(),
  productId: text('product_id').references(() => products.id, { onDelete: 'cascade' }).notNull(),
  barcode: text('barcode').notNull(),
  serialNumber: text('serial_number'),
  expiredDate: text('expired_date'), // 'YYYY-MM-DD'
  supplier: text('supplier'),
  purchasePrice: doublePrecision('purchase_price').notNull().default(0),
  purchaseDate: text('purchase_date'), // 'YYYY-MM-DD'
  soldTransactionId: text('sold_transaction_id'),
  soldAt: text('sold_at'), // ISO datetime string or text date
  returnedAt: text('returned_at'), // ISO datetime string or text date
  notes: text('notes'),
  status: text('status').notNull().default('READY'), // 'READY' | 'SOLD' | 'RETURNED' | 'DAMAGED' | 'EXPIRED'
  history: jsonb('history').notNull().default('[]'), // JSONB array containing VoucherHistoryItem[]
  createdAt: text('created_at').notNull(),
  updatedAt: text('updated_at').notNull(),
}, (table) => ({
  barcodeIdx: uniqueIndex('barcode_idx').on(table.barcode),
}));


// System Backups Table
export const backups = pgTable('backups', {
  id: text('id').primaryKey(),
  filename: text('filename').notNull(),
  size: integer('size').notNull(), // size in bytes
  status: text('status').notNull(), // 'success' | 'failed'
  type: text('type').notNull(), // 'manual' | 'auto'
  error: text('error'),
  createdAt: text('created_at').notNull(),
});

// System Error & Info Logs Table
export const systemLogs = pgTable('system_logs', {
  id: text('id').primaryKey(),
  timestamp: text('timestamp').notNull(),
  level: text('level').notNull(), // 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL'
  module: text('module').notNull(), // 'Backend' | 'Database' | 'API' | 'Auth' | 'CRUD'
  message: text('message').notNull(),
  stackTrace: text('stack_trace'),
  userId: text('user_id'),
  username: text('username'),
});





