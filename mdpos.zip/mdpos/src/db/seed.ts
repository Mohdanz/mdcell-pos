import { db } from './index.js';
import * as schema from './schema.js';
import { eq } from 'drizzle-orm';
import { 
  INITIAL_USERS, 
  INITIAL_PRODUCTS, 
  INITIAL_EWALLETS, 
  INITIAL_TRANSACTIONS, 
  INITIAL_EWALLET_HISTORIES, 
  INITIAL_PHYSICAL_CATEGORIES,
  INITIAL_VOUCHER_SERIALS
} from '../data/initialData.js';

export const CHART_OF_ACCOUNTS = [
  { code: '101', name: 'Kas di Tangan (Drawer)', category: 'Asset', normalBalance: 'Debit' },
  { code: '102', name: 'Saldo E-Wallet & Bank', category: 'Asset', normalBalance: 'Debit' },
  { code: '103', name: 'Persediaan Barang Dagang', category: 'Asset', normalBalance: 'Debit' },
  { code: '301', name: 'Modal Pemilik', category: 'Equity', normalBalance: 'Credit' },
  { code: '302', name: 'Laba Ditahan', category: 'Equity', normalBalance: 'Credit' },
  { code: '401', name: 'Pendapatan Penjualan', category: 'Revenue', normalBalance: 'Credit' },
  { code: '402', name: 'Pendapatan Jasa & Komisi', category: 'Revenue', normalBalance: 'Credit' },
  { code: '501', name: 'Harga Pokok Penjualan (HPP)', category: 'Expense', normalBalance: 'Debit' },
  { code: '502', name: 'Beban Selisih Kas Shift', category: 'Expense', normalBalance: 'Debit' },
  { code: '503', name: 'Beban Diskon & Promosi', category: 'Expense', normalBalance: 'Debit' },
  { code: '504', name: 'Beban Listrik & Internet', category: 'Expense', normalBalance: 'Debit' },
  { code: '505', name: 'Beban Sewa Konter', category: 'Expense', normalBalance: 'Debit' },
  { code: '506', name: 'Beban Gaji & Operator', category: 'Expense', normalBalance: 'Debit' },
  { code: '507', name: 'Beban Operasional Lain', category: 'Expense', normalBalance: 'Debit' },
];

export async function seedDatabase() {
  console.log('🌱 Starting database seeding check...');

  // 1. Seed Accounts (Chart of Accounts)
  const existingAccounts = await db.select().from(schema.accounts).limit(1);
  if (existingAccounts.length === 0) {
    console.log('Seeding Chart of Accounts...');
    for (const account of CHART_OF_ACCOUNTS) {
      await db.insert(schema.accounts).values({
        code: account.code,
        name: account.name,
        category: account.category,
        normalBalance: account.normalBalance,
      });
    }
  }

  // 2. Seed Users
  const existingUsers = await db.select().from(schema.users).limit(1);
  if (existingUsers.length === 0) {
    console.log('Seeding initial users...');
    for (const user of INITIAL_USERS) {
      await db.insert(schema.users).values({
        id: user.id,
        username: user.username,
        name: user.name,
        role: user.role,
        email: user.email,
        avatarColor: user.avatarColor || 'bg-slate-500',
        password: 'password' in user ? (user as any).password : '123456',
      });
    }
  }

  // 3. Seed Physical Categories
  const existingCategories = await db.select().from(schema.physicalCategories).limit(1);
  if (existingCategories.length === 0) {
    console.log('Seeding initial physical categories...');
    for (const cat of INITIAL_PHYSICAL_CATEGORIES) {
      await db.insert(schema.physicalCategories).values({
        id: cat.id,
        name: cat.name,
        icon: cat.icon || null,
        sortOrder: cat.sort_order || 0,
        isActive: cat.is_active !== false,
        createdAt: cat.created_at || new Date().toISOString(),
        updatedAt: cat.updated_at || new Date().toISOString(),
      });
    }
  }

  // 4. Seed E-Wallets
  const existingWallets = await db.select().from(schema.eWallets).limit(1);
  if (existingWallets.length === 0) {
    console.log('Seeding initial ewallets...');
    for (const ew of INITIAL_EWALLETS) {
      await db.insert(schema.eWallets).values({
        id: ew.id,
        name: ew.name,
        provider: ew.provider,
        balance: ew.balance,
        description: ew.description || '',
        isActive: ew.isActive !== false,
        logoUrl: ew.logoUrl || null,
        category: ew.category || 'ewallet',
      });
    }
  } else {
    // Ensure the fallback 'cash' wallet exists anyway if eWallets table has other entries but is missing 'cash'
    const cashWallet = await db.select().from(schema.eWallets).where(eq(schema.eWallets.id, 'cash')).limit(1);
    if (cashWallet.length === 0) {
      console.log('Adding cash e-wallet for cash transactions...');
      await db.insert(schema.eWallets).values({
        id: 'cash',
        name: 'Uang Tunai Laci',
        provider: 'Lainnya',
        balance: 0,
        description: 'Pembayaran tunai langsung masuk laci kasir',
        isActive: true,
        category: 'ewallet',
      });
    }
  }

  // 5. Seed Products
  const existingProducts = await db.select().from(schema.products).limit(1);
  if (existingProducts.length === 0) {
    console.log('Seeding initial products...');
    for (const prod of INITIAL_PRODUCTS) {
      await db.insert(schema.products).values({
        id: prod.id,
        name: prod.name,
        category: prod.category,
        operator: prod.operator || 'Lainnya',
        purchasePrice: prod.purchasePrice || 0,
        sellingPrice: prod.sellingPrice || 0,
        stock: prod.stock || 0,
        minStockLimit: prod.minStockLimit || 5,
        description: prod.description || '',
        imageUrl: prod.imageUrl || null,
        barcodeType: prod.barcodeType || 'none',
        barcode: prod.barcode || null,
      });
    }
  }

  // 6. Seed Transactions
  const existingTransactions = await db.select().from(schema.transactions).limit(1);
  if (existingTransactions.length === 0) {
    console.log('Seeding initial transactions...');
    for (const tx of INITIAL_TRANSACTIONS) {
      await db.insert(schema.transactions).values({
        id: tx.id,
        invoiceNumber: tx.invoiceNumber,
        date: tx.date || new Date().toISOString(),
        customerPhone: tx.customerPhone || '',
        totalAmount: tx.totalAmount || 0,
        totalProfit: tx.totalProfit || 0,
        cashierId: tx.cashierId || null,
        cashierName: tx.cashierName || 'Kasir',
        eWalletId: tx.eWalletId || null,
        eWalletName: tx.eWalletName || 'Tunai',
        status: tx.status || 'success',
        type: tx.type || 'topup',
        withdrawalType: (tx as any).withdrawalType || null,
        adminFee: (tx as any).adminFee || 0,
        items: tx.items || [],
      });
    }
  }

  // 7. Seed E-Wallet Histories
  const existingHistories = await db.select().from(schema.eWalletHistories).limit(1);
  if (existingHistories.length === 0) {
    console.log('Seeding initial ewallet histories...');
    for (const hist of INITIAL_EWALLET_HISTORIES) {
      await db.insert(schema.eWalletHistories).values({
        id: hist.id,
        eWalletId: hist.eWalletId || null,
        eWalletName: hist.eWalletName,
        amount: hist.amount || 0,
        type: hist.type,
        transactionId: hist.transactionId || null,
        description: hist.description || '',
        date: hist.date || new Date().toISOString(),
      });
    }
  }

  // 8. Seed Voucher Serials
  const existingVoucherSerials = await db.select().from(schema.voucherSerials).limit(1);
  if (existingVoucherSerials.length === 0) {
    console.log('Seeding initial voucher serials...');
    for (const v of INITIAL_VOUCHER_SERIALS) {
      await db.insert(schema.voucherSerials).values({
        id: v.id,
        productId: v.productId,
        barcode: v.barcode,
        serialNumber: v.serialNumber || null,
        expiredDate: v.expiredDate || null,
        supplier: v.supplier || null,
        purchasePrice: v.purchasePrice,
        purchaseDate: v.purchaseDate || null,
        status: v.status,
        notes: v.notes || null,
        history: v.history || [],
        createdAt: v.createdAt || new Date().toISOString(),
        updatedAt: v.updatedAt || new Date().toISOString(),
      });
    }
  }

  console.log('🌱 Database seeding check completed!');
}
