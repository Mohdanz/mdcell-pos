export type Role = 'admin' | 'kasir';

export interface User {
  id: string;
  username: string;
  name: string;
  role: Role;
  email: string;
  avatarColor: string;
}

export type ProductCategory = string;

export interface PhysicalCategory {
  id: string;
  name: string;
  icon?: string;
  sort_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  operator: string; // e.g., 'Telkomsel', 'Indosat', 'XL', 'Tri', 'Smartfren', 'PLN', 'Garena', etc.
  purchasePrice: number; // Harga modal
  sellingPrice: number;  // Harga jual
  stock: number;         // Sisa stok
  minStockLimit: number; // Batas minimal stok untuk peringatan
  description: string;
  imageUrl?: string;
  barcodeType?: 'none' | 'single' | 'massal';
  barcode?: string;
}

export interface EWallet {
  id: string;
  name: string; // e.g., 'DANA Server Utama', 'OVO Merchant Konter'
  provider: 'DANA' | 'OVO' | 'GoPay' | 'ShopeePay' | 'LinkAja' | 'Lainnya';
  balance: number;
  description: string;
  isActive: boolean;
  logoUrl?: string; // Base64 or custom image URL
  category?: 'ewallet' | 'aplikasi';
}

export interface TransactionItem {
  productId: string;
  productName: string;
  category: ProductCategory;
  sellingPrice: number;
  purchasePrice: number;
  quantity: number;
  profit: number;
  discountAmount?: number;
  discountType?: 'none' | 'nominal' | 'percent';
  discountReason?: string;
  originalPrice?: number;
  paymentMethod?: 'cash' | 'transfer';
  targetEWalletId?: string;
  scannedBarcodes?: string[];
  voucherBarcodes?: string[];
}

export interface Transaction {
  id: string;
  invoiceNumber: string;
  date: string; // ISO String
  customerPhone: string;
  items: TransactionItem[];
  totalAmount: number;
  totalProfit: number;
  cashierId: string;
  cashierName: string;
  eWalletId: string; // The e-wallet used to fund/process this transaction
  eWalletName: string;
  status: 'success' | 'failed' | 'pending';
  type?: 'topup' | 'withdrawal' | 'physical' | 'edc_transfer';
  withdrawalType?: 'admin_luar' | 'admin_potong';
  adminFee?: number;
}

export interface EWalletHistory {
  id: string;
  eWalletId: string;
  eWalletName: string;
  amount: number; // Positive number
  type: 'debit' | 'credit'; // 'debit' = penambahan saldo, 'credit' = pemotongan saldo (pengeluaran)
  transactionId?: string;
  description: string;
  date: string; // ISO String
}

export interface DashboardStats {
  totalSalesToday: number;
  totalProfitToday: number;
  transactionCountToday: number;
  lowStockCount: number;
  totalEWalletBalance: number;
}

export interface Shift {
  id: string;
  cashierId: string;
  cashierName: string;
  startTime: string; // ISO String
  endTime?: string; // ISO String
  initialCash: number; // Uang laci / modal awal
  totalSales: number; // Penjualan tunai/transfer selama shift
  totalTransferSales?: number; // Total penjualan nontunai/transfer (tidak masuk laci)
  totalWithdrawals?: number; // Total pengeluaran uang laci untuk penarikan/tarik tunai selama shift
  totalProfit: number; // Total untung selama shift
  totalDiscounts?: number; // Total discount given during shift
  transactionCount: number;
  status: 'open' | 'closed';
  closedBy?: string; // Nama admin/kasir yang menutup
}

export interface Account {
  code: string;
  name: string;
  category: 'Asset' | 'Liability' | 'Equity' | 'Revenue' | 'Expense';
  normalBalance: 'Debit' | 'Credit';
}

export interface JournalLine {
  accountCode: string;
  accountName: string;
  type: 'debit' | 'credit';
  amount: number;
}

export interface JournalEntry {
  id: string;
  date: string;
  reference: string;
  description: string;
  lines: JournalLine[];
  isManual?: boolean;
}

export interface Budget {
  id: string;
  accountCode: string;
  accountName: string;
  limit: number;
  period: string; // "YYYY-MM"
}

export type VoucherStatus = 'READY' | 'SOLD' | 'RETURNED' | 'DAMAGED' | 'EXPIRED';

export interface VoucherHistoryItem {
  event: string; // e.g. 'Masuk Gudang' | 'Terjual' | 'Retur' | 'Dijual Lagi' | 'Expired' etc.
  date: string;  // ISO string
  details?: string;
}

export interface VoucherSerial {
  id: string;
  productId: string;
  barcode: string;
  serialNumber?: string | null;
  expiredDate?: string | null; // YYYY-MM-DD
  supplier?: string | null;
  purchasePrice: number;
  purchaseDate?: string | null; // YYYY-MM-DD
  soldTransactionId?: string | null;
  soldAt?: string | null;
  returnedAt?: string | null;
  notes?: string | null;
  status: VoucherStatus;
  history: VoucherHistoryItem[];
  createdAt: string;
  updatedAt: string;
  productName?: string; // Virtual property often joined from products
}



