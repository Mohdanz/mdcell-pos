import { User, Product, EWallet, Transaction, EWalletHistory, PhysicalCategory, VoucherSerial } from '../types';

export const INITIAL_PHYSICAL_CATEGORIES: PhysicalCategory[] = [];

export const INITIAL_USERS: User[] = [
  {
    id: 'u-1',
    username: 'admin',
    name: 'Dandi (Admin Owner)',
    role: 'admin',
    email: 'mohddandii@gmail.com',
    avatarColor: 'bg-emerald-500'
  },
  {
    id: 'u-2',
    username: 'kasir',
    name: 'Rian (Kasir)',
    role: 'kasir',
    email: 'rian.kasir@gmail.com',
    avatarColor: 'bg-indigo-500'
  }
];

export const INITIAL_EWALLETS: EWallet[] = [
  {
    id: 'ew-1',
    name: 'DANA Agen Server',
    provider: 'DANA',
    balance: 2750000,
    description: 'Saldo server utama untuk pengisian pulsa & paket data nasional.',
    isActive: true,
    logoUrl: 'https://img.utdstc.com/icon/8db/a76/8dba764506c19f563d3fb6672322384a601e3cb39891823793f7734a71b489a2:200'
  },
  {
    id: 'ew-2',
    name: 'OVO Merchant Pulsa',
    provider: 'OVO',
    balance: 1420000,
    description: 'Saldo merchant OVO khusus produk token PLN dan topup e-wallet retail.',
    isActive: true,
    logoUrl: 'https://img.utdstc.com/icon/e6b/e9f/e6be9fe92019c6f2df7e96b9979d500eb58e72ba185cb795c64c76b9762a4d0f:200'
  },
  {
    id: 'ew-3',
    name: 'GoPay Toko',
    provider: 'GoPay',
    balance: 850000,
    description: 'Saldo alternatif untuk topup game dan voucher fisik.',
    isActive: true,
    logoUrl: 'https://img.utdstc.com/icon/c0e/a34/c0ea349b16b47c0b0b8ff4f447f8ba1689ea5242eb0e5fe4098939a04a5bfbb0:200'
  },
  {
    id: 'ew-4',
    name: 'ShopeePay Counter',
    provider: 'ShopeePay',
    balance: 450000,
    description: 'Saldo cadangan transaksi digital Shopee.',
    isActive: true,
    logoUrl: 'https://img.utdstc.com/icon/c59/89f/c5989f660d3d528b3cf4e0f4955b9e078ea43734e5657ef1968eb78b5fc28d3e:200'
  },
  {
    id: 'cash',
    name: 'Uang Tunai Laci',
    provider: 'Lainnya',
    balance: 0,
    description: 'Pembayaran tunai langsung masuk laci kasir',
    isActive: true,
    category: 'ewallet'
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  // PULSA
  {
    id: 'p-1',
    name: 'Pulsa Telkomsel 5.000',
    category: 'pulsa',
    operator: 'Telkomsel',
    purchasePrice: 5300,
    sellingPrice: 7000,
    stock: 95,
    minStockLimit: 10,
    description: 'Pulsa elektrik Telkomsel reguler menambah masa aktif.'
  },
  {
    id: 'p-2',
    name: 'Pulsa Telkomsel 10.000',
    category: 'pulsa',
    operator: 'Telkomsel',
    purchasePrice: 10150,
    sellingPrice: 12000,
    stock: 140,
    minStockLimit: 15,
    description: 'Pulsa elektrik Telkomsel reguler.'
  },
  {
    id: 'p-3',
    name: 'Pulsa Telkomsel 50.000',
    category: 'pulsa',
    operator: 'Telkomsel',
    purchasePrice: 49050,
    sellingPrice: 52000,
    stock: 35,
    minStockLimit: 5,
    description: 'Pulsa elektrik Telkomsel nominal besar.'
  },
  {
    id: 'p-4',
    name: 'Pulsa Indosat 10.000',
    category: 'pulsa',
    operator: 'Indosat',
    purchasePrice: 10250,
    sellingPrice: 12000,
    stock: 80,
    minStockLimit: 10,
    description: 'Pulsa elektrik Indosat Ooredoo reguler.'
  },
  {
    id: 'p-5',
    name: 'Pulsa XL 10.000',
    category: 'pulsa',
    operator: 'XL',
    purchasePrice: 10200,
    sellingPrice: 12000,
    stock: 65,
    minStockLimit: 10,
    description: 'Pulsa elektrik XL Axiata.'
  },
  // PAKET DATA
  {
    id: 'p-6',
    name: 'Tsel Internet MAX 10GB',
    category: 'paket_data',
    operator: 'Telkomsel',
    purchasePrice: 32000,
    sellingPrice: 38000,
    stock: 45,
    minStockLimit: 8,
    description: 'Kuota 10GB Telkomsel (8GB Lokal + 2GB Nasional) 30 Hari.'
  },
  {
    id: 'p-7',
    name: 'Indosat Freedom 18GB',
    category: 'paket_data',
    operator: 'Indosat',
    purchasePrice: 45000,
    sellingPrice: 53000,
    stock: 4,
    minStockLimit: 5,
    description: 'Indosat Freedom Internet Kuota Utama Full 24 Jam 30 Hari.'
  },
  {
    id: 'p-8',
    name: 'XL Xtra Combo Flex 20GB',
    category: 'paket_data',
    operator: 'XL',
    purchasePrice: 51000,
    sellingPrice: 59000,
    stock: 12,
    minStockLimit: 5,
    description: 'XL Xtra Combo Flex M Kuota Utama 20GB 30 Hari.'
  },
  // TOKEN PLN
  {
    id: 'p-9',
    name: 'Token PLN Listrik 20.000',
    category: 'token_pln',
    operator: 'PLN',
    purchasePrice: 20150,
    sellingPrice: 22500,
    stock: 50,
    minStockLimit: 5,
    description: 'Token listrik PLN prabayar nominal 20.000.'
  },
  {
    id: 'p-10',
    name: 'Token PLN Listrik 50.000',
    category: 'token_pln',
    operator: 'PLN',
    purchasePrice: 50150,
    sellingPrice: 52500,
    stock: 40,
    minStockLimit: 5,
    description: 'Token listrik PLN prabayar nominal 50.000.'
  },
  // TOPUP GAME
  {
    id: 'p-11',
    name: 'Free Fire 70 Diamonds',
    category: 'topup_game',
    operator: 'Garena',
    purchasePrice: 9100,
    sellingPrice: 11000,
    stock: 100,
    minStockLimit: 10,
    description: 'Top up instan diamond Free Fire via ID Player.'
  },
  {
    id: 'p-12',
    name: 'Mobile Legends 86 Diamonds',
    category: 'topup_game',
    operator: 'Moonton',
    purchasePrice: 17200,
    sellingPrice: 20000,
    stock: 90,
    minStockLimit: 10,
    description: 'Top up instan diamond Mobile Legends via ID & Zone ID.'
  },
  // VOUCHER FISIK
  {
    id: 'p-13',
    name: 'Voucher Fisik Tri Happy 3GB',
    category: 'voucher_fisik',
    operator: 'Tri',
    purchasePrice: 10500,
    sellingPrice: 13000,
    stock: 2,
    minStockLimit: 5,
    description: 'Voucher fisik internet Tri Happy 3GB 7 Hari.',
    barcodeType: 'massal'
  },
  {
    id: 'p-14',
    name: 'Voucher Fisik Smartfren 10GB',
    category: 'voucher_fisik',
    operator: 'Smartfren',
    purchasePrice: 21000,
    sellingPrice: 25000,
    stock: 15,
    minStockLimit: 4,
    description: 'Voucher fisik internet Smartfren Super Kuota 10GB 30 Hari.',
    barcodeType: 'massal'
  },
  {
    id: 'p-15',
    name: 'Charger Robot 2.4A Fast Charging',
    category: 'barang_fisik',
    operator: 'Robot',
    purchasePrice: 22000,
    sellingPrice: 35000,
    stock: 12,
    minStockLimit: 3,
    description: 'Charger kabel Micro-USB / Type-C 2.4A fast charging.',
    imageUrl: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=400&auto=format&fit=crop&q=60'
  },
  {
    id: 'p-16',
    name: 'Kabel Data Type-C Vivan 1M',
    category: 'barang_fisik',
    operator: 'Vivan',
    purchasePrice: 9000,
    sellingPrice: 15000,
    stock: 25,
    minStockLimit: 5,
    description: 'Kabel data elastis tahan lama arus maksimal 3A panjang 100cm.',
    imageUrl: 'https://images.unsplash.com/photo-1541660707928-8f837334def3?w=400&auto=format&fit=crop&q=60'
  },
  {
    id: 'p-17',
    name: 'Tempered Glass Universal 6.5 Inch',
    category: 'barang_fisik',
    operator: 'Lainnya',
    purchasePrice: 6000,
    sellingPrice: 15000,
    stock: 8,
    minStockLimit: 2,
    description: 'Anti gores kaca tempered glass ketebalan 0.3mm pelindung layar hp.',
    imageUrl: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400&auto=format&fit=crop&q=60'
  },
  {
    id: 'p-18',
    name: 'Powerbank Robot 10000mAh RT180',
    category: 'barang_fisik',
    operator: 'Robot',
    purchasePrice: 95000,
    sellingPrice: 135000,
    stock: 6,
    minStockLimit: 2,
    description: 'Powerbank tipis kapasitas 10000mAh dual input Type-C & Micro-USB.',
    imageUrl: 'https://images.unsplash.com/photo-1609592424109-dd77884bc78e?w=400&auto=format&fit=crop&q=60'
  },
  {
    id: 'p-19',
    name: 'Earphone Bass JBL C100SI',
    category: 'barang_fisik',
    operator: 'Lainnya',
    purchasePrice: 48000,
    sellingPrice: 75000,
    stock: 15,
    minStockLimit: 3,
    description: 'In-ear headphones dengan legendaris suara bass JBL jernih dan microphone.',
    imageUrl: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=400&auto=format&fit=crop&q=60'
  }
];

// Helper to generate ISO date strings relative to today
const getDateDaysAgo = (daysAgo: number, hour: number, minute: number): string => {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  d.setHours(hour, minute, 0, 0);
  return d.toISOString();
};

export const INITIAL_TRANSACTIONS: Transaction[] = [
  // 2 days ago
  {
    id: 'tx-1',
    invoiceNumber: 'TRX-20260702-001',
    date: getDateDaysAgo(2, 10, 15),
    customerPhone: '081234567890',
    items: [
      {
        productId: 'p-1',
        productName: 'Pulsa Telkomsel 5.000',
        category: 'pulsa',
        sellingPrice: 7000,
        purchasePrice: 5300,
        quantity: 1,
        profit: 1700
      }
    ],
    totalAmount: 7000,
    totalProfit: 1700,
    cashierId: 'u-2',
    cashierName: 'Rian (Kasir)',
    eWalletId: 'ew-1',
    eWalletName: 'DANA Agen Server',
    status: 'success'
  },
  {
    id: 'tx-2',
    invoiceNumber: 'TRX-20260702-002',
    date: getDateDaysAgo(2, 14, 30),
    customerPhone: '085712345678',
    items: [
      {
        productId: 'p-7',
        productName: 'Indosat Freedom 18GB',
        category: 'paket_data',
        sellingPrice: 53000,
        purchasePrice: 45000,
        quantity: 1,
        profit: 8000
      }
    ],
    totalAmount: 53000,
    totalProfit: 8000,
    cashierId: 'u-2',
    cashierName: 'Rian (Kasir)',
    eWalletId: 'ew-1',
    eWalletName: 'DANA Agen Server',
    status: 'success'
  },
  {
    id: 'tx-3',
    invoiceNumber: 'TRX-20260702-003',
    date: getDateDaysAgo(2, 19, 45),
    customerPhone: '089988776655',
    items: [
      {
        productId: 'p-10',
        productName: 'Token PLN Listrik 50.000',
        category: 'token_pln',
        sellingPrice: 52500,
        purchasePrice: 50150,
        quantity: 1,
        profit: 2350
      }
    ],
    totalAmount: 52500,
    totalProfit: 2350,
    cashierId: 'u-1',
    cashierName: 'Dandi (Admin Owner)',
    eWalletId: 'ew-2',
    eWalletName: 'OVO Merchant Pulsa',
    status: 'success'
  },

  // Yesterday
  {
    id: 'tx-4',
    invoiceNumber: 'TRX-20260703-001',
    date: getDateDaysAgo(1, 9, 30),
    customerPhone: '087811223344',
    items: [
      {
        productId: 'p-2',
        productName: 'Pulsa Telkomsel 10.000',
        category: 'pulsa',
        sellingPrice: 12000,
        purchasePrice: 10150,
        quantity: 1,
        profit: 1850
      }
    ],
    totalAmount: 12000,
    totalProfit: 1850,
    cashierId: 'u-2',
    cashierName: 'Rian (Kasir)',
    eWalletId: 'ew-1',
    eWalletName: 'DANA Agen Server',
    status: 'success'
  },
  {
    id: 'tx-5',
    invoiceNumber: 'TRX-20260703-002',
    date: getDateDaysAgo(1, 13, 10),
    customerPhone: '081233445566',
    items: [
      {
        productId: 'p-8',
        productName: 'XL Xtra Combo Flex 20GB',
        category: 'paket_data',
        sellingPrice: 59000,
        purchasePrice: 51000,
        quantity: 1,
        profit: 8000
      }
    ],
    totalAmount: 59000,
    totalProfit: 8000,
    cashierId: 'u-2',
    cashierName: 'Rian (Kasir)',
    eWalletId: 'ew-3',
    eWalletName: 'GoPay Toko',
    status: 'success'
  },
  {
    id: 'tx-6',
    invoiceNumber: 'TRX-20260703-003',
    date: getDateDaysAgo(1, 16, 40),
    customerPhone: '085299887766',
    items: [
      {
        productId: 'p-12',
        productName: 'Mobile Legends 86 Diamonds',
        category: 'topup_game',
        sellingPrice: 20000,
        purchasePrice: 17200,
        quantity: 1,
        profit: 2800
      }
    ],
    totalAmount: 20000,
    totalProfit: 2800,
    cashierId: 'u-2',
    cashierName: 'Rian (Kasir)',
    eWalletId: 'ew-3',
    eWalletName: 'GoPay Toko',
    status: 'success'
  },
  {
    id: 'tx-7',
    invoiceNumber: 'TRX-20260703-004',
    date: getDateDaysAgo(1, 20, 15),
    customerPhone: '081912345678',
    items: [
      {
        productId: 'p-9',
        productName: 'Token PLN Listrik 20.000',
        category: 'token_pln',
        sellingPrice: 22500,
        purchasePrice: 20150,
        quantity: 1,
        profit: 2350
      }
    ],
    totalAmount: 22500,
    totalProfit: 2350,
    cashierId: 'u-1',
    cashierName: 'Dandi (Admin Owner)',
    eWalletId: 'ew-2',
    eWalletName: 'OVO Merchant Pulsa',
    status: 'success'
  },

  // Today
  {
    id: 'tx-8',
    invoiceNumber: 'TRX-20260704-001',
    date: getDateDaysAgo(0, 8, 45),
    customerPhone: '081399881122',
    items: [
      {
        productId: 'p-3',
        productName: 'Pulsa Telkomsel 50.000',
        category: 'pulsa',
        sellingPrice: 52000,
        purchasePrice: 49050,
        quantity: 1,
        profit: 2950
      }
    ],
    totalAmount: 52000,
    totalProfit: 2950,
    cashierId: 'u-2',
    cashierName: 'Rian (Kasir)',
    eWalletId: 'ew-1',
    eWalletName: 'DANA Agen Server',
    status: 'success'
  },
  {
    id: 'tx-9',
    invoiceNumber: 'TRX-20260704-002',
    date: getDateDaysAgo(0, 10, 30),
    customerPhone: '085644332211',
    items: [
      {
        productId: 'p-6',
        productName: 'Tsel Internet MAX 10GB',
        category: 'paket_data',
        sellingPrice: 38000,
        purchasePrice: 32000,
        quantity: 1,
        profit: 6000
      }
    ],
    totalAmount: 38000,
    totalProfit: 6000,
    cashierId: 'u-2',
    cashierName: 'Rian (Kasir)',
    eWalletId: 'ew-1',
    eWalletName: 'DANA Agen Server',
    status: 'success'
  }
];

export const INITIAL_EWALLET_HISTORIES: EWalletHistory[] = [
  // initial balance adds
  {
    id: 'ewh-init-1',
    eWalletId: 'ew-1',
    eWalletName: 'DANA Agen Server',
    amount: 3000000,
    type: 'debit',
    description: 'Deposit awal saldo server utama.',
    date: getDateDaysAgo(3, 8, 0)
  },
  {
    id: 'ewh-init-2',
    eWalletId: 'ew-2',
    eWalletName: 'OVO Merchant Pulsa',
    amount: 1500000,
    type: 'debit',
    description: 'Deposit awal saldo merchant OVO.',
    date: getDateDaysAgo(3, 8, 10)
  },
  {
    id: 'ewh-init-3',
    eWalletId: 'ew-3',
    eWalletName: 'GoPay Toko',
    amount: 1000000,
    type: 'debit',
    description: 'Deposit awal saldo GoPay.',
    date: getDateDaysAgo(3, 8, 20)
  },
  {
    id: 'ewh-init-4',
    eWalletId: 'ew-4',
    eWalletName: 'ShopeePay Counter',
    amount: 500000,
    type: 'debit',
    description: 'Deposit awal saldo ShopeePay.',
    date: getDateDaysAgo(3, 8, 30)
  },

  // Deductions based on Transactions
  {
    id: 'ewh-tx-1',
    eWalletId: 'ew-1',
    eWalletName: 'DANA Agen Server',
    amount: 5300,
    type: 'credit',
    transactionId: 'tx-1',
    description: 'Pemotongan saldo transaksi TRX-20260702-001 (Pulsa Telkomsel 5.000)',
    date: getDateDaysAgo(2, 10, 15)
  },
  {
    id: 'ewh-tx-2',
    eWalletId: 'ew-1',
    eWalletName: 'DANA Agen Server',
    amount: 45000,
    type: 'credit',
    transactionId: 'tx-2',
    description: 'Pemotongan saldo transaksi TRX-20260702-002 (Indosat Freedom 18GB)',
    date: getDateDaysAgo(2, 14, 30)
  },
  {
    id: 'ewh-tx-3',
    eWalletId: 'ew-2',
    eWalletName: 'OVO Merchant Pulsa',
    amount: 50150,
    type: 'credit',
    transactionId: 'tx-3',
    description: 'Pemotongan saldo transaksi TRX-20260702-003 (Token PLN Listrik 50.000)',
    date: getDateDaysAgo(2, 19, 45)
  },
  {
    id: 'ewh-tx-4',
    eWalletId: 'ew-1',
    eWalletName: 'DANA Agen Server',
    amount: 10150,
    type: 'credit',
    transactionId: 'tx-4',
    description: 'Pemotongan saldo transaksi TRX-20260703-001 (Pulsa Telkomsel 10.000)',
    date: getDateDaysAgo(1, 9, 30)
  },
  {
    id: 'ewh-tx-5',
    eWalletId: 'ew-3',
    eWalletName: 'GoPay Toko',
    amount: 51000,
    type: 'credit',
    transactionId: 'tx-5',
    description: 'Pemotongan saldo transaksi TRX-20260703-002 (XL Xtra Combo Flex 20GB)',
    date: getDateDaysAgo(1, 13, 10)
  },
  {
    id: 'ewh-tx-6',
    eWalletId: 'ew-3',
    eWalletName: 'GoPay Toko',
    amount: 17200,
    type: 'credit',
    transactionId: 'tx-6',
    description: 'Pemotongan saldo transaksi TRX-20260703-003 (Mobile Legends 86 Diamonds)',
    date: getDateDaysAgo(1, 16, 40)
  },
  {
    id: 'ewh-tx-7',
    eWalletId: 'ew-2',
    eWalletName: 'OVO Merchant Pulsa',
    amount: 20150,
    type: 'credit',
    transactionId: 'tx-7',
    description: 'Pemotongan saldo transaksi TRX-20260703-004 (Token PLN Listrik 20.000)',
    date: getDateDaysAgo(1, 20, 15)
  },
  {
    id: 'ewh-tx-8',
    eWalletId: 'ew-1',
    eWalletName: 'DANA Agen Server',
    amount: 49050,
    type: 'credit',
    transactionId: 'tx-8',
    description: 'Pemotongan saldo transaksi TRX-20260704-001 (Pulsa Telkomsel 50.000)',
    date: getDateDaysAgo(0, 8, 45)
  },
  {
    id: 'ewh-tx-9',
    eWalletId: 'ew-1',
    eWalletName: 'DANA Agen Server',
    amount: 32000,
    type: 'credit',
    transactionId: 'tx-9',
    description: 'Pemotongan saldo transaksi TRX-20260704-002 (Tsel Internet MAX 10GB)',
    date: getDateDaysAgo(0, 10, 30)
  }
];

export const INITIAL_VOUCHER_SERIALS: VoucherSerial[] = [
  // Serials for p-13 (Voucher Fisik Tri Happy 3GB)
  {
    id: 'vs-tri-1',
    productId: 'p-13',
    barcode: '8991234560131',
    serialNumber: 'SN-TRI-3GB-100001',
    expiredDate: '2027-12-31',
    supplier: 'Tri Distributor Utama',
    purchasePrice: 10500,
    purchaseDate: '2026-07-01',
    status: 'READY',
    notes: 'Stok awal Tri Happy 3GB',
    history: [{ event: 'Pendaftaran', date: '2026-07-01T10:00:00.000Z', details: 'Pendaftaran stok awal' }],
    createdAt: '2026-07-01T10:00:00.000Z',
    updatedAt: '2026-07-01T10:00:00.000Z'
  },
  {
    id: 'vs-tri-2',
    productId: 'p-13',
    barcode: '8991234560132',
    serialNumber: 'SN-TRI-3GB-100002',
    expiredDate: '2027-12-31',
    supplier: 'Tri Distributor Utama',
    purchasePrice: 10500,
    purchaseDate: '2026-07-01',
    status: 'READY',
    notes: 'Stok awal Tri Happy 3GB',
    history: [{ event: 'Pendaftaran', date: '2026-07-01T10:00:00.000Z', details: 'Pendaftaran stok awal' }],
    createdAt: '2026-07-01T10:00:00.000Z',
    updatedAt: '2026-07-01T10:00:00.000Z'
  },
  // Serials for p-14 (Voucher Fisik Smartfren 10GB)
  ...Array.from({ length: 15 }, (_, i) => ({
    id: `vs-sf-${i + 1}`,
    productId: 'p-14',
    barcode: `899123456014${String(i + 1).padStart(2, '0')}`,
    serialNumber: `SN-SF-10GB-2000${String(i + 1).padStart(2, '0')}`,
    expiredDate: '2028-06-30',
    supplier: 'Smartfren Sales Center',
    purchasePrice: 21000,
    purchaseDate: '2026-07-01',
    status: 'READY' as const,
    notes: 'Stok awal Smartfren 10GB',
    history: [{ event: 'Pendaftaran', date: '2026-07-01T10:00:00.000Z', details: 'Pendaftaran stok awal' }],
    createdAt: '2026-07-01T10:00:00.000Z',
    updatedAt: '2026-07-01T10:00:00.000Z'
  }))
];
