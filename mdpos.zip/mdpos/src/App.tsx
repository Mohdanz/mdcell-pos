import React, { useState, useEffect } from 'react';
import { User, Product, EWallet, Transaction, EWalletHistory, Shift, PhysicalCategory, VoucherSerial } from './types';


import Navigation, { ActiveTab } from './components/Navigation';
import LoginView from './components/LoginView';
import POSView from './components/POSView';
import ProductManagement from './components/ProductManagement';
import EWalletManagement from './components/EWalletManagement';
import ReportsView from './components/ReportsView';
import UserManagement from './components/UserManagement';
import DashboardView from './components/DashboardView';
import SettingsView, { AppConfig } from './components/SettingsView';
import AboutView from './components/AboutView';
import AccountingView from './components/AccountingView';
import BarcodeCenter from './components/BarcodeCenter';
import LogViewer from './components/LogViewer';
import BarcodeCameraScanner from './components/BarcodeCameraScanner';



import { 
  ShieldAlert, 
  QrCode, 
  Camera, 
  Layers, 
  CheckCircle2, 
  AlertCircle, 
  Search, 
  Info, 
  Clock, 
  Check, 
  AlertTriangle 
} from 'lucide-react';
import { getJakartaDateString } from './utils/dateUtils';

export default function App() {
  // Global Theme State: 'light' | 'dark'
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  // Sync theme class to document element
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('pos_theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => (prev === 'light' ? 'dark' : 'light'));
  };

  // Current logged in user session
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  // Core Data Lists
  const [users, setUsers] = useState<User[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [physicalCategories, setPhysicalCategories] = useState<PhysicalCategory[]>([]);
  const [eWallets, setEWallets] = useState<EWallet[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [histories, setHistories] = useState<EWalletHistory[]>([]);
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [currentShift, setCurrentShift] = useState<Shift | null>(null);

  // Current active navigation tab
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [vouchersProductFilter, setVouchersProductFilter] = useState<string | null>(null);
  const [physicalScannerTrigger, setPhysicalScannerTrigger] = useState(0);
  const [posScannerTrigger, setPosScannerTrigger] = useState(0);

  // Dedicated Scanner Tab states
  const [isAppScannerOpen, setIsAppScannerOpen] = useState(false);
  const [isGlobalScannerOpen, setIsGlobalScannerOpen] = useState(false);

  useEffect(() => {
    const handleScannerStatus = (e: any) => {
      setIsGlobalScannerOpen(!!e.detail.isOpen);
    };
    window.addEventListener('scanner-status', handleScannerStatus);
    return () => {
      window.removeEventListener('scanner-status', handleScannerStatus);
    };
  }, []);

  const [appLastScannedItem, setAppLastScannedItem] = useState<{
    barcode: string;
    productName: string;
    time: string;
    status: 'SUCCESS' | 'NOT_FOUND';
    price?: number;
    category?: string;
  } | null>(null);
  const [appScannerSelectedProductId, setAppScannerSelectedProductId] = useState<string>('');
  const [appScannerVouchers, setAppScannerVouchers] = useState<VoucherSerial[]>([]);
  const [appScannerSearchQuery, setAppScannerSearchQuery] = useState<string>('');
  const [appScannerIsLoading, setAppScannerIsLoading] = useState<boolean>(false);

  // System configurations
  const [appConfig, setAppConfig] = useState<AppConfig>({
    name: 'MD POS',
    slogan: 'KONTER POS MODERN',
    lowStockLimit: 5,
    currency: 'Rp',
    receiptFooter: 'Terima kasih telah berbelanja!',
    logoUrl: '/logo.png',
  });

  // Synchronize document title and favicon dynamically based on custom logo
  useEffect(() => {
    if (appConfig.name) {
      document.title = `${appConfig.name} - ${appConfig.slogan || 'Sistem POS'}`;
    }
    
    // Update favicon dynamically
    const faviconUrl = appConfig.logoUrl || '/logo.png';
    let link = document.querySelector("link[rel~='icon']") as HTMLLinkElement;
    if (!link) {
      link = document.createElement('link');
      link.rel = 'icon';
      document.getElementsByTagName('head')[0].appendChild(link);
    }
    link.href = faviconUrl;
  }, [appConfig]);

  // Load state from PostgreSQL REST API on mount
  useEffect(() => {
    const fetchAllData = async () => {
      try {
        const fetchJson = async (url: string, fallback: any) => {
          try {
            const res = await fetch(url);
            if (!res.ok) return fallback;
            const data = await res.json();
            if (data && data.error) return fallback;
            return data;
          } catch (e) {
            console.error(`Failed to fetch ${url}:`, e);
            return fallback;
          }
        };

        const [
          usersRes,
          productsRes,
          categoriesRes,
          walletsRes,
          transactionsRes,
          historiesRes,
          shiftsRes,
          settingsRes
        ] = await Promise.all([
          fetchJson('/api/users', []),
          fetchJson('/api/products', []),
          fetchJson('/api/physical-categories', []),
          fetchJson('/api/ewallets', []),
          fetchJson('/api/transactions', []),
          fetchJson('/api/ewallet-histories', []),
          fetchJson('/api/shifts', []),
          fetchJson('/api/settings', { allowLossTransaction: true })
        ]);

        if (Array.isArray(usersRes)) setUsers(usersRes);
        if (Array.isArray(productsRes)) setProducts(productsRes);
        if (Array.isArray(categoriesRes)) setPhysicalCategories(categoriesRes);
        if (Array.isArray(walletsRes)) setEWallets(walletsRes);
        if (Array.isArray(transactionsRes)) setTransactions(transactionsRes);
        if (Array.isArray(historiesRes)) setHistories(historiesRes);
        if (Array.isArray(shiftsRes)) {
          setShifts(shiftsRes);
          const active = shiftsRes.find((s: Shift) => s.status === 'open');
          if (active) {
            setCurrentShift(active);
          }
        }
        if (settingsRes && !settingsRes.error) {
          setAppConfig(prev => ({
            ...prev,
            ...settingsRes,
            logoUrl: settingsRes.logoUrl || prev.logoUrl || '/logo.png'
          }));
        }
      } catch (err) {
        console.error('Failed to load initial data from PostgreSQL API:', err);
      }
    };

    fetchAllData();

    // Restore session if any
    const savedSession = localStorage.getItem('konter_session');
    if (savedSession) {
      setCurrentUser(JSON.parse(savedSession));
    }
  }, []);

  // Sync state helpers
  const saveUsersState = async (updated: User[]) => {
    setUsers(updated);
  };

  const saveProductsState = async (updated: Product[]) => {
    setProducts(updated);
  };

  const savePhysicalCategoriesState = async (updated: PhysicalCategory[]) => {
    setPhysicalCategories(updated);
  };

  const saveEWalletsState = async (updated: EWallet[]) => {
    setEWallets(updated);
  };

  const saveTransactionsState = async (updated: Transaction[]) => {
    setTransactions(updated);
  };

  const saveHistoriesState = async (updated: EWalletHistory[]) => {
    setHistories(updated);
  };

  const saveShiftsState = async (updated: Shift[]) => {
    setShifts(updated);
    const active = updated.find((s: Shift) => s.status === 'open');
    setCurrentShift(active || null);
  };

  const handleStartShift = async (initialCash: number, cashierId: string, cashierName: string) => {
    if (currentUser?.role !== 'admin') {
      alert('Sif hanya bisa dimulai oleh Administrator Pemilik!');
      throw new Error('Akses ditolak: Hanya Admin yang dapat memulai sif baru.');
    }

    const newShift: Shift = {
      id: `shift-${Date.now()}`,
      cashierId,
      cashierName,
      startTime: new Date().toISOString(),
      initialCash,
      totalSales: 0,
      totalProfit: 0,
      transactionCount: 0,
      status: 'open'
    };

    try {
      const saved = await fetch('/api/shifts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newShift),
      }).then(res => res.json());

      saveShiftsState([saved, ...shifts]);
      return saved;
    } catch (err) {
      console.error('Failed to start shift in DB:', err);
      return newShift;
    }
  };

  const handleCloseShift = async (closedBy: string) => {
    if (!currentShift) return null;
    const closedShift: Shift = {
      ...currentShift,
      endTime: new Date().toISOString(),
      status: 'closed',
      closedBy
    };

    try {
      const saved = await fetch(`/api/shifts/${currentShift.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(closedShift),
      }).then(res => res.json());

      const updated = shifts.map(s => s.id === currentShift.id ? saved : s);
      saveShiftsState(updated);
      return saved;
    } catch (err) {
      console.error('Failed to close shift in DB:', err);
      return closedShift;
    }
  };

  // Auth Functions
  const handleLogin = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('konter_session', JSON.stringify(user));
    setActiveTab('dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('konter_session');
  };

  const openCameraScanner = () => {
    setIsAppScannerOpen(true);
  };

  const handleScanClick = () => {
    if (!currentShift) {
      alert("Akses ditolak. Fitur scan hanya dapat digunakan saat Sif Kasir dalam keadaan Terbuka. Harap buka sif di menu Dashboard terlebih dahulu.");
      return;
    }
    if (activeTab === 'physical_pos') {
      setPhysicalScannerTrigger(prev => prev + 1);
    } else if (activeTab === 'pos') {
      setPosScannerTrigger(prev => prev + 1);
    } else {
      setActiveTab('physical_pos');
      setPhysicalScannerTrigger(prev => prev + 1);
    }
  };

  // ==========================================
  // TRANSACTION / SALES LOGIC (The Core Feature)
  // ==========================================
  const handleProcessTransaction = async (
    customerPhone: string,
    item: any,
    eWalletId: string
  ) => {
    if (!currentUser) return { success: false, message: 'Harap masuk terlebih dahulu.' };
    if (!currentShift) {
      return { 
        success: false, 
        message: 'Transaksi ditolak. Sif kasir belum dimulai. Harap hubungi Admin atau buka sif kasir terlebih dahulu dengan modal uang laci.' 
      };
    }

    const isMulti = Array.isArray(item);
    const isWithdrawal = !isMulti && (item.type === 'withdrawal' || item.category === 'withdrawal');
    const isDigital = !isMulti && (['pulsa', 'paket_data', 'token_pln', 'topup_game', 'withdrawal', 'edc_transfer'].includes(item.category) || isWithdrawal);
    const isPhysical = isMulti || !isDigital || eWalletId === 'cash';

    // 1. Double check the product's live status & stock
    if (isMulti) {
      for (const subItem of item) {
        const targetProduct = products.find(p => p.id === subItem.productId);
        if (subItem.productId !== 'manual' && subItem.productId !== 'edc_transfer') {
          if (!targetProduct) return { success: false, message: `Produk ${subItem.productName} tidak ditemukan.` };
          if (targetProduct.stock < subItem.quantity) {
            return { success: false, message: `Stok produk ${targetProduct.name} tidak cukup. Sisa stok: ${targetProduct.stock}` };
          }
        }
      }
    } else {
      let targetProduct = products.find(p => p.id === item.productId);
      if (!isWithdrawal && item.productId !== 'manual' && item.productId !== 'edc_transfer') {
        if (!targetProduct) return { success: false, message: 'Produk tidak ditemukan.' };
        if (targetProduct.stock < item.quantity) {
          return { success: false, message: `Stok produk tidak cukup. Sisa stok: ${targetProduct.stock}` };
        }
      }
    }

    // Fetch the latest shift state from the database to guarantee fresh drawer balance check
    let dbShift: Shift = currentShift;
    try {
      const shiftsRes = await fetch('/api/shifts');
      if (shiftsRes.ok) {
        const list = await shiftsRes.json();
        if (Array.isArray(list)) {
          const latestShift = list.find((s: any) => s.id === currentShift.id);
          if (latestShift) {
            dbShift = latestShift;
          }
        }
      }
    } catch (err) {
      console.warn('Failed to fetch latest shift from db, falling back to local state:', err);
    }

    // Fetch latest e-wallets from database to guarantee fresh balance check
    let dbWalletsList = eWallets;
    try {
      const walletsRes = await fetch('/api/ewallets');
      if (walletsRes.ok) {
        const list = await walletsRes.json();
        if (Array.isArray(list)) {
          dbWalletsList = list;
        }
      }
    } catch (err) {
      console.warn('Failed to fetch latest e-wallets from db, falling back to local state:', err);
    }

    // 2. Double check and calculate e-wallet changes
    let dbWallet: EWallet;
    let deductionAmount = 0;
    let addAmount = 0;

    const isTransferPhysical = !isDigital && eWalletId !== 'cash';

    let totalAmount = 0;
    let totalProfit = 0;
    let totalDiscounts = 0;

    if (isMulti) {
      item.forEach((subItem: any) => {
        totalAmount += subItem.sellingPrice * subItem.quantity;
        totalProfit += subItem.profit * subItem.quantity;
        totalDiscounts += (subItem.discountAmount || 0);
      });
    } else {
      totalAmount = isWithdrawal ? item.amount : (item.sellingPrice * item.quantity);
      totalProfit = isWithdrawal ? item.adminFee : (item.profit * item.quantity);
      totalDiscounts = item.discountAmount || 0;
    }

    if (isPhysical) {
      if (eWalletId === 'cash') {
        dbWallet = {
          id: 'cash',
          name: 'Uang Tunai Laci',
          provider: 'Lainnya',
          balance: 0,
          description: 'Pembayaran tunai langsung masuk laci kasir',
          isActive: true,
          category: 'ewallet'
        };
      } else {
        const wallet = dbWalletsList.find(w => w.id === eWalletId);
        if (!wallet) return { success: false, message: 'E-Wallet tidak ditemukan.' };
        dbWallet = wallet;
        addAmount = totalAmount;
      }
    } else {
      const wallet = dbWalletsList.find(w => w.id === eWalletId);
      if (!wallet) return { success: false, message: 'E-Wallet tidak ditemukan.' };
      dbWallet = wallet;

      if (isWithdrawal) {
        addAmount = Number(item.amount || 0);
        // Check if cash drawer has enough cash to pay the customer
        const currentWithdrawals = Number(dbShift.totalWithdrawals || 0);
        const currentCashInDrawer = Number(dbShift.initialCash || 0) + Number(dbShift.totalSales || 0) - (Number(dbShift.totalTransferSales || 0)) - currentWithdrawals;
        const cashNeeded = item.withdrawalType === 'admin_potong' ? (Number(item.amount || 0) - Number(item.adminFee || 0)) : Number(item.amount || 0);
        
        if (currentCashInDrawer < cashNeeded) {
          return {
            success: false,
            message: `Uang di laci kasir tidak cukup untuk penarikan ini. Sisa uang laci: Rp ${(Number(currentCashInDrawer) || 0).toLocaleString('id-ID')}, Dibutuhkan: Rp ${(Number(cashNeeded) || 0).toLocaleString('id-ID')}`
          };
        }
      } else {
        deductionAmount = Number(item.purchasePrice || 0) * Number(item.quantity || 1);
        if (Number(dbWallet.balance || 0) < deductionAmount) {
          return { 
            success: false, 
            message: `Saldo ${dbWallet.name} tidak cukup. Dibutuhkan: Rp ${(Number(deductionAmount) || 0).toLocaleString('id-ID')}` 
          };
        }
      }
    }

    // 3. Generate sequential invoice number
    const today = new Date();
    const dateCode = getJakartaDateString(today).replace(/-/g, '');
    const todayPrefix = (!isMulti && item.type === 'edc_transfer')
      ? `TRX-EDC-${dateCode}-`
      : isWithdrawal 
      ? `TRX-WD-${dateCode}-` 
      : isPhysical 
      ? `TRX-FSK-${dateCode}-` 
      : `TRX-${dateCode}-`;
    const todayTrxsCount = transactions.filter(t => t.invoiceNumber.startsWith(todayPrefix)).length;
    const nextSuffix = String(todayTrxsCount + 1).padStart(3, '0');
    const invoiceNumber = todayPrefix + nextSuffix;
 
    // 4. Create the Transaction record
    const newTransaction: Transaction = {
      id: `tx-${Date.now()}`,
      invoiceNumber,
      date: new Date().toISOString(),
      customerPhone,
      items: isMulti ? item : [item],
      totalAmount,
      totalProfit,
      cashierId: currentUser.id,
      cashierName: currentUser.name,
      eWalletId: dbWallet.id,
      eWalletName: dbWallet.name,
      status: 'success',
      type: (!isMulti && item.type === 'edc_transfer') ? 'edc_transfer' : isWithdrawal ? 'withdrawal' : isPhysical ? 'physical' : 'topup',
      withdrawalType: isWithdrawal ? item.withdrawalType : undefined,
      adminFee: isWithdrawal ? item.adminFee : undefined
    };

    // 5. Create E-Wallet mutation history
    const newHistory: EWalletHistory = {
      id: `ewh-${Date.now()}`,
      eWalletId: dbWallet.id,
      eWalletName: dbWallet.name,
      amount: isWithdrawal 
        ? item.amount 
        : isTransferPhysical 
        ? totalAmount 
        : deductionAmount,
      type: (isWithdrawal || isTransferPhysical) ? 'debit' : 'credit',
      transactionId: newTransaction.id,
      description: isWithdrawal 
        ? `Tarik Tunai ${invoiceNumber} (${item.withdrawalType === 'admin_potong' ? 'Admin Potong' : 'Admin Luar'}) dari No: ${customerPhone}`
        : isTransferPhysical
        ? `Transfer Jual Item ${invoiceNumber} (${isMulti ? `${item.length} item` : item.productName} ke No: ${customerPhone})`
        : `Transaksi ${invoiceNumber} (${isMulti ? `${item.length} item` : item.productName} ke No: ${customerPhone})`,
      date: new Date().toISOString()
    };

    // 6. Calculate state variables
    const isTransferSale = !isWithdrawal && (isTransferPhysical || (isDigital && item.paymentMethod === 'transfer'));
    const updatedShift: Shift = {
      ...dbShift,
      totalSales: isWithdrawal ? dbShift.totalSales : (dbShift.totalSales + newTransaction.totalAmount),
      totalTransferSales: isTransferSale ? ((dbShift.totalTransferSales || 0) + newTransaction.totalAmount) : (dbShift.totalTransferSales || 0),
      totalWithdrawals: isWithdrawal ? ((dbShift.totalWithdrawals || 0) + (item.amount - item.adminFee)) : (dbShift.totalWithdrawals || 0),
      totalProfit: dbShift.totalProfit + newTransaction.totalProfit,
      totalDiscounts: (dbShift.totalDiscounts || 0) + totalDiscounts,
      transactionCount: dbShift.transactionCount + 1
    };

    try {
      // Direct REST API PostgreSQL synchronization calls
      // 6.1 Save transaction
      const txRes = await fetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newTransaction),
      });
      if (!txRes.ok) {
        const errData = await txRes.json().catch(() => ({}));
        throw new Error(errData.error || 'Gagal menyimpan transaksi ke database.');
      }
      const savedTx = await txRes.json();

      // 6.2 Update stock if needed
      if (isMulti) {
        for (const subItem of item) {
          const subProd = products.find(p => p.id === subItem.productId);
          if (subProd && subProd.barcodeType !== 'massal') {
            const nextStock = subProd.stock - subItem.quantity;
            const prodRes = await fetch(`/api/products/${subProd.id}`, {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ ...subProd, stock: nextStock }),
            });
            if (!prodRes.ok) {
              const errData = await prodRes.json().catch(() => ({}));
              throw new Error(errData.error || `Gagal memperbarui stok produk ${subProd.name} di database.`);
            }
            const updatedProd = await prodRes.json();
            setProducts(prev => prev.map(p => p.id === updatedProd.id ? updatedProd : p));
          }
        }
        // Refresh massal products if any
        const refreshRes = await fetch('/api/products');
        if (refreshRes.ok) {
          const refreshedProds = await refreshRes.json();
          setProducts(refreshedProds);
        }
      } else {
        let targetProduct = products.find(p => p.id === item.productId);
        if (targetProduct) {
          if (targetProduct.barcodeType !== 'massal') {
            const nextStock = targetProduct.stock - item.quantity;
            const prodRes = await fetch(`/api/products/${targetProduct.id}`, {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ ...targetProduct, stock: nextStock }),
            });
            if (!prodRes.ok) {
              const errData = await prodRes.json().catch(() => ({}));
              throw new Error(errData.error || 'Gagal memperbarui stok produk di database.');
            }
            const updatedProd = await prodRes.json();
            setProducts(prev => prev.map(p => p.id === updatedProd.id ? updatedProd : p));
          } else {
            // For massal products, just refresh products list so the dynamically-calculated stock is fetched
            const refreshRes = await fetch('/api/products');
            if (refreshRes.ok) {
              const refreshedProds = await refreshRes.json();
              setProducts(refreshedProds);
            }
          }
        }
      }

      // 6.3 Update wallet balance if needed
      if (isDigital && item.paymentMethod === 'transfer' && item.targetEWalletId) {
        // Digital Transfer payment: Source decreases, Target increases!
        const targetWallet = dbWalletsList.find(w => w.id === item.targetEWalletId);
        if (!targetWallet) throw new Error('E-Wallet penerima transfer tidak ditemukan.');

        // Update Source Wallet (deductionAmount)
        const nextSourceBalance = Number(dbWallet.balance || 0) - deductionAmount;
        const srcRes = await fetch(`/api/ewallets/${dbWallet.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...dbWallet, balance: nextSourceBalance }),
        });
        if (!srcRes.ok) throw new Error('Gagal memperbarui saldo e-wallet sumber.');
        const updatedSrc = await srcRes.json();

        // Update Target Wallet (addAmount)
        const targetAddAmount = item.sellingPrice * item.quantity;
        const nextTargetBalance = Number(targetWallet.balance || 0) + targetAddAmount;
        const tgtRes = await fetch(`/api/ewallets/${targetWallet.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...targetWallet, balance: nextTargetBalance }),
        });
        if (!tgtRes.ok) throw new Error('Gagal memperbarui saldo e-wallet penerima.');
        const updatedTgt = await tgtRes.json();

        setEWallets(prev => prev.map(w => w.id === updatedSrc.id ? updatedSrc : w.id === updatedTgt.id ? updatedTgt : w));

        // Create wallet history for source
        const srcHistRes = await fetch('/api/ewallet-histories', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newHistory),
        });
        if (!srcHistRes.ok) throw new Error('Gagal menyimpan riwayat saldo e-wallet sumber.');
        const savedSrcHist = await srcHistRes.json();

        // Create wallet history for target
        const newTargetHistory: EWalletHistory = {
          id: `ewh-tgt-${Date.now()}`,
          eWalletId: targetWallet.id,
          eWalletName: targetWallet.name,
          amount: targetAddAmount,
          type: 'debit',
          transactionId: newTransaction.id,
          description: `Penerimaan Transfer Jual ${invoiceNumber} (${item.productName} ke No: ${customerPhone})`,
          date: new Date().toISOString()
        };
        const tgtHistRes = await fetch('/api/ewallet-histories', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newTargetHistory),
        });
        if (!tgtHistRes.ok) throw new Error('Gagal menyimpan riwayat saldo e-wallet penerima.');
        const savedTgtHist = await tgtHistRes.json();

        setHistories(prev => [savedTgtHist, savedSrcHist, ...prev]);
      } else if (dbWallet.id !== 'cash') {
        const nextBalance = Number(dbWallet.balance || 0) + (Number(addAmount || 0) - Number(deductionAmount || 0));
        const walRes = await fetch(`/api/ewallets/${dbWallet.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...dbWallet, balance: nextBalance }),
        });
        if (!walRes.ok) {
          const errData = await walRes.json().catch(() => ({}));
          throw new Error(errData.error || 'Gagal memperbarui saldo e-wallet di database.');
        }
        const updatedWal = await walRes.json();

        setEWallets(prev => prev.map(w => w.id === updatedWal.id ? updatedWal : w));

        // Create wallet history
        const histRes = await fetch('/api/ewallet-histories', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newHistory),
        });
        if (!histRes.ok) {
          const errData = await histRes.json().catch(() => ({}));
          throw new Error(errData.error || 'Gagal menyimpan riwayat saldo e-wallet.');
        }
        const savedHist = await histRes.json();

        setHistories(prev => [savedHist, ...prev]);
      }

      // 6.4 Update active shift in database
      const shiftRes = await fetch(`/api/shifts/${currentShift.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedShift),
      });
      if (!shiftRes.ok) {
        const errData = await shiftRes.json().catch(() => ({}));
        throw new Error(errData.error || 'Gagal memperbarui data shift kasir.');
      }
      const savedShift = await shiftRes.json();

      setShifts(prev => prev.map(s => s.id === savedShift.id ? savedShift : s));
      setCurrentShift(savedShift);
      
      // Refresh transactions directly from PostgreSQL to guarantee perfect real-time data representation and trigger a clean re-render
      const refreshRes = await fetch('/api/transactions');
      if (refreshRes.ok) {
        const refreshedTransactions = await refreshRes.json();
        setTransactions(refreshedTransactions);
      }

      return { 
        success: true, 
        message: 'Transaksi Berhasil!', 
        transaction: savedTx 
      };
    } catch (err: any) {
      console.error('Failed to commit transaction to PostgreSQL:', err);
      return { success: false, message: err.message || 'Gagal sinkronisasi data transaksi ke database.' };
    }
  };

  const handleProcessBatchTransactions = async (
    txs: Array<{ customerPhone: string; item: any; eWalletId: string }>
  ) => {
    if (!currentUser) return { success: false, message: 'Harap masuk terlebih dahulu.' };
    if (!currentShift) {
      return { 
        success: false, 
        message: 'Sif kasir belum dimulai. Harap hubungi Admin atau buka sif kasir terlebih dahulu.' 
      };
    }

    try {
      const res = await fetch('/api/transactions/batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          txs, 
          shiftId: currentShift.id,
          cashierId: currentUser.id,
          cashierName: currentUser.name
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Gagal memproses batch transaksi.');
      }

      // Refresh products (since stock changed)
      const prodRes = await fetch('/api/products');
      if (prodRes.ok) {
        const refreshedProducts = await prodRes.json();
        setProducts(refreshedProducts);
      }

      // Refresh e-wallets (since balances changed)
      const walRes = await fetch('/api/ewallets');
      if (walRes.ok) {
        const refreshedWallets = await walRes.json();
        setEWallets(refreshedWallets);
      }

      // Refresh shift statistics
      const savedShift = data.shift;
      setShifts(prev => prev.map(s => s.id === savedShift.id ? savedShift : s));
      setCurrentShift(savedShift);

      // Refresh transactions
      const refreshRes = await fetch('/api/transactions');
      if (refreshRes.ok) {
        const refreshedTransactions = await refreshRes.json();
        setTransactions(refreshedTransactions);
      }

      // Refresh wallet history mutations
      const histRes = await fetch('/api/ewallet-histories');
      if (histRes.ok) {
        const refreshedHistories = await histRes.json();
        setHistories(refreshedHistories);
      }

      return {
        success: true,
        message: 'Batch Transaksi Berhasil!',
        transactions: data.transactions
      };
    } catch (err: any) {
      console.error('Failed to process batch transactions:', err);
      return { success: false, message: err.message || 'Gagal memproses batch transaksi.' };
    }
  };

  // ==========================================
  // INVENTORY / PRODUCT LOGIC
  // ==========================================
  const handleAddProduct = async (newProduct: Omit<Product, 'id'>) => {
    try {
      const saved = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newProduct),
      }).then(res => res.json());

      saveProductsState([...products, saved]);
    } catch (err) {
      console.error('Failed to add product to DB:', err);
    }
  };

  const handleEditProduct = async (id: string, updated: Partial<Product>) => {
    const target = products.find(p => p.id === id);
    if (!target) return;
    try {
      const saved = await fetch(`/api/products/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...target, ...updated }),
      }).then(res => res.json());

      const updatedList = products.map(p => p.id === id ? saved : p);
      saveProductsState(updatedList);
    } catch (err) {
      console.error('Failed to edit product in DB:', err);
    }
  };

  const handleRefreshProducts = async () => {
    try {
      const res = await fetch('/api/products');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          setProducts(data);
        }
      }
    } catch (err) {
      console.error('Failed to refresh products list:', err);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    try {
      await fetch(`/api/products/${id}`, { method: 'DELETE' });
      const remaining = products.filter(p => p.id !== id);
      saveProductsState(remaining);
    } catch (err) {
      console.error('Failed to delete product from DB:', err);
    }
  };

  // ==========================================
  // E-WALLET / MODAL DEPOSIT LOGIC
  // ==========================================
  const handleAddEWallet = async (newWallet: Omit<EWallet, 'id'>) => {
    const freshId = `ew-${Date.now()}`;
    const fresh: EWallet = {
      ...newWallet,
      id: freshId
    };

    try {
      const saved = await fetch('/api/ewallets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(fresh),
      }).then(res => res.json());

      let updatedHistories = [...histories];
      if (fresh.balance > 0) {
        const initDeposit: EWalletHistory = {
          id: `ewh-init-${Date.now()}`,
          eWalletId: freshId,
          eWalletName: fresh.name,
          amount: fresh.balance,
          type: 'debit',
          description: `Deposit saldo pembuka saat pendaftaran ${fresh.name}`,
          date: new Date().toISOString()
        };

        const savedHist = await fetch('/api/ewallet-histories', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(initDeposit),
        }).then(res => res.json());

        updatedHistories = [savedHist, ...updatedHistories];
      }

      saveEWalletsState([...eWallets, saved]);
      saveHistoriesState(updatedHistories);
    } catch (err) {
      console.error('Failed to create E-wallet in DB:', err);
    }
  };

  const handleEditEWallet = async (id: string, updated: Partial<EWallet>) => {
    const target = eWallets.find(w => w.id === id);
    if (!target) return;
    try {
      const saved = await fetch(`/api/ewallets/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...target, ...updated }),
      }).then(res => res.json());

      const updatedList = eWallets.map(w => w.id === id ? saved : w);
      saveEWalletsState(updatedList);
    } catch (err) {
      console.error('Failed to update E-wallet in DB:', err);
    }
  };

  const handleDeleteEWallet = async (id: string) => {
    try {
      const res = await fetch(`/api/ewallets/${id}`, { method: 'DELETE' });
      if (!res.ok) {
        throw new Error('Gagal menghapus E-Wallet dari server');
      }
      const remaining = eWallets.filter(w => w.id !== id);
      const associatedHistories = histories.filter(h => h.eWalletId !== id);
      saveEWalletsState(remaining);
      saveHistoriesState(associatedHistories);
    } catch (err) {
      console.error('Failed to delete E-wallet from DB:', err);
      alert('Gagal menghapus E-Wallet dari server. Silakan coba lagi.');
    }
  };

  const handleDepositEWallet = async (id: string, amount: number, description: string) => {
    const wallet = eWallets.find(w => w.id === id);
    if (!wallet) return;

    try {
      const nextBalance = Number(wallet.balance || 0) + Number(amount || 0);
      const updatedWal = await fetch(`/api/ewallets/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...wallet, balance: nextBalance }),
      }).then(res => res.json());

      const depositLog: EWalletHistory = {
        id: `ewh-dep-${Date.now()}`,
        eWalletId: id,
        eWalletName: wallet.name,
        amount,
        type: 'debit',
        description: description || 'Top Up / Refill Saldo Server',
        date: new Date().toISOString()
      };

      const savedHist = await fetch('/api/ewallet-histories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(depositLog),
      }).then(res => res.json());

      const updatedList = eWallets.map(w => w.id === id ? updatedWal : w);
      saveEWalletsState(updatedList);
      saveHistoriesState([savedHist, ...histories]);
    } catch (err) {
      console.error('Failed to process deposit to E-wallet in DB:', err);
    }
  };

  // ==========================================
  // OPERATOR / USER ACCOUNT LOGIC
  // ==========================================
  const handleAddUser = async (newUser: Omit<User, 'id'> & { password?: string }) => {
    try {
      const saved = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newUser),
      }).then(res => res.json());

      saveUsersState([...users, saved]);
    } catch (err) {
      console.error('Failed to add user to DB:', err);
    }
  };

  const handleEditUser = async (id: string, updated: Partial<User> & { password?: string }) => {
    const target = users.find(u => u.id === id);
    if (!target) return;
    try {
      const saved = await fetch(`/api/users/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...target, ...updated }),
      }).then(res => res.json());

      const updatedList = users.map(u => u.id === id ? saved : u);
      saveUsersState(updatedList);
      
      if (currentUser && currentUser.id === id) {
        setCurrentUser(saved);
        localStorage.setItem('konter_session', JSON.stringify(saved));
      }
    } catch (err) {
      console.error('Failed to update user in DB:', err);
    }
  };

  const handleDeleteUser = async (id: string) => {
    try {
      await fetch(`/api/users/${id}`, { method: 'DELETE' });
      const remaining = users.filter(u => u.id !== id);
      saveUsersState(remaining);
    } catch (err) {
      console.error('Failed to delete user from DB:', err);
    }
  };

  const handleSavePhysicalCategories = async (updated: PhysicalCategory[]) => {
    try {
      const oldIds = physicalCategories.map(c => c.id);
      const newIds = updated.map(c => c.id);
      const deletedIds = oldIds.filter(id => !newIds.includes(id));

      for (const id of deletedIds) {
        await fetch(`/api/physical-categories/${id}`, { method: 'DELETE' });
      }

      for (const cat of updated) {
        const isNew = !oldIds.includes(cat.id);
        if (isNew) {
          await fetch('/api/physical-categories', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(cat),
          });
        } else {
          const oldCat = physicalCategories.find(c => c.id === cat.id);
          if (oldCat && (oldCat.name !== cat.name || oldCat.sort_order !== cat.sort_order || oldCat.is_active !== cat.is_active)) {
            await fetch(`/api/physical-categories/${cat.id}`, {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(cat),
            });
          }
        }
      }

      setPhysicalCategories(updated);
    } catch (err) {
      console.error('Failed to sync categories to DB:', err);
    }
  };



  // Render Login view if user is unauthenticated
  if (!currentUser) {
    return <LoginView users={users} onLogin={handleLogin} theme={theme} toggleTheme={toggleTheme} appConfig={appConfig} />;
  }

  // Render view depending on Active Tab
  const renderTabContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <DashboardView
            currentUser={currentUser}
            transactions={transactions}
            eWallets={eWallets}
            currentShift={currentShift}
            shifts={shifts}
            onStartShift={handleStartShift}
            onCloseShift={handleCloseShift}
            appConfig={appConfig}
            setActiveTab={setActiveTab}
          />
        );
      case 'pos':
        return (
          <POSView
            products={products}
            eWallets={eWallets}
            currentUser={currentUser}
            appConfig={appConfig}
            transactions={transactions}
            onProcessTransaction={handleProcessTransaction}
            onProcessBatchTransactions={handleProcessBatchTransactions}
            currentShift={currentShift}
            shifts={shifts}
            onStartShift={handleStartShift}
            onCloseShift={handleCloseShift}
            initialMode="topup"
            physicalCategories={physicalCategories}
            posScannerTrigger={posScannerTrigger}
          />
        );
      case 'withdrawal':
        return (
          <POSView
            products={products}
            eWallets={eWallets}
            currentUser={currentUser}
            appConfig={appConfig}
            transactions={transactions}
            onProcessTransaction={handleProcessTransaction}
            onProcessBatchTransactions={handleProcessBatchTransactions}
            currentShift={currentShift}
            shifts={shifts}
            onStartShift={handleStartShift}
            onCloseShift={handleCloseShift}
            initialMode="withdrawal"
            physicalCategories={physicalCategories}
          />
        );
      case 'physical_pos':
        return (
          <POSView
            products={products}
            eWallets={eWallets}
            currentUser={currentUser}
            appConfig={appConfig}
            transactions={transactions}
            onProcessTransaction={handleProcessTransaction}
            onProcessBatchTransactions={handleProcessBatchTransactions}
            currentShift={currentShift}
            shifts={shifts}
            onStartShift={handleStartShift}
            onCloseShift={handleCloseShift}
            initialMode="physical"
            physicalCategories={physicalCategories}
            physicalScannerTrigger={physicalScannerTrigger}
          />
        );
      case 'edc_transfer':
        return (
          <POSView
            products={products}
            eWallets={eWallets}
            currentUser={currentUser}
            appConfig={appConfig}
            transactions={transactions}
            onProcessTransaction={handleProcessTransaction}
            onProcessBatchTransactions={handleProcessBatchTransactions}
            currentShift={currentShift}
            shifts={shifts}
            onStartShift={handleStartShift}
            onCloseShift={handleCloseShift}
            initialMode="edc_transfer"
            physicalCategories={physicalCategories}
          />
        );
      case 'products':
        if (currentUser.role !== 'admin') {
          return (
            <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-[16px] border border-slate-100 dark:border-slate-800 m-6 flex flex-col items-center justify-center">
              <ShieldAlert className="w-12 h-12 text-red-500 mb-2" />
              <h2 className="font-bold text-slate-800 dark:text-slate-100 text-lg">Akses Ditolak</h2>
              <p className="text-slate-500 dark:text-slate-400 text-sm mt-1 max-w-sm">
                Menu Stok Produk bersifat sensitif dan hanya dapat diakses oleh Administrator Pemilik.
              </p>
            </div>
          );
        }
        return (
          <ProductManagement
            products={products}
            currentUserRole={currentUser.role}
            onAddProduct={handleAddProduct}
            onEditProduct={handleEditProduct}
            onDeleteProduct={handleDeleteProduct}
            physicalCategories={physicalCategories}
            onSavePhysicalCategories={handleSavePhysicalCategories}
            onRefreshProducts={handleRefreshProducts}
            onViewVouchers={(productId) => {
              setVouchersProductFilter(productId);
              setActiveTab('vouchers');
            }}
          />
        );
      case 'vouchers':
        if (currentUser.role !== 'admin') {
          return (
            <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-[16px] border border-slate-100 dark:border-slate-800 m-6 flex flex-col items-center justify-center">
              <ShieldAlert className="w-12 h-12 text-red-500 mb-2" />
              <h2 className="font-bold text-slate-800 dark:text-slate-100 text-lg">Akses Ditolak</h2>
              <p className="text-slate-500 dark:text-slate-400 text-sm mt-1 max-w-sm">
                Menu Barcode Center bersifat sensitif dan hanya dapat diakses oleh Administrator Pemilik.
              </p>
            </div>
          );
        }
        return (
          <BarcodeCenter
            products={products}
            currentUserRole={currentUser.role}
            onEditProduct={handleEditProduct}
            onRefreshProducts={handleRefreshProducts}
            initialProductIdFilter={vouchersProductFilter}
            onClearProductIdFilter={() => setVouchersProductFilter(null)}
            currentShift={currentShift}
          />
        );
      case 'ewallets':
        if (currentUser.role !== 'admin') {
          return (
            <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-[16px] border border-slate-100 dark:border-slate-800 m-6 flex flex-col items-center justify-center">
              <ShieldAlert className="w-12 h-12 text-red-500 mb-2" />
              <h2 className="font-bold text-slate-800 dark:text-slate-100 text-lg">Akses Ditolak</h2>
              <p className="text-slate-500 dark:text-slate-400 text-sm mt-1 max-w-sm">
                Manajemen E-Wallet hanya dapat diakses oleh Administrator Pemilik.
              </p>
            </div>
          );
        }
        return (
          <EWalletManagement
            eWallets={eWallets}
            histories={histories}
            currentUserRole={currentUser.role}
            onAddEWallet={handleAddEWallet}
            onEditEWallet={handleEditEWallet}
            onDeleteEWallet={handleDeleteEWallet}
            onDepositEWallet={handleDepositEWallet}
          />
        );
      case 'reports':
        return (
          <ReportsView
            transactions={transactions}
            eWallets={eWallets}
            products={products}
            physicalCategories={physicalCategories}
            currentUser={currentUser}
          />
        );
      case 'accounting':
        // Protected Admin route
        if (currentUser.role !== 'admin') {
          return (
            <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-[16px] border border-slate-100 dark:border-slate-800 m-6 flex flex-col items-center justify-center">
              <ShieldAlert className="w-12 h-12 text-red-500 mb-2" />
              <h2 className="font-bold text-slate-800 dark:text-slate-100 text-lg">Akses Ditolak</h2>
              <p className="text-slate-500 dark:text-slate-400 text-sm mt-1 max-w-sm">
                Fitur Pembukuan (Accounting) bersifat rahasia dan hanya dapat diakses oleh Administrator Pemilik.
              </p>
            </div>
          );
        }
        return (
          <AccountingView
            transactions={transactions}
            eWallets={eWallets}
            histories={histories}
            products={products}
            shifts={shifts}
          />
        );
      case 'users':
        // Protected Admin route
        if (currentUser.role !== 'admin') {
          return (
            <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-[16px] border border-slate-100 dark:border-slate-800 m-6 flex flex-col items-center justify-center">
              <ShieldAlert className="w-12 h-12 text-red-500 mb-2" />
              <h2 className="font-bold text-slate-800 dark:text-slate-100 text-lg">Akses Ditolak</h2>
              <p className="text-slate-500 dark:text-slate-400 text-sm mt-1 max-w-sm">
                Pendaftaran dan pengelolaan akun operator kasir hanya dapat diakses oleh Administrator Pemilik.
              </p>
            </div>
          );
        }
        return (
          <UserManagement
            users={users}
            currentUser={currentUser}
            onAddUser={handleAddUser}
            onEditUser={handleEditUser}
            onDeleteUser={handleDeleteUser}
          />
        );
      case 'settings':
        // Protected Admin route
        if (currentUser.role !== 'admin') {
          return (
            <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-[16px] border border-slate-100 dark:border-slate-800 m-6 flex flex-col items-center justify-center">
              <ShieldAlert className="w-12 h-12 text-red-500 mb-2" />
              <h2 className="font-bold text-slate-800 dark:text-slate-100 text-lg">Akses Ditolak</h2>
              <p className="text-slate-500 dark:text-slate-400 text-sm mt-1 max-w-sm">
                Pengaturan sistem hanya dapat diakses oleh Administrator Pemilik.
              </p>
            </div>
          );
        }
        return (
          <SettingsView
            appConfig={appConfig}
            currentUser={currentUser}
            transactions={transactions}
            eWallets={eWallets}
            histories={histories}
            products={products}
            shifts={shifts}
            onSaveSettings={async (config) => {
              setAppConfig(config);
              localStorage.setItem('konter_settings', JSON.stringify(config));
              try {
                await fetch('/api/settings', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify(config),
                });
              } catch (err) {
                console.error('Failed to save settings to server:', err);
              }
            }}
          />
        );
      case 'about':
        return <AboutView appConfig={appConfig} />;
      case 'logs':
        if (currentUser.role !== 'admin') {
          return (
            <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-[16px] border border-slate-100 dark:border-slate-800 m-6 flex flex-col items-center justify-center">
              <ShieldAlert className="w-12 h-12 text-red-500 mb-2" />
              <h2 className="font-bold text-slate-800 dark:text-slate-100 text-lg">Akses Ditolak</h2>
              <p className="text-slate-500 dark:text-slate-400 text-sm mt-1 max-w-sm">
                Log sistem hanya dapat diakses oleh Administrator Pemilik.
              </p>
            </div>
          );
        }
        return <LogViewer />;
      default:
        return <div className="p-6">Tab {activeTab} Belum Tersedia.</div>;
    }
  };

  return (
    <div className={`flex flex-col lg:flex-row lg:h-screen lg:overflow-hidden font-sans transition-colors duration-200 relative w-full max-w-full overflow-x-hidden ${isGlobalScannerOpen ? 'h-screen overflow-hidden' : ''} ${theme === 'dark' ? 'dark bg-slate-900 text-slate-100' : 'bg-slate-50 text-slate-800'}`}>
      {/* iOS-Style Ambient Gradient Glow Blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-15%] left-[-15%] w-[60%] h-[60%] rounded-full bg-blue-400/20 dark:bg-blue-500/15 blur-[150px]" />
        <div className="absolute bottom-[5%] right-[-15%] w-[55%] h-[55%] rounded-full bg-emerald-400/20 dark:bg-emerald-500/15 blur-[150px]" />
        <div className="absolute top-[35%] left-[25%] w-[50%] h-[50%] rounded-full bg-indigo-400/20 dark:bg-indigo-500/15 blur-[150px]" />
        <div className="absolute top-[10%] right-[10%] w-[40%] h-[40%] rounded-full bg-pink-400/15 dark:bg-pink-500/10 blur-[150px]" />
      </div>

      {/* Side sidebar Navigation (Desktop) & Top nav (Mobile) */}
      <Navigation
        currentUser={currentUser}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onLogout={handleLogout}
        products={products}
        eWallets={eWallets}
        currentShift={currentShift}
        appConfig={appConfig}
        theme={theme}
        toggleTheme={toggleTheme}
        users={users}
        onEditUser={handleEditUser}
        onScanClick={handleScanClick}
      />

      {/* Primary tab workspace contents */}
      <main className={`flex-1 flex flex-col min-w-0 w-full max-w-full overflow-x-hidden ${
        isGlobalScannerOpen 
          ? 'h-screen w-screen overflow-hidden p-0 m-0 z-50' 
          : 'lg:h-screen lg:overflow-y-auto pb-28 lg:pb-0'
      }`}>
        {(appConfig.slogan?.includes('MODE PREVIEW') || appConfig.slogan?.includes('MODE DEMO')) && (
          <div className="bg-amber-500/10 border-b border-amber-500/15 px-6 py-2.5 text-amber-600 dark:text-amber-400 text-xs font-medium flex items-center justify-between gap-4 select-none">
            <div className="flex items-center gap-2">
              <span className="flex h-2 w-2 rounded-full bg-amber-500 animate-pulse" />
              <span>
                <strong>Mode Preview Aktif (Tanpa Data Fiktif):</strong> Aplikasi berjalan menggunakan database in-memory sementara dengan keadaan kosong (empty state) untuk kenyamanan pengembangan dan pengujian UI. Nilai dimulai dari 0 dan menampilkan "Belum ada data". Transaksi baru yang ditambahkan hanya akan disimpan di memori dan tidak akan mengubah database asli.
              </span>
            </div>
            <span className="text-[10px] shrink-0 font-bold uppercase bg-amber-500/10 dark:bg-amber-500/20 px-2 py-0.5 rounded tracking-wide border border-amber-500/10">PREVIEW MODE</span>
          </div>
        )}
        <div key={activeTab} className={`flex-1 animate-fade-in w-full ${isGlobalScannerOpen ? 'h-full' : 'max-w-7xl mx-auto'}`}>
          {renderTabContent()}
        </div>

        {/* Footer Aplikasi */}
        {!isGlobalScannerOpen && (
          <footer className="py-6 px-4 border-t border-slate-150 dark:border-slate-800 text-center text-xs font-semibold text-slate-400 dark:text-slate-500 mt-auto flex flex-col sm:flex-row items-center justify-between gap-2 max-w-7xl mx-auto w-full transition-colors duration-200">
            <div>
              &copy; {new Date().getFullYear()} <span className="font-bold text-slate-700 dark:text-slate-300">MD POS</span>. Hak Cipta Dilindungi.
            </div>
            <div className="flex items-center space-x-1.5">
              <span>Website Resmi:</span>
              <a 
                href="https://mdcell.my.id" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-indigo-500 dark:text-indigo-400 hover:underline font-bold"
              >
                https://mdcell.my.id
              </a>
            </div>
          </footer>
        )}
      </main>
    </div>
  );
}
