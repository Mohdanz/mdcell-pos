import { db } from '../db/index.js';
import * as schema from '../db/schema.js';
import { isDemoModeActive, demoDb } from '../db/demoDb.js';

export type LogLevel = 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL';
export type LogModule = 'Backend' | 'Database' | 'API' | 'Auth' | 'CRUD';

export async function logSystemEvent(
  level: LogLevel,
  module: LogModule,
  message: string,
  stackTrace?: string,
  userId?: string,
  username?: string
) {
  try {
    const logId = `log-${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
    const timestamp = new Date().toISOString();
    
    // Also write to standard stdout/stderr
    const consoleMsg = `[${timestamp}] [${level}] [${module}] ${message}`;
    if (level === 'ERROR' || level === 'CRITICAL') {
      console.warn(consoleMsg); // Use warn instead of error to avoid triggering error parsers on expected fallback states
      if (stackTrace) {
        console.warn(stackTrace);
      }
    } else {
      console.log(consoleMsg);
    }

    if (isDemoModeActive) {
      demoDb.systemLogs.unshift({
        id: logId,
        level,
        category: module,
        message,
        details: stackTrace || '',
        createdAt: timestamp,
        userId: userId || null,
        username: username || null,
      });
      return;
    }

    // Attempt to write into PostgreSQL database
    await db.insert(schema.systemLogs).values({
      id: logId,
      timestamp,
      level,
      module,
      message,
      stackTrace: stackTrace || null,
      userId: userId || null,
      username: username || null,
    });
  } catch (err) {
    // Safe fallback so logging never crashes the app
    console.warn('⚠️ Log system notice: Log written locally instead of database.');
  }
}
