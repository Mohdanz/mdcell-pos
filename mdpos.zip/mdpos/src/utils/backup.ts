import { db } from '../db/index.js';
import * as schema from '../db/schema.js';
import { eq, ne } from 'drizzle-orm';
import fs from 'fs';
import path from 'path';
import { logSystemEvent } from './logger.js';

const BACKUP_DIR = path.join(process.cwd(), 'backups');

// Ensure backup directory exists
if (!fs.existsSync(BACKUP_DIR)) {
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
}

export interface BackupItem {
  id: string;
  filename: string;
  size: number;
  status: 'success' | 'failed';
  type: 'manual' | 'auto';
  error: string | null;
  createdAt: string;
}

/**
 * Creates a backup of the entire database as a structured JSON file.
 */
export async function createDatabaseBackup(type: 'manual' | 'auto' = 'manual'): Promise<BackupItem> {
  const backupId = `backup-${Date.now()}`;
  const filename = `backup_${type}_${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
  const filePath = path.join(BACKUP_DIR, filename);
  const createdAt = new Date().toISOString();

  console.log(`[Backup] Initiating ${type} backup: ${filename}`);
  await logSystemEvent('INFO', 'Database', `Memulai pencadangan database (${type}): ${filename}`);

  try {
    // 1. Fetch data from all tables
    const usersData = await db.select().from(schema.users);
    const accountsData = await db.select().from(schema.accounts);
    const physicalCategoriesData = await db.select().from(schema.physicalCategories);
    const productsData = await db.select().from(schema.products);
    const eWalletsData = await db.select().from(schema.eWallets);
    const transactionsData = await db.select().from(schema.transactions);
    const eWalletHistoriesData = await db.select().from(schema.eWalletHistories);
    const shiftsData = await db.select().from(schema.shifts);
    const journalEntriesData = await db.select().from(schema.journalEntries);
    const journalLinesData = await db.select().from(schema.journalLines);
    const budgetsData = await db.select().from(schema.budgets);
    const voucherSerialsData = await db.select().from(schema.voucherSerials);
    const systemLogsData = await db.select().from(schema.systemLogs);

    // 2. Compile into a single JSON object
    const backupData = {
      version: '1.0',
      timestamp: createdAt,
      type,
      tables: {
        users: usersData,
        accounts: accountsData,
        physicalCategories: physicalCategoriesData,
        products: productsData,
        eWallets: eWalletsData,
        transactions: transactionsData,
        eWalletHistories: eWalletHistoriesData,
        shifts: shiftsData,
        journalEntries: journalEntriesData,
        journalLines: journalLinesData,
        budgets: budgetsData,
        voucherSerials: voucherSerialsData,
        systemLogs: systemLogsData,
      }
    };

    // 3. Write to file
    const fileContent = JSON.stringify(backupData, null, 2);
    fs.writeFileSync(filePath, fileContent, 'utf8');

    const stats = fs.statSync(filePath);
    const size = stats.size;

    const backupRecord: BackupItem = {
      id: backupId,
      filename,
      size,
      status: 'success',
      type,
      error: null,
      createdAt,
    };

    // 4. Save to database
    await db.insert(schema.backups).values({
      id: backupId,
      filename,
      size,
      status: 'success',
      type,
      error: null,
      createdAt,
    });

    await logSystemEvent('INFO', 'Database', `Pencadangan database berhasil: ${filename} (${(size / 1024).toFixed(2)} KB)`);
    return backupRecord;

  } catch (error: any) {
    const errorMsg = error.message || String(error);
    const stackTrace = error.stack || '';
    
    console.error(`[Backup] Failed to create database backup:`, error);
    await logSystemEvent('ERROR', 'Database', `Pencadangan database gagal: ${errorMsg}`, stackTrace);

    const failedRecord: BackupItem = {
      id: backupId,
      filename,
      size: 0,
      status: 'failed',
      type,
      error: errorMsg,
      createdAt,
    };

    // Attempt to save the failure record to DB if possible
    try {
      await db.insert(schema.backups).values({
        id: backupId,
        filename,
        size: 0,
        status: 'failed',
        type,
        error: errorMsg,
        createdAt,
      });
    } catch (dbErr) {
      console.error('Failed to save failed backup record to DB:', dbErr);
    }

    throw error;
  }
}

/**
 * Restores the entire database from a backup JSON file.
 * Wipes tables in reverse topological order, then restores data.
 */
export async function restoreDatabaseFromBackup(filename: string): Promise<boolean> {
  const filePath = path.join(BACKUP_DIR, filename);
  if (!fs.existsSync(filePath)) {
    throw new Error(`Berkas cadangan tidak ditemukan: ${filename}`);
  }

  await logSystemEvent('WARNING', 'Database', `Memulai pemulihan database dari berkas: ${filename}`);
  console.log(`[Backup] Starting restore from: ${filename}`);

  try {
    const fileContent = fs.readFileSync(filePath, 'utf8');
    const backupData = JSON.parse(fileContent);

    if (backupData.version !== '1.0' || !backupData.tables) {
      throw new Error('Format berkas cadangan tidak valid atau versi tidak didukung.');
    }

    const { tables } = backupData;

    // Use a transaction or sequential clears/inserts
    await db.transaction(async (tx) => {
      console.log('[Restore] Purging existing tables in reverse dependency order...');

      // 1. Clear child tables first
      await tx.delete(schema.voucherSerials);
      await tx.delete(schema.eWalletHistories);
      await tx.delete(schema.transactions);
      await tx.delete(schema.shifts);
      await tx.delete(schema.journalLines);
      await tx.delete(schema.journalEntries);
      await tx.delete(schema.budgets);

      // 2. Clear parent tables
      await tx.delete(schema.products);
      await tx.delete(schema.physicalCategories);
      await tx.delete(schema.eWallets);
      await tx.delete(schema.users);
      await tx.delete(schema.accounts);
      await tx.delete(schema.systemLogs);

      console.log('[Restore] Importing tables in correct order...');

      // 3. Restore accounts
      if (tables.accounts && tables.accounts.length > 0) {
        for (const record of tables.accounts) {
          await tx.insert(schema.accounts).values(record);
        }
      }

      // 4. Restore users
      if (tables.users && tables.users.length > 0) {
        for (const record of tables.users) {
          await tx.insert(schema.users).values(record);
        }
      }

      // 5. Restore eWallets
      if (tables.eWallets && tables.eWallets.length > 0) {
        for (const record of tables.eWallets) {
          await tx.insert(schema.eWallets).values(record);
        }
      }

      // 6. Restore physicalCategories
      if (tables.physicalCategories && tables.physicalCategories.length > 0) {
        for (const record of tables.physicalCategories) {
          await tx.insert(schema.physicalCategories).values(record);
        }
      }

      // 7. Restore products
      if (tables.products && tables.products.length > 0) {
        for (const record of tables.products) {
          await tx.insert(schema.products).values(record);
        }
      }

      // 8. Restore budgets
      if (tables.budgets && tables.budgets.length > 0) {
        for (const record of tables.budgets) {
          await tx.insert(schema.budgets).values(record);
        }
      }

      // 9. Restore journalEntries
      if (tables.journalEntries && tables.journalEntries.length > 0) {
        for (const record of tables.journalEntries) {
          await tx.insert(schema.journalEntries).values(record);
        }
      }

      // 10. Restore journalLines
      if (tables.journalLines && tables.journalLines.length > 0) {
        for (const record of tables.journalLines) {
          await tx.insert(schema.journalLines).values(record);
        }
      }

      // 11. Restore shifts
      if (tables.shifts && tables.shifts.length > 0) {
        for (const record of tables.shifts) {
          await tx.insert(schema.shifts).values(record);
        }
      }

      // 12. Restore transactions
      if (tables.transactions && tables.transactions.length > 0) {
        for (const record of tables.transactions) {
          await tx.insert(schema.transactions).values(record);
        }
      }

      // 13. Restore eWalletHistories
      if (tables.eWalletHistories && tables.eWalletHistories.length > 0) {
        for (const record of tables.eWalletHistories) {
          await tx.insert(schema.eWalletHistories).values(record);
        }
      }

      // 14. Restore voucherSerials
      if (tables.voucherSerials && tables.voucherSerials.length > 0) {
        for (const record of tables.voucherSerials) {
          await tx.insert(schema.voucherSerials).values(record);
        }
      }

      // 15. Restore systemLogs
      if (tables.systemLogs && tables.systemLogs.length > 0) {
        for (const record of tables.systemLogs) {
          await tx.insert(schema.systemLogs).values(record);
        }
      }
    });

    console.log('[Restore] Database restore completed successfully!');
    await logSystemEvent('INFO', 'Database', `Pemulihan database dari berkas ${filename} berhasil diselesaikan.`);
    return true;

  } catch (error: any) {
    const errorMsg = error.message || String(error);
    const stackTrace = error.stack || '';
    
    console.error(`[Restore] Failed to restore database from backup:`, error);
    await logSystemEvent('CRITICAL', 'Database', `Pemulihan database gagal: ${errorMsg}`, stackTrace);
    throw error;
  }
}

/**
 * Lists all backups available in the database history and on disk.
 */
export async function getBackupsHistory() {
  try {
    return await db.select().from(schema.backups).orderBy(schema.backups.createdAt);
  } catch (err) {
    console.error('Failed to fetch backup list from DB:', err);
    // Return empty list on failure
    return [];
  }
}

/**
 * Initializes automatic scheduled backups.
 * By default, backs up once every 24 hours.
 */
export function startAutoBackupScheduler(intervalHours = 24) {
  const intervalMs = intervalHours * 60 * 60 * 1000;
  console.log(`[Backup] Starting auto-backup scheduler. Interval: ${intervalHours} jam.`);
  
  setInterval(async () => {
    try {
      await createDatabaseBackup('auto');
    } catch (err) {
      console.error('[Backup Scheduler] Auto backup failed:', err);
    }
  }, intervalMs);
}
