/**
 * Helper to get the date string in YYYY-MM-DD format in Asia/Jakarta (WIB) timezone
 */
export const getJakartaDateString = (dateInput?: Date | string | null): string => {
  const d = dateInput ? new Date(dateInput) : new Date();
  if (isNaN(d.getTime())) return new Date().toISOString().substring(0, 10);
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Jakarta',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  });
  return formatter.format(d);
};

/**
 * Helper to format time only (HH:mm:ss WIB)
 */
export const formatWIBTimeOnly = (isoString: string): string => {
  if (!isoString) return '-';
  try {
    const d = new Date(isoString);
    if (isNaN(d.getTime())) return isoString;
    return d.toLocaleTimeString('id-ID', {
      timeZone: 'Asia/Jakarta',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    }) + ' WIB';
  } catch (e) {
    return isoString;
  }
};

